var e = Object.create,
  t = Object.defineProperty,
  n = Object.getOwnPropertyDescriptor,
  r = Object.getOwnPropertyNames,
  i = Object.getPrototypeOf,
  a = Object.prototype.hasOwnProperty,
  o = (e, t) => () => (e && (t = e((e = 0))), t),
  s = (e, t) => () => (
    t || (e((t = { exports: {} }).exports, t), (e = null)), t.exports
  ),
  c = (e, n) => {
    let r = {};
    for (var i in e) t(r, i, { get: e[i], enumerable: !0 });
    return n || t(r, Symbol.toStringTag, { value: `Module` }), r;
  },
  l = (e, i, o, s) => {
    if ((i && typeof i == `object`) || typeof i == `function`)
      for (var c = r(i), l = 0, u = c.length, d; l < u; l++)
        (d = c[l]),
          !a.call(e, d) &&
            d !== o &&
            t(e, d, {
              get: ((e) => i[e]).bind(null, d),
              enumerable: !(s = n(i, d)) || s.enumerable,
            });
    return e;
  },
  u = (n, r, a) => (
    (a = n == null ? {} : e(i(n))),
    l(
      r || !n || !n.__esModule
        ? t(a, `default`, { value: n, enumerable: !0 })
        : a,
      n
    )
  ),
  d = (e) =>
    a.call(e, `module.exports`)
      ? e[`module.exports`]
      : l(t({}, `__esModule`, { value: !0 }), e),
  f = Array.isArray,
  p = Array.prototype.indexOf,
  m = Array.prototype.includes,
  h = Array.from,
  g = Object.defineProperty,
  _ = Object.getOwnPropertyDescriptor,
  v = Object.getOwnPropertyDescriptors,
  y = Object.prototype,
  ee = Array.prototype,
  b = Object.getPrototypeOf,
  te = Object.isExtensible;
function ne(e) {
  return typeof e == `function`;
}
var x = () => {};
function re(e) {
  return e();
}
function ie(e) {
  for (var t = 0; t < e.length; t++) e[t]();
}
function ae() {
  var e, t;
  return {
    promise: new Promise((n, r) => {
      (e = n), (t = r);
    }),
    resolve: e,
    reject: t,
  };
}
var oe = 1 << 24,
  se = 1024,
  ce = 2048,
  le = 4096,
  ue = 8192,
  de = 16384,
  fe = 32768,
  pe = 1 << 25,
  me = 65536,
  he = 1 << 19,
  ge = 1 << 20,
  _e = 1 << 25,
  ve = 65536,
  ye = 1 << 21,
  be = 1 << 22,
  xe = 1 << 23,
  Se = Symbol(`$state`),
  Ce = Symbol(`legacy props`),
  we = Symbol(``),
  Te = new (class extends Error {
    name = `StaleReactionError`;
    message =
      "The reaction that called `getAbortSignal()` was re-run or destroyed";
  })(),
  Ee =
    !!globalThis.document?.contentType &&
    globalThis.document.contentType.includes(`xml`);
function De(e) {
  throw Error(`https://svelte.dev/e/lifecycle_outside_component`);
}
function Oe() {
  throw Error(`https://svelte.dev/e/async_derived_orphan`);
}
function ke(e, t, n) {
  throw Error(`https://svelte.dev/e/each_key_duplicate`);
}
function Ae(e) {
  throw Error(`https://svelte.dev/e/effect_in_teardown`);
}
function je() {
  throw Error(`https://svelte.dev/e/effect_in_unowned_derived`);
}
function Me(e) {
  throw Error(`https://svelte.dev/e/effect_orphan`);
}
function Ne() {
  throw Error(`https://svelte.dev/e/effect_update_depth_exceeded`);
}
function Pe(e) {
  throw Error(`https://svelte.dev/e/props_invalid_value`);
}
function Fe() {
  throw Error(`https://svelte.dev/e/set_context_after_init`);
}
function Ie() {
  throw Error(`https://svelte.dev/e/state_descriptors_fixed`);
}
function Le() {
  throw Error(`https://svelte.dev/e/state_prototype_fixed`);
}
function Re() {
  throw Error(`https://svelte.dev/e/state_unsafe_mutation`);
}
function ze() {
  throw Error(`https://svelte.dev/e/svelte_boundary_reset_onerror`);
}
var Be = {},
  S = Symbol(),
  Ve = `http://www.w3.org/1999/xhtml`,
  He = `http://www.w3.org/2000/svg`,
  Ue = `http://www.w3.org/1998/Math/MathML`;
function We() {
  console.warn(`https://svelte.dev/e/derived_inert`);
}
function Ge(e) {
  console.warn(`https://svelte.dev/e/hydration_mismatch`);
}
function Ke() {
  console.warn(`https://svelte.dev/e/select_multiple_invalid_value`);
}
function qe() {
  console.warn(`https://svelte.dev/e/svelte_boundary_reset_noop`);
}
var C = !1;
function Je(e) {
  C = e;
}
var w;
function T(e) {
  if (e === null) throw (Ge(), Be);
  return (w = e);
}
function Ye() {
  return T(Bn(w));
}
function Xe(e) {
  if (C) {
    if (Bn(w) !== null) throw (Ge(), Be);
    w = e;
  }
}
function Ze(e = 1) {
  if (C) {
    for (var t = e, n = w; t--; ) n = Bn(n);
    w = n;
  }
}
function Qe(e = !0) {
  for (var t = 0, n = w; ; ) {
    if (n.nodeType === 8) {
      var r = n.data;
      if (r === `]`) {
        if (t === 0) return n;
        --t;
      } else
        (r === `[` ||
          r === `[!` ||
          (r[0] === `[` && !isNaN(Number(r.slice(1))))) &&
          (t += 1);
    }
    var i = Bn(n);
    e && n.remove(), (n = i);
  }
}
function $e(e) {
  if (!e || e.nodeType !== 8) throw (Ge(), Be);
  return e.data;
}
function et(e) {
  return e === this.v;
}
function tt(e, t) {
  return e == e
    ? e !== t || (typeof e == `object` && !!e) || typeof e == `function`
    : t == t;
}
function nt(e) {
  return !tt(e, this.v);
}
var rt = !1,
  it = !1;
function at() {
  it = !0;
}
var E = null;
function ot(e) {
  E = e;
}
function st(e) {
  return ft(`getContext`).get(e);
}
function ct(e, t) {
  let n = ft(`setContext`);
  if (rt) {
    var r = I.f;
    (!F && r & 32 && !E.i) || Fe();
  }
  return n.set(e, t), t;
}
function lt(e, t = !1, n) {
  E = {
    p: E,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    r: I,
    l: it && !t ? { s: null, u: null, $: [] } : null,
  };
}
function ut(e) {
  var t = E,
    n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n) sr(r);
  }
  return e !== void 0 && (t.x = e), (t.i = !0), (E = t.p), e ?? {};
}
function dt() {
  return !it || (E !== null && E.l === null);
}
function ft(e) {
  return E === null && De(e), (E.c ??= new Map(pt(E) || void 0));
}
function pt(e) {
  let t = e.p;
  for (; t !== null; ) {
    let e = t.c;
    if (e !== null) return e;
    t = t.p;
  }
  return null;
}
var mt = [];
function ht() {
  var e = mt;
  (mt = []), ie(e);
}
function gt(e) {
  if (mt.length === 0 && !zt) {
    var t = mt;
    queueMicrotask(() => {
      t === mt && ht();
    });
  }
  mt.push(e);
}
function _t() {
  for (; mt.length > 0; ) ht();
}
function vt(e) {
  var t = I;
  if (t === null) return (F.f |= xe), e;
  if (!(t.f & 32768) && !(t.f & 4)) throw e;
  yt(e, t);
}
function yt(e, t) {
  for (; t !== null; ) {
    if (t.f & 128) {
      if (!(t.f & 32768)) throw e;
      try {
        t.b.error(e);
        return;
      } catch (t) {
        e = t;
      }
    }
    t = t.parent;
  }
  throw e;
}
var bt = ~(ce | le | se);
function D(e, t) {
  e.f = (e.f & bt) | t;
}
function xt(e) {
  e.f & 512 || e.deps === null ? D(e, se) : D(e, le);
}
function St(e) {
  if (e !== null)
    for (let t of e) !(t.f & 2) || !(t.f & 65536) || ((t.f ^= ve), St(t.deps));
}
function Ct(e, t, n) {
  e.f & 2048 ? t.add(e) : e.f & 4096 && n.add(e), St(e.deps), D(e, se);
}
function wt(e, t, n) {
  if (e == null) return t(void 0), n && n(void 0), x;
  let r = ei(() => e.subscribe(t, n));
  return r.unsubscribe ? () => r.unsubscribe() : r;
}
var Tt = [];
function Et(e, t) {
  return { subscribe: O(e, t).subscribe };
}
function O(e, t = x) {
  let n = null,
    r = new Set();
  function i(t) {
    if (tt(e, t) && ((e = t), n)) {
      let t = !Tt.length;
      for (let t of r) t[1](), Tt.push(t, e);
      if (t) {
        for (let e = 0; e < Tt.length; e += 2) Tt[e][0](Tt[e + 1]);
        Tt.length = 0;
      }
    }
  }
  function a(t) {
    i(t(e));
  }
  function o(o, s = x) {
    let c = [o, s];
    return (
      r.add(c),
      r.size === 1 && (n = t(i, a) || x),
      o(e),
      () => {
        r.delete(c), r.size === 0 && n && (n(), (n = null));
      }
    );
  }
  return { set: i, update: a, subscribe: o };
}
function k(e, t, n) {
  let r = !Array.isArray(e),
    i = r ? [e] : e;
  if (!i.every(Boolean))
    throw Error(`derived() expects stores as input, got a falsy value`);
  let a = t.length < 2;
  return Et(n, (e, n) => {
    let o = !1,
      s = [],
      c = 0,
      l = x,
      u = () => {
        if (c) return;
        l();
        let i = t(r ? s[0] : s, e, n);
        a ? e(i) : (l = typeof i == `function` ? i : x);
      },
      d = i.map((e, t) =>
        wt(
          e,
          (e) => {
            (s[t] = e), (c &= ~(1 << t)), o && u();
          },
          () => {
            c |= 1 << t;
          }
        )
      );
    return (
      (o = !0),
      u(),
      function () {
        ie(d), l(), (o = !1);
      }
    );
  });
}
function A(e) {
  let t;
  return wt(e, (e) => (t = e))(), t;
}
var Dt = !1,
  Ot = !1,
  kt = Symbol();
function At(e, t, n) {
  let r = (n[t] ??= { store: null, source: wn(void 0), unsubscribe: x });
  if (r.store !== e && !(kt in n))
    if ((r.unsubscribe(), (r.store = e ?? null), e == null))
      (r.source.v = void 0), (r.unsubscribe = x);
    else {
      var i = !0;
      (r.unsubscribe = wt(e, (e) => {
        i ? (r.source.v = e) : Tn(r.source, e);
      })),
        (i = !1);
    }
  return e && kt in n ? A(e) : L(r.source);
}
function jt(e, t) {
  return Nt(e, t), t;
}
function Mt() {
  let e = {};
  function t() {
    ar(() => {
      for (var t in e) e[t].unsubscribe();
      g(e, kt, { enumerable: !1, value: !0 });
    });
  }
  return [e, t];
}
function Nt(e, t) {
  Dt = !0;
  try {
    e.set(t);
  } finally {
    Dt = !1;
  }
}
function Pt(e, t, n) {
  return Nt(e, n), t;
}
function Ft(e) {
  var t = Ot;
  try {
    return (Ot = !1), [e(), Ot];
  } finally {
    Ot = t;
  }
}
var It = new Set(),
  j = null,
  Lt = null,
  M = null,
  Rt = null,
  zt = !1,
  Bt = !1,
  Vt = null,
  Ht = null,
  Ut = 0,
  Wt = 1,
  Gt = class e {
    id = Wt++;
    current = new Map();
    previous = new Map();
    #e = new Set();
    #t = new Set();
    #n = new Set();
    #r = new Map();
    #i = new Map();
    #a = null;
    #o = [];
    #s = [];
    #c = new Set();
    #l = new Set();
    #u = new Map();
    #d = new Set();
    is_fork = !1;
    #f = !1;
    #p = new Set();
    #m() {
      return this.is_fork || this.#i.size > 0;
    }
    #h() {
      for (let n of this.#p)
        for (let r of n.#i.keys()) {
          for (var e = !1, t = r; t.parent !== null; ) {
            if (this.#u.has(t)) {
              e = !0;
              break;
            }
            t = t.parent;
          }
          if (!e) return !0;
        }
      return !1;
    }
    skip_effect(e) {
      this.#u.has(e) || this.#u.set(e, { d: [], m: [] }), this.#d.delete(e);
    }
    unskip_effect(e, t = (e) => this.schedule(e)) {
      var n = this.#u.get(e);
      if (n) {
        this.#u.delete(e);
        for (var r of n.d) D(r, ce), t(r);
        for (r of n.m) D(r, le), t(r);
      }
      this.#d.add(e);
    }
    #g() {
      if ((Ut++ > 1e3 && (It.delete(this), qt()), !this.#m())) {
        for (let e of this.#c) this.#l.delete(e), D(e, ce), this.schedule(e);
        for (let e of this.#l) D(e, le), this.schedule(e);
      }
      let t = this.#o;
      (this.#o = []), this.apply();
      var n = (Vt = []),
        r = [],
        i = (Ht = []);
      for (let e of t)
        try {
          this.#_(e, n, r);
        } catch (t) {
          throw (en(e), t);
        }
      if (((j = null), i.length > 0)) {
        var a = e.ensure();
        for (let e of i) a.schedule(e);
      }
      if (((Vt = null), (Ht = null), this.#m() || this.#h())) {
        this.#v(r), this.#v(n);
        for (let [e, t] of this.#u) $t(e, t);
      } else {
        this.#r.size === 0 && It.delete(this), this.#c.clear(), this.#l.clear();
        for (let e of this.#e) e(this);
        this.#e.clear(),
          (Lt = this),
          Yt(r),
          Yt(n),
          (Lt = null),
          this.#a?.resolve();
      }
      var o = j;
      if (this.#o.length > 0) {
        let e = (o ??= this);
        e.#o.push(...this.#o.filter((t) => !e.#o.includes(t)));
      }
      o !== null && (It.add(o), o.#g()), rt && !It.has(this) && this.#y();
    }
    #_(e, t, n) {
      e.f ^= se;
      for (var r = e.first; r !== null; ) {
        var i = r.f,
          a = (i & 96) != 0;
        if (!((a && i & 1024) || i & 8192 || this.#u.has(r)) && r.fn !== null) {
          a
            ? (r.f ^= se)
            : i & 4
            ? t.push(r)
            : rt && i & 16777224
            ? n.push(r)
            : Gr(r) && (i & 16 && this.#l.add(r), Xr(r));
          var o = r.first;
          if (o !== null) {
            r = o;
            continue;
          }
        }
        for (; r !== null; ) {
          var s = r.next;
          if (s !== null) {
            r = s;
            break;
          }
          r = r.parent;
        }
      }
    }
    #v(e) {
      for (var t = 0; t < e.length; t += 1) Ct(e[t], this.#c, this.#l);
    }
    capture(e, t, n = !1) {
      e.v !== S && !this.previous.has(e) && this.previous.set(e, e.v),
        e.f & 8388608 || (this.current.set(e, [t, n]), M?.set(e, t)),
        this.is_fork || (e.v = t);
    }
    activate() {
      j = this;
    }
    deactivate() {
      (j = null), (M = null);
    }
    flush() {
      try {
        (Bt = !0), (j = this), this.#g();
      } finally {
        (Ut = 0),
          (Rt = null),
          (Vt = null),
          (Ht = null),
          (Bt = !1),
          (j = null),
          (M = null),
          bn.clear();
      }
    }
    discard() {
      for (let e of this.#t) e(this);
      this.#t.clear(), this.#n.clear(), It.delete(this);
    }
    register_created_effect(e) {
      this.#s.push(e);
    }
    #y() {
      for (let l of It) {
        var e = l.id < this.id,
          t = [];
        for (let [r, [i, a]] of this.current) {
          if (l.current.has(r)) {
            var n = l.current.get(r)[0];
            if (e && i !== n) l.current.set(r, [i, a]);
            else continue;
          }
          t.push(r);
        }
        var r = [...l.current.keys()].filter((e) => !this.current.has(e));
        if (r.length === 0) e && l.discard();
        else if (t.length > 0) {
          if (e)
            for (let e of this.#d)
              l.unskip_effect(e, (e) => {
                e.f & 4194320 ? l.schedule(e) : l.#v([e]);
              });
          l.activate();
          var i = new Set(),
            a = new Map();
          for (var o of t) Xt(o, r, i, a);
          a = new Map();
          var s = [...l.current.keys()].filter((e) =>
            this.current.has(e) ? this.current.get(e)[0] !== e : !0
          );
          for (let e of this.#s)
            !(e.f & 155648) &&
              Zt(e, s, a) &&
              (e.f & 4194320 ? (D(e, ce), l.schedule(e)) : l.#c.add(e));
          if (l.#o.length > 0) {
            l.apply();
            for (var c of l.#o) l.#_(c, [], []);
            l.#o = [];
          }
          l.deactivate();
        }
      }
      for (let e of It)
        e.#p.has(this) &&
          (e.#p.delete(this),
          e.#p.size === 0 && !e.#m() && (e.activate(), e.#g()));
    }
    increment(e, t) {
      let n = this.#r.get(t) ?? 0;
      if ((this.#r.set(t, n + 1), e)) {
        let e = this.#i.get(t) ?? 0;
        this.#i.set(t, e + 1);
      }
    }
    decrement(e, t, n) {
      let r = this.#r.get(t) ?? 0;
      if ((r === 1 ? this.#r.delete(t) : this.#r.set(t, r - 1), e)) {
        let e = this.#i.get(t) ?? 0;
        e === 1 ? this.#i.delete(t) : this.#i.set(t, e - 1);
      }
      this.#f ||
        n ||
        ((this.#f = !0),
        gt(() => {
          (this.#f = !1), this.flush();
        }));
    }
    transfer_effects(e, t) {
      for (let t of e) this.#c.add(t);
      for (let e of t) this.#l.add(e);
      e.clear(), t.clear();
    }
    oncommit(e) {
      this.#e.add(e);
    }
    ondiscard(e) {
      this.#t.add(e);
    }
    on_fork_commit(e) {
      this.#n.add(e);
    }
    run_fork_commit_callbacks() {
      for (let e of this.#n) e(this);
      this.#n.clear();
    }
    settled() {
      return (this.#a ??= ae()).promise;
    }
    static ensure() {
      if (j === null) {
        let t = (j = new e());
        Bt ||
          (It.add(j),
          zt ||
            gt(() => {
              j === t && t.flush();
            }));
      }
      return j;
    }
    apply() {
      if (!rt || (!this.is_fork && It.size === 1)) {
        M = null;
        return;
      }
      M = new Map();
      for (let [e, [t]] of this.current) M.set(e, t);
      for (let n of It)
        if (!(n === this || n.is_fork)) {
          var e = !1,
            t = !1;
          if (n.id < this.id)
            for (let [r, [, i]] of n.current)
              i || ((e ||= this.current.has(r)), (t ||= !this.current.has(r)));
          if (e && t) this.#p.add(n);
          else for (let [e, t] of n.previous) M.has(e) || M.set(e, t);
        }
    }
    schedule(e) {
      if (((Rt = e), e.b?.is_pending && e.f & 16777228 && !(e.f & 32768))) {
        e.b.defer_effect(e);
        return;
      }
      for (var t = e; t.parent !== null; ) {
        t = t.parent;
        var n = t.f;
        if (
          Vt !== null &&
          t === I &&
          (rt || ((F === null || !(F.f & 2)) && !Dt))
        )
          return;
        if (n & 96) {
          if (!(n & 1024)) return;
          t.f ^= se;
        }
      }
      this.#o.push(t);
    }
  };
function Kt(e) {
  var t = zt;
  zt = !0;
  try {
    var n;
    for (e && (j !== null && !j.is_fork && j.flush(), (n = e())); ; ) {
      if ((_t(), j === null)) return n;
      j.flush();
    }
  } finally {
    zt = t;
  }
}
function qt() {
  try {
    Ne();
  } catch (e) {
    yt(e, Rt);
  }
}
var Jt = null;
function Yt(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if (
        !(r.f & 24576) &&
        Gr(r) &&
        ((Jt = new Set()),
        Xr(r),
        r.deps === null &&
          r.first === null &&
          r.nodes === null &&
          r.teardown === null &&
          r.ac === null &&
          xr(r),
        Jt?.size > 0)
      ) {
        bn.clear();
        for (let e of Jt) {
          if (e.f & 24576) continue;
          let t = [e],
            n = e.parent;
          for (; n !== null; )
            Jt.has(n) && (Jt.delete(n), t.push(n)), (n = n.parent);
          for (let e = t.length - 1; e >= 0; e--) {
            let n = t[e];
            n.f & 24576 || Xr(n);
          }
        }
        Jt.clear();
      }
    }
    Jt = null;
  }
}
function Xt(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (let i of e.reactions) {
      let e = i.f;
      e & 2
        ? Xt(i, t, n, r)
        : e & 4194320 && !(e & 2048) && Zt(i, t, r) && (D(i, ce), Qt(i));
    }
}
function Zt(e, t, n) {
  let r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (let r of e.deps) {
      if (m.call(t, r)) return !0;
      if (r.f & 2 && Zt(r, t, n)) return n.set(r, !0), !0;
    }
  return n.set(e, !1), !1;
}
function Qt(e) {
  j.schedule(e);
}
function $t(e, t) {
  if (!(e.f & 32 && e.f & 1024)) {
    e.f & 2048 ? t.d.push(e) : e.f & 4096 && t.m.push(e), D(e, se);
    for (var n = e.first; n !== null; ) $t(n, t), (n = n.next);
  }
}
function en(e) {
  D(e, se);
  for (var t = e.first; t !== null; ) en(t), (t = t.next);
}
function tn(e) {
  let t = 0,
    n = Sn(0),
    r;
  return () => {
    ir() &&
      (L(n),
      fr(
        () => (
          t === 0 && (r = ei(() => e(() => kn(n)))),
          (t += 1),
          () => {
            gt(() => {
              --t, t === 0 && (r?.(), (r = void 0), kn(n));
            });
          }
        )
      ));
  };
}
var nn = me | he;
function rn(e, t, n, r) {
  new an(e, t, n, r);
}
var an = class {
  parent;
  is_pending = !1;
  transform_error;
  #e;
  #t = C ? w : null;
  #n;
  #r;
  #i;
  #a = null;
  #o = null;
  #s = null;
  #c = null;
  #l = 0;
  #u = 0;
  #d = !1;
  #f = new Set();
  #p = new Set();
  #m = null;
  #h = tn(
    () => (
      (this.#m = Sn(this.#l)),
      () => {
        this.#m = null;
      }
    )
  );
  constructor(e, t, n, r) {
    (this.#e = e),
      (this.#n = t),
      (this.#r = (e) => {
        var t = I;
        (t.b = this), (t.f |= 128), n(e);
      }),
      (this.parent = I.b),
      (this.transform_error = r ?? this.parent?.transform_error ?? ((e) => e)),
      (this.#i = mr(() => {
        if (C) {
          let e = this.#t;
          Ye();
          let t = e.data === `[!`;
          if (e.data.startsWith(`[?`)) {
            let t = JSON.parse(e.data.slice(2));
            this.#_(t);
          } else t ? this.#v() : this.#g();
        } else this.#y();
      }, nn)),
      C && (this.#e = w);
  }
  #g() {
    try {
      this.#a = gr(() => this.#r(this.#e));
    } catch (e) {
      this.error(e);
    }
  }
  #_(e) {
    let t = this.#n.failed;
    t &&
      (this.#s = gr(() => {
        t(
          this.#e,
          () => e,
          () => () => {}
        );
      }));
  }
  #v() {
    let e = this.#n.pending;
    e &&
      ((this.is_pending = !0),
      (this.#o = gr(() => e(this.#e))),
      gt(() => {
        var e = (this.#c = document.createDocumentFragment()),
          t = zn();
        e.append(t),
          (this.#a = this.#x(() => gr(() => this.#r(t)))),
          this.#u === 0 &&
            (this.#e.before(e),
            (this.#c = null),
            Sr(this.#o, () => {
              this.#o = null;
            }),
            this.#b(j));
      }));
  }
  #y() {
    try {
      if (
        ((this.is_pending = this.has_pending_snippet()),
        (this.#u = 0),
        (this.#l = 0),
        (this.#a = gr(() => {
          this.#r(this.#e);
        })),
        this.#u > 0)
      ) {
        var e = (this.#c = document.createDocumentFragment());
        Er(this.#a, e);
        let t = this.#n.pending;
        this.#o = gr(() => t(this.#e));
      } else this.#b(j);
    } catch (e) {
      this.error(e);
    }
  }
  #b(e) {
    (this.is_pending = !1), e.transfer_effects(this.#f, this.#p);
  }
  defer_effect(e) {
    Ct(e, this.#f, this.#p);
  }
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#n.pending;
  }
  #x(e) {
    var t = I,
      n = F,
      r = E;
    Nr(this.#i), Mr(this.#i), ot(this.#i.ctx);
    try {
      return Gt.ensure(), e();
    } catch (e) {
      return vt(e), null;
    } finally {
      Nr(t), Mr(n), ot(r);
    }
  }
  #S(e, t) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#S(e, t);
      return;
    }
    (this.#u += e),
      this.#u === 0 &&
        (this.#b(t),
        this.#o &&
          Sr(this.#o, () => {
            this.#o = null;
          }),
        (this.#c &&= (this.#e.before(this.#c), null)));
  }
  update_pending_count(e, t) {
    this.#S(e, t),
      (this.#l += e),
      !(!this.#m || this.#d) &&
        ((this.#d = !0),
        gt(() => {
          (this.#d = !1), this.#m && En(this.#m, this.#l);
        }));
  }
  get_effect_pending() {
    return this.#h(), L(this.#m);
  }
  error(e) {
    if (!this.#n.onerror && !this.#n.failed) throw e;
    j?.is_fork
      ? (this.#a && j.skip_effect(this.#a),
        this.#o && j.skip_effect(this.#o),
        this.#s && j.skip_effect(this.#s),
        j.on_fork_commit(() => {
          this.#C(e);
        }))
      : this.#C(e);
  }
  #C(e) {
    (this.#a &&= (P(this.#a), null)),
      (this.#o &&= (P(this.#o), null)),
      (this.#s &&= (P(this.#s), null)),
      C && (T(this.#t), Ze(), T(Qe()));
    var t = this.#n.onerror;
    let n = this.#n.failed;
    var r = !1,
      i = !1;
    let a = () => {
        if (r) {
          qe();
          return;
        }
        (r = !0),
          i && ze(),
          this.#s !== null &&
            Sr(this.#s, () => {
              this.#s = null;
            }),
          this.#x(() => {
            this.#y();
          });
      },
      o = (e) => {
        try {
          (i = !0), t?.(e, a), (i = !1);
        } catch (e) {
          yt(e, this.#i && this.#i.parent);
        }
        n &&
          (this.#s = this.#x(() => {
            try {
              return gr(() => {
                var t = I;
                (t.b = this),
                  (t.f |= 128),
                  n(
                    this.#e,
                    () => e,
                    () => a
                  );
              });
            } catch (e) {
              return yt(e, this.#i.parent), null;
            }
          }));
      };
    gt(() => {
      var t;
      try {
        t = this.transform_error(e);
      } catch (e) {
        yt(e, this.#i && this.#i.parent);
        return;
      }
      typeof t == `object` && t && typeof t.then == `function`
        ? t.then(o, (e) => yt(e, this.#i && this.#i.parent))
        : o(t);
    });
  }
};
function on(e, t, n, r) {
  let i = dt() ? un : pn;
  var a = e.filter((e) => !e.settled);
  if (n.length === 0 && a.length === 0) {
    r(t.map(i));
    return;
  }
  var o = I,
    s = sn(),
    c =
      a.length === 1
        ? a[0].promise
        : a.length > 1
        ? Promise.all(a.map((e) => e.promise))
        : null;
  function l(e) {
    s();
    try {
      r(e);
    } catch (e) {
      o.f & 16384 || yt(e, o);
    }
    cn();
  }
  if (n.length === 0) {
    c.then(() => l(t.map(i)));
    return;
  }
  var u = ln();
  function d() {
    Promise.all(n.map((e) => dn(e)))
      .then((e) => l([...t.map(i), ...e]))
      .catch((e) => yt(e, o))
      .finally(() => u());
  }
  c
    ? c.then(() => {
        s(), d(), cn();
      })
    : d();
}
function sn() {
  var e = I,
    t = F,
    n = E,
    r = j;
  return function (i = !0) {
    Nr(e), Mr(t), ot(n), i && !(e.f & 16384) && (r?.activate(), r?.apply());
  };
}
function cn(e = !0) {
  Nr(null), Mr(null), ot(null), e && j?.deactivate();
}
function ln() {
  var e = I,
    t = e.b,
    n = j,
    r = t.is_rendered();
  return (
    t.update_pending_count(1, n),
    n.increment(r, e),
    (i = !1) => {
      t.update_pending_count(-1, n), n.decrement(r, e, i);
    }
  );
}
function un(e) {
  var t = 2 | ce;
  return (
    I !== null && (I.f |= he),
    {
      ctx: E,
      deps: null,
      effects: null,
      equals: et,
      f: t,
      fn: e,
      reactions: null,
      rv: 0,
      v: S,
      wv: 0,
      parent: I,
      ac: null,
    }
  );
}
function dn(e, t, n) {
  let r = I;
  r === null && Oe();
  var i = void 0,
    a = Sn(S),
    o = !F,
    s = new Map();
  return (
    dr(() => {
      var t = I,
        n = ae();
      i = n.promise;
      try {
        Promise.resolve(e()).then(n.resolve, n.reject).finally(cn);
      } catch (e) {
        n.reject(e), cn();
      }
      var c = j;
      if (o) {
        if (t.f & 32768) var l = ln();
        if (r.b.is_rendered()) s.get(c)?.reject(Te), s.delete(c);
        else {
          for (let e of s.values()) e.reject(Te);
          s.clear();
        }
        s.set(c, n);
      }
      let u = (e, n = void 0) => {
        if ((l && l(n === Te), !(n === Te || t.f & 16384))) {
          if ((c.activate(), n)) (a.f |= xe), En(a, n);
          else {
            a.f & 8388608 && (a.f ^= xe), En(a, e);
            for (let [e, t] of s) {
              if ((s.delete(e), e === c)) break;
              t.reject(Te);
            }
          }
          c.deactivate();
        }
      };
      n.promise.then(u, (e) => u(null, e || `unknown`));
    }),
    ar(() => {
      for (let e of s.values()) e.reject(Te);
    }),
    new Promise((e) => {
      function t(n) {
        function r() {
          n === i ? e(a) : t(i);
        }
        n.then(r, r);
      }
      t(i);
    })
  );
}
function fn(e) {
  let t = un(e);
  return rt || Fr(t), t;
}
function pn(e) {
  let t = un(e);
  return (t.equals = nt), t;
}
function mn(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1) P(t[n]);
  }
}
function hn(e) {
  var t,
    n = I,
    r = e.parent;
  if (!kr && r !== null && r.f & 24576) return We(), e.v;
  Nr(r);
  try {
    (e.f &= ~ve), mn(e), (t = qr(e));
  } finally {
    Nr(n);
  }
  return t;
}
function gn(e) {
  var t = hn(e);
  if (
    !e.equals(t) &&
    ((e.wv = Wr()),
    (!j?.is_fork || e.deps === null) &&
      (j === null ? (e.v = t) : j.capture(e, t, !0), e.deps === null))
  ) {
    D(e, se);
    return;
  }
  kr || (M === null ? xt(e) : (ir() || j?.is_fork) && M.set(e, t));
}
function _n(e) {
  if (e.effects !== null)
    for (let t of e.effects)
      (t.teardown || t.ac) &&
        (t.teardown?.(),
        t.ac?.abort(Te),
        (t.teardown = x),
        (t.ac = null),
        Yr(t, 0),
        vr(t));
}
function vn(e) {
  if (e.effects !== null) for (let t of e.effects) t.teardown && Xr(t);
}
var yn = new Set(),
  bn = new Map(),
  xn = !1;
function Sn(e, t) {
  return { f: 0, v: e, reactions: null, equals: et, rv: 0, wv: 0 };
}
function Cn(e, t) {
  let n = Sn(e, t);
  return Fr(n), n;
}
function wn(e, t = !1, n = !0) {
  let r = Sn(e);
  return (
    t || (r.equals = nt),
    it && n && E !== null && E.l !== null && (E.l.s ??= []).push(r),
    r
  );
}
function Tn(e, t, n = !1) {
  return (
    F !== null &&
      (!jr || F.f & 131072) &&
      dt() &&
      F.f & 4325394 &&
      (Pr === null || !m.call(Pr, e)) &&
      Re(),
    En(e, n ? jn(t) : t, Ht)
  );
}
function En(e, t, n = null) {
  if (!e.equals(t)) {
    bn.set(e, kr ? t : e.v);
    var r = Gt.ensure();
    if ((r.capture(e, t), e.f & 2)) {
      let t = e;
      e.f & 2048 && hn(t), M === null && xt(t);
    }
    (e.wv = Wr()),
      An(e, ce, n),
      dt() &&
        I !== null &&
        I.f & 1024 &&
        !(I.f & 96) &&
        (Rr === null ? zr([e]) : Rr.push(e)),
      !r.is_fork && yn.size > 0 && !xn && Dn();
  }
  return t;
}
function Dn() {
  xn = !1;
  for (let e of yn) e.f & 1024 && D(e, le), Gr(e) && Xr(e);
  yn.clear();
}
function On(e, t = 1) {
  var n = L(e),
    r = t === 1 ? n++ : n--;
  return Tn(e, n), r;
}
function kn(e) {
  Tn(e, e.v + 1);
}
function An(e, t, n) {
  var r = e.reactions;
  if (r !== null)
    for (var i = dt(), a = r.length, o = 0; o < a; o++) {
      var s = r[o],
        c = s.f;
      if (!(!i && s === I)) {
        var l = (c & ce) === 0;
        if ((l && D(s, t), c & 2)) {
          var u = s;
          M?.delete(u),
            c & 65536 ||
              (c & 512 && (I === null || !(I.f & 2097152)) && (s.f |= ve),
              An(u, le, n));
        } else if (l) {
          var d = s;
          c & 16 && Jt !== null && Jt.add(d), n === null ? Qt(d) : n.push(d);
        }
      }
    }
}
function jn(e) {
  if (typeof e != `object` || !e || Se in e) return e;
  let t = b(e);
  if (t !== y && t !== ee) return e;
  var n = new Map(),
    r = f(e),
    i = Cn(0),
    a = null,
    o = Hr,
    s = (e) => {
      if (Hr === o) return e();
      var t = F,
        n = Hr;
      Mr(null), Ur(o);
      var r = e();
      return Mr(t), Ur(n), r;
    };
  return (
    r && n.set(`length`, Cn(e.length, a)),
    new Proxy(e, {
      defineProperty(e, t, r) {
        (!(`value` in r) ||
          r.configurable === !1 ||
          r.enumerable === !1 ||
          r.writable === !1) &&
          Ie();
        var i = n.get(t);
        return (
          i === void 0
            ? s(() => {
                var e = Cn(r.value, a);
                return n.set(t, e), e;
              })
            : Tn(i, r.value, !0),
          !0
        );
      },
      deleteProperty(e, t) {
        var r = n.get(t);
        if (r === void 0) {
          if (t in e) {
            let e = s(() => Cn(S, a));
            n.set(t, e), kn(i);
          }
        } else Tn(r, S), kn(i);
        return !0;
      },
      get(t, r, i) {
        if (r === Se) return e;
        var o = n.get(r),
          c = r in t;
        if (
          (o === void 0 &&
            (!c || _(t, r)?.writable) &&
            ((o = s(() => Cn(jn(c ? t[r] : S), a))), n.set(r, o)),
          o !== void 0)
        ) {
          var l = L(o);
          return l === S ? void 0 : l;
        }
        return Reflect.get(t, r, i);
      },
      getOwnPropertyDescriptor(e, t) {
        var r = Reflect.getOwnPropertyDescriptor(e, t);
        if (r && `value` in r) {
          var i = n.get(t);
          i && (r.value = L(i));
        } else if (r === void 0) {
          var a = n.get(t),
            o = a?.v;
          if (a !== void 0 && o !== S)
            return { enumerable: !0, configurable: !0, value: o, writable: !0 };
        }
        return r;
      },
      has(e, t) {
        if (t === Se) return !0;
        var r = n.get(t),
          i = (r !== void 0 && r.v !== S) || Reflect.has(e, t);
        return (r !== void 0 || (I !== null && (!i || _(e, t)?.writable))) &&
          (r === void 0 &&
            ((r = s(() => Cn(i ? jn(e[t]) : S, a))), n.set(t, r)),
          L(r) === S)
          ? !1
          : i;
      },
      set(e, t, o, c) {
        var l = n.get(t),
          u = t in e;
        if (r && t === `length`)
          for (var d = o; d < l.v; d += 1) {
            var f = n.get(d + ``);
            f === void 0
              ? d in e && ((f = s(() => Cn(S, a))), n.set(d + ``, f))
              : Tn(f, S);
          }
        if (l === void 0)
          (!u || _(e, t)?.writable) &&
            ((l = s(() => Cn(void 0, a))), Tn(l, jn(o)), n.set(t, l));
        else {
          u = l.v !== S;
          var p = s(() => jn(o));
          Tn(l, p);
        }
        var m = Reflect.getOwnPropertyDescriptor(e, t);
        if ((m?.set && m.set.call(c, o), !u)) {
          if (r && typeof t == `string`) {
            var h = n.get(`length`),
              g = Number(t);
            Number.isInteger(g) && g >= h.v && Tn(h, g + 1);
          }
          kn(i);
        }
        return !0;
      },
      ownKeys(e) {
        L(i);
        var t = Reflect.ownKeys(e).filter((e) => {
          var t = n.get(e);
          return t === void 0 || t.v !== S;
        });
        for (var [r, a] of n) a.v !== S && !(r in e) && t.push(r);
        return t;
      },
      setPrototypeOf() {
        Le();
      },
    })
  );
}
function Mn(e) {
  try {
    if (typeof e == `object` && e && Se in e) return e[Se];
  } catch {}
  return e;
}
function Nn(e, t) {
  return Object.is(Mn(e), Mn(t));
}
var Pn, Fn, In, Ln;
function Rn() {
  if (Pn === void 0) {
    (Pn = window), (Fn = /Firefox/.test(navigator.userAgent));
    var e = Element.prototype,
      t = Node.prototype,
      n = Text.prototype;
    (In = _(t, `firstChild`).get),
      (Ln = _(t, `nextSibling`).get),
      te(e) &&
        ((e.__click = void 0),
        (e.__className = void 0),
        (e.__attributes = null),
        (e.__style = void 0),
        (e.__e = void 0)),
      te(n) && (n.__t = void 0);
  }
}
function zn(e = ``) {
  return document.createTextNode(e);
}
function N(e) {
  return In.call(e);
}
function Bn(e) {
  return Ln.call(e);
}
function Vn(e, t) {
  if (!C) return N(e);
  var n = N(w);
  if (n === null) n = w.appendChild(zn());
  else if (t && n.nodeType !== 3) {
    var r = zn();
    return n?.before(r), T(r), r;
  }
  return t && Jn(n), T(n), n;
}
function Hn(e, t = !1) {
  if (!C) {
    var n = N(e);
    return n instanceof Comment && n.data === `` ? Bn(n) : n;
  }
  if (t) {
    if (w?.nodeType !== 3) {
      var r = zn();
      return w?.before(r), T(r), r;
    }
    Jn(w);
  }
  return w;
}
function Un(e, t = 1, n = !1) {
  let r = C ? w : e;
  for (var i; t--; ) (i = r), (r = Bn(r));
  if (!C) return r;
  if (n) {
    if (r?.nodeType !== 3) {
      var a = zn();
      return r === null ? i?.after(a) : r.before(a), T(a), a;
    }
    Jn(r);
  }
  return T(r), r;
}
function Wn(e) {
  e.textContent = ``;
}
function Gn() {
  return !rt || Jt !== null ? !1 : (I.f & fe) !== 0;
}
function Kn(e, t, n) {
  let r = n ? { is: n } : void 0;
  return document.createElementNS(t ?? `http://www.w3.org/1999/xhtml`, e, r);
}
function qn(e = ``) {
  return document.createComment(e);
}
function Jn(e) {
  if (e.nodeValue.length < 65536) return;
  let t = e.nextSibling;
  for (; t !== null && t.nodeType === 3; )
    t.remove(), (e.nodeValue += t.nodeValue), (t = e.nextSibling);
}
function Yn(e, t) {
  if (t) {
    let t = document.body;
    (e.autofocus = !0),
      gt(() => {
        document.activeElement === t && e.focus();
      });
  }
}
function Xn(e) {
  C && N(e) !== null && Wn(e);
}
var Zn = !1;
function Qn() {
  Zn ||
    ((Zn = !0),
    document.addEventListener(
      `reset`,
      (e) => {
        Promise.resolve().then(() => {
          if (!e.defaultPrevented)
            for (let t of e.target.elements) t.__on_r?.();
        });
      },
      { capture: !0 }
    ));
}
function $n(e) {
  var t = F,
    n = I;
  Mr(null), Nr(null);
  try {
    return e();
  } finally {
    Mr(t), Nr(n);
  }
}
function er(e, t, n, r = n) {
  e.addEventListener(t, () => $n(n));
  let i = e.__on_r;
  i
    ? (e.__on_r = () => {
        i(), r(!0);
      })
    : (e.__on_r = () => r(!0)),
    Qn();
}
function tr(e) {
  I === null && (F === null && Me(e), je()), kr && Ae(e);
}
function nr(e, t) {
  var n = t.last;
  n === null
    ? (t.last = t.first = e)
    : ((n.next = e), (e.prev = n), (t.last = e));
}
function rr(e, t) {
  var n = I;
  n !== null && n.f & 8192 && (e |= ue);
  var r = {
    ctx: E,
    deps: null,
    nodes: null,
    f: e | ce | 512,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: n,
    b: n && n.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null,
  };
  j?.register_created_effect(r);
  var i = r;
  if (e & 4) Vt === null ? Gt.ensure().schedule(r) : Vt.push(r);
  else if (t !== null) {
    try {
      Xr(r);
    } catch (e) {
      throw (P(r), e);
    }
    i.deps === null &&
      i.teardown === null &&
      i.nodes === null &&
      i.first === i.last &&
      !(i.f & 524288) &&
      ((i = i.first), e & 16 && e & 65536 && i !== null && (i.f |= me));
  }
  if (
    i !== null &&
    ((i.parent = n), n !== null && nr(i, n), F !== null && F.f & 2 && !(e & 64))
  ) {
    var a = F;
    (a.effects ??= []).push(i);
  }
  return r;
}
function ir() {
  return F !== null && !jr;
}
function ar(e) {
  let t = rr(8, null);
  return D(t, se), (t.teardown = e), t;
}
function or(e) {
  tr(`$effect`);
  var t = I.f;
  if (!F && t & 32 && !(t & 32768)) {
    var n = E;
    (n.e ??= []).push(e);
  } else return sr(e);
}
function sr(e) {
  return rr(4 | ge, e);
}
function cr(e) {
  return tr(`$effect.pre`), rr(8 | ge, e);
}
function lr(e) {
  Gt.ensure();
  let t = rr(64 | he, e);
  return (e = {}) =>
    new Promise((n) => {
      e.outro
        ? Sr(t, () => {
            P(t), n(void 0);
          })
        : (P(t), n(void 0));
    });
}
function ur(e) {
  return rr(4, e);
}
function dr(e) {
  return rr(be | he, e);
}
function fr(e, t = 0) {
  return rr(8 | t, e);
}
function pr(e, t = [], n = [], r = []) {
  on(r, t, n, (t) => {
    rr(8, () => e(...t.map(L)));
  });
}
function mr(e, t = 0) {
  return rr(16 | t, e);
}
function hr(e, t = 0) {
  return rr(oe | t, e);
}
function gr(e) {
  return rr(32 | he, e);
}
function _r(e) {
  var t = e.teardown;
  if (t !== null) {
    let e = kr,
      n = F;
    Ar(!0), Mr(null);
    try {
      t.call(null);
    } finally {
      Ar(e), Mr(n);
    }
  }
}
function vr(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    let e = n.ac;
    e !== null &&
      $n(() => {
        e.abort(Te);
      });
    var r = n.next;
    n.f & 64 ? (n.parent = null) : P(n, t), (n = r);
  }
}
function yr(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    t.f & 32 || P(t), (t = n);
  }
}
function P(e, t = !0) {
  var n = !1;
  (t || e.f & 262144) &&
    e.nodes !== null &&
    e.nodes.end !== null &&
    (br(e.nodes.start, e.nodes.end), (n = !0)),
    D(e, pe),
    vr(e, t && !n),
    Yr(e, 0);
  var r = e.nodes && e.nodes.t;
  if (r !== null) for (let e of r) e.stop();
  _r(e), (e.f ^= pe), (e.f |= de);
  var i = e.parent;
  i !== null && i.first !== null && xr(e),
    (e.next =
      e.prev =
      e.teardown =
      e.ctx =
      e.deps =
      e.fn =
      e.nodes =
      e.ac =
      e.b =
        null);
}
function br(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : Bn(e);
    e.remove(), (e = n);
  }
}
function xr(e) {
  var t = e.parent,
    n = e.prev,
    r = e.next;
  n !== null && (n.next = r),
    r !== null && (r.prev = n),
    t !== null &&
      (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function Sr(e, t, n = !0) {
  var r = [];
  Cr(e, r, !0);
  var i = () => {
      n && P(e), t && t();
    },
    a = r.length;
  if (a > 0) {
    var o = () => --a || i();
    for (var s of r) s.out(o);
  } else i();
}
function Cr(e, t, n) {
  if (!(e.f & 8192)) {
    e.f ^= ue;
    var r = e.nodes && e.nodes.t;
    if (r !== null) for (let e of r) (e.is_global || n) && t.push(e);
    for (var i = e.first; i !== null; ) {
      var a = i.next;
      if (!(i.f & 64)) {
        var o = (i.f & 65536) != 0 || ((i.f & 32) != 0 && (e.f & 16) != 0);
        Cr(i, t, o ? n : !1);
      }
      i = a;
    }
  }
}
function wr(e) {
  Tr(e, !0);
}
function Tr(e, t) {
  if (e.f & 8192) {
    (e.f ^= ue), e.f & 1024 || (D(e, ce), Gt.ensure().schedule(e));
    for (var n = e.first; n !== null; ) {
      var r = n.next,
        i = (n.f & 65536) != 0 || (n.f & 32) != 0;
      Tr(n, i ? t : !1), (n = r);
    }
    var a = e.nodes && e.nodes.t;
    if (a !== null) for (let e of a) (e.is_global || t) && e.in();
  }
}
function Er(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var i = n === r ? null : Bn(n);
      t.append(n), (n = i);
    }
}
var Dr = null,
  Or = !1,
  kr = !1;
function Ar(e) {
  kr = e;
}
var F = null,
  jr = !1;
function Mr(e) {
  F = e;
}
var I = null;
function Nr(e) {
  I = e;
}
var Pr = null;
function Fr(e) {
  F !== null && (!rt || F.f & 2) && (Pr === null ? (Pr = [e]) : Pr.push(e));
}
var Ir = null,
  Lr = 0,
  Rr = null;
function zr(e) {
  Rr = e;
}
var Br = 1,
  Vr = 0,
  Hr = Vr;
function Ur(e) {
  Hr = e;
}
function Wr() {
  return ++Br;
}
function Gr(e) {
  var t = e.f;
  if (t & 2048) return !0;
  if ((t & 2 && (e.f &= ~ve), t & 4096)) {
    for (var n = e.deps, r = n.length, i = 0; i < r; i++) {
      var a = n[i];
      if ((Gr(a) && gn(a), a.wv > e.wv)) return !0;
    }
    t & 512 && M === null && D(e, se);
  }
  return !1;
}
function Kr(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !(!rt && Pr !== null && m.call(Pr, e)))
    for (var i = 0; i < r.length; i++) {
      var a = r[i];
      a.f & 2
        ? Kr(a, t, !1)
        : t === a && (n ? D(a, ce) : a.f & 1024 && D(a, le), Qt(a));
    }
}
function qr(e) {
  var t = Ir,
    n = Lr,
    r = Rr,
    i = F,
    a = Pr,
    o = E,
    s = jr,
    c = Hr,
    l = e.f;
  (Ir = null),
    (Lr = 0),
    (Rr = null),
    (F = l & 96 ? null : e),
    (Pr = null),
    ot(e.ctx),
    (jr = !1),
    (Hr = ++Vr),
    e.ac !== null &&
      ($n(() => {
        e.ac.abort(Te);
      }),
      (e.ac = null));
  try {
    e.f |= ye;
    var u = e.fn,
      d = u();
    e.f |= fe;
    var f = e.deps,
      p = j?.is_fork;
    if (Ir !== null) {
      var m;
      if ((p || Yr(e, Lr), f !== null && Lr > 0))
        for (f.length = Lr + Ir.length, m = 0; m < Ir.length; m++)
          f[Lr + m] = Ir[m];
      else e.deps = f = Ir;
      if (ir() && e.f & 512)
        for (m = Lr; m < f.length; m++) (f[m].reactions ??= []).push(e);
    } else !p && f !== null && Lr < f.length && (Yr(e, Lr), (f.length = Lr));
    if (dt() && Rr !== null && !jr && f !== null && !(e.f & 6146))
      for (m = 0; m < Rr.length; m++) Kr(Rr[m], e);
    if (i !== null && i !== e) {
      if ((Vr++, i.deps !== null))
        for (let e = 0; e < n; e += 1) i.deps[e].rv = Vr;
      if (t !== null) for (let e of t) e.rv = Vr;
      Rr !== null && (r === null ? (r = Rr) : r.push(...Rr));
    }
    return e.f & 8388608 && (e.f ^= xe), d;
  } catch (e) {
    return vt(e);
  } finally {
    (e.f ^= ye),
      (Ir = t),
      (Lr = n),
      (Rr = r),
      (F = i),
      (Pr = a),
      ot(o),
      (jr = s),
      (Hr = c);
  }
}
function Jr(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = p.call(n, e);
    if (r !== -1) {
      var i = n.length - 1;
      i === 0 ? (n = t.reactions = null) : ((n[r] = n[i]), n.pop());
    }
  }
  if (n === null && t.f & 2 && (Ir === null || !m.call(Ir, t))) {
    var a = t;
    a.f & 512 && ((a.f ^= 512), (a.f &= ~ve)),
      a.v !== S && xt(a),
      _n(a),
      Yr(a, 0);
  }
}
function Yr(e, t) {
  var n = e.deps;
  if (n !== null) for (var r = t; r < n.length; r++) Jr(e, n[r]);
}
function Xr(e) {
  var t = e.f;
  if (!(t & 16384)) {
    D(e, se);
    var n = I,
      r = Or;
    (I = e), (Or = !0);
    try {
      t & 16777232 ? yr(e) : vr(e), _r(e);
      var i = qr(e);
      (e.teardown = typeof i == `function` ? i : null), (e.wv = Br);
    } finally {
      (Or = r), (I = n);
    }
  }
}
async function Zr() {
  if (rt)
    return new Promise((e) => {
      requestAnimationFrame(() => e()), setTimeout(() => e());
    });
  await Promise.resolve(), Kt();
}
function L(e) {
  var t = (e.f & 2) != 0;
  if (
    (Dr?.add(e),
    F !== null &&
      !jr &&
      !(I !== null && I.f & 16384) &&
      (Pr === null || !m.call(Pr, e)))
  ) {
    var n = F.deps;
    if (F.f & 2097152)
      e.rv < Vr &&
        ((e.rv = Vr),
        Ir === null && n !== null && n[Lr] === e
          ? Lr++
          : Ir === null
          ? (Ir = [e])
          : Ir.push(e));
    else {
      (F.deps ??= []).push(e);
      var r = e.reactions;
      r === null ? (e.reactions = [F]) : m.call(r, F) || r.push(F);
    }
  }
  if (kr && bn.has(e)) return bn.get(e);
  if (t) {
    var i = e;
    if (kr) {
      var a = i.v;
      return (
        ((!(i.f & 1024) && i.reactions !== null) || $r(i)) && (a = hn(i)),
        bn.set(i, a),
        a
      );
    }
    var o = (i.f & 512) == 0 && !jr && F !== null && (Or || (F.f & 512) != 0),
      s = (i.f & fe) === 0;
    Gr(i) && (o && (i.f |= 512), gn(i)), o && !s && (vn(i), Qr(i));
  }
  if (M?.has(e)) return M.get(e);
  if (e.f & 8388608) throw e.v;
  return e.v;
}
function Qr(e) {
  if (((e.f |= 512), e.deps !== null))
    for (let t of e.deps)
      (t.reactions ??= []).push(e), t.f & 2 && !(t.f & 512) && (vn(t), Qr(t));
}
function $r(e) {
  if (e.v === S) return !0;
  if (e.deps === null) return !1;
  for (let t of e.deps) if (bn.has(t) || (t.f & 2 && $r(t))) return !0;
  return !1;
}
function ei(e) {
  var t = jr;
  try {
    return (jr = !0), e();
  } finally {
    jr = t;
  }
}
function ti(e) {
  if (!(typeof e != `object` || !e || e instanceof EventTarget)) {
    if (Se in e) ni(e);
    else if (!Array.isArray(e))
      for (let t in e) {
        let n = e[t];
        typeof n == `object` && n && Se in n && ni(n);
      }
  }
}
function ni(e, t = new Set()) {
  if (typeof e == `object` && e && !(e instanceof EventTarget) && !t.has(e)) {
    t.add(e), e instanceof Date && e.getTime();
    for (let n in e)
      try {
        ni(e[n], t);
      } catch {}
    let n = b(e);
    if (
      n !== Object.prototype &&
      n !== Array.prototype &&
      n !== Map.prototype &&
      n !== Set.prototype &&
      n !== Date.prototype
    ) {
      let t = v(n);
      for (let n in t) {
        let r = t[n].get;
        if (r)
          try {
            r.call(e);
          } catch {}
      }
    }
  }
}
function ri(e) {
  return (
    e.endsWith(`capture`) &&
    e !== `gotpointercapture` &&
    e !== `lostpointercapture`
  );
}
var ii = [
  `beforeinput`,
  `click`,
  `change`,
  `dblclick`,
  `contextmenu`,
  `focusin`,
  `focusout`,
  `input`,
  `keydown`,
  `keyup`,
  `mousedown`,
  `mousemove`,
  `mouseout`,
  `mouseover`,
  `mouseup`,
  `pointerdown`,
  `pointermove`,
  `pointerout`,
  `pointerover`,
  `pointerup`,
  `touchend`,
  `touchmove`,
  `touchstart`,
];
function ai(e) {
  return ii.includes(e);
}
var oi =
    `allowfullscreen.async.autofocus.autoplay.checked.controls.default.disabled.formnovalidate.indeterminate.inert.ismap.loop.multiple.muted.nomodule.novalidate.open.playsinline.readonly.required.reversed.seamless.selected.webkitdirectory.defer.disablepictureinpicture.disableremoteplayback`.split(
      `.`
    ),
  si = {
    formnovalidate: `formNoValidate`,
    ismap: `isMap`,
    nomodule: `noModule`,
    playsinline: `playsInline`,
    readonly: `readOnly`,
    defaultvalue: `defaultValue`,
    defaultchecked: `defaultChecked`,
    srcobject: `srcObject`,
    novalidate: `noValidate`,
    allowfullscreen: `allowFullscreen`,
    disablepictureinpicture: `disablePictureInPicture`,
    disableremoteplayback: `disableRemotePlayback`,
  };
function ci(e) {
  return (e = e.toLowerCase()), si[e] ?? e;
}
[...oi];
var li = [`touchstart`, `touchmove`];
function ui(e) {
  return li.includes(e);
}
var di = Symbol(`events`),
  fi = new Set(),
  pi = new Set();
function mi(e) {
  if (!C) return;
  e.removeAttribute(`onload`), e.removeAttribute(`onerror`);
  let t = e.__e;
  t !== void 0 &&
    ((e.__e = void 0),
    queueMicrotask(() => {
      e.isConnected && e.dispatchEvent(t);
    }));
}
function hi(e, t, n, r = {}) {
  function i(e) {
    if ((r.capture || bi.call(t, e), !e.cancelBubble))
      return $n(() => n?.call(this, e));
  }
  return (
    e.startsWith(`pointer`) || e.startsWith(`touch`) || e === `wheel`
      ? gt(() => {
          t.addEventListener(e, i, r);
        })
      : t.addEventListener(e, i, r),
    i
  );
}
function gi(e, t, n, r, i) {
  var a = { capture: r, passive: i },
    o = hi(e, t, n, a);
  (t === document.body ||
    t === window ||
    t === document ||
    t instanceof HTMLMediaElement) &&
    ar(() => {
      t.removeEventListener(e, o, a);
    });
}
function _i(e, t, n) {
  (t[di] ??= {})[e] = n;
}
function vi(e) {
  for (var t = 0; t < e.length; t++) fi.add(e[t]);
  for (var n of pi) n(e);
}
var yi = null;
function bi(e) {
  var t = this,
    n = t.ownerDocument,
    r = e.type,
    i = e.composedPath?.() || [],
    a = i[0] || e.target;
  yi = e;
  var o = 0,
    s = yi === e && e[di];
  if (s) {
    var c = i.indexOf(s);
    if (c !== -1 && (t === document || t === window)) {
      e[di] = t;
      return;
    }
    var l = i.indexOf(t);
    if (l === -1) return;
    c <= l && (o = c);
  }
  if (((a = i[o] || e.target), a !== t)) {
    g(e, `currentTarget`, {
      configurable: !0,
      get() {
        return a || n;
      },
    });
    var u = F,
      d = I;
    Mr(null), Nr(null);
    try {
      for (var f, p = []; a !== null; ) {
        var m = a.assignedSlot || a.parentNode || a.host || null;
        try {
          var h = a[di]?.[r];
          h != null && (!a.disabled || e.target === a) && h.call(a, e);
        } catch (e) {
          f ? p.push(e) : (f = e);
        }
        if (e.cancelBubble || m === t || m === null) break;
        a = m;
      }
      if (f) {
        for (let e of p)
          queueMicrotask(() => {
            throw e;
          });
        throw f;
      }
    } finally {
      (e[di] = t), delete e.currentTarget, Mr(u), Nr(d);
    }
  }
}
var xi =
  globalThis?.window?.trustedTypes &&
  globalThis.window.trustedTypes.createPolicy(`svelte-trusted-html`, {
    createHTML: (e) => e,
  });
function Si(e) {
  return xi?.createHTML(e) ?? e;
}
function Ci(e) {
  var t = Kn(`template`);
  return (t.innerHTML = Si(e.replaceAll(`<!>`, `<!---->`))), t.content;
}
function R(e, t) {
  var n = I;
  n.nodes === null && (n.nodes = { start: e, end: t, a: null, t: null });
}
function wi(e, t) {
  var n = (t & 1) != 0,
    r = (t & 2) != 0,
    i,
    a = !e.startsWith(`<!>`);
  return () => {
    if (C) return R(w, null), w;
    i === void 0 && ((i = Ci(a ? e : `<!>` + e)), n || (i = N(i)));
    var t = r || Fn ? document.importNode(i, !0) : i.cloneNode(!0);
    if (n) {
      var o = N(t),
        s = t.lastChild;
      R(o, s);
    } else R(t, t);
    return t;
  };
}
function Ti(e, t, n = `svg`) {
  var r = !e.startsWith(`<!>`),
    i = (t & 1) != 0,
    a = `<${n}>${r ? e : `<!>` + e}</${n}>`,
    o;
  return () => {
    if (C) return R(w, null), w;
    if (!o) {
      var e = N(Ci(a));
      if (i)
        for (o = document.createDocumentFragment(); N(e); ) o.appendChild(N(e));
      else o = N(e);
    }
    var t = o.cloneNode(!0);
    if (i) {
      var n = N(t),
        r = t.lastChild;
      R(n, r);
    } else R(t, t);
    return t;
  };
}
function Ei(e, t) {
  return Ti(e, t, `svg`);
}
function Di(e = ``) {
  if (!C) {
    var t = zn(e + ``);
    return R(t, t), t;
  }
  var n = w;
  return n.nodeType === 3 ? Jn(n) : (n.before((n = zn())), T(n)), R(n, n), n;
}
function Oi() {
  if (C) return R(w, null), w;
  var e = document.createDocumentFragment(),
    t = document.createComment(``),
    n = zn();
  return e.append(t, n), R(t, n), e;
}
function ki(e, t) {
  if (C) {
    var n = I;
    (!(n.f & 32768) || n.nodes.end === null) && (n.nodes.end = w), Ye();
    return;
  }
  e !== null && e.before(t);
}
var Ai = !0;
function ji(e, t) {
  var n = t == null ? `` : typeof t == `object` ? `${t}` : t;
  n !== (e.__t ??= e.nodeValue) && ((e.__t = n), (e.nodeValue = `${n}`));
}
function Mi(e, t) {
  return Pi(e, t);
}
var Ni = new Map();
function Pi(
  e,
  {
    target: t,
    anchor: n,
    props: r = {},
    events: i,
    context: a,
    intro: o = !0,
    transformError: s,
  }
) {
  Rn();
  var c = void 0,
    l = lr(() => {
      var l = n ?? t.appendChild(zn());
      rn(
        l,
        { pending: () => {} },
        (t) => {
          lt({});
          var n = E;
          if (
            (a && (n.c = a),
            i && (r.$$events = i),
            C && R(t, null),
            (Ai = o),
            (c = e(t, r) || {}),
            (Ai = !0),
            C &&
              ((I.nodes.end = w),
              w === null || w.nodeType !== 8 || w.data !== `]`))
          )
            throw (Ge(), Be);
          ut();
        },
        s
      );
      var u = new Set(),
        d = (e) => {
          for (var n = 0; n < e.length; n++) {
            var r = e[n];
            if (!u.has(r)) {
              u.add(r);
              var i = ui(r);
              for (let e of [t, document]) {
                var a = Ni.get(e);
                a === void 0 && ((a = new Map()), Ni.set(e, a));
                var o = a.get(r);
                o === void 0
                  ? (e.addEventListener(r, bi, { passive: i }), a.set(r, 1))
                  : a.set(r, o + 1);
              }
            }
          }
        };
      return (
        d(h(fi)),
        pi.add(d),
        () => {
          for (var e of u)
            for (let n of [t, document]) {
              var r = Ni.get(n),
                i = r.get(e);
              --i == 0
                ? (n.removeEventListener(e, bi),
                  r.delete(e),
                  r.size === 0 && Ni.delete(n))
                : r.set(e, i);
            }
          pi.delete(d), l !== n && l.parentNode?.removeChild(l);
        }
      );
    });
  return Fi.set(c, l), c;
}
var Fi = new WeakMap();
function Ii(e, t) {
  let n = Fi.get(e);
  return n ? (Fi.delete(e), n(t)) : Promise.resolve();
}
var Li = class {
  anchor;
  #e = new Map();
  #t = new Map();
  #n = new Map();
  #r = new Set();
  #i = !0;
  constructor(e, t = !0) {
    (this.anchor = e), (this.#i = t);
  }
  #a = (e) => {
    if (this.#e.has(e)) {
      var t = this.#e.get(e),
        n = this.#t.get(t);
      if (n) wr(n), this.#r.delete(t);
      else {
        var r = this.#n.get(t);
        r &&
          (this.#t.set(t, r.effect),
          this.#n.delete(t),
          r.fragment.lastChild.remove(),
          this.anchor.before(r.fragment),
          (n = r.effect));
      }
      for (let [t, n] of this.#e) {
        if ((this.#e.delete(t), t === e)) break;
        let r = this.#n.get(n);
        r && (P(r.effect), this.#n.delete(n));
      }
      for (let [e, r] of this.#t) {
        if (e === t || this.#r.has(e)) continue;
        let i = () => {
          if (Array.from(this.#e.values()).includes(e)) {
            var t = document.createDocumentFragment();
            Er(r, t),
              t.append(zn()),
              this.#n.set(e, { effect: r, fragment: t });
          } else P(r);
          this.#r.delete(e), this.#t.delete(e);
        };
        this.#i || !n ? (this.#r.add(e), Sr(r, i, !1)) : i();
      }
    }
  };
  #o = (e) => {
    this.#e.delete(e);
    let t = Array.from(this.#e.values());
    for (let [e, n] of this.#n)
      t.includes(e) || (P(n.effect), this.#n.delete(e));
  };
  ensure(e, t) {
    var n = j,
      r = Gn();
    if (t && !this.#t.has(e) && !this.#n.has(e))
      if (r) {
        var i = document.createDocumentFragment(),
          a = zn();
        i.append(a), this.#n.set(e, { effect: gr(() => t(a)), fragment: i });
      } else
        this.#t.set(
          e,
          gr(() => t(this.anchor))
        );
    if ((this.#e.set(n, e), r)) {
      for (let [t, r] of this.#t)
        t === e ? n.unskip_effect(r) : n.skip_effect(r);
      for (let [t, r] of this.#n)
        t === e ? n.unskip_effect(r.effect) : n.skip_effect(r.effect);
      n.oncommit(this.#a), n.ondiscard(this.#o);
    } else C && (this.anchor = w), this.#a(n);
  }
};
function Ri(e, t, n = !1) {
  var r;
  C && ((r = w), Ye());
  var i = new Li(e),
    a = n ? me : 0;
  function o(e, t) {
    if (C) {
      var n = $e(r);
      if (e !== parseInt(n.substring(1))) {
        var a = Qe();
        T(a), (i.anchor = a), Je(!1), i.ensure(e, t), Je(!0);
        return;
      }
    }
    i.ensure(e, t);
  }
  mr(() => {
    var e = !1;
    t((t, n = 0) => {
      (e = !0), o(n, t);
    }),
      e || o(-1, null);
  }, a);
}
var zi = Symbol(`NaN`);
function Bi(e, t, n) {
  C && Ye();
  var r = new Li(e),
    i = !dt();
  mr(() => {
    var e = t();
    e !== e && (e = zi),
      i && typeof e == `object` && e && (e = {}),
      r.ensure(e, n);
  });
}
function Vi(e, t) {
  return t;
}
function Hi(e, t, n) {
  for (var r = [], i = t.length, a, o = t.length, s = 0; s < i; s++) {
    let n = t[s];
    Sr(
      n,
      () => {
        if (a) {
          if ((a.pending.delete(n), a.done.add(n), a.pending.size === 0)) {
            var t = e.outrogroups;
            Ui(e, h(a.done)),
              t.delete(a),
              t.size === 0 && (e.outrogroups = null);
          }
        } else --o;
      },
      !1
    );
  }
  if (o === 0) {
    var c = r.length === 0 && n !== null;
    if (c) {
      var l = n,
        u = l.parentNode;
      Wn(u), u.append(l), e.items.clear();
    }
    Ui(e, t, !c);
  } else
    (a = { pending: new Set(t), done: new Set() }),
      (e.outrogroups ??= new Set()).add(a);
}
function Ui(e, t, n = !0) {
  var r;
  if (e.pending.size > 0) {
    r = new Set();
    for (let t of e.pending.values()) for (let n of t) r.add(e.items.get(n).e);
  }
  for (var i = 0; i < t.length; i++) {
    var a = t[i];
    r?.has(a)
      ? ((a.f |= _e), Er(a, document.createDocumentFragment()))
      : P(t[i], n);
  }
}
var Wi;
function Gi(e, t, n, r, i, a = null) {
  var o = e,
    s = new Map();
  if (t & 4) {
    var c = e;
    o = C ? T(N(c)) : c.appendChild(zn());
  }
  C && Ye();
  var l = null,
    u = pn(() => {
      var e = n();
      return f(e) ? e : e == null ? [] : h(e);
    }),
    d,
    p = new Map(),
    m = !0;
  function g(e) {
    v.effect.f & 16384 ||
      (v.pending.delete(e),
      (v.fallback = l),
      qi(v, d, o, t, r),
      l !== null &&
        (d.length === 0
          ? l.f & 33554432
            ? ((l.f ^= _e), Yi(l, null, o))
            : wr(l)
          : Sr(l, () => {
              l = null;
            })));
  }
  function _(e) {
    v.pending.delete(e);
  }
  var v = {
    effect: mr(() => {
      d = L(u);
      var e = d.length;
      let c = !1;
      C &&
        ($e(o) === `[!`) != (e === 0) &&
        ((o = Qe()), T(o), Je(!1), (c = !0));
      for (var f = new Set(), h = j, v = Gn(), y = 0; y < e; y += 1) {
        C && w.nodeType === 8 && w.data === `]` && ((o = w), (c = !0), Je(!1));
        var ee = d[y],
          b = r(ee, y),
          te = m ? null : s.get(b);
        te
          ? (te.v && En(te.v, ee),
            te.i && En(te.i, y),
            v && h.unskip_effect(te.e))
          : ((te = Ji(s, m ? o : (Wi ??= zn()), ee, b, y, i, t, n)),
            m || (te.e.f |= _e),
            s.set(b, te)),
          f.add(b);
      }
      if (
        (e === 0 &&
          a &&
          !l &&
          (m
            ? (l = gr(() => a(o)))
            : ((l = gr(() => a((Wi ??= zn())))), (l.f |= _e))),
        e > f.size && ke(``, ``, ``),
        C && e > 0 && T(Qe()),
        !m)
      )
        if ((p.set(h, f), v)) {
          for (let [e, t] of s) f.has(e) || h.skip_effect(t.e);
          h.oncommit(g), h.ondiscard(_);
        } else g(h);
      c && Je(!0), L(u);
    }),
    flags: t,
    items: s,
    pending: p,
    outrogroups: null,
    fallback: l,
  };
  (m = !1), C && (o = w);
}
function Ki(e) {
  for (; e !== null && !(e.f & 32); ) e = e.next;
  return e;
}
function qi(e, t, n, r, i) {
  var a = (r & 8) != 0,
    o = t.length,
    s = e.items,
    c = Ki(e.effect.first),
    l,
    u = null,
    d,
    f = [],
    p = [],
    m,
    g,
    _,
    v;
  if (a)
    for (v = 0; v < o; v += 1)
      (m = t[v]),
        (g = i(m, v)),
        (_ = s.get(g).e),
        _.f & 33554432 || (_.nodes?.a?.measure(), (d ??= new Set()).add(_));
  for (v = 0; v < o; v += 1) {
    if (((m = t[v]), (g = i(m, v)), (_ = s.get(g).e), e.outrogroups !== null))
      for (let t of e.outrogroups) t.pending.delete(_), t.done.delete(_);
    if (
      (_.f & 8192 &&
        (wr(_), a && (_.nodes?.a?.unfix(), (d ??= new Set()).delete(_))),
      _.f & 33554432)
    )
      if (((_.f ^= _e), _ === c)) Yi(_, null, n);
      else {
        var y = u ? u.next : c;
        _ === e.effect.last && (e.effect.last = _.prev),
          _.prev && (_.prev.next = _.next),
          _.next && (_.next.prev = _.prev),
          Xi(e, u, _),
          Xi(e, _, y),
          Yi(_, y, n),
          (u = _),
          (f = []),
          (p = []),
          (c = Ki(u.next));
        continue;
      }
    if (_ !== c) {
      if (l !== void 0 && l.has(_)) {
        if (f.length < p.length) {
          var ee = p[0],
            b;
          u = ee.prev;
          var te = f[0],
            ne = f[f.length - 1];
          for (b = 0; b < f.length; b += 1) Yi(f[b], ee, n);
          for (b = 0; b < p.length; b += 1) l.delete(p[b]);
          Xi(e, te.prev, ne.next),
            Xi(e, u, te),
            Xi(e, ne, ee),
            (c = ee),
            (u = ne),
            --v,
            (f = []),
            (p = []);
        } else
          l.delete(_),
            Yi(_, c, n),
            Xi(e, _.prev, _.next),
            Xi(e, _, u === null ? e.effect.first : u.next),
            Xi(e, u, _),
            (u = _);
        continue;
      }
      for (f = [], p = []; c !== null && c !== _; )
        (l ??= new Set()).add(c), p.push(c), (c = Ki(c.next));
      if (c === null) continue;
    }
    _.f & 33554432 || f.push(_), (u = _), (c = Ki(_.next));
  }
  if (e.outrogroups !== null) {
    for (let t of e.outrogroups)
      t.pending.size === 0 && (Ui(e, h(t.done)), e.outrogroups?.delete(t));
    e.outrogroups.size === 0 && (e.outrogroups = null);
  }
  if (c !== null || l !== void 0) {
    var x = [];
    if (l !== void 0) for (_ of l) _.f & 8192 || x.push(_);
    for (; c !== null; )
      !(c.f & 8192) && c !== e.fallback && x.push(c), (c = Ki(c.next));
    var re = x.length;
    if (re > 0) {
      var ie = r & 4 && o === 0 ? n : null;
      if (a) {
        for (v = 0; v < re; v += 1) x[v].nodes?.a?.measure();
        for (v = 0; v < re; v += 1) x[v].nodes?.a?.fix();
      }
      Hi(e, x, ie);
    }
  }
  a &&
    gt(() => {
      if (d !== void 0) for (_ of d) _.nodes?.a?.apply();
    });
}
function Ji(e, t, n, r, i, a, o, s) {
  var c = o & 1 ? (o & 16 ? Sn(n) : wn(n, !1, !1)) : null,
    l = o & 2 ? Sn(i) : null;
  return {
    v: c,
    i: l,
    e: gr(
      () => (
        a(t, c ?? n, l ?? i, s),
        () => {
          e.delete(r);
        }
      )
    ),
  };
}
function Yi(e, t, n) {
  if (e.nodes)
    for (
      var r = e.nodes.start,
        i = e.nodes.end,
        a = t && !(t.f & 33554432) ? t.nodes.start : n;
      r !== null;

    ) {
      var o = Bn(r);
      if ((a.before(r), r === i)) return;
      r = o;
    }
}
function Xi(e, t, n) {
  t === null ? (e.effect.first = n) : (t.next = n),
    n === null ? (e.effect.last = t) : (n.prev = t);
}
function Zi(e, t, n = !1, r = !1, i = !1, a = !1) {
  var o = e,
    s = ``;
  if (n) {
    var c = e;
    C && (o = T(N(c)));
  }
  pr(() => {
    var e = I;
    if (s === (s = t() ?? ``)) {
      C && Ye();
      return;
    }
    if (n && !C) {
      (e.nodes = null), (c.innerHTML = s), s !== `` && R(N(c), c.lastChild);
      return;
    }
    if (
      (e.nodes !== null && (br(e.nodes.start, e.nodes.end), (e.nodes = null)),
      s !== ``)
    ) {
      if (C) {
        for (
          var a = w.data, l = Ye(), u = l;
          l !== null && (l.nodeType !== 8 || l.data !== ``);

        )
          (u = l), (l = Bn(l));
        if (l === null) throw (Ge(), Be);
        R(w, u), (o = T(l));
        return;
      }
      var d = Kn(r ? `svg` : i ? `math` : `template`, r ? He : i ? Ue : void 0);
      d.innerHTML = s;
      var f = r || i ? d : d.content;
      if ((R(N(f), f.lastChild), r || i)) for (; N(f); ) o.before(N(f));
      else o.before(f);
    }
  });
}
function Qi(e, t, ...n) {
  var r = new Li(e);
  mr(() => {
    let e = t() ?? null;
    r.ensure(e, e && ((t) => e(t, ...n)));
  }, me);
}
function $i(e, t, n) {
  var r;
  C && ((r = w), Ye());
  var i = new Li(e);
  mr(() => {
    var e = t() ?? null;
    if (C && ($e(r) === `[`) != (e !== null)) {
      var a = Qe();
      T(a), (i.anchor = a), Je(!1), i.ensure(e, e && ((t) => n(t, e))), Je(!0);
      return;
    }
    i.ensure(e, e && ((t) => n(t, e)));
  }, me);
}
var ea = () => performance.now(),
  ta = {
    tick: (e) => requestAnimationFrame(e),
    now: () => ea(),
    tasks: new Set(),
  };
function na() {
  let e = ta.now();
  ta.tasks.forEach((t) => {
    t.c(e) || (ta.tasks.delete(t), t.f());
  }),
    ta.tasks.size !== 0 && ta.tick(na);
}
function ra(e) {
  let t;
  return (
    ta.tasks.size === 0 && ta.tick(na),
    {
      promise: new Promise((n) => {
        ta.tasks.add((t = { c: e, f: n }));
      }),
      abort() {
        ta.tasks.delete(t);
      },
    }
  );
}
function ia(e, t) {
  $n(() => {
    e.dispatchEvent(new CustomEvent(t));
  });
}
function aa(e) {
  if (e === `float`) return `cssFloat`;
  if (e === `offset`) return `cssOffset`;
  if (e.startsWith(`--`)) return e;
  let t = e.split(`-`);
  return t.length === 1
    ? t[0]
    : t[0] +
        t
          .slice(1)
          .map((e) => e[0].toUpperCase() + e.slice(1))
          .join(``);
}
function oa(e) {
  let t = {},
    n = e.split(`;`);
  for (let e of n) {
    let [n, r] = e.split(`:`);
    if (!n || r === void 0) break;
    let i = aa(n.trim());
    t[i] = r.trim();
  }
  return t;
}
var sa = (e) => e;
function ca(e, t, n, r) {
  var i = (e & 1) != 0,
    a = (e & 2) != 0,
    o = i && a,
    s = (e & 4) != 0,
    c = o ? `both` : i ? `in` : `out`,
    l,
    u = t.inert,
    d = t.style.overflow,
    f,
    p;
  function m() {
    return $n(() => (l ??= n()(t, r?.() ?? {}, { direction: c })));
  }
  var h = {
      is_global: s,
      in() {
        if (((t.inert = u), !i)) {
          p?.abort(), p?.reset?.();
          return;
        }
        a || f?.abort(),
          (f = la(
            t,
            m(),
            p,
            1,
            () => {
              ia(t, `introstart`);
            },
            () => {
              ia(t, `introend`),
                f?.abort(),
                (f = l = void 0),
                (t.style.overflow = d);
            }
          ));
      },
      out(e) {
        if (!a) {
          e?.(), (l = void 0);
          return;
        }
        (t.inert = !0),
          (p = la(
            t,
            m(),
            f,
            0,
            () => {
              ia(t, `outrostart`);
            },
            () => {
              ia(t, `outroend`), e?.();
            }
          ));
      },
      stop: () => {
        f?.abort(), p?.abort();
      },
    },
    g = I;
  if (((g.nodes.t ??= []).push(h), i && Ai)) {
    var _ = s;
    if (!_) {
      for (var v = g.parent; v && v.f & 65536; )
        for (; (v = v.parent) && !(v.f & 16); );
      _ = !v || (v.f & 32768) != 0;
    }
    _ &&
      ur(() => {
        ei(() => h.in());
      });
  }
}
function la(e, t, n, r, i, a) {
  var o = r === 1;
  if (ne(t)) {
    var s,
      c = !1;
    return (
      gt(() => {
        c || (s = la(e, t({ direction: o ? `in` : `out` }), n, r, i, a));
      }),
      {
        abort: () => {
          (c = !0), s?.abort();
        },
        deactivate: () => s.deactivate(),
        reset: () => s.reset(),
        t: () => s.t(),
      }
    );
  }
  if ((n?.deactivate(), !t?.duration && !t?.delay))
    return i(), a(), { abort: x, deactivate: x, reset: x, t: () => r };
  let { delay: l = 0, css: u, tick: d, easing: f = sa } = t;
  var p = [];
  if (o && n === void 0 && (d && d(0, 1), u)) {
    var m = oa(u(0, 1));
    p.push(m, m);
  }
  var h = () => 1 - r,
    g = e.animate(p, { duration: l, fill: `forwards` });
  return (
    (g.onfinish = () => {
      g.cancel(), i();
      var o = n?.t() ?? 1 - r;
      n?.abort();
      var s = r - o,
        c = t.duration * Math.abs(s),
        l = [];
      if (c > 0) {
        var p = !1;
        if (u)
          for (var m = Math.ceil(c / (1e3 / 60)), _ = 0; _ <= m; _ += 1) {
            var v = o + s * f(_ / m),
              y = oa(u(v, 1 - v));
            l.push(y), (p ||= y.overflow === `hidden`);
          }
        p && (e.style.overflow = `hidden`),
          (h = () => {
            var e = g.currentTime;
            return o + s * f(e / c);
          }),
          d &&
            ra(() => {
              if (g.playState !== `running`) return !1;
              var e = h();
              return d(e, 1 - e), !0;
            });
      }
      (g = e.animate(l, { duration: c, fill: `forwards` })),
        (g.onfinish = () => {
          (h = () => r), d?.(r, 1 - r), a();
        });
    }),
    {
      abort: () => {
        g && (g.cancel(), (g.effect = null), (g.onfinish = x));
      },
      deactivate: () => {
        a = x;
      },
      reset: () => {
        r === 0 && d?.(1, 0);
      },
      t: () => h(),
    }
  );
}
function ua(e, t, n) {
  ur(() => {
    var r = ei(() => t(e, n?.()) || {});
    if (n && r?.update) {
      var i = !1,
        a = {};
      fr(() => {
        var e = n();
        ti(e), i && tt(a, e) && ((a = e), r.update(e));
      }),
        (i = !0);
    }
    if (r?.destroy) return () => r.destroy();
  });
}
function da(e, t) {
  var n = void 0,
    r;
  hr(() => {
    n !== (n = t()) &&
      ((r &&= (P(r), null)),
      n &&
        (r = gr(() => {
          ur(() => n(e));
        })));
  });
}
function fa(e) {
  var t,
    n,
    r = ``;
  if (typeof e == `string` || typeof e == `number`) r += e;
  else if (typeof e == `object`)
    if (Array.isArray(e)) {
      var i = e.length;
      for (t = 0; t < i; t++)
        e[t] && (n = fa(e[t])) && (r && (r += ` `), (r += n));
    } else for (n in e) e[n] && (r && (r += ` `), (r += n));
  return r;
}
function pa() {
  for (var e, t, n = 0, r = ``, i = arguments.length; n < i; n++)
    (e = arguments[n]) && (t = fa(e)) && (r && (r += ` `), (r += t));
  return r;
}
function ma(e) {
  return typeof e == `object` ? pa(e) : e ?? ``;
}
var ha = [
  ...` 	
\r\f\xA0\v﻿`,
];
function ga(e, t, n) {
  var r = e == null ? `` : `` + e;
  if ((t && (r = r ? r + ` ` + t : t), n)) {
    for (var i of Object.keys(n))
      if (n[i]) r = r ? r + ` ` + i : i;
      else if (r.length)
        for (var a = i.length, o = 0; (o = r.indexOf(i, o)) >= 0; ) {
          var s = o + a;
          (o === 0 || ha.includes(r[o - 1])) &&
          (s === r.length || ha.includes(r[s]))
            ? (r = (o === 0 ? `` : r.substring(0, o)) + r.substring(s + 1))
            : (o = s);
        }
  }
  return r === `` ? null : r;
}
function _a(e, t = !1) {
  var n = t ? ` !important;` : `;`,
    r = ``;
  for (var i of Object.keys(e)) {
    var a = e[i];
    a != null && a !== `` && (r += ` ` + i + `: ` + a + n);
  }
  return r;
}
function va(e) {
  return e[0] !== `-` || e[1] !== `-` ? e.toLowerCase() : e;
}
function ya(e, t) {
  if (t) {
    var n = ``,
      r,
      i;
    if ((Array.isArray(t) ? ((r = t[0]), (i = t[1])) : (r = t), e)) {
      e = String(e)
        .replaceAll(/\s*\/\*.*?\*\/\s*/g, ``)
        .trim();
      var a = !1,
        o = 0,
        s = !1,
        c = [];
      r && c.push(...Object.keys(r).map(va)),
        i && c.push(...Object.keys(i).map(va));
      var l = 0,
        u = -1;
      let t = e.length;
      for (var d = 0; d < t; d++) {
        var f = e[d];
        if (
          (s
            ? f === `/` && e[d - 1] === `*` && (s = !1)
            : a
            ? a === f && (a = !1)
            : f === `/` && e[d + 1] === `*`
            ? (s = !0)
            : f === `"` || f === `'`
            ? (a = f)
            : f === `(`
            ? o++
            : f === `)` && o--,
          !s && a === !1 && o === 0)
        ) {
          if (f === `:` && u === -1) u = d;
          else if (f === `;` || d === t - 1) {
            if (u !== -1) {
              var p = va(e.substring(l, u).trim());
              if (!c.includes(p)) {
                f !== `;` && d++;
                var m = e.substring(l, d).trim();
                n += ` ` + m + `;`;
              }
            }
            (l = d + 1), (u = -1);
          }
        }
      }
    }
    return (
      r && (n += _a(r)),
      i && (n += _a(i, !0)),
      (n = n.trim()),
      n === `` ? null : n
    );
  }
  return e == null ? null : String(e);
}
function ba(e, t, n, r, i, a) {
  var o = e.__className;
  if (C || o !== n || o === void 0) {
    var s = ga(n, r, a);
    (!C || s !== e.getAttribute(`class`)) &&
      (s == null
        ? e.removeAttribute(`class`)
        : t
        ? (e.className = s)
        : e.setAttribute(`class`, s)),
      (e.__className = n);
  } else if (a && i !== a)
    for (var c in a) {
      var l = !!a[c];
      (i == null || l !== !!i[c]) && e.classList.toggle(c, l);
    }
  return a;
}
function xa(e, t = {}, n, r) {
  for (var i in n) {
    var a = n[i];
    t[i] !== a &&
      (n[i] == null ? e.style.removeProperty(i) : e.style.setProperty(i, a, r));
  }
}
function Sa(e, t, n, r) {
  var i = e.__style;
  if (C || i !== t) {
    var a = ya(t, r);
    (!C || a !== e.getAttribute(`style`)) &&
      (a == null ? e.removeAttribute(`style`) : (e.style.cssText = a)),
      (e.__style = t);
  } else
    r &&
      (Array.isArray(r)
        ? (xa(e, n?.[0], r[0]), xa(e, n?.[1], r[1], `important`))
        : xa(e, n, r));
  return r;
}
function Ca(e, t, n = !1) {
  if (e.multiple) {
    if (t == null) return;
    if (!f(t)) return Ke();
    for (var r of e.options) r.selected = t.includes(Ea(r));
    return;
  }
  for (r of e.options)
    if (Nn(Ea(r), t)) {
      r.selected = !0;
      return;
    }
  (!n || t !== void 0) && (e.selectedIndex = -1);
}
function wa(e) {
  var t = new MutationObserver(() => {
    Ca(e, e.__value);
  });
  t.observe(e, {
    childList: !0,
    subtree: !0,
    attributes: !0,
    attributeFilter: [`value`],
  }),
    ar(() => {
      t.disconnect();
    });
}
function Ta(e, t, n = t) {
  var r = new WeakSet(),
    i = !0;
  er(e, `change`, (t) => {
    var i = t ? `[selected]` : `:checked`,
      a;
    if (e.multiple) a = [].map.call(e.querySelectorAll(i), Ea);
    else {
      var o = e.querySelector(i) ?? e.querySelector(`option:not([disabled])`);
      a = o && Ea(o);
    }
    n(a), (e.__value = a), j !== null && r.add(j);
  }),
    ur(() => {
      var a = t();
      if (e === document.activeElement) {
        var o = rt ? Lt : j;
        if (r.has(o)) return;
      }
      if ((Ca(e, a, i), i && a === void 0)) {
        var s = e.querySelector(`:checked`);
        s !== null && ((a = Ea(s)), n(a));
      }
      (e.__value = a), (i = !1);
    }),
    wa(e);
}
function Ea(e) {
  return `__value` in e ? e.__value : e.value;
}
var Da = Symbol(`class`),
  Oa = Symbol(`style`),
  ka = Symbol(`is custom element`),
  Aa = Symbol(`is html`),
  ja = Ee ? `link` : `LINK`,
  Ma = Ee ? `input` : `INPUT`,
  Na = Ee ? `option` : `OPTION`,
  Pa = Ee ? `select` : `SELECT`,
  Fa = Ee ? `progress` : `PROGRESS`;
function Ia(e) {
  if (C) {
    var t = !1,
      n = () => {
        if (!t) {
          if (((t = !0), e.hasAttribute(`value`))) {
            var n = e.value;
            za(e, `value`, null), (e.value = n);
          }
          if (e.hasAttribute(`checked`)) {
            var r = e.checked;
            za(e, `checked`, null), (e.checked = r);
          }
        }
      };
    (e.__on_r = n), gt(n), Qn();
  }
}
function La(e, t) {
  var n = Ha(e);
  n.value === (n.value = t ?? void 0) ||
    (e.value === t && (t !== 0 || e.nodeName !== Fa)) ||
    (e.value = t ?? ``);
}
function Ra(e, t) {
  t
    ? e.hasAttribute(`selected`) || e.setAttribute(`selected`, ``)
    : e.removeAttribute(`selected`);
}
function za(e, t, n, r) {
  var i = Ha(e);
  (C &&
    ((i[t] = e.getAttribute(t)),
    t === `src` || t === `srcset` || (t === `href` && e.nodeName === ja))) ||
    (i[t] !== (i[t] = n) &&
      (t === `loading` && (e[we] = n),
      n == null
        ? e.removeAttribute(t)
        : typeof n != `string` && Wa(e).includes(t)
        ? (e[t] = n)
        : e.setAttribute(t, n)));
}
function Ba(e, t, n, r, i = !1, a = !1) {
  if (C && i && e.nodeName === Ma) {
    var o = e;
    (o.type === `checkbox` ? `defaultChecked` : `defaultValue`) in n || Ia(o);
  }
  var s = Ha(e),
    c = s[ka],
    l = !s[Aa];
  let u = C && c;
  u && Je(!1);
  var d = t || {},
    f = e.nodeName === Na;
  for (var p in t) p in n || (n[p] = null);
  n.class ? (n.class = ma(n.class)) : (r || n[Da]) && (n.class = null),
    n[Oa] && (n.style ??= null);
  var m = Wa(e);
  for (let i in n) {
    let o = n[i];
    if (f && i === `value` && o == null) {
      (e.value = e.__value = ``), (d[i] = o);
      continue;
    }
    if (i === `class`) {
      ba(
        e,
        e.namespaceURI === `http://www.w3.org/1999/xhtml`,
        o,
        r,
        t?.[Da],
        n[Da]
      ),
        (d[i] = o),
        (d[Da] = n[Da]);
      continue;
    }
    if (i === `style`) {
      Sa(e, o, t?.[Oa], n[Oa]), (d[i] = o), (d[Oa] = n[Oa]);
      continue;
    }
    var h = d[i];
    if (!(o === h && !(o === void 0 && e.hasAttribute(i)))) {
      d[i] = o;
      var g = i[0] + i[1];
      if (g !== `$$`)
        if (g === `on`) {
          let t = {},
            n = `$$` + i,
            r = i.slice(2);
          var _ = ai(r);
          if ((ri(r) && ((r = r.slice(0, -7)), (t.capture = !0)), !_ && h)) {
            if (o != null) continue;
            e.removeEventListener(r, d[n], t), (d[n] = null);
          }
          if (_) _i(r, e, o), vi([r]);
          else if (o != null) {
            function a(e) {
              d[i].call(this, e);
            }
            d[n] = hi(r, e, a, t);
          }
        } else if (i === `style`) za(e, i, o);
        else if (i === `autofocus`) Yn(e, !!o);
        else if (!c && (i === `__value` || (i === `value` && o != null)))
          e.value = e.__value = o;
        else if (i === `selected` && f) Ra(e, o);
        else {
          var v = i;
          l || (v = ci(v));
          var y = v === `defaultValue` || v === `defaultChecked`;
          if (o == null && !c && !y)
            if (((s[i] = null), v === `value` || v === `checked`)) {
              let n = e,
                r = t === void 0;
              if (v === `value`) {
                let e = n.defaultValue;
                n.removeAttribute(v),
                  (n.defaultValue = e),
                  (n.value = n.__value = r ? e : null);
              } else {
                let e = n.defaultChecked;
                n.removeAttribute(v),
                  (n.defaultChecked = e),
                  (n.checked = r ? e : !1);
              }
            } else e.removeAttribute(i);
          else
            y || (m.includes(v) && (c || typeof o != `string`))
              ? ((e[v] = o), v in s && (s[v] = S))
              : typeof o != `function` && za(e, v, o, a);
        }
    }
  }
  return u && Je(!0), d;
}
function Va(e, t, n = [], r = [], i = [], a, o = !1, s = !1) {
  on(i, n, r, (n) => {
    var r = void 0,
      i = {},
      c = e.nodeName === Pa,
      l = !1;
    if (
      (hr(() => {
        var u = t(...n.map(L)),
          d = Ba(e, r, u, a, o, s);
        l && c && `value` in u && Ca(e, u.value);
        for (let e of Object.getOwnPropertySymbols(i)) u[e] || P(i[e]);
        for (let t of Object.getOwnPropertySymbols(u)) {
          var f = u[t];
          t.description === `@attach` &&
            (!r || f !== r[t]) &&
            (i[t] && P(i[t]), (i[t] = gr(() => da(e, () => f)))),
            (d[t] = f);
        }
        r = d;
      }),
      c)
    ) {
      var u = e;
      ur(() => {
        Ca(u, r.value, !0), wa(u);
      });
    }
    l = !0;
  });
}
function Ha(e) {
  return (e.__attributes ??= {
    [ka]: e.nodeName.includes(`-`),
    [Aa]: e.namespaceURI === Ve,
  });
}
var Ua = new Map();
function Wa(e) {
  var t = e.getAttribute(`is`) || e.nodeName,
    n = Ua.get(t);
  if (n) return n;
  Ua.set(t, (n = []));
  for (var r, i = e, a = Element.prototype; a !== i; ) {
    for (var o in ((r = v(i)), r)) r[o].set && n.push(o);
    i = b(i);
  }
  return n;
}
var Ga = null;
function Ka() {
  if (Ga === null) {
    var e = Kn(`select`);
    (e.innerHTML = Si(`<option><span>t</span></option>`)),
      (Ga = e.firstChild?.firstChild?.nodeType === 1);
  }
  return Ga;
}
function qa(e, t) {
  var n = C;
  Ka() || (Je(!1), (e.textContent = ``), e.append(qn(``)));
  try {
    t();
  } finally {
    n && (C ? Xe(e) : (Je(!0), T(e)));
  }
}
function Ja(e, t, n = t) {
  var r = new WeakSet();
  er(e, `input`, async (i) => {
    var a = i ? e.defaultValue : e.value;
    if (
      ((a = Xa(e) ? Za(a) : a),
      n(a),
      j !== null && r.add(j),
      await Zr(),
      a !== (a = t()))
    ) {
      var o = e.selectionStart,
        s = e.selectionEnd,
        c = e.value.length;
      if (((e.value = a ?? ``), s !== null)) {
        var l = e.value.length;
        o === s && s === c && l > c
          ? ((e.selectionStart = l), (e.selectionEnd = l))
          : ((e.selectionStart = o), (e.selectionEnd = Math.min(s, l)));
      }
    }
  }),
    ((C && e.defaultValue !== e.value) || (ei(t) == null && e.value)) &&
      (n(Xa(e) ? Za(e.value) : e.value), j !== null && r.add(j)),
    fr(() => {
      var n = t();
      if (e === document.activeElement) {
        var i = rt ? Lt : j;
        if (r.has(i)) return;
      }
      (Xa(e) && n === Za(e.value)) ||
        (e.type === `date` && !n && !e.value) ||
        (n !== e.value && (e.value = n ?? ``));
    });
}
function Ya(e, t, n = t) {
  er(e, `change`, (t) => {
    n(t ? e.defaultChecked : e.checked);
  }),
    ((C && e.defaultChecked !== e.checked) || ei(t) == null) && n(e.checked),
    fr(() => {
      e.checked = !!t();
    });
}
function Xa(e) {
  var t = e.type;
  return t === `number` || t === `range`;
}
function Za(e) {
  return e === `` ? null : +e;
}
function Qa(e, t) {
  return e === t || e?.[Se] === t;
}
function $a(e = {}, t, n, r) {
  var i = E.r,
    a = I;
  return (
    ur(() => {
      var o, s;
      return (
        fr(() => {
          (o = s),
            (s = r?.() || []),
            ei(() => {
              e !== n(...s) &&
                (t(e, ...s), o && Qa(n(...o), e) && t(null, ...o));
            });
        }),
        () => {
          let r = a;
          for (; r !== i && r.parent !== null && r.parent.f & 33554432; )
            r = r.parent;
          let o = () => {
              s && Qa(n(...s), e) && t(null, ...s);
            },
            c = r.teardown;
          r.teardown = () => {
            o(), c?.();
          };
        }
      );
    }),
    e
  );
}
function eo(e = !1) {
  let t = E,
    n = t.l.u;
  if (!n) return;
  let r = () => ti(t.s);
  if (e) {
    let e = 0,
      n = {},
      i = un(() => {
        let r = !1,
          i = t.s;
        for (let e in i) i[e] !== n[e] && ((n[e] = i[e]), (r = !0));
        return r && e++, e;
      });
    r = () => L(i);
  }
  n.b.length &&
    cr(() => {
      to(t, r), ie(n.b);
    }),
    or(() => {
      let e = ei(() => n.m.map(re));
      return () => {
        for (let t of e) typeof t == `function` && t();
      };
    }),
    n.a.length &&
      or(() => {
        to(t, r), ie(n.a);
      });
}
function to(e, t) {
  if (e.l.s) for (let t of e.l.s) L(t);
  t();
}
var no = {
  get(e, t) {
    if (!e.exclude.includes(t)) return e.props[t];
  },
  set(e, t) {
    return !1;
  },
  getOwnPropertyDescriptor(e, t) {
    if (!e.exclude.includes(t) && t in e.props)
      return { enumerable: !0, configurable: !0, value: e.props[t] };
  },
  has(e, t) {
    return e.exclude.includes(t) ? !1 : t in e.props;
  },
  ownKeys(e) {
    return Reflect.ownKeys(e.props).filter((t) => !e.exclude.includes(t));
  },
};
function ro(e, t, n) {
  return new Proxy({ props: e, exclude: t }, no);
}
var io = {
  get(e, t) {
    let n = e.props.length;
    for (; n--; ) {
      let r = e.props[n];
      if ((ne(r) && (r = r()), typeof r == `object` && r && t in r))
        return r[t];
    }
  },
  set(e, t, n) {
    let r = e.props.length;
    for (; r--; ) {
      let i = e.props[r];
      ne(i) && (i = i());
      let a = _(i, t);
      if (a && a.set) return a.set(n), !0;
    }
    return !1;
  },
  getOwnPropertyDescriptor(e, t) {
    let n = e.props.length;
    for (; n--; ) {
      let r = e.props[n];
      if ((ne(r) && (r = r()), typeof r == `object` && r && t in r)) {
        let e = _(r, t);
        return e && !e.configurable && (e.configurable = !0), e;
      }
    }
  },
  has(e, t) {
    if (t === Se || t === Ce) return !1;
    for (let n of e.props)
      if ((ne(n) && (n = n()), n != null && t in n)) return !0;
    return !1;
  },
  ownKeys(e) {
    let t = [];
    for (let n of e.props)
      if ((ne(n) && (n = n()), n)) {
        for (let e in n) t.includes(e) || t.push(e);
        for (let e of Object.getOwnPropertySymbols(n))
          t.includes(e) || t.push(e);
      }
    return t;
  },
};
function ao(...e) {
  return new Proxy({ props: e }, io);
}
function oo(e, t, n, r) {
  var i = !it || (n & 2) != 0,
    a = (n & 8) != 0,
    o = (n & 16) != 0,
    s = r,
    c = !0,
    l = () => (c && ((c = !1), (s = o ? ei(r) : r)), s);
  let u;
  if (a) {
    var d = Se in e || Ce in e;
    u = _(e, t)?.set ?? (d && t in e ? (n) => (e[t] = n) : void 0);
  }
  var f,
    p = !1;
  a ? ([f, p] = Ft(() => e[t])) : (f = e[t]),
    f === void 0 && r !== void 0 && ((f = l()), u && (i && Pe(t), u(f)));
  var m = i
    ? () => {
        var n = e[t];
        return n === void 0 ? l() : ((c = !0), n);
      }
    : () => {
        var n = e[t];
        return n !== void 0 && (s = void 0), n === void 0 ? s : n;
      };
  if (i && !(n & 4)) return m;
  if (u) {
    var h = e.$$legacy;
    return function (e, t) {
      return arguments.length > 0
        ? ((!i || !t || h || p) && u(t ? m() : e), e)
        : m();
    };
  }
  var g = !1,
    v = (n & 1 ? un : pn)(() => ((g = !1), m()));
  a && L(v);
  var y = I;
  return function (e, t) {
    if (arguments.length > 0) {
      let n = t ? L(v) : i && a ? jn(e) : e;
      return Tn(v, n), (g = !0), s !== void 0 && (s = n), e;
    }
    return (kr && g) || y.f & 16384 ? v.v : L(v);
  };
}
function so(e) {
  E === null && De(`onMount`),
    it && E.l !== null
      ? lo(E).m.push(e)
      : or(() => {
          let t = ei(e);
          if (typeof t == `function`) return t;
        });
}
function co(e) {
  E === null && De(`onDestroy`), so(() => () => ei(e));
}
function lo(e) {
  var t = e.l;
  return (t.u ??= { a: [], b: [], m: [] });
}
var z = (() => {
    let e = new Map();
    return Object.freeze({
      on: (t, n) => {
        let r = e.get(t);
        r ? r.push(n) : e.set(t, [n]);
      },
      off: (t, n) => {
        let r = e.get(t);
        r &&
          e.set(
            t,
            r.filter((e) => e !== n)
          );
      },
      emit: (t, n) => {
        let r = e.get(t);
        r && r.forEach((e) => e(n));
      },
    });
  })(),
  uo = `data-smartsupp-id`,
  fo = () => window.top ?? window.parent,
  B = () => window.parent,
  po = () => B().document,
  mo = (e) => (e && e.ownerDocument) || document,
  ho = ({ vid: e }) => {
    let t = B().smartsupp || {};
    (t.vid = e), (B().smartsupp = t);
  },
  go = `debug`,
  _o = (e) => {
    try {
      let t = B().localStorage.getItem(go);
      if (!t) return !1;
      if (t === e || t === `*`) return !0;
      let n = e.match(/^\w+:/g);
      return n ? t === `${n[0]}*` : !1;
    } catch {
      return !1;
    }
  },
  vo = (
    (e, t) =>
    (n, ...r) => {
      _o(e) && console.debug(`%c${e}`, `color: ${t};`, n, ...r);
    }
  )(`smartsupp:widget`, `#1233df`),
  V = (() => {
    let e = null,
      t = [];
    return Object.freeze({
      init: (n) => {
        (e = n), vo(`widget options`, n), t.forEach((e) => e(n));
      },
      getOptions: () => {
        if (!e) throw Error(`Widget options not initialized`);
        return e;
      },
      awaitOptions: async () =>
        e ||
        new Promise((e) => {
          t.push(e);
        }),
      updateOptions: (t) => {
        e = { ...e, ...t };
      },
    });
  })(),
  yo = (e) => {
    let t = e.document.getElementsByTagName(`body`)[0].getAttribute(uo);
    if (!t) throw Error(`Missing chat ID attribute on body element.`);
    if (!e.parent.$smartsupp)
      throw Error(
        `Something went wrong. Seems like loader.js did not initialize widget.`
      );
    if (!e.parent.$smartsupp.getWidget)
      throw Error(`Get widget function was not supplied by loader.js.`);
    return e.parent.$smartsupp.getWidget(t);
  };
function bo(e) {
  for (var t = 1; t < arguments.length; t++) {
    var n = arguments[t];
    for (var r in n) e[r] = n[r];
  }
  return e;
}
var xo = {
  read: function (e) {
    return (
      e[0] === `"` && (e = e.slice(1, -1)),
      e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
    );
  },
  write: function (e) {
    return encodeURIComponent(e).replace(
      /%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,
      decodeURIComponent
    );
  },
};
function So(e, t) {
  function n(n, r, i) {
    if (!(typeof document > `u`)) {
      (i = bo({}, t, i)),
        typeof i.expires == `number` &&
          (i.expires = new Date(Date.now() + i.expires * 864e5)),
        (i.expires &&= i.expires.toUTCString()),
        (n = encodeURIComponent(n)
          .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
          .replace(/[()]/g, escape));
      var a = ``;
      for (var o in i)
        i[o] &&
          ((a += `; ` + o), i[o] !== !0 && (a += `=` + i[o].split(`;`)[0]));
      return (document.cookie = n + `=` + e.write(r, n) + a);
    }
  }
  function r(t) {
    if (!(typeof document > `u` || (arguments.length && !t))) {
      for (
        var n = document.cookie ? document.cookie.split(`; `) : [],
          r = {},
          i = 0;
        i < n.length;
        i++
      ) {
        var a = n[i].split(`=`),
          o = a.slice(1).join(`=`);
        try {
          var s = decodeURIComponent(a[0]);
          if (((r[s] = e.read(o, s)), t === s)) break;
        } catch {}
      }
      return t ? r[t] : r;
    }
  }
  return Object.create(
    {
      set: n,
      get: r,
      remove: function (e, t) {
        n(e, ``, bo({}, t, { expires: -1 }));
      },
      withAttributes: function (e) {
        return So(this.converter, bo({}, this.attributes, e));
      },
      withConverter: function (e) {
        return So(bo({}, this.converter, e), this.attributes);
      },
    },
    {
      attributes: { value: Object.freeze(t) },
      converter: { value: Object.freeze(e) },
    }
  );
}
var Co = So(xo, { path: `/` }),
  wo = `ssupp`,
  To = (e = 182) => ({
    expires: e,
    domain: V.getOptions().cookieDomain,
    path: V.getOptions().cookiePath || `/`,
    sameSite: `strict`,
    secure: B().location.protocol === `https:`,
  }),
  Eo = (e) => `${V.getOptions().cookiePrefix || ``}${wo}.${e}`,
  Do = ({ name: e, value: t, expirationInDays: n = 182, options: r }) => {
    Co.set(Eo(e), t, { ...To(n), ...r });
  },
  Oo = (e) => Co.get(Eo(e)),
  ko = (e) => {
    let t = Eo(e);
    if (Co.get(t)) {
      let { path: e, domain: n } = To();
      Co.remove(t, { path: e, domain: n });
    }
  },
  Ao =
    (e) =>
    (t, ...n) => {
      e(`[Smartsupp] ${t}`, ...n);
    },
  H = Ao(console.warn),
  jo = Ao(console.error),
  Mo = () => {
    let { key: e } = V.getOptions();
    return `${
      B().SMARTSUPP_AUTOCREATE === !1 ? `${yo(window).id}_${wo}` : wo
    }_${e}`;
  },
  No = (e) => `${Mo()}${e ? `_${e}` : ``}`,
  Po = (e) => {
    try {
      let t = window.localStorage.getItem(No(e)) ?? `{}`;
      return JSON.parse(t);
    } catch {
      return {};
    }
  },
  Fo = (e, t) => {
    try {
      window.localStorage.setItem(No(t), JSON.stringify(e));
    } catch (e) {
      H(`Set to local storage failed`, e);
    }
  },
  Io = (e, t) => {
    Fo({ ...Po(), [e]: String(t) });
  },
  Lo = (e) => {
    let t = Po();
    t[e] && (delete t[e], Fo(t));
  },
  Ro = () => {
    window.localStorage.removeItem(No()),
      window.localStorage.removeItem(No(`cards`));
  },
  U = (function (e) {
    return (
      (e.AnalyticsConsent = `analyticsConsent`),
      (e.AuthForm = `authForm`),
      (e.IsMessengerFrameExpanded = `isMessengerFrameExpanded`),
      (e.IsMessengerFrameOpened = `opened`),
      (e.MarketingConsent = `marketingConsent`),
      (e.Message = `message`),
      (e.PopupClosedAt = `popupClosedAt`),
      (e.RatingText = `ratingText`),
      (e.SoundsEnabled = `enableSounds`),
      (e.VisitorId = `vid`),
      (e.Visits = `visits`),
      (e.TicketForm = `ticketForm`),
      (e.SessionId = `sessionId`),
      e
    );
  })({}),
  zo = (e) => {
    let t = ``;
    return (
      e === U.VisitorId && V.getOptions().cookieDomain && (t = Oo(e)),
      t || Po()[e]
    );
  },
  Bo = ({ name: e, value: t }) => {
    e === U.VisitorId &&
      V.getOptions().cookieDomain &&
      Do({ name: e, value: t }),
      Io(e, t);
  },
  Vo = (e) => {
    Lo(e);
  };
z.on(`analyticsConsentChanged`, (e) => {
  Bo({ name: U.AnalyticsConsent, value: String(e) });
}),
  z.on(`marketingConsentChanged`, (e) => {
    Bo({ name: U.MarketingConsent, value: String(e) });
  });
var Ho = () => !!V.getOptions().consentModeEnabled,
  Uo = () => {
    let e = zo(U.AnalyticsConsent) === `true`;
    return !(Ho() && !e);
  },
  Wo = () => {
    let e = zo(U.MarketingConsent) === `true`;
    return !(Ho() && !e);
  },
  Go = `modulepreload`,
  Ko = function (e, t) {
    return new URL(e, t).href;
  },
  qo = {},
  Jo = function (e, t, n) {
    let r = Promise.resolve();
    if (t && t.length > 0) {
      let e = document.getElementsByTagName(`link`),
        i = document.querySelector(`meta[property=csp-nonce]`),
        a = i?.nonce || i?.getAttribute(`nonce`);
      function o(e) {
        return Promise.all(
          e.map((e) =>
            Promise.resolve(e).then(
              (e) => ({ status: `fulfilled`, value: e }),
              (e) => ({ status: `rejected`, reason: e })
            )
          )
        );
      }
      r = o(
        t.map((t) => {
          if (((t = Ko(t, n)), t in qo)) return;
          qo[t] = !0;
          let r = t.endsWith(`.css`),
            i = r ? `[rel="stylesheet"]` : ``;
          if (n)
            for (let n = e.length - 1; n >= 0; n--) {
              let i = e[n];
              if (i.href === t && (!r || i.rel === `stylesheet`)) return;
            }
          else if (document.querySelector(`link[href="${t}"]${i}`)) return;
          let o = document.createElement(`link`);
          if (
            ((o.rel = r ? `stylesheet` : Go),
            r || (o.as = `script`),
            (o.crossOrigin = ``),
            (o.href = t),
            a && o.setAttribute(`nonce`, a),
            document.head.appendChild(o),
            r)
          )
            return new Promise((e, n) => {
              o.addEventListener(`load`, e),
                o.addEventListener(`error`, () =>
                  n(Error(`Unable to preload CSS for ${t}`))
                );
            });
        })
      );
    }
    function i(e) {
      let t = new Event(`vite:preloadError`, { cancelable: !0 });
      if (((t.payload = e), window.dispatchEvent(t), !t.defaultPrevented))
        throw e;
    }
    return r.then((t) => {
      for (let e of t || []) e.status === `rejected` && i(e.reason);
      return e().catch(i);
    });
  },
  Yo = () => !!V.getOptions().crossDomainEnabled,
  Xo = () => V.getOptions().allowedDomains.length > 0,
  Zo = async () => {
    try {
      let e = await new (
        await Jo(
          () => import(`./thumbmark.esm-CP4CU0yL.js`),
          [],
          import.meta.url
        )
      ).Thumbmark().get();
      return vo(`Visitor fingerprint created`, e.thumbmark), e.thumbmark;
    } catch (e) {
      H(`Failed to generate fingerprint:`, e);
    }
  },
  Qo = async () => {
    if (!(!Yo() || !Xo())) return Zo();
  },
  $o = () => zo(U.VisitorId) || null,
  es = (e) => Bo({ name: U.VisitorId, value: String(e) }),
  ts = () => {
    if (Wo()) return zo(U.Visits) ? Number(zo(U.Visits)) : 0;
  },
  ns = (e) => {
    Wo() && Bo({ name: U.Visits, value: String(e) });
  };
z.on(`marketingConsentChanged`, (e) => {
  e || Vo(U.Visits);
});
var rs = (e, t, n) => {
    let { set: r, subscribe: i } = O(t, (t) => {
        let r = zo(e);
        r && t(n ? n(r) : r);
      }),
      a = (t) => {
        Bo({ name: e, value: String(t) });
      };
    return {
      set: (e) => {
        a(e), r(e);
      },
      subscribe: i,
    };
  },
  is = () => `ontouchstart` in window || navigator.msMaxTouchPoints > 0,
  as = () =>
    [
      `iPad Simulator`,
      `iPhone Simulator`,
      `iPod Simulator`,
      `iPad`,
      `iPhone`,
      `iPod`,
    ].includes(navigator.platform) ||
    (navigator.userAgent.includes(`Mac`) && `ontouchend` in document),
  os = O(null),
  ss = k(
    [os, O({ width: B().innerWidth, height: B().innerHeight })],
    ([e, t]) => {
      let { widgetBlockingOptions: n } = V.getOptions();
      if (n?.enforceDesktopMode) return !1;
      if (e) {
        let { isMobile: t, isTablet: n } = e;
        if (n) return !1;
        if (t) return !0;
      }
      return t.width < 450 || t.height < 500;
    }
  ),
  cs = k([ss], ([e]) => {
    let { fullScreenEnabled: t } = V.getOptions();
    return !!(e || t);
  }),
  ls = k([os], ([e]) => (e ? !!e?.isDesktop && !as() : !is())),
  us = k([ls, cs], ([e, t]) => e && !t);
k([os], ([e]) => !!e?.isTablet);
var ds = (() => {
    let e = O({}),
      { subscribe: t, update: n } = e;
    return {
      subscribe: t,
      add: (e) => {
        n((t) => ({ ...t, [e.id]: e }));
      },
      remove: (e) => {
        n((t) => {
          let { [e]: n, ...r } = t;
          return r;
        });
      },
      find: (t) => A(e)[t] || null,
    };
  })(),
  fs = k([ds], ([e]) => Object.values(e)),
  ps =
    (e) =>
    (t, n = 3e3) => {
      let r = `fm-${e}-${t}`,
        i = ds.find(r),
        a = 1;
      i && (clearTimeout(i.timeout), (a = i.recurrence + 1));
      let o;
      return (
        n > 0 &&
          (o = window.setTimeout(() => {
            ms(r);
          }, n)),
        ds.add({ id: r, type: e, text: t, timeout: o, recurrence: a }),
        () => ms(r)
      );
    },
  ms = (e) => {
    ds.remove(e);
  },
  hs = ps(`success`),
  gs = ps(`error`),
  _s = ps(`warning`),
  vs = (function (e) {
    return (
      (e[(e.Good = 5)] = `Good`),
      (e[(e.Normal = 3)] = `Normal`),
      (e[(e.Bad = 1)] = `Bad`),
      e
    );
  })({}),
  ys = {
    [vs.Good]: {
      value: vs.Good,
      text: `agentRating.good.formText`,
      name: `good`,
    },
    [vs.Normal]: {
      value: vs.Normal,
      text: `agentRating.normal.formText`,
      name: `neutral`,
    },
    [vs.Bad]: { value: vs.Bad, text: `agentRating.bad.formText`, name: `bad` },
  },
  bs = Object.values(ys).sort((e, t) => t.value - e.value),
  xs = `rate_form_id`,
  Ss = {
    id: xs,
    type: `message`,
    subType: `system`,
    channel: { type: `default`, id: null },
    chatId: ``,
    visitorId: ``,
    groupId: null,
    agentId: null,
    trigger: null,
    createdAt: ``,
    content: { type: `rate_form`, data: {} },
    attachments: [],
    subject: null,
    forwardedMessageId: null,
    participants: [],
    replyToMessageId: null,
    deletedAt: null,
    widgetOptions: {
      disableInput: !1,
      disableAuthentication: !1,
      disableAttachments: !1,
    },
  },
  Cs = O(null),
  ws = s((e, t) => {
    var n = 1e3,
      r = n * 60,
      i = r * 60,
      a = i * 24,
      o = a * 7,
      s = a * 365.25;
    t.exports = function (e, t) {
      t ||= {};
      var n = typeof e;
      if (n === `string` && e.length > 0) return c(e);
      if (n === `number` && isFinite(e)) return t.long ? u(e) : l(e);
      throw Error(
        `val is not a non-empty string or a valid number. val=` +
          JSON.stringify(e)
      );
    };
    function c(e) {
      if (((e = String(e)), !(e.length > 100))) {
        var t =
          /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
            e
          );
        if (t) {
          var c = parseFloat(t[1]);
          switch ((t[2] || `ms`).toLowerCase()) {
            case `years`:
            case `year`:
            case `yrs`:
            case `yr`:
            case `y`:
              return c * s;
            case `weeks`:
            case `week`:
            case `w`:
              return c * o;
            case `days`:
            case `day`:
            case `d`:
              return c * a;
            case `hours`:
            case `hour`:
            case `hrs`:
            case `hr`:
            case `h`:
              return c * i;
            case `minutes`:
            case `minute`:
            case `mins`:
            case `min`:
            case `m`:
              return c * r;
            case `seconds`:
            case `second`:
            case `secs`:
            case `sec`:
            case `s`:
              return c * n;
            case `milliseconds`:
            case `millisecond`:
            case `msecs`:
            case `msec`:
            case `ms`:
              return c;
            default:
              return;
          }
        }
      }
    }
    function l(e) {
      var t = Math.abs(e);
      return t >= a
        ? Math.round(e / a) + `d`
        : t >= i
        ? Math.round(e / i) + `h`
        : t >= r
        ? Math.round(e / r) + `m`
        : t >= n
        ? Math.round(e / n) + `s`
        : e + `ms`;
    }
    function u(e) {
      var t = Math.abs(e);
      return t >= a
        ? d(e, t, a, `day`)
        : t >= i
        ? d(e, t, i, `hour`)
        : t >= r
        ? d(e, t, r, `minute`)
        : t >= n
        ? d(e, t, n, `second`)
        : e + ` ms`;
    }
    function d(e, t, n, r) {
      var i = t >= n * 1.5;
      return Math.round(e / n) + ` ` + r + (i ? `s` : ``);
    }
  }),
  Ts = s((e, t) => {
    function n(e) {
      (n.debug = n),
        (n.default = n),
        (n.coerce = c),
        (n.disable = o),
        (n.enable = i),
        (n.enabled = s),
        (n.humanize = ws()),
        (n.destroy = l),
        Object.keys(e).forEach((t) => {
          n[t] = e[t];
        }),
        (n.names = []),
        (n.skips = []),
        (n.formatters = {});
      function t(e) {
        let t = 0;
        for (let n = 0; n < e.length; n++)
          (t = (t << 5) - t + e.charCodeAt(n)), (t |= 0);
        return n.colors[Math.abs(t) % n.colors.length];
      }
      n.selectColor = t;
      function n(e) {
        let t,
          i = null,
          a,
          o;
        function s(...e) {
          if (!s.enabled) return;
          let r = s,
            i = Number(new Date());
          (r.diff = i - (t || i)),
            (r.prev = t),
            (r.curr = i),
            (t = i),
            (e[0] = n.coerce(e[0])),
            typeof e[0] != `string` && e.unshift(`%O`);
          let a = 0;
          (e[0] = e[0].replace(/%([a-zA-Z%])/g, (t, i) => {
            if (t === `%%`) return `%`;
            a++;
            let o = n.formatters[i];
            if (typeof o == `function`) {
              let n = e[a];
              (t = o.call(r, n)), e.splice(a, 1), a--;
            }
            return t;
          })),
            n.formatArgs.call(r, e),
            (r.log || n.log).apply(r, e);
        }
        return (
          (s.namespace = e),
          (s.useColors = n.useColors()),
          (s.color = n.selectColor(e)),
          (s.extend = r),
          (s.destroy = n.destroy),
          Object.defineProperty(s, `enabled`, {
            enumerable: !0,
            configurable: !1,
            get: () =>
              i === null
                ? (a !== n.namespaces &&
                    ((a = n.namespaces), (o = n.enabled(e))),
                  o)
                : i,
            set: (e) => {
              i = e;
            },
          }),
          typeof n.init == `function` && n.init(s),
          s
        );
      }
      function r(e, t) {
        let r = n(this.namespace + (t === void 0 ? `:` : t) + e);
        return (r.log = this.log), r;
      }
      function i(e) {
        n.save(e), (n.namespaces = e), (n.names = []), (n.skips = []);
        let t = (typeof e == `string` ? e : ``)
          .trim()
          .replace(/\s+/g, `,`)
          .split(`,`)
          .filter(Boolean);
        for (let e of t)
          e[0] === `-` ? n.skips.push(e.slice(1)) : n.names.push(e);
      }
      function a(e, t) {
        let n = 0,
          r = 0,
          i = -1,
          a = 0;
        for (; n < e.length; )
          if (r < t.length && (t[r] === e[n] || t[r] === `*`))
            t[r] === `*` ? ((i = r), (a = n), r++) : (n++, r++);
          else if (i !== -1) (r = i + 1), a++, (n = a);
          else return !1;
        for (; r < t.length && t[r] === `*`; ) r++;
        return r === t.length;
      }
      function o() {
        let e = [...n.names, ...n.skips.map((e) => `-` + e)].join(`,`);
        return n.enable(``), e;
      }
      function s(e) {
        for (let t of n.skips) if (a(e, t)) return !1;
        for (let t of n.names) if (a(e, t)) return !0;
        return !1;
      }
      function c(e) {
        return e instanceof Error ? e.stack || e.message : e;
      }
      function l() {
        console.warn(
          "Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."
        );
      }
      return n.enable(n.load()), n;
    }
    t.exports = n;
  }),
  Es = s((e, t) => {
    (e.formatArgs = r),
      (e.save = i),
      (e.load = a),
      (e.useColors = n),
      (e.storage = o()),
      (e.destroy = (() => {
        let e = !1;
        return () => {
          e ||
            ((e = !0),
            console.warn(
              "Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."
            ));
        };
      })()),
      (e.colors =
        `#0000CC.#0000FF.#0033CC.#0033FF.#0066CC.#0066FF.#0099CC.#0099FF.#00CC00.#00CC33.#00CC66.#00CC99.#00CCCC.#00CCFF.#3300CC.#3300FF.#3333CC.#3333FF.#3366CC.#3366FF.#3399CC.#3399FF.#33CC00.#33CC33.#33CC66.#33CC99.#33CCCC.#33CCFF.#6600CC.#6600FF.#6633CC.#6633FF.#66CC00.#66CC33.#9900CC.#9900FF.#9933CC.#9933FF.#99CC00.#99CC33.#CC0000.#CC0033.#CC0066.#CC0099.#CC00CC.#CC00FF.#CC3300.#CC3333.#CC3366.#CC3399.#CC33CC.#CC33FF.#CC6600.#CC6633.#CC9900.#CC9933.#CCCC00.#CCCC33.#FF0000.#FF0033.#FF0066.#FF0099.#FF00CC.#FF00FF.#FF3300.#FF3333.#FF3366.#FF3399.#FF33CC.#FF33FF.#FF6600.#FF6633.#FF9900.#FF9933.#FFCC00.#FFCC33`.split(
          `.`
        ));
    function n() {
      if (
        typeof window < `u` &&
        window.process &&
        (window.process.type === `renderer` || window.process.__nwjs)
      )
        return !0;
      if (
        typeof navigator < `u` &&
        navigator.userAgent &&
        navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)
      )
        return !1;
      let e;
      return (
        (typeof document < `u` &&
          document.documentElement &&
          document.documentElement.style &&
          document.documentElement.style.WebkitAppearance) ||
        (typeof window < `u` &&
          window.console &&
          (window.console.firebug ||
            (window.console.exception && window.console.table))) ||
        (typeof navigator < `u` &&
          navigator.userAgent &&
          (e = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) &&
          parseInt(e[1], 10) >= 31) ||
        (typeof navigator < `u` &&
          navigator.userAgent &&
          navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/))
      );
    }
    function r(e) {
      if (
        ((e[0] =
          (this.useColors ? `%c` : ``) +
          this.namespace +
          (this.useColors ? ` %c` : ` `) +
          e[0] +
          (this.useColors ? `%c ` : ` `) +
          `+` +
          t.exports.humanize(this.diff)),
        !this.useColors)
      )
        return;
      let n = `color: ` + this.color;
      e.splice(1, 0, n, `color: inherit`);
      let r = 0,
        i = 0;
      e[0].replace(/%[a-zA-Z%]/g, (e) => {
        e !== `%%` && (r++, e === `%c` && (i = r));
      }),
        e.splice(i, 0, n);
    }
    e.log = console.debug || console.log || (() => {});
    function i(t) {
      try {
        t ? e.storage.setItem(`debug`, t) : e.storage.removeItem(`debug`);
      } catch {}
    }
    function a() {
      let t;
      try {
        t = e.storage.getItem(`debug`) || e.storage.getItem(`DEBUG`);
      } catch {}
      return (
        !t && typeof process < `u` && `env` in process && (t = {}.DEBUG), t
      );
    }
    function o() {
      try {
        return localStorage;
      } catch {}
    }
    t.exports = Ts()(e);
    var { formatters: s } = t.exports;
    s.j = function (e) {
      try {
        return JSON.stringify(e);
      } catch (e) {
        return `[UnexpectedJSONParseError]: ` + e.message;
      }
    };
  }),
  Ds = s((e) => {
    var t =
      (e && e.__extends) ||
      (function () {
        var e = function (t, n) {
          return (
            (e =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var n in t)
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              }),
            e(t, n)
          );
        };
        return function (t, n) {
          if (typeof n != `function` && n !== null)
            throw TypeError(
              `Class extends value ` +
                String(n) +
                ` is not a constructor or null`
            );
          e(t, n);
          function r() {
            this.constructor = t;
          }
          t.prototype =
            n === null
              ? Object.create(n)
              : ((r.prototype = n.prototype), new r());
        };
      })();
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.createEmitter =
        e.createCallback =
        e.bound =
        e.createSocketError =
        e.SocketError =
        e.debug =
          void 0),
      (e.debug = n());
    function n() {
      try {
        return Es()(`smartsupp:client`);
      } catch {
        return function () {};
      }
    }
    var r = (function (e) {
      t(n, e);
      function n(t, r) {
        var i = e.call(this, t) || this;
        return (
          Object.setPrototypeOf(i, n.prototype),
          (i.name = i.constructor.name),
          (i.code = r.code),
          (i.type = r.type),
          (i.event = r.event),
          r &&
            r.stack &&
            (i.stack = `${i.stack}
Caused By: ${r.stack}`),
          i
        );
      }
      return n;
    })(Error);
    e.SocketError = r;
    function i(e) {
      return new r(e.message, e);
    }
    e.createSocketError = i;
    function a(e, t) {
      return function () {
        var n = [...arguments];
        e[t].apply(e, n);
      };
    }
    e.bound = a;
    function o(e, t) {
      return function (n, r) {
        n ? t(i(n)) : e(r);
      };
    }
    e.createCallback = o;
    function s(e, t) {
      return function (n) {
        e.emit(t, n);
      };
    }
    e.createEmitter = s;
  }),
  Os = s((e, t) => {
    var n = Object.prototype.hasOwnProperty,
      r = `~`;
    function i() {}
    Object.create &&
      ((i.prototype = Object.create(null)), new i().__proto__ || (r = !1));
    function a(e, t, n) {
      (this.fn = e), (this.context = t), (this.once = n || !1);
    }
    function o(e, t, n, i, o) {
      if (typeof n != `function`)
        throw TypeError(`The listener must be a function`);
      var s = new a(n, i || e, o),
        c = r ? r + t : t;
      return (
        e._events[c]
          ? e._events[c].fn
            ? (e._events[c] = [e._events[c], s])
            : e._events[c].push(s)
          : ((e._events[c] = s), e._eventsCount++),
        e
      );
    }
    function s(e, t) {
      --e._eventsCount === 0 ? (e._events = new i()) : delete e._events[t];
    }
    function c() {
      (this._events = new i()), (this._eventsCount = 0);
    }
    (c.prototype.eventNames = function () {
      var e = [],
        t,
        i;
      if (this._eventsCount === 0) return e;
      for (i in (t = this._events)) n.call(t, i) && e.push(r ? i.slice(1) : i);
      return Object.getOwnPropertySymbols
        ? e.concat(Object.getOwnPropertySymbols(t))
        : e;
    }),
      (c.prototype.listeners = function (e) {
        var t = r ? r + e : e,
          n = this._events[t];
        if (!n) return [];
        if (n.fn) return [n.fn];
        for (var i = 0, a = n.length, o = Array(a); i < a; i++) o[i] = n[i].fn;
        return o;
      }),
      (c.prototype.listenerCount = function (e) {
        var t = r ? r + e : e,
          n = this._events[t];
        return n ? (n.fn ? 1 : n.length) : 0;
      }),
      (c.prototype.emit = function (e, t, n, i, a, o) {
        var s = r ? r + e : e;
        if (!this._events[s]) return !1;
        var c = this._events[s],
          l = arguments.length,
          u,
          d;
        if (c.fn) {
          switch ((c.once && this.removeListener(e, c.fn, void 0, !0), l)) {
            case 1:
              return c.fn.call(c.context), !0;
            case 2:
              return c.fn.call(c.context, t), !0;
            case 3:
              return c.fn.call(c.context, t, n), !0;
            case 4:
              return c.fn.call(c.context, t, n, i), !0;
            case 5:
              return c.fn.call(c.context, t, n, i, a), !0;
            case 6:
              return c.fn.call(c.context, t, n, i, a, o), !0;
          }
          for (d = 1, u = Array(l - 1); d < l; d++) u[d - 1] = arguments[d];
          c.fn.apply(c.context, u);
        } else {
          var f = c.length,
            p;
          for (d = 0; d < f; d++)
            switch (
              (c[d].once && this.removeListener(e, c[d].fn, void 0, !0), l)
            ) {
              case 1:
                c[d].fn.call(c[d].context);
                break;
              case 2:
                c[d].fn.call(c[d].context, t);
                break;
              case 3:
                c[d].fn.call(c[d].context, t, n);
                break;
              case 4:
                c[d].fn.call(c[d].context, t, n, i);
                break;
              default:
                if (!u)
                  for (p = 1, u = Array(l - 1); p < l; p++)
                    u[p - 1] = arguments[p];
                c[d].fn.apply(c[d].context, u);
            }
        }
        return !0;
      }),
      (c.prototype.on = function (e, t, n) {
        return o(this, e, t, n, !1);
      }),
      (c.prototype.once = function (e, t, n) {
        return o(this, e, t, n, !0);
      }),
      (c.prototype.removeListener = function (e, t, n, i) {
        var a = r ? r + e : e;
        if (!this._events[a]) return this;
        if (!t) return s(this, a), this;
        var o = this._events[a];
        if (o.fn)
          o.fn === t && (!i || o.once) && (!n || o.context === n) && s(this, a);
        else {
          for (var c = 0, l = [], u = o.length; c < u; c++)
            (o[c].fn !== t || (i && !o[c].once) || (n && o[c].context !== n)) &&
              l.push(o[c]);
          l.length ? (this._events[a] = l.length === 1 ? l[0] : l) : s(this, a);
        }
        return this;
      }),
      (c.prototype.removeAllListeners = function (e) {
        var t;
        return (
          e
            ? ((t = r ? r + e : e), this._events[t] && s(this, t))
            : ((this._events = new i()), (this._eventsCount = 0)),
          this
        );
      }),
      (c.prototype.off = c.prototype.removeListener),
      (c.prototype.addListener = c.prototype.on),
      (c.prefixed = r),
      (c.EventEmitter = c),
      t !== void 0 && (t.exports = c);
  }),
  ks = s((e, t) => {
    var n =
        /^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/,
      r = [
        `source`,
        `protocol`,
        `authority`,
        `userInfo`,
        `user`,
        `password`,
        `host`,
        `port`,
        `relative`,
        `path`,
        `directory`,
        `file`,
        `query`,
        `anchor`,
      ];
    t.exports = function (e) {
      var t = e,
        o = e.indexOf(`[`),
        s = e.indexOf(`]`);
      o != -1 &&
        s != -1 &&
        (e =
          e.substring(0, o) +
          e.substring(o, s).replace(/:/g, `;`) +
          e.substring(s, e.length));
      for (var c = n.exec(e || ``), l = {}, u = 14; u--; ) l[r[u]] = c[u] || ``;
      return (
        o != -1 &&
          s != -1 &&
          ((l.source = t),
          (l.host = l.host.substring(1, l.host.length - 1).replace(/;/g, `:`)),
          (l.authority = l.authority
            .replace(`[`, ``)
            .replace(`]`, ``)
            .replace(/;/g, `:`)),
          (l.ipv6uri = !0)),
        (l.pathNames = i(l, l.path)),
        (l.queryKey = a(l, l.query)),
        l
      );
    };
    function i(e, t) {
      var n = t.replace(/\/{2,9}/g, `/`).split(`/`);
      return (
        (t.substr(0, 1) == `/` || t.length === 0) && n.splice(0, 1),
        t.substr(t.length - 1, 1) == `/` && n.splice(n.length - 1, 1),
        n
      );
    }
    function a(e, t) {
      var n = {};
      return (
        t.replace(/(?:^|&)([^&=]*)=?([^&]*)/g, function (e, t, r) {
          t && (n[t] = r);
        }),
        n
      );
    }
  }),
  As = s((e, t) => {
    var n = 1e3,
      r = n * 60,
      i = r * 60,
      a = i * 24,
      o = a * 365.25;
    t.exports = function (e, t) {
      t ||= {};
      var n = typeof e;
      if (n === `string` && e.length > 0) return s(e);
      if (n === `number` && isNaN(e) === !1) return t.long ? l(e) : c(e);
      throw Error(
        `val is not a non-empty string or a valid number. val=` +
          JSON.stringify(e)
      );
    };
    function s(e) {
      if (((e = String(e)), !(e.length > 100))) {
        var t =
          /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(
            e
          );
        if (t) {
          var s = parseFloat(t[1]);
          switch ((t[2] || `ms`).toLowerCase()) {
            case `years`:
            case `year`:
            case `yrs`:
            case `yr`:
            case `y`:
              return s * o;
            case `days`:
            case `day`:
            case `d`:
              return s * a;
            case `hours`:
            case `hour`:
            case `hrs`:
            case `hr`:
            case `h`:
              return s * i;
            case `minutes`:
            case `minute`:
            case `mins`:
            case `min`:
            case `m`:
              return s * r;
            case `seconds`:
            case `second`:
            case `secs`:
            case `sec`:
            case `s`:
              return s * n;
            case `milliseconds`:
            case `millisecond`:
            case `msecs`:
            case `msec`:
            case `ms`:
              return s;
            default:
              return;
          }
        }
      }
    }
    function c(e) {
      return e >= a
        ? Math.round(e / a) + `d`
        : e >= i
        ? Math.round(e / i) + `h`
        : e >= r
        ? Math.round(e / r) + `m`
        : e >= n
        ? Math.round(e / n) + `s`
        : e + `ms`;
    }
    function l(e) {
      return (
        u(e, a, `day`) ||
        u(e, i, `hour`) ||
        u(e, r, `minute`) ||
        u(e, n, `second`) ||
        e + ` ms`
      );
    }
    function u(e, t, n) {
      if (!(e < t))
        return e < t * 1.5
          ? Math.floor(e / t) + ` ` + n
          : Math.ceil(e / t) + ` ` + n + `s`;
    }
  }),
  js = s((e, t) => {
    (e = t.exports = r.debug = r.default = r),
      (e.coerce = c),
      (e.disable = o),
      (e.enable = a),
      (e.enabled = s),
      (e.humanize = As()),
      (e.instances = []),
      (e.names = []),
      (e.skips = []),
      (e.formatters = {});
    function n(t) {
      var n = 0,
        r;
      for (r in t) (n = (n << 5) - n + t.charCodeAt(r)), (n |= 0);
      return e.colors[Math.abs(n) % e.colors.length];
    }
    function r(t) {
      var r;
      function a() {
        if (a.enabled) {
          var t = a,
            n = +new Date();
          (t.diff = n - (r || n)), (t.prev = r), (t.curr = n), (r = n);
          for (var i = Array(arguments.length), o = 0; o < i.length; o++)
            i[o] = arguments[o];
          (i[0] = e.coerce(i[0])), typeof i[0] != `string` && i.unshift(`%O`);
          var s = 0;
          (i[0] = i[0].replace(/%([a-zA-Z%])/g, function (n, r) {
            if (n === `%%`) return n;
            s++;
            var a = e.formatters[r];
            if (typeof a == `function`) {
              var o = i[s];
              (n = a.call(t, o)), i.splice(s, 1), s--;
            }
            return n;
          })),
            e.formatArgs.call(t, i),
            (a.log || e.log || console.log.bind(console)).apply(t, i);
        }
      }
      return (
        (a.namespace = t),
        (a.enabled = e.enabled(t)),
        (a.useColors = e.useColors()),
        (a.color = n(t)),
        (a.destroy = i),
        typeof e.init == `function` && e.init(a),
        e.instances.push(a),
        a
      );
    }
    function i() {
      var t = e.instances.indexOf(this);
      return t === -1 ? !1 : (e.instances.splice(t, 1), !0);
    }
    function a(t) {
      e.save(t), (e.names = []), (e.skips = []);
      var n,
        r = (typeof t == `string` ? t : ``).split(/[\s,]+/),
        i = r.length;
      for (n = 0; n < i; n++)
        r[n] &&
          ((t = r[n].replace(/\*/g, `.*?`)),
          t[0] === `-`
            ? e.skips.push(RegExp(`^` + t.substr(1) + `$`))
            : e.names.push(RegExp(`^` + t + `$`)));
      for (n = 0; n < e.instances.length; n++) {
        var a = e.instances[n];
        a.enabled = e.enabled(a.namespace);
      }
    }
    function o() {
      e.enable(``);
    }
    function s(t) {
      if (t[t.length - 1] === `*`) return !0;
      var n, r;
      for (n = 0, r = e.skips.length; n < r; n++)
        if (e.skips[n].test(t)) return !1;
      for (n = 0, r = e.names.length; n < r; n++)
        if (e.names[n].test(t)) return !0;
      return !1;
    }
    function c(e) {
      return e instanceof Error ? e.stack || e.message : e;
    }
  }),
  Ms = s((e, t) => {
    (e = t.exports = js()),
      (e.log = i),
      (e.formatArgs = r),
      (e.save = a),
      (e.load = o),
      (e.useColors = n),
      (e.storage =
        typeof chrome < `u` && chrome.storage !== void 0
          ? chrome.storage.local
          : s()),
      (e.colors =
        `#0000CC.#0000FF.#0033CC.#0033FF.#0066CC.#0066FF.#0099CC.#0099FF.#00CC00.#00CC33.#00CC66.#00CC99.#00CCCC.#00CCFF.#3300CC.#3300FF.#3333CC.#3333FF.#3366CC.#3366FF.#3399CC.#3399FF.#33CC00.#33CC33.#33CC66.#33CC99.#33CCCC.#33CCFF.#6600CC.#6600FF.#6633CC.#6633FF.#66CC00.#66CC33.#9900CC.#9900FF.#9933CC.#9933FF.#99CC00.#99CC33.#CC0000.#CC0033.#CC0066.#CC0099.#CC00CC.#CC00FF.#CC3300.#CC3333.#CC3366.#CC3399.#CC33CC.#CC33FF.#CC6600.#CC6633.#CC9900.#CC9933.#CCCC00.#CCCC33.#FF0000.#FF0033.#FF0066.#FF0099.#FF00CC.#FF00FF.#FF3300.#FF3333.#FF3366.#FF3399.#FF33CC.#FF33FF.#FF6600.#FF6633.#FF9900.#FF9933.#FFCC00.#FFCC33`.split(
          `.`
        ));
    function n() {
      return typeof window < `u` &&
        window.process &&
        window.process.type === `renderer`
        ? !0
        : typeof navigator < `u` &&
          navigator.userAgent &&
          navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)
        ? !1
        : (typeof document < `u` &&
            document.documentElement &&
            document.documentElement.style &&
            document.documentElement.style.WebkitAppearance) ||
          (typeof window < `u` &&
            window.console &&
            (window.console.firebug ||
              (window.console.exception && window.console.table))) ||
          (typeof navigator < `u` &&
            navigator.userAgent &&
            navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) &&
            parseInt(RegExp.$1, 10) >= 31) ||
          (typeof navigator < `u` &&
            navigator.userAgent &&
            navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/));
    }
    e.formatters.j = function (e) {
      try {
        return JSON.stringify(e);
      } catch (e) {
        return `[UnexpectedJSONParseError]: ` + e.message;
      }
    };
    function r(t) {
      var n = this.useColors;
      if (
        ((t[0] =
          (n ? `%c` : ``) +
          this.namespace +
          (n ? ` %c` : ` `) +
          t[0] +
          (n ? `%c ` : ` `) +
          `+` +
          e.humanize(this.diff)),
        n)
      ) {
        var r = `color: ` + this.color;
        t.splice(1, 0, r, `color: inherit`);
        var i = 0,
          a = 0;
        t[0].replace(/%[a-zA-Z%]/g, function (e) {
          e !== `%%` && (i++, e === `%c` && (a = i));
        }),
          t.splice(a, 0, r);
      }
    }
    function i() {
      return (
        typeof console == `object` &&
        console.log &&
        Function.prototype.apply.call(console.log, console, arguments)
      );
    }
    function a(t) {
      try {
        t == null ? e.storage.removeItem(`debug`) : (e.storage.debug = t);
      } catch {}
    }
    function o() {
      var t;
      try {
        t = e.storage.debug;
      } catch {}
      return (
        !t && typeof process < `u` && `env` in process && (t = {}.DEBUG), t
      );
    }
    e.enable(o());
    function s() {
      try {
        return window.localStorage;
      } catch {}
    }
  }),
  Ns = s((e, t) => {
    var n = ks(),
      r = Ms()(`socket.io-client:url`);
    t.exports = i;
    function i(e, t) {
      var i = e;
      (t ||= typeof location < `u` && location),
        (e ??= t.protocol + `//` + t.host),
        typeof e == `string` &&
          (e.charAt(0) === `/` &&
            (e = e.charAt(1) === `/` ? t.protocol + e : t.host + e),
          /^(https?|wss?):\/\//.test(e) ||
            (r(`protocol-less url %s`, e),
            (e = t === void 0 ? `https://` + e : t.protocol + `//` + e)),
          r(`parse %s`, e),
          (i = n(e))),
        i.port ||
          (/^(http|ws)$/.test(i.protocol)
            ? (i.port = `80`)
            : /^(http|ws)s$/.test(i.protocol) && (i.port = `443`)),
        (i.path = i.path || `/`);
      var a = i.host.indexOf(`:`) === -1 ? i.host : `[` + i.host + `]`;
      return (
        (i.id = i.protocol + `://` + a + `:` + i.port),
        (i.href =
          i.protocol +
          `://` +
          a +
          (t && t.port === i.port ? `` : `:` + i.port)),
        i
      );
    }
  }),
  Ps = s((e, t) => {
    t !== void 0 && (t.exports = n);
    function n(e) {
      if (e) return r(e);
    }
    function r(e) {
      for (var t in n.prototype) e[t] = n.prototype[t];
      return e;
    }
    (n.prototype.on = n.prototype.addEventListener =
      function (e, t) {
        return (
          (this._callbacks = this._callbacks || {}),
          (this._callbacks[`$` + e] = this._callbacks[`$` + e] || []).push(t),
          this
        );
      }),
      (n.prototype.once = function (e, t) {
        function n() {
          this.off(e, n), t.apply(this, arguments);
        }
        return (n.fn = t), this.on(e, n), this;
      }),
      (n.prototype.off =
        n.prototype.removeListener =
        n.prototype.removeAllListeners =
        n.prototype.removeEventListener =
          function (e, t) {
            if (
              ((this._callbacks = this._callbacks || {}), arguments.length == 0)
            )
              return (this._callbacks = {}), this;
            var n = this._callbacks[`$` + e];
            if (!n) return this;
            if (arguments.length == 1)
              return delete this._callbacks[`$` + e], this;
            for (var r, i = 0; i < n.length; i++)
              if (((r = n[i]), r === t || r.fn === t)) {
                n.splice(i, 1);
                break;
              }
            return n.length === 0 && delete this._callbacks[`$` + e], this;
          }),
      (n.prototype.emit = function (e) {
        this._callbacks = this._callbacks || {};
        for (
          var t = Array(arguments.length - 1),
            n = this._callbacks[`$` + e],
            r = 1;
          r < arguments.length;
          r++
        )
          t[r - 1] = arguments[r];
        if (n) {
          n = n.slice(0);
          for (var r = 0, i = n.length; r < i; ++r) n[r].apply(this, t);
        }
        return this;
      }),
      (n.prototype.listeners = function (e) {
        return (
          (this._callbacks = this._callbacks || {}),
          this._callbacks[`$` + e] || []
        );
      }),
      (n.prototype.hasListeners = function (e) {
        return !!this.listeners(e).length;
      });
  }),
  Fs = s((e, t) => {
    var n = {}.toString;
    t.exports =
      Array.isArray ||
      function (e) {
        return n.call(e) == `[object Array]`;
      };
  }),
  Is = s((e, t) => {
    t.exports = a;
    var n = typeof Buffer == `function` && typeof Buffer.isBuffer == `function`,
      r = typeof ArrayBuffer == `function`,
      i = function (e) {
        return typeof ArrayBuffer.isView == `function`
          ? ArrayBuffer.isView(e)
          : e.buffer instanceof ArrayBuffer;
      };
    function a(e) {
      return (
        (n && Buffer.isBuffer(e)) || (r && (e instanceof ArrayBuffer || i(e)))
      );
    }
  }),
  Ls = s((e) => {
    var t = Fs(),
      n = Is(),
      r = Object.prototype.toString,
      i =
        typeof Blob == `function` ||
        (typeof Blob < `u` && r.call(Blob) === `[object BlobConstructor]`),
      a =
        typeof File == `function` ||
        (typeof File < `u` && r.call(File) === `[object FileConstructor]`);
    e.deconstructPacket = function (e) {
      var t = [],
        n = e.data,
        r = e;
      return (
        (r.data = o(n, t)),
        (r.attachments = t.length),
        { packet: r, buffers: t }
      );
    };
    function o(e, r) {
      if (!e) return e;
      if (n(e)) {
        var i = { _placeholder: !0, num: r.length };
        return r.push(e), i;
      } else if (t(e)) {
        for (var a = Array(e.length), s = 0; s < e.length; s++)
          a[s] = o(e[s], r);
        return a;
      } else if (typeof e == `object` && !(e instanceof Date)) {
        var a = {};
        for (var c in e) a[c] = o(e[c], r);
        return a;
      }
      return e;
    }
    e.reconstructPacket = function (e, t) {
      return (e.data = s(e.data, t)), (e.attachments = void 0), e;
    };
    function s(e, n) {
      if (!e) return e;
      if (e && e._placeholder === !0) {
        if (typeof e.num == `number` && e.num >= 0 && e.num < n.length)
          return n[e.num];
        throw Error(`illegal attachments`);
      } else if (t(e)) for (var r = 0; r < e.length; r++) e[r] = s(e[r], n);
      else if (typeof e == `object`) for (var i in e) e[i] = s(e[i], n);
      return e;
    }
    e.removeBlobs = function (e, r) {
      function o(e, l, u) {
        if (!e) return e;
        if ((i && e instanceof Blob) || (a && e instanceof File)) {
          s++;
          var d = new FileReader();
          (d.onload = function () {
            u ? (u[l] = this.result) : (c = this.result), --s || r(c);
          }),
            d.readAsArrayBuffer(e);
        } else if (t(e)) for (var f = 0; f < e.length; f++) o(e[f], f, e);
        else if (typeof e == `object` && !n(e)) for (var p in e) o(e[p], p, e);
      }
      var s = 0,
        c = e;
      o(c), s || r(c);
    };
  }),
  Rs = s((e) => {
    var t = Ms()(`socket.io-parser`),
      n = Ps(),
      r = Ls(),
      i = Fs(),
      a = Is();
    (e.protocol = 4),
      (e.types = [
        `CONNECT`,
        `DISCONNECT`,
        `EVENT`,
        `ACK`,
        `ERROR`,
        `BINARY_EVENT`,
        `BINARY_ACK`,
      ]),
      (e.CONNECT = 0),
      (e.DISCONNECT = 1),
      (e.EVENT = 2),
      (e.ACK = 3),
      (e.ERROR = 4),
      (e.BINARY_EVENT = 5),
      (e.BINARY_ACK = 6),
      (e.Encoder = o),
      (e.Decoder = d);
    function o() {}
    var s = e.ERROR + `"encode error"`;
    o.prototype.encode = function (n, r) {
      t(`encoding packet %j`, n),
        e.BINARY_EVENT === n.type || e.BINARY_ACK === n.type
          ? u(n, r)
          : r([c(n)]);
    };
    function c(n) {
      var r = `` + n.type;
      if (
        ((e.BINARY_EVENT === n.type || e.BINARY_ACK === n.type) &&
          (r += n.attachments + `-`),
        n.nsp && n.nsp !== `/` && (r += n.nsp + `,`),
        n.id != null && (r += n.id),
        n.data != null)
      ) {
        var i = l(n.data);
        if (i !== !1) r += i;
        else return s;
      }
      return t(`encoded %j as %s`, n, r), r;
    }
    function l(e) {
      try {
        return JSON.stringify(e);
      } catch {
        return !1;
      }
    }
    function u(e, t) {
      function n(e) {
        var n = r.deconstructPacket(e),
          i = c(n.packet),
          a = n.buffers;
        a.unshift(i), t(a);
      }
      r.removeBlobs(e, n);
    }
    function d() {
      this.reconstructor = null;
    }
    n(d.prototype),
      (d.prototype.add = function (t) {
        var n;
        if (typeof t == `string`) {
          if (this.reconstructor)
            throw Error(`got plaintext data when reconstructing a packet`);
          (n = f(t)),
            e.BINARY_EVENT === n.type || e.BINARY_ACK === n.type
              ? ((this.reconstructor = new m(n)),
                this.reconstructor.reconPack.attachments === 0 &&
                  this.emit(`decoded`, n))
              : this.emit(`decoded`, n);
        } else if (a(t) || t.base64)
          if (this.reconstructor)
            (n = this.reconstructor.takeBinaryData(t)),
              n && ((this.reconstructor = null), this.emit(`decoded`, n));
          else throw Error(`got binary data when not reconstructing a packet`);
        else throw Error(`Unknown type: ` + t);
      });
    function f(n) {
      var r = 0,
        a = { type: Number(n.charAt(0)) };
      if (e.types[a.type] == null) return h(`unknown packet type ` + a.type);
      if (e.BINARY_EVENT === a.type || e.BINARY_ACK === a.type) {
        for (var o = r + 1; n.charAt(++r) !== `-` && r != n.length; );
        var s = n.substring(o, r);
        if (s != Number(s) || n.charAt(r) !== `-`)
          throw Error(`Illegal attachments`);
        a.attachments = Number(s);
      }
      if (n.charAt(r + 1) === `/`) {
        for (var o = r + 1; ++r; ) {
          var c = n.charAt(r);
          if (c === `,` || r === n.length) break;
        }
        a.nsp = n.substring(o, r);
      } else a.nsp = `/`;
      var l = n.charAt(r + 1);
      if (l !== `` && Number(l) == l) {
        for (var o = r + 1; ++r; ) {
          var c = n.charAt(r);
          if (c == null || Number(c) != c) {
            --r;
            break;
          }
          if (r === n.length) break;
        }
        a.id = Number(n.substring(o, r + 1));
      }
      if (n.charAt(++r)) {
        var u = p(n.substr(r));
        if (u !== !1 && (a.type === e.ERROR || i(u))) a.data = u;
        else return h(`invalid payload`);
      }
      return t(`decoded %s as %j`, n, a), a;
    }
    function p(e) {
      try {
        return JSON.parse(e);
      } catch {
        return !1;
      }
    }
    d.prototype.destroy = function () {
      this.reconstructor && this.reconstructor.finishedReconstruction();
    };
    function m(e) {
      (this.reconPack = e), (this.buffers = []);
    }
    (m.prototype.takeBinaryData = function (e) {
      if (
        (this.buffers.push(e),
        this.buffers.length === this.reconPack.attachments)
      ) {
        var t = r.reconstructPacket(this.reconPack, this.buffers);
        return this.finishedReconstruction(), t;
      }
      return null;
    }),
      (m.prototype.finishedReconstruction = function () {
        (this.reconPack = null), (this.buffers = []);
      });
    function h(t) {
      return { type: e.ERROR, data: `parser error: ` + t };
    }
  }),
  zs = s((e, t) => {
    try {
      t.exports =
        typeof XMLHttpRequest < `u` &&
        `withCredentials` in new XMLHttpRequest();
    } catch {
      t.exports = !1;
    }
  }),
  Bs = s((e, t) => {
    t.exports = (function () {
      return typeof self < `u`
        ? self
        : typeof window < `u`
        ? window
        : Function(`return this`)();
    })();
  }),
  Vs = s((e, t) => {
    var n = zs(),
      r = Bs();
    t.exports = function (e) {
      var t = e.xdomain,
        i = e.xscheme,
        a = e.enablesXDR;
      try {
        if (typeof XMLHttpRequest < `u` && (!t || n))
          return new XMLHttpRequest();
      } catch {}
      try {
        if (typeof XDomainRequest < `u` && !i && a) return new XDomainRequest();
      } catch {}
      if (!t)
        try {
          return new r[[`Active`, `Object`].join(`X`)](`Microsoft.XMLHTTP`);
        } catch {}
    };
  }),
  Hs = s((e, t) => {
    t.exports =
      Object.keys ||
      function (e) {
        var t = [],
          n = Object.prototype.hasOwnProperty;
        for (var r in e) n.call(e, r) && t.push(r);
        return t;
      };
  }),
  Us = s((e, t) => {
    var n = Fs(),
      r = Object.prototype.toString,
      i =
        typeof Blob == `function` ||
        (typeof Blob < `u` && r.call(Blob) === `[object BlobConstructor]`),
      a =
        typeof File == `function` ||
        (typeof File < `u` && r.call(File) === `[object FileConstructor]`);
    t.exports = o;
    function o(e) {
      if (!e || typeof e != `object`) return !1;
      if (n(e)) {
        for (var t = 0, r = e.length; t < r; t++) if (o(e[t])) return !0;
        return !1;
      }
      if (
        (typeof Buffer == `function` &&
          Buffer.isBuffer &&
          Buffer.isBuffer(e)) ||
        (typeof ArrayBuffer == `function` && e instanceof ArrayBuffer) ||
        (i && e instanceof Blob) ||
        (a && e instanceof File)
      )
        return !0;
      if (e.toJSON && typeof e.toJSON == `function` && arguments.length === 1)
        return o(e.toJSON(), !0);
      for (var s in e)
        if (Object.prototype.hasOwnProperty.call(e, s) && o(e[s])) return !0;
      return !1;
    }
  }),
  Ws = s((e, t) => {
    t.exports = function (e, t, n) {
      var r = e.byteLength;
      if (((t ||= 0), (n ||= r), e.slice)) return e.slice(t, n);
      if (
        (t < 0 && (t += r),
        n < 0 && (n += r),
        n > r && (n = r),
        t >= r || t >= n || r === 0)
      )
        return new ArrayBuffer(0);
      for (
        var i = new Uint8Array(e), a = new Uint8Array(n - t), o = t, s = 0;
        o < n;
        o++, s++
      )
        a[s] = i[o];
      return a.buffer;
    };
  }),
  Gs = s((e, t) => {
    t.exports = n;
    function n(e, t, n) {
      var i = !1;
      return (n ||= r), (a.count = e), e === 0 ? t() : a;
      function a(e, r) {
        if (a.count <= 0) throw Error(`after called too many times`);
        --a.count,
          e ? ((i = !0), t(e), (t = n)) : a.count === 0 && !i && t(null, r);
      }
    }
    function r() {}
  }),
  Ks = s((e, t) => {
    var n = String.fromCharCode;
    function r(e) {
      for (var t = [], n = 0, r = e.length, i, a; n < r; )
        (i = e.charCodeAt(n++)),
          i >= 55296 && i <= 56319 && n < r
            ? ((a = e.charCodeAt(n++)),
              (a & 64512) == 56320
                ? t.push(((i & 1023) << 10) + (a & 1023) + 65536)
                : (t.push(i), n--))
            : t.push(i);
      return t;
    }
    function i(e) {
      for (var t = e.length, r = -1, i, a = ``; ++r < t; )
        (i = e[r]),
          i > 65535 &&
            ((i -= 65536),
            (a += n(((i >>> 10) & 1023) | 55296)),
            (i = 56320 | (i & 1023))),
          (a += n(i));
      return a;
    }
    function a(e, t) {
      if (e >= 55296 && e <= 57343) {
        if (t)
          throw Error(
            `Lone surrogate U+` +
              e.toString(16).toUpperCase() +
              ` is not a scalar value`
          );
        return !1;
      }
      return !0;
    }
    function o(e, t) {
      return n(((e >> t) & 63) | 128);
    }
    function s(e, t) {
      if (!(e & 4294967168)) return n(e);
      var r = ``;
      return (
        e & 4294965248
          ? e & 4294901760
            ? e & 4292870144 ||
              ((r = n(((e >> 18) & 7) | 240)), (r += o(e, 12)), (r += o(e, 6)))
            : (a(e, t) || (e = 65533),
              (r = n(((e >> 12) & 15) | 224)),
              (r += o(e, 6)))
          : (r = n(((e >> 6) & 31) | 192)),
        (r += n((e & 63) | 128)),
        r
      );
    }
    function c(e, t) {
      t ||= {};
      for (
        var n = !1 !== t.strict, i = r(e), a = i.length, o = -1, c, l = ``;
        ++o < a;

      )
        (c = i[o]), (l += s(c, n));
      return l;
    }
    function l() {
      if (p >= f) throw Error(`Invalid byte index`);
      var e = d[p] & 255;
      if ((p++, (e & 192) == 128)) return e & 63;
      throw Error(`Invalid continuation byte`);
    }
    function u(e) {
      var t, n, r, i, o;
      if (p > f) throw Error(`Invalid byte index`);
      if (p == f) return !1;
      if (((t = d[p] & 255), p++, !(t & 128))) return t;
      if ((t & 224) == 192) {
        if (((n = l()), (o = ((t & 31) << 6) | n), o >= 128)) return o;
        throw Error(`Invalid continuation byte`);
      }
      if ((t & 240) == 224) {
        if (
          ((n = l()),
          (r = l()),
          (o = ((t & 15) << 12) | (n << 6) | r),
          o >= 2048)
        )
          return a(o, e) ? o : 65533;
        throw Error(`Invalid continuation byte`);
      }
      if (
        (t & 248) == 240 &&
        ((n = l()),
        (r = l()),
        (i = l()),
        (o = ((t & 7) << 18) | (n << 12) | (r << 6) | i),
        o >= 65536 && o <= 1114111)
      )
        return o;
      throw Error(`Invalid UTF-8 detected`);
    }
    var d, f, p;
    function m(e, t) {
      t ||= {};
      var n = !1 !== t.strict;
      (d = r(e)), (f = d.length), (p = 0);
      for (var a = [], o; (o = u(n)) !== !1; ) a.push(o);
      return i(a);
    }
    t.exports = { version: `2.1.2`, encode: c, decode: m };
  }),
  qs = s((e) => {
    (function (t) {
      (e.encode = function (e) {
        var n = new Uint8Array(e),
          r,
          i = n.length,
          a = ``;
        for (r = 0; r < i; r += 3)
          (a += t[n[r] >> 2]),
            (a += t[((n[r] & 3) << 4) | (n[r + 1] >> 4)]),
            (a += t[((n[r + 1] & 15) << 2) | (n[r + 2] >> 6)]),
            (a += t[n[r + 2] & 63]);
        return (
          i % 3 == 2
            ? (a = a.substring(0, a.length - 1) + `=`)
            : i % 3 == 1 && (a = a.substring(0, a.length - 2) + `==`),
          a
        );
      }),
        (e.decode = function (e) {
          var n = e.length * 0.75,
            r = e.length,
            i,
            a = 0,
            o,
            s,
            c,
            l;
          e[e.length - 1] === `=` && (n--, e[e.length - 2] === `=` && n--);
          var u = new ArrayBuffer(n),
            d = new Uint8Array(u);
          for (i = 0; i < r; i += 4)
            (o = t.indexOf(e[i])),
              (s = t.indexOf(e[i + 1])),
              (c = t.indexOf(e[i + 2])),
              (l = t.indexOf(e[i + 3])),
              (d[a++] = (o << 2) | (s >> 4)),
              (d[a++] = ((s & 15) << 4) | (c >> 2)),
              (d[a++] = ((c & 3) << 6) | (l & 63));
          return u;
        });
    })(`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/`);
  }),
  Js = s((e, t) => {
    var n =
        n === void 0
          ? typeof WebKitBlobBuilder < `u`
            ? WebKitBlobBuilder
            : typeof MSBlobBuilder < `u`
            ? MSBlobBuilder
            : typeof MozBlobBuilder < `u`
            ? MozBlobBuilder
            : !1
          : n,
      r = (function () {
        try {
          return new Blob([`hi`]).size === 2;
        } catch {
          return !1;
        }
      })(),
      i =
        r &&
        (function () {
          try {
            return new Blob([new Uint8Array([1, 2])]).size === 2;
          } catch {
            return !1;
          }
        })(),
      a = n && n.prototype.append && n.prototype.getBlob;
    function o(e) {
      return e.map(function (e) {
        if (e.buffer instanceof ArrayBuffer) {
          var t = e.buffer;
          if (e.byteLength !== t.byteLength) {
            var n = new Uint8Array(e.byteLength);
            n.set(new Uint8Array(t, e.byteOffset, e.byteLength)),
              (t = n.buffer);
          }
          return t;
        }
        return e;
      });
    }
    function s(e, t) {
      t ||= {};
      var r = new n();
      return (
        o(e).forEach(function (e) {
          r.append(e);
        }),
        t.type ? r.getBlob(t.type) : r.getBlob()
      );
    }
    function c(e, t) {
      return new Blob(o(e), t || {});
    }
    typeof Blob < `u` &&
      ((s.prototype = Blob.prototype), (c.prototype = Blob.prototype)),
      (t.exports = (function () {
        if (r) return i ? Blob : c;
        if (a) return s;
      })());
  }),
  Ys = s((e) => {
    var t = Hs(),
      n = Us(),
      r = Ws(),
      i = Gs(),
      a = Ks(),
      o;
    typeof ArrayBuffer < `u` && (o = qs());
    var s = typeof navigator < `u` && /Android/i.test(navigator.userAgent),
      c = typeof navigator < `u` && /PhantomJS/i.test(navigator.userAgent),
      l = s || c;
    e.protocol = 3;
    var u = (e.packets = {
        open: 0,
        close: 1,
        ping: 2,
        pong: 3,
        message: 4,
        upgrade: 5,
        noop: 6,
      }),
      d = t(u),
      f = { type: `error`, data: `parser error` },
      p = Js();
    e.encodePacket = function (e, t, n, r) {
      typeof t == `function` && ((r = t), (t = !1)),
        typeof n == `function` && ((r = n), (n = null));
      var i = e.data === void 0 ? void 0 : e.data.buffer || e.data;
      if (typeof ArrayBuffer < `u` && i instanceof ArrayBuffer)
        return h(e, t, r);
      if (p !== void 0 && i instanceof p) return _(e, t, r);
      if (i && i.base64) return m(e, r);
      var o = u[e.type];
      return (
        e.data !== void 0 &&
          (o += n ? a.encode(String(e.data), { strict: !1 }) : String(e.data)),
        r(`` + o)
      );
    };
    function m(t, n) {
      return n(`b` + e.packets[t.type] + t.data.data);
    }
    function h(t, n, r) {
      if (!n) return e.encodeBase64Packet(t, r);
      var i = t.data,
        a = new Uint8Array(i),
        o = new Uint8Array(1 + i.byteLength);
      o[0] = u[t.type];
      for (var s = 0; s < a.length; s++) o[s + 1] = a[s];
      return r(o.buffer);
    }
    function g(t, n, r) {
      if (!n) return e.encodeBase64Packet(t, r);
      var i = new FileReader();
      return (
        (i.onload = function () {
          e.encodePacket({ type: t.type, data: i.result }, n, !0, r);
        }),
        i.readAsArrayBuffer(t.data)
      );
    }
    function _(t, n, r) {
      if (!n) return e.encodeBase64Packet(t, r);
      if (l) return g(t, n, r);
      var i = new Uint8Array(1);
      return (i[0] = u[t.type]), r(new p([i.buffer, t.data]));
    }
    (e.encodeBase64Packet = function (t, n) {
      var r = `b` + e.packets[t.type];
      if (p !== void 0 && t.data instanceof p) {
        var i = new FileReader();
        return (
          (i.onload = function () {
            var e = i.result.split(`,`)[1];
            n(r + e);
          }),
          i.readAsDataURL(t.data)
        );
      }
      var a;
      try {
        a = String.fromCharCode.apply(null, new Uint8Array(t.data));
      } catch {
        for (
          var o = new Uint8Array(t.data), s = Array(o.length), c = 0;
          c < o.length;
          c++
        )
          s[c] = o[c];
        a = String.fromCharCode.apply(null, s);
      }
      return (r += btoa(a)), n(r);
    }),
      (e.decodePacket = function (t, n, i) {
        if (t === void 0) return f;
        if (typeof t == `string`) {
          if (t.charAt(0) === `b`) return e.decodeBase64Packet(t.substr(1), n);
          if (i && ((t = v(t)), t === !1)) return f;
          var a = t.charAt(0);
          return Number(a) != a || !d[a]
            ? f
            : t.length > 1
            ? { type: d[a], data: t.substring(1) }
            : { type: d[a] };
        }
        var a = new Uint8Array(t)[0],
          o = r(t, 1);
        return p && n === `blob` && (o = new p([o])), { type: d[a], data: o };
      });
    function v(e) {
      try {
        e = a.decode(e, { strict: !1 });
      } catch {
        return !1;
      }
      return e;
    }
    (e.decodeBase64Packet = function (e, t) {
      var n = d[e.charAt(0)];
      if (!o) return { type: n, data: { base64: !0, data: e.substr(1) } };
      var r = o.decode(e.substr(1));
      return t === `blob` && p && (r = new p([r])), { type: n, data: r };
    }),
      (e.encodePayload = function (t, r, i) {
        typeof r == `function` && ((i = r), (r = null));
        var a = n(t);
        if (r && a)
          return p && !l
            ? e.encodePayloadAsBlob(t, i)
            : e.encodePayloadAsArrayBuffer(t, i);
        if (!t.length) return i(`0:`);
        function o(e) {
          return e.length + `:` + e;
        }
        function s(t, n) {
          e.encodePacket(t, a ? r : !1, !1, function (e) {
            n(null, o(e));
          });
        }
        y(t, s, function (e, t) {
          return i(t.join(``));
        });
      });
    function y(e, t, n) {
      for (
        var r = Array(e.length),
          a = i(e.length, n),
          o = function (e, n, i) {
            t(n, function (t, n) {
              (r[e] = n), i(t, r);
            });
          },
          s = 0;
        s < e.length;
        s++
      )
        o(s, e[s], a);
    }
    (e.decodePayload = function (t, n, r) {
      if (typeof t != `string`) return e.decodePayloadAsBinary(t, n, r);
      typeof n == `function` && ((r = n), (n = null));
      var i;
      if (t === ``) return r(f, 0, 1);
      for (var a = ``, o, s, c = 0, l = t.length; c < l; c++) {
        var u = t.charAt(c);
        if (u !== `:`) {
          a += u;
          continue;
        }
        if (
          a === `` ||
          a != (o = Number(a)) ||
          ((s = t.substr(c + 1, o)), a != s.length)
        )
          return r(f, 0, 1);
        if (s.length) {
          if (
            ((i = e.decodePacket(s, n, !1)),
            f.type === i.type && f.data === i.data)
          )
            return r(f, 0, 1);
          if (!1 === r(i, c + o, l)) return;
        }
        (c += o), (a = ``);
      }
      if (a !== ``) return r(f, 0, 1);
    }),
      (e.encodePayloadAsArrayBuffer = function (t, n) {
        if (!t.length) return n(new ArrayBuffer(0));
        function r(t, n) {
          e.encodePacket(t, !0, !0, function (e) {
            return n(null, e);
          });
        }
        y(t, r, function (e, t) {
          var r = t.reduce(function (e, t) {
              var n = typeof t == `string` ? t.length : t.byteLength;
              return e + n.toString().length + n + 2;
            }, 0),
            i = new Uint8Array(r),
            a = 0;
          return (
            t.forEach(function (e) {
              var t = typeof e == `string`,
                n = e;
              if (t) {
                for (var r = new Uint8Array(e.length), o = 0; o < e.length; o++)
                  r[o] = e.charCodeAt(o);
                n = r.buffer;
              }
              t ? (i[a++] = 0) : (i[a++] = 1);
              for (var s = n.byteLength.toString(), o = 0; o < s.length; o++)
                i[a++] = parseInt(s[o]);
              i[a++] = 255;
              for (var r = new Uint8Array(n), o = 0; o < r.length; o++)
                i[a++] = r[o];
            }),
            n(i.buffer)
          );
        });
      }),
      (e.encodePayloadAsBlob = function (t, n) {
        function r(t, n) {
          e.encodePacket(t, !0, !0, function (e) {
            var t = new Uint8Array(1);
            if (((t[0] = 1), typeof e == `string`)) {
              for (var r = new Uint8Array(e.length), i = 0; i < e.length; i++)
                r[i] = e.charCodeAt(i);
              (e = r.buffer), (t[0] = 0);
            }
            for (
              var a = (
                  e instanceof ArrayBuffer ? e.byteLength : e.size
                ).toString(),
                o = new Uint8Array(a.length + 1),
                i = 0;
              i < a.length;
              i++
            )
              o[i] = parseInt(a[i]);
            (o[a.length] = 255), p && n(null, new p([t.buffer, o.buffer, e]));
          });
        }
        y(t, r, function (e, t) {
          return n(new p(t));
        });
      }),
      (e.decodePayloadAsBinary = function (t, n, i) {
        typeof n == `function` && ((i = n), (n = null));
        for (var a = t, o = []; a.byteLength > 0; ) {
          for (
            var s = new Uint8Array(a), c = s[0] === 0, l = ``, u = 1;
            s[u] !== 255;
            u++
          ) {
            if (l.length > 310) return i(f, 0, 1);
            l += s[u];
          }
          (a = r(a, 2 + l.length)), (l = parseInt(l));
          var d = r(a, 0, l);
          if (c)
            try {
              d = String.fromCharCode.apply(null, new Uint8Array(d));
            } catch {
              var p = new Uint8Array(d);
              d = ``;
              for (var u = 0; u < p.length; u++) d += String.fromCharCode(p[u]);
            }
          o.push(d), (a = r(a, l));
        }
        var m = o.length;
        o.forEach(function (t, r) {
          i(e.decodePacket(t, n, !0), r, m);
        });
      });
  }),
  Xs = s((e, t) => {
    var n = Ys(),
      r = Ps();
    t.exports = i;
    function i(e) {
      (this.path = e.path),
        (this.hostname = e.hostname),
        (this.port = e.port),
        (this.secure = e.secure),
        (this.query = e.query),
        (this.timestampParam = e.timestampParam),
        (this.timestampRequests = e.timestampRequests),
        (this.readyState = ``),
        (this.agent = e.agent || !1),
        (this.socket = e.socket),
        (this.enablesXDR = e.enablesXDR),
        (this.withCredentials = e.withCredentials),
        (this.pfx = e.pfx),
        (this.key = e.key),
        (this.passphrase = e.passphrase),
        (this.cert = e.cert),
        (this.ca = e.ca),
        (this.ciphers = e.ciphers),
        (this.rejectUnauthorized = e.rejectUnauthorized),
        (this.forceNode = e.forceNode),
        (this.isReactNative = e.isReactNative),
        (this.extraHeaders = e.extraHeaders),
        (this.localAddress = e.localAddress);
    }
    r(i.prototype),
      (i.prototype.onError = function (e, t) {
        var n = Error(e);
        return (
          (n.type = `TransportError`),
          (n.description = t),
          this.emit(`error`, n),
          this
        );
      }),
      (i.prototype.open = function () {
        return (
          (this.readyState === `closed` || this.readyState === ``) &&
            ((this.readyState = `opening`), this.doOpen()),
          this
        );
      }),
      (i.prototype.close = function () {
        return (
          (this.readyState === `opening` || this.readyState === `open`) &&
            (this.doClose(), this.onClose()),
          this
        );
      }),
      (i.prototype.send = function (e) {
        if (this.readyState === `open`) this.write(e);
        else throw Error(`Transport not open`);
      }),
      (i.prototype.onOpen = function () {
        (this.readyState = `open`), (this.writable = !0), this.emit(`open`);
      }),
      (i.prototype.onData = function (e) {
        var t = n.decodePacket(e, this.socket.binaryType);
        this.onPacket(t);
      }),
      (i.prototype.onPacket = function (e) {
        this.emit(`packet`, e);
      }),
      (i.prototype.onClose = function () {
        (this.readyState = `closed`), this.emit(`close`);
      });
  }),
  Zs = s((e) => {
    (e.encode = function (e) {
      var t = ``;
      for (var n in e)
        e.hasOwnProperty(n) &&
          (t.length && (t += `&`),
          (t += encodeURIComponent(n) + `=` + encodeURIComponent(e[n])));
      return t;
    }),
      (e.decode = function (e) {
        for (var t = {}, n = e.split(`&`), r = 0, i = n.length; r < i; r++) {
          var a = n[r].split(`=`);
          t[decodeURIComponent(a[0])] = decodeURIComponent(a[1]);
        }
        return t;
      });
  }),
  Qs = s((e, t) => {
    t.exports = function (e, t) {
      var n = function () {};
      (n.prototype = t.prototype),
        (e.prototype = new n()),
        (e.prototype.constructor = e);
    };
  }),
  $s = s((e, t) => {
    var n =
        `0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_`.split(
          ``
        ),
      r = 64,
      i = {},
      a = 0,
      o = 0,
      s;
    function c(e) {
      var t = ``;
      do (t = n[e % r] + t), (e = Math.floor(e / r));
      while (e > 0);
      return t;
    }
    function l(e) {
      var t = 0;
      for (o = 0; o < e.length; o++) t = t * r + i[e.charAt(o)];
      return t;
    }
    function u() {
      var e = c(+new Date());
      return e === s ? e + `.` + c(a++) : ((a = 0), (s = e));
    }
    for (; o < r; o++) i[n[o]] = o;
    (u.encode = c), (u.decode = l), (t.exports = u);
  }),
  ec = s((e, t) => {
    var n = Xs(),
      r = Zs(),
      i = Ys(),
      a = Qs(),
      o = $s(),
      s = Ms()(`engine.io-client:polling`);
    t.exports = l;
    var c = (function () {
      return new (Vs())({ xdomain: !1 }).responseType != null;
    })();
    function l(e) {
      var t = e && e.forceBase64;
      (!c || t) && (this.supportsBinary = !1), n.call(this, e);
    }
    a(l, n),
      (l.prototype.name = `polling`),
      (l.prototype.doOpen = function () {
        this.poll();
      }),
      (l.prototype.pause = function (e) {
        var t = this;
        this.readyState = `pausing`;
        function n() {
          s(`paused`), (t.readyState = `paused`), e();
        }
        if (this.polling || !this.writable) {
          var r = 0;
          this.polling &&
            (s(`we are currently polling - waiting to pause`),
            r++,
            this.once(`pollComplete`, function () {
              s(`pre-pause polling complete`), --r || n();
            })),
            this.writable ||
              (s(`we are currently writing - waiting to pause`),
              r++,
              this.once(`drain`, function () {
                s(`pre-pause writing complete`), --r || n();
              }));
        } else n();
      }),
      (l.prototype.poll = function () {
        s(`polling`), (this.polling = !0), this.doPoll(), this.emit(`poll`);
      }),
      (l.prototype.onData = function (e) {
        var t = this;
        s(`polling got data %s`, e),
          i.decodePayload(e, this.socket.binaryType, function (e, n, r) {
            if (
              (t.readyState === `opening` && e.type === `open` && t.onOpen(),
              e.type === `close`)
            )
              return t.onClose(), !1;
            t.onPacket(e);
          }),
          this.readyState !== `closed` &&
            ((this.polling = !1),
            this.emit(`pollComplete`),
            this.readyState === `open`
              ? this.poll()
              : s(`ignoring poll - transport state "%s"`, this.readyState));
      }),
      (l.prototype.doClose = function () {
        var e = this;
        function t() {
          s(`writing close packet`), e.write([{ type: `close` }]);
        }
        this.readyState === `open`
          ? (s(`transport open - closing`), t())
          : (s(`transport not open - deferring close`), this.once(`open`, t));
      }),
      (l.prototype.write = function (e) {
        var t = this;
        this.writable = !1;
        var n = function () {
          (t.writable = !0), t.emit(`drain`);
        };
        i.encodePayload(e, this.supportsBinary, function (e) {
          t.doWrite(e, n);
        });
      }),
      (l.prototype.uri = function () {
        var e = this.query || {},
          t = this.secure ? `https` : `http`,
          n = ``;
        !1 !== this.timestampRequests && (e[this.timestampParam] = o()),
          !this.supportsBinary && !e.sid && (e.b64 = 1),
          (e = r.encode(e)),
          this.port &&
            ((t === `https` && Number(this.port) !== 443) ||
              (t === `http` && Number(this.port) !== 80)) &&
            (n = `:` + this.port),
          e.length && (e = `?` + e);
        var i = this.hostname.indexOf(`:`) !== -1;
        return (
          t +
          `://` +
          (i ? `[` + this.hostname + `]` : this.hostname) +
          n +
          this.path +
          e
        );
      });
  }),
  tc = s((e, t) => {
    var n = Vs(),
      r = ec(),
      i = Ps(),
      a = Qs(),
      o = Ms()(`engine.io-client:polling-xhr`),
      s = Bs();
    (t.exports = l), (t.exports.Request = u);
    function c() {}
    function l(e) {
      if (
        (r.call(this, e),
        (this.requestTimeout = e.requestTimeout),
        (this.extraHeaders = e.extraHeaders),
        typeof location < `u`)
      ) {
        var t = location.protocol === `https:`,
          n = location.port;
        (n ||= t ? 443 : 80),
          (this.xd =
            (typeof location < `u` && e.hostname !== location.hostname) ||
            n !== e.port),
          (this.xs = e.secure !== t);
      }
    }
    a(l, r),
      (l.prototype.supportsBinary = !0),
      (l.prototype.request = function (e) {
        return (
          (e ||= {}),
          (e.uri = this.uri()),
          (e.xd = this.xd),
          (e.xs = this.xs),
          (e.agent = this.agent || !1),
          (e.supportsBinary = this.supportsBinary),
          (e.enablesXDR = this.enablesXDR),
          (e.withCredentials = this.withCredentials),
          (e.pfx = this.pfx),
          (e.key = this.key),
          (e.passphrase = this.passphrase),
          (e.cert = this.cert),
          (e.ca = this.ca),
          (e.ciphers = this.ciphers),
          (e.rejectUnauthorized = this.rejectUnauthorized),
          (e.requestTimeout = this.requestTimeout),
          (e.extraHeaders = this.extraHeaders),
          new u(e)
        );
      }),
      (l.prototype.doWrite = function (e, t) {
        var n = typeof e != `string` && e !== void 0,
          r = this.request({ method: `POST`, data: e, isBinary: n }),
          i = this;
        r.on(`success`, t),
          r.on(`error`, function (e) {
            i.onError(`xhr post error`, e);
          }),
          (this.sendXhr = r);
      }),
      (l.prototype.doPoll = function () {
        o(`xhr poll`);
        var e = this.request(),
          t = this;
        e.on(`data`, function (e) {
          t.onData(e);
        }),
          e.on(`error`, function (e) {
            t.onError(`xhr poll error`, e);
          }),
          (this.pollXhr = e);
      });
    function u(e) {
      (this.method = e.method || `GET`),
        (this.uri = e.uri),
        (this.xd = !!e.xd),
        (this.xs = !!e.xs),
        (this.async = !1 !== e.async),
        (this.data = e.data === void 0 ? null : e.data),
        (this.agent = e.agent),
        (this.isBinary = e.isBinary),
        (this.supportsBinary = e.supportsBinary),
        (this.enablesXDR = e.enablesXDR),
        (this.withCredentials = e.withCredentials),
        (this.requestTimeout = e.requestTimeout),
        (this.pfx = e.pfx),
        (this.key = e.key),
        (this.passphrase = e.passphrase),
        (this.cert = e.cert),
        (this.ca = e.ca),
        (this.ciphers = e.ciphers),
        (this.rejectUnauthorized = e.rejectUnauthorized),
        (this.extraHeaders = e.extraHeaders),
        this.create();
    }
    if (
      (i(u.prototype),
      (u.prototype.create = function () {
        var e = {
          agent: this.agent,
          xdomain: this.xd,
          xscheme: this.xs,
          enablesXDR: this.enablesXDR,
        };
        (e.pfx = this.pfx),
          (e.key = this.key),
          (e.passphrase = this.passphrase),
          (e.cert = this.cert),
          (e.ca = this.ca),
          (e.ciphers = this.ciphers),
          (e.rejectUnauthorized = this.rejectUnauthorized);
        var t = (this.xhr = new n(e)),
          r = this;
        try {
          o(`xhr open %s: %s`, this.method, this.uri),
            t.open(this.method, this.uri, this.async);
          try {
            if (this.extraHeaders)
              for (var i in (t.setDisableHeaderCheck &&
                t.setDisableHeaderCheck(!0),
              this.extraHeaders))
                this.extraHeaders.hasOwnProperty(i) &&
                  t.setRequestHeader(i, this.extraHeaders[i]);
          } catch {}
          if (this.method === `POST`)
            try {
              this.isBinary
                ? t.setRequestHeader(`Content-type`, `application/octet-stream`)
                : t.setRequestHeader(
                    `Content-type`,
                    `text/plain;charset=UTF-8`
                  );
            } catch {}
          try {
            t.setRequestHeader(`Accept`, `*/*`);
          } catch {}
          `withCredentials` in t && (t.withCredentials = this.withCredentials),
            this.requestTimeout && (t.timeout = this.requestTimeout),
            this.hasXDR()
              ? ((t.onload = function () {
                  r.onLoad();
                }),
                (t.onerror = function () {
                  r.onError(t.responseText);
                }))
              : (t.onreadystatechange = function () {
                  if (t.readyState === 2)
                    try {
                      var e = t.getResponseHeader(`Content-Type`);
                      ((r.supportsBinary && e === `application/octet-stream`) ||
                        e === `application/octet-stream; charset=UTF-8`) &&
                        (t.responseType = `arraybuffer`);
                    } catch {}
                  t.readyState === 4 &&
                    (t.status === 200 || t.status === 1223
                      ? r.onLoad()
                      : setTimeout(function () {
                          r.onError(typeof t.status == `number` ? t.status : 0);
                        }, 0));
                }),
            o(`xhr data %s`, this.data),
            t.send(this.data);
        } catch (e) {
          setTimeout(function () {
            r.onError(e);
          }, 0);
          return;
        }
        typeof document < `u` &&
          ((this.index = u.requestsCount++), (u.requests[this.index] = this));
      }),
      (u.prototype.onSuccess = function () {
        this.emit(`success`), this.cleanup();
      }),
      (u.prototype.onData = function (e) {
        this.emit(`data`, e), this.onSuccess();
      }),
      (u.prototype.onError = function (e) {
        this.emit(`error`, e), this.cleanup(!0);
      }),
      (u.prototype.cleanup = function (e) {
        if (!(this.xhr === void 0 || this.xhr === null)) {
          if (
            (this.hasXDR()
              ? (this.xhr.onload = this.xhr.onerror = c)
              : (this.xhr.onreadystatechange = c),
            e)
          )
            try {
              this.xhr.abort();
            } catch {}
          typeof document < `u` && delete u.requests[this.index],
            (this.xhr = null);
        }
      }),
      (u.prototype.onLoad = function () {
        var e;
        try {
          var t;
          try {
            t = this.xhr.getResponseHeader(`Content-Type`);
          } catch {}
          e =
            ((t === `application/octet-stream` ||
              t === `application/octet-stream; charset=UTF-8`) &&
              this.xhr.response) ||
            this.xhr.responseText;
        } catch (e) {
          this.onError(e);
        }
        e != null && this.onData(e);
      }),
      (u.prototype.hasXDR = function () {
        return typeof XDomainRequest < `u` && !this.xs && this.enablesXDR;
      }),
      (u.prototype.abort = function () {
        this.cleanup();
      }),
      (u.requestsCount = 0),
      (u.requests = {}),
      typeof document < `u`)
    ) {
      if (typeof attachEvent == `function`) attachEvent(`onunload`, f);
      else if (typeof addEventListener == `function`) {
        var d = `onpagehide` in s ? `pagehide` : `unload`;
        addEventListener(d, f, !1);
      }
    }
    function f() {
      for (var e in u.requests)
        u.requests.hasOwnProperty(e) && u.requests[e].abort();
    }
  }),
  nc = s((e, t) => {
    var n = ec(),
      r = Qs(),
      i = Bs();
    t.exports = l;
    var a = /\n/g,
      o = /\\n/g,
      s;
    function c() {}
    function l(e) {
      n.call(this, e),
        (this.query = this.query || {}),
        (s ||= i.___eio = i.___eio || []),
        (this.index = s.length);
      var t = this;
      s.push(function (e) {
        t.onData(e);
      }),
        (this.query.j = this.index),
        typeof addEventListener == `function` &&
          addEventListener(
            `beforeunload`,
            function () {
              t.script && (t.script.onerror = c);
            },
            !1
          );
    }
    r(l, n),
      (l.prototype.supportsBinary = !1),
      (l.prototype.doClose = function () {
        (this.script &&=
          (this.script.parentNode.removeChild(this.script), null)),
          this.form &&
            (this.form.parentNode.removeChild(this.form),
            (this.form = null),
            (this.iframe = null)),
          n.prototype.doClose.call(this);
      }),
      (l.prototype.doPoll = function () {
        var e = this,
          t = document.createElement(`script`);
        (this.script &&=
          (this.script.parentNode.removeChild(this.script), null)),
          (t.async = !0),
          (t.src = this.uri()),
          (t.onerror = function (t) {
            e.onError(`jsonp poll error`, t);
          });
        var n = document.getElementsByTagName(`script`)[0];
        n
          ? n.parentNode.insertBefore(t, n)
          : (document.head || document.body).appendChild(t),
          (this.script = t),
          typeof navigator < `u` &&
            /gecko/i.test(navigator.userAgent) &&
            setTimeout(function () {
              var e = document.createElement(`iframe`);
              document.body.appendChild(e), document.body.removeChild(e);
            }, 100);
      }),
      (l.prototype.doWrite = function (e, t) {
        var n = this;
        if (!this.form) {
          var r = document.createElement(`form`),
            i = document.createElement(`textarea`),
            s = (this.iframeId = `eio_iframe_` + this.index),
            c;
          (r.className = `socketio`),
            (r.style.position = `absolute`),
            (r.style.top = `-1000px`),
            (r.style.left = `-1000px`),
            (r.target = s),
            (r.method = `POST`),
            r.setAttribute(`accept-charset`, `utf-8`),
            (i.name = `d`),
            r.appendChild(i),
            document.body.appendChild(r),
            (this.form = r),
            (this.area = i);
        }
        this.form.action = this.uri();
        function l() {
          u(), t();
        }
        function u() {
          if (n.iframe)
            try {
              n.form.removeChild(n.iframe);
            } catch (e) {
              n.onError(`jsonp polling iframe removal error`, e);
            }
          try {
            var e = `<iframe src="javascript:0" name="` + n.iframeId + `">`;
            c = document.createElement(e);
          } catch {
            (c = document.createElement(`iframe`)),
              (c.name = n.iframeId),
              (c.src = `javascript:0`);
          }
          (c.id = n.iframeId), n.form.appendChild(c), (n.iframe = c);
        }
        u(),
          (e = e.replace(
            o,
            `\\
`
          )),
          (this.area.value = e.replace(a, `\\n`));
        try {
          this.form.submit();
        } catch {}
        this.iframe.attachEvent
          ? (this.iframe.onreadystatechange = function () {
              n.iframe.readyState === `complete` && l();
            })
          : (this.iframe.onload = l);
      });
  }),
  rc = s((e, t) => {
    t.exports = {};
  }),
  ic = s((e, t) => {
    var n = Xs(),
      r = Ys(),
      i = Zs(),
      a = Qs(),
      o = $s(),
      s = Ms()(`engine.io-client:websocket`),
      c,
      l;
    if (
      (typeof WebSocket < `u`
        ? (c = WebSocket)
        : typeof self < `u` && (c = self.WebSocket || self.MozWebSocket),
      typeof window > `u`)
    )
      try {
        l = rc();
      } catch {}
    var u = c || l;
    t.exports = d;
    function d(e) {
      e && e.forceBase64 && (this.supportsBinary = !1),
        (this.perMessageDeflate = e.perMessageDeflate),
        (this.usingBrowserWebSocket = c && !e.forceNode),
        (this.protocols = e.protocols),
        this.usingBrowserWebSocket || (u = l),
        n.call(this, e);
    }
    a(d, n),
      (d.prototype.name = `websocket`),
      (d.prototype.supportsBinary = !0),
      (d.prototype.doOpen = function () {
        if (this.check()) {
          var e = this.uri(),
            t = this.protocols,
            n = {};
          this.isReactNative ||
            ((n.agent = this.agent),
            (n.perMessageDeflate = this.perMessageDeflate),
            (n.pfx = this.pfx),
            (n.key = this.key),
            (n.passphrase = this.passphrase),
            (n.cert = this.cert),
            (n.ca = this.ca),
            (n.ciphers = this.ciphers),
            (n.rejectUnauthorized = this.rejectUnauthorized)),
            this.extraHeaders && (n.headers = this.extraHeaders),
            this.localAddress && (n.localAddress = this.localAddress);
          try {
            this.ws =
              this.usingBrowserWebSocket && !this.isReactNative
                ? t
                  ? new u(e, t)
                  : new u(e)
                : new u(e, t, n);
          } catch (e) {
            return this.emit(`error`, e);
          }
          this.ws.binaryType === void 0 && (this.supportsBinary = !1),
            this.ws.supports && this.ws.supports.binary
              ? ((this.supportsBinary = !0),
                (this.ws.binaryType = `nodebuffer`))
              : (this.ws.binaryType = `arraybuffer`),
            this.addEventListeners();
        }
      }),
      (d.prototype.addEventListeners = function () {
        var e = this;
        (this.ws.onopen = function () {
          e.onOpen();
        }),
          (this.ws.onclose = function () {
            e.onClose();
          }),
          (this.ws.onmessage = function (t) {
            e.onData(t.data);
          }),
          (this.ws.onerror = function (t) {
            e.onError(`websocket error`, t);
          });
      }),
      (d.prototype.write = function (e) {
        var t = this;
        this.writable = !1;
        for (var n = e.length, i = 0, a = n; i < a; i++)
          (function (e) {
            r.encodePacket(e, t.supportsBinary, function (r) {
              if (!t.usingBrowserWebSocket) {
                var i = {};
                e.options && (i.compress = e.options.compress),
                  t.perMessageDeflate &&
                    (typeof r == `string` ? Buffer.byteLength(r) : r.length) <
                      t.perMessageDeflate.threshold &&
                    (i.compress = !1);
              }
              try {
                t.usingBrowserWebSocket ? t.ws.send(r) : t.ws.send(r, i);
              } catch {
                s(`websocket closed before onclose event`);
              }
              --n || o();
            });
          })(e[i]);
        function o() {
          t.emit(`flush`),
            setTimeout(function () {
              (t.writable = !0), t.emit(`drain`);
            }, 0);
        }
      }),
      (d.prototype.onClose = function () {
        n.prototype.onClose.call(this);
      }),
      (d.prototype.doClose = function () {
        this.ws !== void 0 &&
          ((this.ws.onerror = function () {}), this.ws.close());
      }),
      (d.prototype.uri = function () {
        var e = this.query || {},
          t = this.secure ? `wss` : `ws`,
          n = ``;
        this.port &&
          ((t === `wss` && Number(this.port) !== 443) ||
            (t === `ws` && Number(this.port) !== 80)) &&
          (n = `:` + this.port),
          this.timestampRequests && (e[this.timestampParam] = o()),
          this.supportsBinary || (e.b64 = 1),
          (e = i.encode(e)),
          e.length && (e = `?` + e);
        var r = this.hostname.indexOf(`:`) !== -1;
        return (
          t +
          `://` +
          (r ? `[` + this.hostname + `]` : this.hostname) +
          n +
          this.path +
          e
        );
      }),
      (d.prototype.check = function () {
        return !!u && !(`__initialize` in u && this.name === d.prototype.name);
      });
  }),
  ac = s((e) => {
    var t = Vs(),
      n = tc(),
      r = nc(),
      i = ic();
    (e.polling = a), (e.websocket = i);
    function a(e) {
      var i,
        a = !1,
        o = !1,
        s = !1 !== e.jsonp;
      if (typeof location < `u`) {
        var c = location.protocol === `https:`,
          l = location.port;
        (l ||= c ? 443 : 80),
          (a = e.hostname !== location.hostname || l !== e.port),
          (o = e.secure !== c);
      }
      if (
        ((e.xdomain = a),
        (e.xscheme = o),
        (i = new t(e)),
        `open` in i && !e.forceJSONP)
      )
        return new n(e);
      if (!s) throw Error(`JSONP disabled`);
      return new r(e);
    }
  }),
  oc = s((e, t) => {
    var n = [].indexOf;
    t.exports = function (e, t) {
      if (n) return e.indexOf(t);
      for (var r = 0; r < e.length; ++r) if (e[r] === t) return r;
      return -1;
    };
  }),
  sc = s((e, t) => {
    var n = ac(),
      r = Ps(),
      i = Ms()(`engine.io-client:socket`),
      a = oc(),
      o = Ys(),
      s = ks(),
      c = Zs();
    t.exports = l;
    function l(e, t) {
      if (!(this instanceof l)) return new l(e, t);
      (t ||= {}),
        e && typeof e == `object` && ((t = e), (e = null)),
        e
          ? ((e = s(e)),
            (t.hostname = e.host),
            (t.secure = e.protocol === `https` || e.protocol === `wss`),
            (t.port = e.port),
            e.query && (t.query = e.query))
          : t.host && (t.hostname = s(t.host).host),
        (this.secure =
          t.secure == null
            ? typeof location < `u` && location.protocol === `https:`
            : t.secure),
        t.hostname && !t.port && (t.port = this.secure ? `443` : `80`),
        (this.agent = t.agent || !1),
        (this.hostname =
          t.hostname ||
          (typeof location < `u` ? location.hostname : `localhost`)),
        (this.port =
          t.port ||
          (typeof location < `u` && location.port
            ? location.port
            : this.secure
            ? 443
            : 80)),
        (this.query = t.query || {}),
        typeof this.query == `string` && (this.query = c.decode(this.query)),
        (this.upgrade = !1 !== t.upgrade),
        (this.path = (t.path || `/engine.io`).replace(/\/$/, ``) + `/`),
        (this.forceJSONP = !!t.forceJSONP),
        (this.jsonp = !1 !== t.jsonp),
        (this.forceBase64 = !!t.forceBase64),
        (this.enablesXDR = !!t.enablesXDR),
        (this.withCredentials = !1 !== t.withCredentials),
        (this.timestampParam = t.timestampParam || `t`),
        (this.timestampRequests = t.timestampRequests),
        (this.transports = t.transports || [`polling`, `websocket`]),
        (this.transportOptions = t.transportOptions || {}),
        (this.readyState = ``),
        (this.writeBuffer = []),
        (this.prevBufferLen = 0),
        (this.policyPort = t.policyPort || 843),
        (this.rememberUpgrade = t.rememberUpgrade || !1),
        (this.binaryType = null),
        (this.onlyBinaryUpgrades = t.onlyBinaryUpgrades),
        (this.perMessageDeflate =
          !1 === t.perMessageDeflate ? !1 : t.perMessageDeflate || {}),
        !0 === this.perMessageDeflate && (this.perMessageDeflate = {}),
        this.perMessageDeflate &&
          this.perMessageDeflate.threshold == null &&
          (this.perMessageDeflate.threshold = 1024),
        (this.pfx = t.pfx || void 0),
        (this.key = t.key || void 0),
        (this.passphrase = t.passphrase || void 0),
        (this.cert = t.cert || void 0),
        (this.ca = t.ca || void 0),
        (this.ciphers = t.ciphers || void 0),
        (this.rejectUnauthorized =
          t.rejectUnauthorized === void 0 ? !0 : t.rejectUnauthorized),
        (this.forceNode = !!t.forceNode),
        (this.isReactNative =
          typeof navigator < `u` &&
          typeof navigator.product == `string` &&
          navigator.product.toLowerCase() === `reactnative`),
        (typeof self > `u` || this.isReactNative) &&
          (t.extraHeaders &&
            Object.keys(t.extraHeaders).length > 0 &&
            (this.extraHeaders = t.extraHeaders),
          t.localAddress && (this.localAddress = t.localAddress)),
        (this.id = null),
        (this.upgrades = null),
        (this.pingInterval = null),
        (this.pingTimeout = null),
        (this.pingIntervalTimer = null),
        (this.pingTimeoutTimer = null),
        this.open();
    }
    (l.priorWebsocketSuccess = !1),
      r(l.prototype),
      (l.protocol = o.protocol),
      (l.Socket = l),
      (l.Transport = Xs()),
      (l.transports = ac()),
      (l.parser = Ys()),
      (l.prototype.createTransport = function (e) {
        i(`creating transport "%s"`, e);
        var t = u(this.query);
        (t.EIO = o.protocol), (t.transport = e);
        var r = this.transportOptions[e] || {};
        return (
          this.id && (t.sid = this.id),
          new n[e]({
            query: t,
            socket: this,
            agent: r.agent || this.agent,
            hostname: r.hostname || this.hostname,
            port: r.port || this.port,
            secure: r.secure || this.secure,
            path: r.path || this.path,
            forceJSONP: r.forceJSONP || this.forceJSONP,
            jsonp: r.jsonp || this.jsonp,
            forceBase64: r.forceBase64 || this.forceBase64,
            enablesXDR: r.enablesXDR || this.enablesXDR,
            withCredentials: r.withCredentials || this.withCredentials,
            timestampRequests: r.timestampRequests || this.timestampRequests,
            timestampParam: r.timestampParam || this.timestampParam,
            policyPort: r.policyPort || this.policyPort,
            pfx: r.pfx || this.pfx,
            key: r.key || this.key,
            passphrase: r.passphrase || this.passphrase,
            cert: r.cert || this.cert,
            ca: r.ca || this.ca,
            ciphers: r.ciphers || this.ciphers,
            rejectUnauthorized: r.rejectUnauthorized || this.rejectUnauthorized,
            perMessageDeflate: r.perMessageDeflate || this.perMessageDeflate,
            extraHeaders: r.extraHeaders || this.extraHeaders,
            forceNode: r.forceNode || this.forceNode,
            localAddress: r.localAddress || this.localAddress,
            requestTimeout: r.requestTimeout || this.requestTimeout,
            protocols: r.protocols || void 0,
            isReactNative: this.isReactNative,
          })
        );
      });
    function u(e) {
      var t = {};
      for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
      return t;
    }
    (l.prototype.open = function () {
      var e;
      if (
        this.rememberUpgrade &&
        l.priorWebsocketSuccess &&
        this.transports.indexOf(`websocket`) !== -1
      )
        e = `websocket`;
      else if (this.transports.length === 0) {
        var t = this;
        setTimeout(function () {
          t.emit(`error`, `No transports available`);
        }, 0);
        return;
      } else e = this.transports[0];
      this.readyState = `opening`;
      try {
        e = this.createTransport(e);
      } catch {
        this.transports.shift(), this.open();
        return;
      }
      e.open(), this.setTransport(e);
    }),
      (l.prototype.setTransport = function (e) {
        i(`setting transport %s`, e.name);
        var t = this;
        this.transport &&
          (i(`clearing existing transport %s`, this.transport.name),
          this.transport.removeAllListeners()),
          (this.transport = e),
          e
            .on(`drain`, function () {
              t.onDrain();
            })
            .on(`packet`, function (e) {
              t.onPacket(e);
            })
            .on(`error`, function (e) {
              t.onError(e);
            })
            .on(`close`, function () {
              t.onClose(`transport close`);
            });
      }),
      (l.prototype.probe = function (e) {
        i(`probing transport "%s"`, e);
        var t = this.createTransport(e, { probe: 1 }),
          n = !1,
          r = this;
        l.priorWebsocketSuccess = !1;
        function a() {
          if (r.onlyBinaryUpgrades) {
            var a = !this.supportsBinary && r.transport.supportsBinary;
            n ||= a;
          }
          n ||
            (i(`probe transport "%s" opened`, e),
            t.send([{ type: `ping`, data: `probe` }]),
            t.once(`packet`, function (a) {
              if (!n)
                if (a.type === `pong` && a.data === `probe`) {
                  if (
                    (i(`probe transport "%s" pong`, e),
                    (r.upgrading = !0),
                    r.emit(`upgrading`, t),
                    !t)
                  )
                    return;
                  (l.priorWebsocketSuccess = t.name === `websocket`),
                    i(`pausing current transport "%s"`, r.transport.name),
                    r.transport.pause(function () {
                      n ||
                        (r.readyState !== `closed` &&
                          (i(`changing transport and sending upgrade packet`),
                          f(),
                          r.setTransport(t),
                          t.send([{ type: `upgrade` }]),
                          r.emit(`upgrade`, t),
                          (t = null),
                          (r.upgrading = !1),
                          r.flush()));
                    });
                } else {
                  i(`probe transport "%s" failed`, e);
                  var o = Error(`probe error`);
                  (o.transport = t.name), r.emit(`upgradeError`, o);
                }
            }));
        }
        function o() {
          n || ((n = !0), f(), t.close(), (t = null));
        }
        function s(n) {
          var a = Error(`probe error: ` + n);
          (a.transport = t.name),
            o(),
            i(`probe transport "%s" failed because of error: %s`, e, n),
            r.emit(`upgradeError`, a);
        }
        function c() {
          s(`transport closed`);
        }
        function u() {
          s(`socket closed`);
        }
        function d(e) {
          t &&
            e.name !== t.name &&
            (i(`"%s" works - aborting "%s"`, e.name, t.name), o());
        }
        function f() {
          t.removeListener(`open`, a),
            t.removeListener(`error`, s),
            t.removeListener(`close`, c),
            r.removeListener(`close`, u),
            r.removeListener(`upgrading`, d);
        }
        t.once(`open`, a),
          t.once(`error`, s),
          t.once(`close`, c),
          this.once(`close`, u),
          this.once(`upgrading`, d),
          t.open();
      }),
      (l.prototype.onOpen = function () {
        if (
          (i(`socket open`),
          (this.readyState = `open`),
          (l.priorWebsocketSuccess = this.transport.name === `websocket`),
          this.emit(`open`),
          this.flush(),
          this.readyState === `open` && this.upgrade && this.transport.pause)
        ) {
          i(`starting upgrade probes`);
          for (var e = 0, t = this.upgrades.length; e < t; e++)
            this.probe(this.upgrades[e]);
        }
      }),
      (l.prototype.onPacket = function (e) {
        if (
          this.readyState === `opening` ||
          this.readyState === `open` ||
          this.readyState === `closing`
        )
          switch (
            (i(`socket receive: type "%s", data "%s"`, e.type, e.data),
            this.emit(`packet`, e),
            this.emit(`heartbeat`),
            e.type)
          ) {
            case `open`:
              this.onHandshake(JSON.parse(e.data));
              break;
            case `pong`:
              this.setPing(), this.emit(`pong`);
              break;
            case `error`:
              var t = Error(`server error`);
              (t.code = e.data), this.onError(t);
              break;
            case `message`:
              this.emit(`data`, e.data), this.emit(`message`, e.data);
              break;
          }
        else i(`packet received with socket readyState "%s"`, this.readyState);
      }),
      (l.prototype.onHandshake = function (e) {
        this.emit(`handshake`, e),
          (this.id = e.sid),
          (this.transport.query.sid = e.sid),
          (this.upgrades = this.filterUpgrades(e.upgrades)),
          (this.pingInterval = e.pingInterval),
          (this.pingTimeout = e.pingTimeout),
          this.onOpen(),
          this.readyState !== `closed` &&
            (this.setPing(),
            this.removeListener(`heartbeat`, this.onHeartbeat),
            this.on(`heartbeat`, this.onHeartbeat));
      }),
      (l.prototype.onHeartbeat = function (e) {
        clearTimeout(this.pingTimeoutTimer);
        var t = this;
        t.pingTimeoutTimer = setTimeout(function () {
          t.readyState !== `closed` && t.onClose(`ping timeout`);
        }, e || t.pingInterval + t.pingTimeout);
      }),
      (l.prototype.setPing = function () {
        var e = this;
        clearTimeout(e.pingIntervalTimer),
          (e.pingIntervalTimer = setTimeout(function () {
            i(
              `writing ping packet - expecting pong within %sms`,
              e.pingTimeout
            ),
              e.ping(),
              e.onHeartbeat(e.pingTimeout);
          }, e.pingInterval));
      }),
      (l.prototype.ping = function () {
        var e = this;
        this.sendPacket(`ping`, function () {
          e.emit(`ping`);
        });
      }),
      (l.prototype.onDrain = function () {
        this.writeBuffer.splice(0, this.prevBufferLen),
          (this.prevBufferLen = 0),
          this.writeBuffer.length === 0 ? this.emit(`drain`) : this.flush();
      }),
      (l.prototype.flush = function () {
        this.readyState !== `closed` &&
          this.transport.writable &&
          !this.upgrading &&
          this.writeBuffer.length &&
          (i(`flushing %d packets in socket`, this.writeBuffer.length),
          this.transport.send(this.writeBuffer),
          (this.prevBufferLen = this.writeBuffer.length),
          this.emit(`flush`));
      }),
      (l.prototype.write = l.prototype.send =
        function (e, t, n) {
          return this.sendPacket(`message`, e, t, n), this;
        }),
      (l.prototype.sendPacket = function (e, t, n, r) {
        if (
          (typeof t == `function` && ((r = t), (t = void 0)),
          typeof n == `function` && ((r = n), (n = null)),
          !(this.readyState === `closing` || this.readyState === `closed`))
        ) {
          (n ||= {}), (n.compress = !1 !== n.compress);
          var i = { type: e, data: t, options: n };
          this.emit(`packetCreate`, i),
            this.writeBuffer.push(i),
            r && this.once(`flush`, r),
            this.flush();
        }
      }),
      (l.prototype.close = function () {
        if (this.readyState === `opening` || this.readyState === `open`) {
          this.readyState = `closing`;
          var e = this;
          this.writeBuffer.length
            ? this.once(`drain`, function () {
                this.upgrading ? r() : t();
              })
            : this.upgrading
            ? r()
            : t();
        }
        function t() {
          e.onClose(`forced close`),
            i(`socket closing - telling transport to close`),
            e.transport.close();
        }
        function n() {
          e.removeListener(`upgrade`, n),
            e.removeListener(`upgradeError`, n),
            t();
        }
        function r() {
          e.once(`upgrade`, n), e.once(`upgradeError`, n);
        }
        return this;
      }),
      (l.prototype.onError = function (e) {
        i(`socket error %j`, e),
          (l.priorWebsocketSuccess = !1),
          this.emit(`error`, e),
          this.onClose(`transport error`, e);
      }),
      (l.prototype.onClose = function (e, t) {
        if (
          this.readyState === `opening` ||
          this.readyState === `open` ||
          this.readyState === `closing`
        ) {
          i(`socket close with reason: "%s"`, e);
          var n = this;
          clearTimeout(this.pingIntervalTimer),
            clearTimeout(this.pingTimeoutTimer),
            this.transport.removeAllListeners(`close`),
            this.transport.close(),
            this.transport.removeAllListeners(),
            (this.readyState = `closed`),
            (this.id = null),
            this.emit(`close`, e, t),
            (n.writeBuffer = []),
            (n.prevBufferLen = 0);
        }
      }),
      (l.prototype.filterUpgrades = function (e) {
        for (var t = [], n = 0, r = e.length; n < r; n++)
          ~a(this.transports, e[n]) && t.push(e[n]);
        return t;
      });
  }),
  cc = s((e, t) => {
    (t.exports = sc()), (t.exports.parser = Ys());
  }),
  lc = s((e, t) => {
    t.exports = n;
    function n(e, t) {
      var n = [];
      t ||= 0;
      for (var r = t || 0; r < e.length; r++) n[r - t] = e[r];
      return n;
    }
  }),
  uc = s((e, t) => {
    t.exports = n;
    function n(e, t, n) {
      return (
        e.on(t, n),
        {
          destroy: function () {
            e.removeListener(t, n);
          },
        }
      );
    }
  }),
  dc = s((e, t) => {
    var n = [].slice;
    t.exports = function (e, t) {
      if ((typeof t == `string` && (t = e[t]), typeof t != `function`))
        throw Error(`bind() requires a function`);
      var r = n.call(arguments, 2);
      return function () {
        return t.apply(e, r.concat(n.call(arguments)));
      };
    };
  }),
  fc = s((e, t) => {
    var n = Rs(),
      r = Ps(),
      i = lc(),
      a = uc(),
      o = dc(),
      s = Ms()(`socket.io-client:socket`),
      c = Zs(),
      l = Us();
    t.exports = e = f;
    var u = {
        connect: 1,
        connect_error: 1,
        connect_timeout: 1,
        connecting: 1,
        disconnect: 1,
        error: 1,
        reconnect: 1,
        reconnect_attempt: 1,
        reconnect_failed: 1,
        reconnect_error: 1,
        reconnecting: 1,
        ping: 1,
        pong: 1,
      },
      d = r.prototype.emit;
    function f(e, t, n) {
      (this.io = e),
        (this.nsp = t),
        (this.json = this),
        (this.ids = 0),
        (this.acks = {}),
        (this.receiveBuffer = []),
        (this.sendBuffer = []),
        (this.connected = !1),
        (this.disconnected = !0),
        (this.flags = {}),
        n && n.query && (this.query = n.query),
        this.io.autoConnect && this.open();
    }
    r(f.prototype),
      (f.prototype.subEvents = function () {
        if (!this.subs) {
          var e = this.io;
          this.subs = [
            a(e, `open`, o(this, `onopen`)),
            a(e, `packet`, o(this, `onpacket`)),
            a(e, `close`, o(this, `onclose`)),
          ];
        }
      }),
      (f.prototype.open = f.prototype.connect =
        function () {
          return this.connected
            ? this
            : (this.subEvents(),
              this.io.reconnecting || this.io.open(),
              this.io.readyState === `open` && this.onopen(),
              this.emit(`connecting`),
              this);
        }),
      (f.prototype.send = function () {
        var e = i(arguments);
        return e.unshift(`message`), this.emit.apply(this, e), this;
      }),
      (f.prototype.emit = function (e) {
        if (u.hasOwnProperty(e)) return d.apply(this, arguments), this;
        var t = i(arguments),
          r = {
            type: (this.flags.binary === void 0 ? l(t) : this.flags.binary)
              ? n.BINARY_EVENT
              : n.EVENT,
            data: t,
          };
        return (
          (r.options = {}),
          (r.options.compress = !this.flags || !1 !== this.flags.compress),
          typeof t[t.length - 1] == `function` &&
            (s(`emitting packet with ack id %d`, this.ids),
            (this.acks[this.ids] = t.pop()),
            (r.id = this.ids++)),
          this.connected ? this.packet(r) : this.sendBuffer.push(r),
          (this.flags = {}),
          this
        );
      }),
      (f.prototype.packet = function (e) {
        (e.nsp = this.nsp), this.io.packet(e);
      }),
      (f.prototype.onopen = function () {
        if ((s(`transport is open - connecting`), this.nsp !== `/`))
          if (this.query) {
            var e =
              typeof this.query == `object` ? c.encode(this.query) : this.query;
            s(`sending connect packet with query %s`, e),
              this.packet({ type: n.CONNECT, query: e });
          } else this.packet({ type: n.CONNECT });
      }),
      (f.prototype.onclose = function (e) {
        s(`close (%s)`, e),
          (this.connected = !1),
          (this.disconnected = !0),
          delete this.id,
          this.emit(`disconnect`, e);
      }),
      (f.prototype.onpacket = function (e) {
        var t = e.nsp === this.nsp,
          r = e.type === n.ERROR && e.nsp === `/`;
        if (!(!t && !r))
          switch (e.type) {
            case n.CONNECT:
              this.onconnect();
              break;
            case n.EVENT:
              this.onevent(e);
              break;
            case n.BINARY_EVENT:
              this.onevent(e);
              break;
            case n.ACK:
              this.onack(e);
              break;
            case n.BINARY_ACK:
              this.onack(e);
              break;
            case n.DISCONNECT:
              this.ondisconnect();
              break;
            case n.ERROR:
              this.emit(`error`, e.data);
              break;
          }
      }),
      (f.prototype.onevent = function (e) {
        var t = e.data || [];
        s(`emitting event %j`, t),
          e.id != null &&
            (s(`attaching ack callback to event`), t.push(this.ack(e.id))),
          this.connected ? d.apply(this, t) : this.receiveBuffer.push(t);
      }),
      (f.prototype.ack = function (e) {
        var t = this,
          r = !1;
        return function () {
          if (!r) {
            r = !0;
            var a = i(arguments);
            s(`sending ack %j`, a),
              t.packet({ type: l(a) ? n.BINARY_ACK : n.ACK, id: e, data: a });
          }
        };
      }),
      (f.prototype.onack = function (e) {
        var t = this.acks[e.id];
        typeof t == `function`
          ? (s(`calling ack %s with %j`, e.id, e.data),
            t.apply(this, e.data),
            delete this.acks[e.id])
          : s(`bad ack %s`, e.id);
      }),
      (f.prototype.onconnect = function () {
        (this.connected = !0),
          (this.disconnected = !1),
          this.emitBuffered(),
          this.emit(`connect`);
      }),
      (f.prototype.emitBuffered = function () {
        var e;
        for (e = 0; e < this.receiveBuffer.length; e++)
          d.apply(this, this.receiveBuffer[e]);
        for (this.receiveBuffer = [], e = 0; e < this.sendBuffer.length; e++)
          this.packet(this.sendBuffer[e]);
        this.sendBuffer = [];
      }),
      (f.prototype.ondisconnect = function () {
        s(`server disconnect (%s)`, this.nsp),
          this.destroy(),
          this.onclose(`io server disconnect`);
      }),
      (f.prototype.destroy = function () {
        if (this.subs) {
          for (var e = 0; e < this.subs.length; e++) this.subs[e].destroy();
          this.subs = null;
        }
        this.io.destroy(this);
      }),
      (f.prototype.close = f.prototype.disconnect =
        function () {
          return (
            this.connected &&
              (s(`performing disconnect (%s)`, this.nsp),
              this.packet({ type: n.DISCONNECT })),
            this.destroy(),
            this.connected && this.onclose(`io client disconnect`),
            this
          );
        }),
      (f.prototype.compress = function (e) {
        return (this.flags.compress = e), this;
      }),
      (f.prototype.binary = function (e) {
        return (this.flags.binary = e), this;
      });
  }),
  pc = s((e, t) => {
    t.exports = n;
    function n(e) {
      (e ||= {}),
        (this.ms = e.min || 100),
        (this.max = e.max || 1e4),
        (this.factor = e.factor || 2),
        (this.jitter = e.jitter > 0 && e.jitter <= 1 ? e.jitter : 0),
        (this.attempts = 0);
    }
    (n.prototype.duration = function () {
      var e = this.ms * this.factor ** +this.attempts++;
      if (this.jitter) {
        var t = Math.random(),
          n = Math.floor(t * this.jitter * e);
        e = Math.floor(t * 10) & 1 ? e + n : e - n;
      }
      return Math.min(e, this.max) | 0;
    }),
      (n.prototype.reset = function () {
        this.attempts = 0;
      }),
      (n.prototype.setMin = function (e) {
        this.ms = e;
      }),
      (n.prototype.setMax = function (e) {
        this.max = e;
      }),
      (n.prototype.setJitter = function (e) {
        this.jitter = e;
      });
  }),
  mc = s((e, t) => {
    var n = cc(),
      r = fc(),
      i = Ps(),
      a = Rs(),
      o = uc(),
      s = dc(),
      c = Ms()(`socket.io-client:manager`),
      l = oc(),
      u = pc(),
      d = Object.prototype.hasOwnProperty;
    t.exports = f;
    function f(e, t) {
      if (!(this instanceof f)) return new f(e, t);
      e && typeof e == `object` && ((t = e), (e = void 0)),
        (t ||= {}),
        (t.path = t.path || `/socket.io`),
        (this.nsps = {}),
        (this.subs = []),
        (this.opts = t),
        this.reconnection(t.reconnection !== !1),
        this.reconnectionAttempts(t.reconnectionAttempts || 1 / 0),
        this.reconnectionDelay(t.reconnectionDelay || 1e3),
        this.reconnectionDelayMax(t.reconnectionDelayMax || 5e3),
        this.randomizationFactor(t.randomizationFactor || 0.5),
        (this.backoff = new u({
          min: this.reconnectionDelay(),
          max: this.reconnectionDelayMax(),
          jitter: this.randomizationFactor(),
        })),
        this.timeout(t.timeout == null ? 2e4 : t.timeout),
        (this.readyState = `closed`),
        (this.uri = e),
        (this.connecting = []),
        (this.lastPing = null),
        (this.encoding = !1),
        (this.packetBuffer = []);
      var n = t.parser || a;
      (this.encoder = new n.Encoder()),
        (this.decoder = new n.Decoder()),
        (this.autoConnect = t.autoConnect !== !1),
        this.autoConnect && this.open();
    }
    (f.prototype.emitAll = function () {
      for (var e in (this.emit.apply(this, arguments), this.nsps))
        d.call(this.nsps, e) &&
          this.nsps[e].emit.apply(this.nsps[e], arguments);
    }),
      (f.prototype.updateSocketIds = function () {
        for (var e in this.nsps)
          d.call(this.nsps, e) && (this.nsps[e].id = this.generateId(e));
      }),
      (f.prototype.generateId = function (e) {
        return (e === `/` ? `` : e + `#`) + this.engine.id;
      }),
      i(f.prototype),
      (f.prototype.reconnection = function (e) {
        return arguments.length
          ? ((this._reconnection = !!e), this)
          : this._reconnection;
      }),
      (f.prototype.reconnectionAttempts = function (e) {
        return arguments.length
          ? ((this._reconnectionAttempts = e), this)
          : this._reconnectionAttempts;
      }),
      (f.prototype.reconnectionDelay = function (e) {
        return arguments.length
          ? ((this._reconnectionDelay = e),
            this.backoff && this.backoff.setMin(e),
            this)
          : this._reconnectionDelay;
      }),
      (f.prototype.randomizationFactor = function (e) {
        return arguments.length
          ? ((this._randomizationFactor = e),
            this.backoff && this.backoff.setJitter(e),
            this)
          : this._randomizationFactor;
      }),
      (f.prototype.reconnectionDelayMax = function (e) {
        return arguments.length
          ? ((this._reconnectionDelayMax = e),
            this.backoff && this.backoff.setMax(e),
            this)
          : this._reconnectionDelayMax;
      }),
      (f.prototype.timeout = function (e) {
        return arguments.length ? ((this._timeout = e), this) : this._timeout;
      }),
      (f.prototype.maybeReconnectOnOpen = function () {
        !this.reconnecting &&
          this._reconnection &&
          this.backoff.attempts === 0 &&
          this.reconnect();
      }),
      (f.prototype.open = f.prototype.connect =
        function (e, t) {
          if (
            (c(`readyState %s`, this.readyState),
            ~this.readyState.indexOf(`open`))
          )
            return this;
          c(`opening %s`, this.uri), (this.engine = n(this.uri, this.opts));
          var r = this.engine,
            i = this;
          (this.readyState = `opening`), (this.skipReconnect = !1);
          var a = o(r, `open`, function () {
              i.onopen(), e && e();
            }),
            s = o(r, `error`, function (t) {
              if (
                (c(`connect_error`),
                i.cleanup(),
                (i.readyState = `closed`),
                i.emitAll(`connect_error`, t),
                e)
              ) {
                var n = Error(`Connection error`);
                (n.data = t), e(n);
              } else i.maybeReconnectOnOpen();
            });
          if (!1 !== this._timeout) {
            var l = this._timeout;
            c(`connect attempt will timeout after %d`, l),
              l === 0 && a.destroy();
            var u = setTimeout(function () {
              c(`connect attempt timed out after %d`, l),
                a.destroy(),
                r.close(),
                r.emit(`error`, `timeout`),
                i.emitAll(`connect_timeout`, l);
            }, l);
            this.subs.push({
              destroy: function () {
                clearTimeout(u);
              },
            });
          }
          return this.subs.push(a), this.subs.push(s), this;
        }),
      (f.prototype.onopen = function () {
        c(`open`),
          this.cleanup(),
          (this.readyState = `open`),
          this.emit(`open`);
        var e = this.engine;
        this.subs.push(o(e, `data`, s(this, `ondata`))),
          this.subs.push(o(e, `ping`, s(this, `onping`))),
          this.subs.push(o(e, `pong`, s(this, `onpong`))),
          this.subs.push(o(e, `error`, s(this, `onerror`))),
          this.subs.push(o(e, `close`, s(this, `onclose`))),
          this.subs.push(o(this.decoder, `decoded`, s(this, `ondecoded`)));
      }),
      (f.prototype.onping = function () {
        (this.lastPing = new Date()), this.emitAll(`ping`);
      }),
      (f.prototype.onpong = function () {
        this.emitAll(`pong`, new Date() - this.lastPing);
      }),
      (f.prototype.ondata = function (e) {
        this.decoder.add(e);
      }),
      (f.prototype.ondecoded = function (e) {
        this.emit(`packet`, e);
      }),
      (f.prototype.onerror = function (e) {
        c(`error`, e), this.emitAll(`error`, e);
      }),
      (f.prototype.socket = function (e, t) {
        var n = this.nsps[e];
        if (!n) {
          (n = new r(this, e, t)), (this.nsps[e] = n);
          var i = this;
          n.on(`connecting`, a),
            n.on(`connect`, function () {
              n.id = i.generateId(e);
            }),
            this.autoConnect && a();
        }
        function a() {
          ~l(i.connecting, n) || i.connecting.push(n);
        }
        return n;
      }),
      (f.prototype.destroy = function (e) {
        var t = l(this.connecting, e);
        ~t && this.connecting.splice(t, 1),
          !this.connecting.length && this.close();
      }),
      (f.prototype.packet = function (e) {
        c(`writing packet %j`, e);
        var t = this;
        e.query && e.type === 0 && (e.nsp += `?` + e.query),
          t.encoding
            ? t.packetBuffer.push(e)
            : ((t.encoding = !0),
              this.encoder.encode(e, function (n) {
                for (var r = 0; r < n.length; r++)
                  t.engine.write(n[r], e.options);
                (t.encoding = !1), t.processPacketQueue();
              }));
      }),
      (f.prototype.processPacketQueue = function () {
        if (this.packetBuffer.length > 0 && !this.encoding) {
          var e = this.packetBuffer.shift();
          this.packet(e);
        }
      }),
      (f.prototype.cleanup = function () {
        c(`cleanup`);
        for (var e = this.subs.length, t = 0; t < e; t++)
          this.subs.shift().destroy();
        (this.packetBuffer = []),
          (this.encoding = !1),
          (this.lastPing = null),
          this.decoder.destroy();
      }),
      (f.prototype.close = f.prototype.disconnect =
        function () {
          c(`disconnect`),
            (this.skipReconnect = !0),
            (this.reconnecting = !1),
            this.readyState === `opening` && this.cleanup(),
            this.backoff.reset(),
            (this.readyState = `closed`),
            this.engine && this.engine.close();
        }),
      (f.prototype.onclose = function (e) {
        c(`onclose`),
          this.cleanup(),
          this.backoff.reset(),
          (this.readyState = `closed`),
          this.emit(`close`, e),
          this._reconnection && !this.skipReconnect && this.reconnect();
      }),
      (f.prototype.reconnect = function () {
        if (this.reconnecting || this.skipReconnect) return this;
        var e = this;
        if (this.backoff.attempts >= this._reconnectionAttempts)
          c(`reconnect failed`),
            this.backoff.reset(),
            this.emitAll(`reconnect_failed`),
            (this.reconnecting = !1);
        else {
          var t = this.backoff.duration();
          c(`will wait %dms before reconnect attempt`, t),
            (this.reconnecting = !0);
          var n = setTimeout(function () {
            e.skipReconnect ||
              (c(`attempting reconnect`),
              e.emitAll(`reconnect_attempt`, e.backoff.attempts),
              e.emitAll(`reconnecting`, e.backoff.attempts),
              !e.skipReconnect &&
                e.open(function (t) {
                  t
                    ? (c(`reconnect attempt error`),
                      (e.reconnecting = !1),
                      e.reconnect(),
                      e.emitAll(`reconnect_error`, t.data))
                    : (c(`reconnect success`), e.onreconnect());
                }));
          }, t);
          this.subs.push({
            destroy: function () {
              clearTimeout(n);
            },
          });
        }
      }),
      (f.prototype.onreconnect = function () {
        var e = this.backoff.attempts;
        (this.reconnecting = !1),
          this.backoff.reset(),
          this.updateSocketIds(),
          this.emitAll(`reconnect`, e);
      });
  }),
  hc = s((e, t) => {
    var n = Ns(),
      r = Rs(),
      i = mc(),
      a = Ms()(`socket.io-client`);
    t.exports = e = s;
    var o = (e.managers = {});
    function s(e, t) {
      typeof e == `object` && ((t = e), (e = void 0)), (t ||= {});
      var r = n(e),
        s = r.source,
        c = r.id,
        l = r.path,
        u = o[c] && l in o[c].nsps,
        d = t.forceNew || t[`force new connection`] || !1 === t.multiplex || u,
        f;
      return (
        d
          ? (a(`ignoring socket cache for %s`, s), (f = i(s, t)))
          : (o[c] || (a(`new io instance for %s`, s), (o[c] = i(s, t))),
            (f = o[c])),
        r.query && !t.query && (t.query = r.query),
        f.socket(r.path, t)
      );
    }
    (e.protocol = r.protocol),
      (e.connect = s),
      (e.Manager = mc()),
      (e.Socket = fc());
  }),
  gc = c({ default: () => _c });
function _c(e, t) {
  return (
    (t ||= {}),
    new Promise(function (n, r) {
      var i = new XMLHttpRequest(),
        a = [],
        o = [],
        s = {},
        c = function () {
          return {
            ok: ((i.status / 100) | 0) == 2,
            statusText: i.statusText,
            status: i.status,
            url: i.responseURL,
            text: function () {
              return Promise.resolve(i.responseText);
            },
            json: function () {
              return Promise.resolve(i.responseText).then(JSON.parse);
            },
            blob: function () {
              return Promise.resolve(new Blob([i.response]));
            },
            clone: c,
            headers: {
              keys: function () {
                return a;
              },
              entries: function () {
                return o;
              },
              get: function (e) {
                return s[e.toLowerCase()];
              },
              has: function (e) {
                return e.toLowerCase() in s;
              },
            },
          };
        };
      for (var l in (i.open(t.method || `get`, e, !0),
      (i.onload = function () {
        i
          .getAllResponseHeaders()
          .replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, function (e, t, n) {
            a.push((t = t.toLowerCase())),
              o.push([t, n]),
              (s[t] = s[t] ? s[t] + `,` + n : n);
          }),
          n(c());
      }),
      (i.onerror = r),
      (i.withCredentials = t.credentials == `include`),
      t.headers))
        i.setRequestHeader(l, t.headers[l]);
      i.send(t.body || null);
    })
  );
}
var vc = o(() => {}),
  yc = s((e, t) => {
    t.exports =
      self.fetch || (self.fetch = (vc(), d(gc)).default || (vc(), d(gc)));
  }),
  bc = s((e) => {
    var t =
      (e && e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.fetchBalancerConfig = void 0);
    var n = Ds(),
      r = t(yc());
    e.fetchBalancerConfig = function (e) {
      return (
        (0, n.debug)(`using balancer ${e} to get websocket url`),
        (0, r.default)(`${e}`)
          .then(function (e) {
            return e.json();
          })
          .then(function (e) {
            return e?.url && e?.token
              ? ((0, n.debug)(
                  `balancer returns url ${e?.url} and token ${e?.token}`
                ),
                e)
              : ((0, n.debug)(`balancer returns invalid response`), null);
          })
          .catch(function (e) {
            return (0, n.debug)(`failed to resolve url: ${e.message}`), null;
          })
      );
    };
  }),
  xc = s((e) => {
    var t =
        (e && e.__extends) ||
        (function () {
          var e = function (t, n) {
            return (
              (e =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                }),
              e(t, n)
            );
          };
          return function (t, n) {
            if (typeof n != `function` && n !== null)
              throw TypeError(
                `Class extends value ` +
                  String(n) +
                  ` is not a constructor or null`
              );
            e(t, n);
            function r() {
              this.constructor = t;
            }
            t.prototype =
              n === null
                ? Object.create(n)
                : ((r.prototype = n.prototype), new r());
          };
        })(),
      n =
        (e && e.__spreadArray) ||
        function (e, t, n) {
          if (n || arguments.length === 2)
            for (var r = 0, i = t.length, a; r < i; r++)
              (a || !(r in t)) &&
                ((a ||= Array.prototype.slice.call(t, 0, r)), (a[r] = t[r]));
          return e.concat(a || Array.prototype.slice.call(t));
        },
      r =
        (e && e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.SocketMock = void 0);
    var i = Ds();
    e.SocketMock = (function (e) {
      t(r, e);
      function r(t) {
        var n = e.call(this) || this;
        return (
          (n.options = t),
          (n.id = `mock`),
          (n.connected = !1),
          (n.disconnected = !0),
          (n.binaryType = `blob`),
          n
        );
      }
      return (
        (r.prototype.open = function () {
          var e = this;
          return (
            (0, i.debug)(`SocketIOMock: connect`),
            this.once(`visitor.connect`, function (t, n) {
              n(null, e.options.connectData);
            }),
            (this.connected = !0),
            (this.disconnected = !1),
            this.emit(`connect`),
            this
          );
        }),
        (r.prototype.close = function () {
          return (
            (0, i.debug)(`SocketIOMock: disconnect`),
            (this.connected = !1),
            (this.disconnected = !1),
            this.emit(`disconnect`, `io client disconnect`),
            this
          );
        }),
        (r.prototype.emit = function (t) {
          var r = [...arguments].slice(1);
          return (
            i.debug.apply(void 0, n([`SocketIOMock: emit`], r, !1)),
            (t === `connect` ||
              t === `disconnect` ||
              t === `visitor.connect`) &&
              e.prototype.emit.apply(this, n([t], r, !1)),
            this
          );
        }),
        (r.prototype.send = function () {
          var e = [...arguments];
          return this.emit.apply(this, n([e[0]], e.slice(1), !1));
        }),
        (r.prototype.compress = function () {
          return this;
        }),
        (r.prototype.connect = function () {
          return this.open();
        }),
        (r.prototype.disconnect = function () {
          return this.close();
        }),
        (r.prototype.hasListeners = function (e) {
          return this.listenerCount(e) === 0;
        }),
        (r.prototype.addEventListener = function (e, t) {
          return this.addListener(e, t), this;
        }),
        (r.prototype.removeEventListener = function (e, t) {
          return this.removeListener(e, t), this;
        }),
        r
      );
    })(r(Os()).default);
  }),
  Sc = s((e) => {
    var t =
        (e && e.__assign) ||
        function () {
          return (
            (t =
              Object.assign ||
              function (e) {
                for (var t, n = 1, r = arguments.length; n < r; n++)
                  for (var i in ((t = arguments[n]), t))
                    Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                return e;
              }),
            t.apply(this, arguments)
          );
        },
      n =
        (e && e.__createBinding) ||
        (Object.create
          ? function (e, t, n, r) {
              r === void 0 && (r = n);
              var i = Object.getOwnPropertyDescriptor(t, n);
              (!i ||
                (`get` in i ? !t.__esModule : i.writable || i.configurable)) &&
                (i = {
                  enumerable: !0,
                  get: function () {
                    return t[n];
                  },
                }),
                Object.defineProperty(e, r, i);
            }
          : function (e, t, n, r) {
              r === void 0 && (r = n), (e[r] = t[n]);
            }),
      r =
        (e && e.__exportStar) ||
        function (e, t) {
          for (var r in e)
            r !== `default` &&
              !Object.prototype.hasOwnProperty.call(t, r) &&
              n(t, e, r);
        },
      i =
        (e && e.__awaiter) ||
        function (e, t, n, r) {
          function i(e) {
            return e instanceof n
              ? e
              : new n(function (t) {
                  t(e);
                });
          }
          return new (n ||= Promise)(function (n, a) {
            function o(e) {
              try {
                c(r.next(e));
              } catch (e) {
                a(e);
              }
            }
            function s(e) {
              try {
                c(r.throw(e));
              } catch (e) {
                a(e);
              }
            }
            function c(e) {
              e.done ? n(e.value) : i(e.value).then(o, s);
            }
            c((r = r.apply(e, t || [])).next());
          });
        },
      a =
        (e && e.__generator) ||
        function (e, t) {
          var n = {
              label: 0,
              sent: function () {
                if (a[0] & 1) throw a[1];
                return a[1];
              },
              trys: [],
              ops: [],
            },
            r,
            i,
            a,
            o = Object.create(
              (typeof Iterator == `function` ? Iterator : Object).prototype
            );
          return (
            (o.next = s(0)),
            (o.throw = s(1)),
            (o.return = s(2)),
            typeof Symbol == `function` &&
              (o[Symbol.iterator] = function () {
                return this;
              }),
            o
          );
          function s(e) {
            return function (t) {
              return c([e, t]);
            };
          }
          function c(s) {
            if (r) throw TypeError(`Generator is already executing.`);
            for (; o && ((o = 0), s[0] && (n = 0)), n; )
              try {
                if (
                  ((r = 1),
                  i &&
                    (a =
                      s[0] & 2
                        ? i.return
                        : s[0]
                        ? i.throw || ((a = i.return) && a.call(i), 0)
                        : i.next) &&
                    !(a = a.call(i, s[1])).done)
                )
                  return a;
                switch (((i = 0), a && (s = [s[0] & 2, a.value]), s[0])) {
                  case 0:
                  case 1:
                    a = s;
                    break;
                  case 4:
                    return n.label++, { value: s[1], done: !1 };
                  case 5:
                    n.label++, (i = s[1]), (s = [0]);
                    continue;
                  case 7:
                    (s = n.ops.pop()), n.trys.pop();
                    continue;
                  default:
                    if (
                      ((a = n.trys), !(a = a.length > 0 && a[a.length - 1])) &&
                      (s[0] === 6 || s[0] === 2)
                    ) {
                      n = 0;
                      continue;
                    }
                    if (s[0] === 3 && (!a || (s[1] > a[0] && s[1] < a[3]))) {
                      n.label = s[1];
                      break;
                    }
                    if (s[0] === 6 && n.label < a[1]) {
                      (n.label = a[1]), (a = s);
                      break;
                    }
                    if (a && n.label < a[2]) {
                      (n.label = a[2]), n.ops.push(s);
                      break;
                    }
                    a[2] && n.ops.pop(), n.trys.pop();
                    continue;
                }
                s = t.call(e, n);
              } catch (e) {
                (s = [6, e]), (i = 0);
              } finally {
                r = a = 0;
              }
            if (s[0] & 5) throw s[1];
            return { value: s[0] ? s[1] : void 0, done: !0 };
          }
        },
      o =
        (e && e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.SocketError = void 0);
    var s = Ds(),
      c = o(Os()),
      l = o(hc()),
      u = bc(),
      d = {
        transports: [`websocket`],
        path: `/socket`,
        reconnection: !0,
        reconnectionDelay: 1e3,
        reconnectionDelayMax: 5e3,
        reconnectionAttempts: 1 / 0,
      };
    e.default = (function () {
      function e(e) {
        (this.options = e),
          (this.initialized = !1),
          (this.forceReconnect = !1),
          (this.identity = null),
          (this.connection = null),
          (this.connectCallback = null),
          (this.disconnectCallback = null),
          (this.initData = null),
          (this.internalReconnection = !1),
          (this.internalReconnecting = !1),
          (this.internalReconnectingAttempt = 0),
          (this.emitter = new c.default()),
          (this.sendBuffer = []),
          (this.options.options = t(t(t({}, d), this.options.options), {
            autoConnect: !1,
          }));
      }
      return (
        (e.prototype.initConnection = function () {
          return i(this, void 0, void 0, function () {
            var e;
            return a(this, function (n) {
              switch (n.label) {
                case 0:
                  if (this.connection) throw Error(`Connection already exists`);
                  return this.options.socket
                    ? ((0, s.debug)(`using socket ${this.options.socket.id}`),
                      (this.internalReconnection = !1),
                      this.setConnection(this.options.socket),
                      [3, 4])
                    : [3, 1];
                case 1:
                  return this.options.balancerUrl
                    ? [4, (0, u.fetchBalancerConfig)(this.options.balancerUrl)]
                    : [3, 3];
                case 2:
                  return (
                    (e = n.sent()),
                    (0, s.debug)(
                      `creating socket to ${e.url} with token ${e.token}`
                    ),
                    (this.internalReconnection = !0),
                    this.setConnection(
                      (0, l.default)(
                        e.url,
                        t(t({}, this.options.options), {
                          autoConnect: !1,
                          reconnection: !1,
                          query: { token: e.token },
                        })
                      ),
                      !0
                    ),
                    [3, 4]
                  );
                case 3:
                  if (this.options.url)
                    (0, s.debug)(`creating socket to ${this.options.url}`),
                      (this.internalReconnection = !1),
                      this.setConnection(
                        (0, l.default)(
                          this.options.url,
                          t(t({}, this.options.options), { autoConnect: !1 })
                        )
                      );
                  else throw Error(`Missing required parameter url`);
                  n.label = 4;
                case 4:
                  return [2];
              }
            });
          });
        }),
        (e.prototype.setConnection = function (e, n) {
          var r = this;
          n === void 0 && (n = !1),
            (this.connection = e),
            (this.forceReconnect = !1),
            (this.internalReconnection = n),
            e.on(`connect_error`, function (e) {
              r.internalReconnection &&
                ((r.connectCallback = null),
                (0, s.debug)(`connection was not reconnected`),
                r.emitter.emit(`reconnect_error`, e),
                r.options.options.reconnectionAttempts >
                r.internalReconnectingAttempt + 1
                  ? r.reconnect(r.internalReconnectingAttempt + 1)
                  : r.emitter.emit(
                      `reconnect_failed`,
                      r.internalReconnectingAttempt
                    ));
            }),
            e.on(`connect`, function () {
              (0, s.debug)(`socket was connected`),
                (r.initialized = !1),
                r.internalReconnecting
                  ? ((0, s.debug)(`connection is reconnected`),
                    r.emitter.emit(`reconnect`),
                    (r.internalReconnecting = !1),
                    (r.internalReconnectingAttempt = 0))
                  : r.emitter.emit(`connect`),
                r
                  .initialize()
                  .then(function (e) {
                    return (
                      (0, s.debug)(`socket was initialized`),
                      r.onInitialized(e),
                      (r.connectCallback &&=
                        (r.connectCallback(null, e), null)),
                      e
                    );
                  })
                  .catch(function (e) {
                    (0, s.debug)(`socket was not initialized `, t({}, e)),
                      r.onInitializeError(e),
                      (r.connectCallback &&= (r.connectCallback(e), null));
                  });
            }),
            e.on(`disconnect`, function (e) {
              (0, s.debug)(`socket was disconnected reason='${e}'`),
                (r.initialized = !1),
                (!r.internalReconnecting ||
                  r.internalReconnectingAttempt === 1) &&
                  setTimeout(function () {
                    r.emitter.emit(`disconnect`, e),
                      (r.disconnectCallback &&= (r.disconnectCallback(), null));
                  }, 100),
                r.options.options.reconnection &&
                  r.internalReconnection &&
                  !r.internalReconnecting &&
                  (r.forceReconnect || e !== `io server disconnect`) &&
                  r.reconnect();
            }),
            e.on(`reconnecting`, function (e) {
              r.emitter.emit(`reconnecting`, e);
            }),
            e.on(`reconnect`, function () {
              r.emitter.emit(`reconnect`);
            }),
            e.on(`reconnect_attempt`, function (e) {
              r.emitter.emit(`reconnect_attempt`, e);
            }),
            e.on(`reconnect_error`, function (e) {
              r.emitter.emit(`reconnect_error`, e);
            }),
            e.on(`reconnect_failed`, function () {
              r.emitter.emit(`reconnect_failed`);
            }),
            e.on(`force_reconnect`, function () {
              (0, s.debug)(
                `received event force_reconnect, setting flag forceReconnect = true`
              ),
                (r.forceReconnect = !0);
            });
        }),
        (e.prototype.getConnection = function () {
          return this.connection;
        }),
        (e.prototype.isConnected = function () {
          return this.connection?.connected || !1;
        }),
        (e.prototype.isInitialized = function () {
          return this.initialized;
        }),
        (e.prototype.getInitData = function () {
          return this.initData;
        }),
        (e.prototype.connect = function () {
          return i(this, void 0, void 0, function () {
            var e = this;
            return a(this, function (t) {
              switch (t.label) {
                case 0:
                  return this.connection ? [3, 2] : [4, this.initConnection()];
                case 1:
                  t.sent(), (t.label = 2);
                case 2:
                  return [
                    2,
                    new Promise(function (t, n) {
                      e.initialized
                        ? t(e.initData)
                        : ((0, s.debug)(`starting connecting`),
                          (e.connectCallback = (0, s.createCallback)(t, n)),
                          e.connection.open());
                    }),
                  ];
              }
            });
          });
        }),
        (e.prototype.disconnect = function () {
          var e = this;
          return new Promise(function (t, n) {
            !e.connection || e.connection.disconnected
              ? ((e.connection = null), t())
              : ((0, s.debug)(`starting disconnecting`),
                (e.disconnectCallback = (0, s.createCallback)(t, n)),
                e.connection.close(),
                (e.connection = null));
          });
        }),
        (e.prototype.reconnect = function (e) {
          var t = this;
          return (
            e === void 0 && (e = 1),
            (this.internalReconnecting = !0),
            (this.internalReconnectingAttempt = e),
            this.disconnect()
              .then(function () {
                var n = Math.floor(
                  Math.random() *
                    (t.options.options.reconnectionDelayMax -
                      t.options.options.reconnectionDelay) +
                    t.options.options.reconnectionDelay
                );
                return (
                  (0, s.debug)(`connection will reconnect in ${n}ms`),
                  t.emitter.emit(`reconnecting`, e),
                  new Promise(function (e) {
                    setTimeout(e, n);
                  })
                );
              })
              .then(function () {
                return (
                  (0, s.debug)(`connection is starting reconnect`),
                  t.emitter.emit(`reconnect_attempt`, e),
                  t.connect()
                );
              })
          );
        }),
        (e.prototype.initialize = function () {
          return new Promise(function (e) {
            e({});
          });
        }),
        (e.prototype.onInitialized = function (e) {
          var t = this;
          this.initialized ||
            ((this.initialized = !0),
            (this.initData = e),
            (0, s.debug)(`emit initialized`),
            this.emitter.emit(`initialized`, e),
            setTimeout(function () {
              if (t.sendBuffer.length > 0) {
                (0, s.debug)(`sending buffered ${t.sendBuffer.length} events`);
                for (var e = 0; e < t.sendBuffer.length; e++) {
                  var n = t.sendBuffer[e];
                  t.connection.emit(n.name, n.data, n.callback);
                }
                t.sendBuffer = [];
              }
            }, 1));
        }),
        (e.prototype.onInitializeError = function (e) {
          this.disconnect(),
            (0, s.debug)(`emit initialize_error`, t({}, e)),
            this.emitter.emit(`initialize_error`, e);
        }),
        (e.prototype.send = function (e, t, n) {
          this.initialized
            ? this.connection.emit(e, t, n)
            : this.sendBuffer.push({ name: e, data: t, callback: n });
        }),
        (e.prototype.on = function (e, t) {
          return this.emitter.on(e, t), this;
        }),
        (e.prototype.once = function (e, t) {
          return this.emitter.once(e, t), this;
        }),
        (e.prototype.removeAllListeners = function () {
          for (var e, t = [], n = 0; n < arguments.length; n++)
            t[n] = arguments[n];
          return (e = this.emitter).removeAllListeners.apply(e, t), this;
        }),
        e
      );
    })();
    var f = Ds();
    Object.defineProperty(e, `SocketError`, {
      enumerable: !0,
      get: function () {
        return f.SocketError;
      },
    }),
      r(xc(), e);
  }),
  Cc = s((e) => {
    var t =
        (e && e.__extends) ||
        (function () {
          var e = function (t, n) {
            return (
              (e =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                }),
              e(t, n)
            );
          };
          return function (t, n) {
            if (typeof n != `function` && n !== null)
              throw TypeError(
                `Class extends value ` +
                  String(n) +
                  ` is not a constructor or null`
              );
            e(t, n);
            function r() {
              this.constructor = t;
            }
            t.prototype =
              n === null
                ? Object.create(n)
                : ((r.prototype = n.prototype), new r());
          };
        })(),
      n =
        (e && e.__assign) ||
        function () {
          return (
            (n =
              Object.assign ||
              function (e) {
                for (var t, n = 1, r = arguments.length; n < r; n++)
                  for (var i in ((t = arguments[n]), t))
                    Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                return e;
              }),
            n.apply(this, arguments)
          );
        },
      r =
        (e && e.__awaiter) ||
        function (e, t, n, r) {
          function i(e) {
            return e instanceof n
              ? e
              : new n(function (t) {
                  t(e);
                });
          }
          return new (n ||= Promise)(function (n, a) {
            function o(e) {
              try {
                c(r.next(e));
              } catch (e) {
                a(e);
              }
            }
            function s(e) {
              try {
                c(r.throw(e));
              } catch (e) {
                a(e);
              }
            }
            function c(e) {
              e.done ? n(e.value) : i(e.value).then(o, s);
            }
            c((r = r.apply(e, t || [])).next());
          });
        },
      i =
        (e && e.__generator) ||
        function (e, t) {
          var n = {
              label: 0,
              sent: function () {
                if (a[0] & 1) throw a[1];
                return a[1];
              },
              trys: [],
              ops: [],
            },
            r,
            i,
            a,
            o = Object.create(
              (typeof Iterator == `function` ? Iterator : Object).prototype
            );
          return (
            (o.next = s(0)),
            (o.throw = s(1)),
            (o.return = s(2)),
            typeof Symbol == `function` &&
              (o[Symbol.iterator] = function () {
                return this;
              }),
            o
          );
          function s(e) {
            return function (t) {
              return c([e, t]);
            };
          }
          function c(s) {
            if (r) throw TypeError(`Generator is already executing.`);
            for (; o && ((o = 0), s[0] && (n = 0)), n; )
              try {
                if (
                  ((r = 1),
                  i &&
                    (a =
                      s[0] & 2
                        ? i.return
                        : s[0]
                        ? i.throw || ((a = i.return) && a.call(i), 0)
                        : i.next) &&
                    !(a = a.call(i, s[1])).done)
                )
                  return a;
                switch (((i = 0), a && (s = [s[0] & 2, a.value]), s[0])) {
                  case 0:
                  case 1:
                    a = s;
                    break;
                  case 4:
                    return n.label++, { value: s[1], done: !1 };
                  case 5:
                    n.label++, (i = s[1]), (s = [0]);
                    continue;
                  case 7:
                    (s = n.ops.pop()), n.trys.pop();
                    continue;
                  default:
                    if (
                      ((a = n.trys), !(a = a.length > 0 && a[a.length - 1])) &&
                      (s[0] === 6 || s[0] === 2)
                    ) {
                      n = 0;
                      continue;
                    }
                    if (s[0] === 3 && (!a || (s[1] > a[0] && s[1] < a[3]))) {
                      n.label = s[1];
                      break;
                    }
                    if (s[0] === 6 && n.label < a[1]) {
                      (n.label = a[1]), (a = s);
                      break;
                    }
                    if (a && n.label < a[2]) {
                      (n.label = a[2]), n.ops.push(s);
                      break;
                    }
                    a[2] && n.ops.pop(), n.trys.pop();
                    continue;
                }
                s = t.call(e, n);
              } catch (e) {
                (s = [6, e]), (i = 0);
              } finally {
                r = a = 0;
              }
            if (s[0] & 5) throw s[1];
            return { value: s[0] ? s[1] : void 0, done: !0 };
          }
        },
      a =
        (e && e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.WebsocketVisitorClient = void 0);
    var o = a(Sc()),
      s = Ds(),
      c = (function (e) {
        t(a, e);
        function a(t) {
          var n = e.call(this, t.connection) || this;
          return (
            (n.serverVersion = null),
            (n.updatedValues = {}),
            (n.connectData = t.data),
            (n.identity = null),
            n
          );
        }
        return (
          (a.prototype.setConnection = function (t) {
            e.prototype.setConnection.call(this, t),
              t.on(`server.error`, (0, s.bound)(this, `onServerError`)),
              t.on(
                `account.updated`,
                (0, s.createEmitter)(this.emitter, `account.updated`)
              ),
              t.on(
                `agent.updated`,
                (0, s.createEmitter)(this.emitter, `agent.updated`)
              ),
              t.on(
                `agent.status_updated`,
                (0, s.createEmitter)(this.emitter, `agent.status_updated`)
              ),
              t.on(
                `agent.removed`,
                (0, s.createEmitter)(this.emitter, `agent.removed`)
              ),
              t.on(`visitor.updated`, (0, s.bound)(this, `onVisitorUpdated`)),
              t.on(
                `chat.updated`,
                (0, s.createEmitter)(this.emitter, `chat.updated`)
              ),
              t.on(
                `chat.agent_joined`,
                (0, s.createEmitter)(this.emitter, `chat.agent_joined`)
              ),
              t.on(
                `chat.agent_assigned`,
                (0, s.createEmitter)(this.emitter, `chat.agent_assigned`)
              ),
              t.on(
                `chat.bot_assigned`,
                (0, s.createEmitter)(this.emitter, `chat.bot_assigned`)
              ),
              t.on(
                `chat.bot_unassigned`,
                (0, s.createEmitter)(this.emitter, `chat.bot_unassigned`)
              ),
              t.on(
                `chat.agent_unassigned`,
                (0, s.createEmitter)(this.emitter, `chat.agent_unassigned`)
              ),
              t.on(
                `chat.agent_left`,
                (0, s.createEmitter)(this.emitter, `chat.agent_left`)
              ),
              t.on(
                `chat.opened`,
                (0, s.createEmitter)(this.emitter, `chat.opened`)
              ),
              t.on(
                `chat.served`,
                (0, s.createEmitter)(this.emitter, `chat.served`)
              ),
              t.on(
                `chat.closed`,
                (0, s.createEmitter)(this.emitter, `chat.closed`)
              ),
              t.on(
                `chat.visitor_closed`,
                (0, s.createEmitter)(this.emitter, `chat.visitor_closed`)
              ),
              t.on(
                `chat.message_received`,
                (0, s.createEmitter)(this.emitter, `chat.message_received`)
              ),
              t.on(
                `chat.message_updated`,
                (0, s.createEmitter)(this.emitter, `chat.message_updated`)
              ),
              t.on(
                `chat.message_deleted`,
                (0, s.createEmitter)(this.emitter, `chat.message_deleted`)
              ),
              t.on(
                `chat.agent_typing`,
                (0, s.createEmitter)(this.emitter, `chat.agent_typing`)
              ),
              t.on(
                `chat.rated`,
                (0, s.createEmitter)(this.emitter, `chat.rated`)
              ),
              t.on(
                `chat.rating_cancelled`,
                (0, s.createEmitter)(this.emitter, `chat.rating_cancelled`)
              ),
              t.on(
                `chat.rating_suggested`,
                (0, s.createEmitter)(this.emitter, `chat.rating_suggested`)
              ),
              t.on(
                `chat.contact_read`,
                (0, s.createEmitter)(this.emitter, `chat.contact_read`)
              ),
              t.on(
                `chat.deleted`,
                (0, s.createEmitter)(this.emitter, `chat.deleted`)
              ),
              t.on(
                `chat.ticket_form_finish`,
                (0, s.createEmitter)(this.emitter, `chat.ticket_form_finish`)
              ),
              t.on(
                `chat.auth_form_requested`,
                (0, s.createEmitter)(this.emitter, `chat.auth_form_requested`)
              ),
              t.on(
                `chat.transcript_pdf`,
                (0, s.createEmitter)(this.emitter, `chat.transcript_pdf`)
              ),
              t.on(
                `contact.acquired`,
                (0, s.createEmitter)(this.emitter, `contact.acquired`)
              ),
              t.on(
                `identity.status_updated`,
                (0, s.createEmitter)(this.emitter, `identity.status_updated`)
              );
          }),
          (a.prototype.on = function (e, t) {
            return this.emitter.on(e, t), this;
          }),
          (a.prototype.once = function (e, t) {
            return this.emitter.once(e, t), this;
          }),
          (a.prototype.getId = function () {
            return this.identity ? this.identity.id : null;
          }),
          (a.prototype.getIdentity = function () {
            return this.identity;
          }),
          (a.prototype.connect = function () {
            return e.prototype.connect.call(this);
          }),
          (a.prototype.disconnect = function () {
            return r(this, arguments, void 0, function (t) {
              var n = this;
              return (
                t === void 0 && (t = !1),
                i(this, function (r) {
                  switch (r.label) {
                    case 0:
                      return t
                        ? [
                            4,
                            new Promise(function (e, t) {
                              n.send(
                                `visitor.logout`,
                                {},
                                (0, s.createCallback)(e, t)
                              );
                            }),
                          ]
                        : [3, 2];
                    case 1:
                      r.sent(), (r.label = 2);
                    case 2:
                      return [2, e.prototype.disconnect.call(this)];
                  }
                })
              );
            });
          }),
          (a.prototype.update = function (e) {
            for (var t in (e === void 0 && (e = {}),
            this.checkServerVersion(),
            e))
              (this.identity[t] = e[t]), (this.updatedValues[t] = e[t]);
            this.saveVisitorValues();
          }),
          (a.prototype.authenticate = function (e) {
            var t = this;
            return (
              this.checkServerVersion(),
              new Promise(function (n, r) {
                t.send(
                  `visitor.authenticate`,
                  { values: e },
                  (0, s.createCallback)(n, r)
                );
              })
            );
          }),
          (a.prototype.notify = function (e, t) {
            var n = this;
            return (
              t === void 0 && (t = null),
              this.checkServerVersion(),
              new Promise(function (r, i) {
                n.send(
                  `visitor.notify`,
                  { name: e, value: t },
                  (0, s.createCallback)(r, i)
                );
              })
            );
          }),
          (a.prototype.chatRead = function () {
            this.checkServerVersion(), this.send(`chat.read`, null);
          }),
          (a.prototype.chatTyping = function (e, t) {
            t === void 0 && (t = null),
              this.checkServerVersion(),
              this.send(`chat.typing`, { typing: { is: e, text: t } });
          }),
          (a.prototype.chatMessage = function (e) {
            var t = this;
            return (
              this.checkServerVersion(),
              new Promise(function (n, r) {
                t.send(`chat.message`, e, (0, s.createCallback)(n, r));
              })
            );
          }),
          (a.prototype.chatClose = function (e) {
            e === void 0 && (e = null),
              this.checkServerVersion(),
              this.send(`chat.close`, { type: e });
          }),
          (a.prototype.chatUploadInit = function () {
            var e = this;
            return (
              this.checkServerVersion(),
              new Promise(function (t, n) {
                e.send(`chat.upload_init`, null, (0, s.createCallback)(t, n));
              })
            );
          }),
          (a.prototype.chatUploadFinish = function (e) {
            var t = this;
            return (
              this.checkServerVersion(),
              new Promise(function (n, r) {
                t.send(
                  `chat.upload_finish`,
                  { uploadToken: e },
                  (0, s.createCallback)(n, r)
                );
              })
            );
          }),
          (a.prototype.chatTranscript = function (e, t) {
            var n = this;
            return (
              this.checkServerVersion(),
              new Promise(function (r, i) {
                n.send(
                  `chat.transcript`,
                  { email: e, lang: t },
                  (0, s.createCallback)(r, i)
                );
              })
            );
          }),
          (a.prototype.chatTicketFormFinish = function (e) {
            var t = this;
            return (
              this.checkServerVersion(),
              new Promise(function (n, r) {
                t.send(
                  `chat.ticket_form_finish`,
                  e,
                  (0, s.createCallback)(n, r)
                );
              })
            );
          }),
          (a.prototype.chatRateInit = function () {
            var e = this;
            return (
              this.checkServerVersion(),
              new Promise(function (t, n) {
                e.send(`chat.rate_init`, null, (0, s.createCallback)(t, n));
              })
            );
          }),
          (a.prototype.chatRate = function (e) {
            var t = this;
            return (
              this.checkServerVersion(),
              new Promise(function (n, r) {
                t.send(`chat.rate`, e, (0, s.createCallback)(n, r));
              })
            );
          }),
          (a.prototype.chatTranscriptPdf = function () {
            var e = this;
            return (
              this.checkServerVersion(),
              new Promise(function (t, n) {
                e.send(
                  `chat.transcript_pdf`,
                  null,
                  (0, s.createCallback)(t, n)
                );
              })
            );
          }),
          (a.prototype.linkOpened = function (e) {
            var t = this;
            return (
              this.checkServerVersion(),
              new Promise(function (n, r) {
                t.send(`chat.link_opened`, e, (0, s.createCallback)(n, r));
              })
            );
          }),
          (a.prototype.visitorConnect = function () {
            var e = this,
              t = n({ version: a.CLIENT_VERSION }, this.connectData);
            for (var r in this.updatedValues) t[r] = this.updatedValues[r];
            if (((this.updatedValues = {}), this.identity))
              for (var r in this.identity)
                [`bannedAt`, `chatId`, `status`].includes(r) ||
                  (t[r] = this.identity[r]);
            return (
              this.emitter.emit(`initialize`, t),
              new Promise(function (n, r) {
                e.connection.emit(
                  `visitor.connect`,
                  t,
                  (0, s.createCallback)(n, r)
                );
              })
            );
          }),
          (a.prototype.visitorDisconnect = function () {
            var e = this;
            return new Promise(function (t, n) {
              e.connection.emit(
                `visitor.disconnect`,
                {},
                (0, s.createCallback)(t, n)
              );
            });
          }),
          (a.prototype.onVisitorUpdated = function (e) {
            var t = {};
            for (var n in e.changes)
              a.identityProperties.includes(n) &&
                (this.identity && (this.identity[n] = e.changes[n]),
                (t[n] = e.changes[n]));
            Object.getOwnPropertyNames(t).length > 0 &&
              this.emitter.emit(`visitor.updated`, t);
          }),
          (a.prototype.onServerError = function (e) {
            var t = (0, s.createSocketError)(e);
            this.emitter.emit(`error`, t);
          }),
          (a.prototype.initialize = function () {
            var e = this;
            return this.visitorConnect().then(function (t) {
              return (
                (e.serverVersion = t.serverVersion),
                (e.identity = n(n({}, t.visitor), {
                  variables: n({}, t.visitor.variables),
                })),
                t
              );
            });
          }),
          (a.prototype.saveVisitorValues = function () {
            var e = this;
            this.initialized &&
              setTimeout(function () {
                if (
                  !(
                    !e.initialized ||
                    Object.getOwnPropertyNames(e.updatedValues).length === 0
                  )
                ) {
                  var t = {};
                  for (var n in e.updatedValues) t[n] = e.updatedValues[n];
                  e.send(`visitor.update`, { values: t }),
                    (e.updatedValues = {});
                }
              }, 1);
          }),
          (a.prototype.checkServerVersion = function () {
            if (this.serverVersion === null)
              throw Error(`Client not yet connected to server`);
          }),
          (a.CLIENT_VERSION = 6),
          (a.identityProperties = [
            `id`,
            `name`,
            `email`,
            `phone`,
            `chatId`,
            `variables`,
            `lang`,
            `group`,
            `bannedAt`,
            `triggerable`,
            `visits`,
            `gdprApproved`,
          ]),
          a
        );
      })(o.default);
    (e.WebsocketVisitorClient = c),
      (function (e) {
        (function (e) {
          (e.WidgetOpen = `widget_open`),
            (e.WidgetShow = `widget_show`),
            (e.VisitorActive = `visitor_active`),
            (e.VisitorInactive = `visitor_inactive`);
        })((e.EventName ||= {}));
      })(c || (e.WebsocketVisitorClient = c = {}));
  }),
  wc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 });
  }),
  Tc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.AuthFormMode = e.RatingTarget = void 0);
    var t;
    (function (e) {
      (e.Agent = `agent`), (e.Ai = `ai`);
    })(t || (e.RatingTarget = t = {}));
    var n;
    (function (e) {
      (e.Enabled = `enabled`),
        (e.Disabled = `disabled`),
        (e.DisabledUntilHandover = `disabled_until_handover`);
    })(n || (e.AuthFormMode = n = {}));
  }),
  Ec = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.MessageDeliveryFailReason =
        e.MessageDeliveryStatus =
        e.AgentDevicePlatform =
        e.AgentDeviceType =
        e.VisitorStatus =
        e.ChatReadInfoType =
        e.ChatStatus =
        e.AgentStatus =
        e.AccountStatus =
          void 0),
      (e.AccountStatus = {
        Online: `online`,
        Offline: `offline`,
        OfflineWithAI: `offlineWithAi`,
      }),
      (e.AgentStatus = { Online: `online`, Offline: `offline` }),
      (e.ChatStatus = {
        Pending: `pending`,
        Open: `open`,
        Closed: `closed`,
        Served: `served`,
      }),
      (e.ChatReadInfoType = { Agent: `agent`, Contact: `contact` }),
      (e.VisitorStatus = {
        Active: `active`,
        Clicked: `clicked`,
        Idle: `idle`,
        Served: `served`,
        Unserved: `unserved`,
        Triggered: `triggered`,
      }),
      (e.AgentDeviceType = {
        Browser: `browser`,
        Mobile: `mobile`,
        Xmpp: `xmpp`,
        Other: `other`,
      }),
      (e.AgentDevicePlatform = { IOS: `ios`, ANDROID: `android` }),
      (e.MessageDeliveryStatus = {
        Ok: `ok`,
        PermanentFail: `permanent_fail`,
        TemporaryFail: `temporary_fail`,
        Complained: `complained`,
        Seen: `seen`,
      }),
      (e.MessageDeliveryFailReason = {
        Facebook24hWindow: `facebook.outside_allowed_window`,
        InstagramExceededFileSize: `instagram.exceeded_file_size`,
        InstagramUnknown: `instagram.unknown`,
        InstagramUnsupportedFileType: `instagram.unsupported_file_type`,
        WhatsappUnsupportedFile: `whatsapp.unsupported_file_type`,
        WhatsappUnknown: `whatsapp.unknown`,
      });
  }),
  Dc = s((e) => {
    var t =
        (e && e.__createBinding) ||
        (Object.create
          ? function (e, t, n, r) {
              r === void 0 && (r = n);
              var i = Object.getOwnPropertyDescriptor(t, n);
              (!i ||
                (`get` in i ? !t.__esModule : i.writable || i.configurable)) &&
                (i = {
                  enumerable: !0,
                  get: function () {
                    return t[n];
                  },
                }),
                Object.defineProperty(e, r, i);
            }
          : function (e, t, n, r) {
              r === void 0 && (r = n), (e[r] = t[n]);
            }),
      n =
        (e && e.__exportStar) ||
        function (e, n) {
          for (var r in e)
            r !== `default` &&
              !Object.prototype.hasOwnProperty.call(n, r) &&
              t(n, e, r);
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.SocketError = e.default = void 0);
    var r = Cc();
    Object.defineProperty(e, `default`, {
      enumerable: !0,
      get: function () {
        return r.WebsocketVisitorClient;
      },
    }),
      n(Cc(), e),
      n(wc(), e),
      n(Tc(), e);
    var i = Ds();
    Object.defineProperty(e, `SocketError`, {
      enumerable: !0,
      get: function () {
        return i.SocketError;
      },
    }),
      n(Ec(), e);
  }),
  Oc = O(null),
  kc = O(!1),
  Ac = O([]),
  jc = (e) => {
    Ac.update((t) => [...t, e]);
  },
  Mc = () => {
    let e;
    return Ac.update((t) => ((e = t.pop()), t)), e ?? null;
  },
  Nc = () => A(Ac).length === 0,
  Pc = k(Oc, (e) => e !== null),
  Fc = (e, { useStack: t = !1 } = {}) => {
    Oc.update((n) => (t && n && jc(n), kc.set(n !== null), e));
  },
  Ic = () => {
    let e = null;
    Nc() || (e = Mc()), Oc.set(e);
  },
  Lc = (function (e) {
    return (
      (e[(e.Options = 0)] = `Options`),
      (e[(e.GdprAndPrivacy = 1)] = `GdprAndPrivacy`),
      (e[(e.AuthForm = 2)] = `AuthForm`),
      (e[(e.CloseChat = 3)] = `CloseChat`),
      (e[(e.ChatRating = 4)] = `ChatRating`),
      (e[(e.TicketForm = 5)] = `TicketForm`),
      e
    );
  })({}),
  Rc = 1e3,
  zc = Symbol(`contentListItem`),
  Bc = Symbol(`contentMessageAttachment`),
  Vc = `-replies`,
  Hc = 0.35,
  Uc = 5e3,
  Wc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 });
  }),
  Gc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.CardActionType = e.CardsLayout = void 0),
      (e.CardsLayout = { Carousel: `carousel` }),
      (e.CardActionType = { OpenUrl: `open_url` });
  }),
  Kc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 });
  }),
  qc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.RatingTarget =
        e.GroupType =
        e.ChannelType =
        e.MessageSubType =
        e.MessageType =
        e.AttachmentInvalidReason =
        e.AttachmentType =
        e.MessageActionType =
          void 0),
      (e.MessageActionType = { Text: `text`, OpenUrl: `open_url` }),
      (e.AttachmentType = {
        Cards: `cards`,
        File: `file`,
        Image: `image`,
        Media: `media`,
        Invalid: `invalid`,
      }),
      (e.AttachmentInvalidReason = {
        InvalidSize: `invalid_size`,
        InvalidType: `invalid_type`,
      }),
      (e.MessageType = {
        Message: `message`,
        Note: `note`,
        Event: `event`,
        Help: `help`,
      }),
      (e.MessageSubType = {
        Agent: `agent`,
        Contact: `contact`,
        Trigger: `trigger`,
        Bot: `bot`,
        System: `system`,
        AgentExternal: `agent_external`,
        FoundEmail: `found_email`,
        ChatResolve: `chat_resolve`,
        Email: `email`,
      }),
      (e.ChannelType = {
        Default: `default`,
        Email: `email`,
        EmailIntegration: `email_integration`,
        FacebookMessenger: `facebook_messenger`,
        Gmail: `gmail`,
        Smartsupp: `smartsupp`,
        Instagram: `instagram`,
        Whatsapp: `whatsapp`,
      });
    var t;
    (function (e) {
      (e.ai = `ai`), (e.chatbot = `chatbot`), (e.message = `message`);
    })(t || (e.GroupType = t = {}));
    var n;
    (function (e) {
      (e.Agent = `agent`), (e.Ai = `ai`);
    })(n || (e.RatingTarget = n = {}));
  }),
  Jc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.ParticipantType = void 0);
    var t;
    (function (e) {
      (e.from = `from`), (e.to = `to`), (e.cc = `cc`), (e.bcc = `bcc`);
    })(t || (e.ParticipantType = t = {}));
  }),
  Yc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.MessageContentType = e.MessageContent = void 0);
    var t;
    (function (e) {
      (function (e) {
        e.Type = {
          Text: `text`,
          Upload: `upload`,
          RateForm: `rate_form`,
          TicketForm: `ticket_form`,
          Email: `email`,
        };
      })((e.Message ||= {})),
        (function (e) {
          e.Type = {
            AgentJoin: `agent_join`,
            AgentAssign: `agent_assign`,
            AgentUnassign: `agent_unassign`,
            AgentLeave: `agent_leave`,
            BotAssign: `bot_assign`,
            BotUnassign: `bot_unassign`,
            ChatClose: `chat_close`,
            ChatVisitorClose: `chat_visitor_close`,
          };
        })((e.Event ||= {})),
        (function (e) {
          e.Type = { Text: `text`, FoundEmail: `found_email` };
        })((e.Help ||= {})),
        (function (e) {
          e.Type = { Text: `text` };
        })((e.Note ||= {}));
    })(t || (e.MessageContent = t = {})),
      (e.MessageContentType = {
        ...t.Message.Type,
        ...t.Event.Type,
        ...t.Help.Type,
        ...t.Note.Type,
      });
  }),
  Xc = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 });
  }),
  Zc = s((e) => {
    var t =
        (e && e.__createBinding) ||
        (Object.create
          ? function (e, t, n, r) {
              r === void 0 && (r = n);
              var i = Object.getOwnPropertyDescriptor(t, n);
              (!i ||
                (`get` in i ? !t.__esModule : i.writable || i.configurable)) &&
                (i = {
                  enumerable: !0,
                  get: function () {
                    return t[n];
                  },
                }),
                Object.defineProperty(e, r, i);
            }
          : function (e, t, n, r) {
              r === void 0 && (r = n), (e[r] = t[n]);
            }),
      n =
        (e && e.__exportStar) ||
        function (e, n) {
          for (var r in e)
            r !== `default` &&
              !Object.prototype.hasOwnProperty.call(n, r) &&
              t(n, e, r);
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      n(Wc(), e),
      n(Gc(), e),
      n(Kc(), e),
      n(qc(), e),
      n(Jc(), e),
      n(Yc(), e),
      n(Xc(), e);
  }),
  Qc = (e, t) => {
    let n = {};
    for (let r of t) {
      let t = String(r[e]);
      n[t] = r;
    }
    return n;
  },
  $c = (() => {
    let { subscribe: e, set: t } = O({});
    return {
      subscribe: e,
      setGroups: (e) => {
        t(Qc(`key`, e));
      },
    };
  })(),
  el = k([$c], ([e]) => Object.values(e)),
  tl = s((e, t) => {
    var n =
        /^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/,
      r = [
        `source`,
        `protocol`,
        `authority`,
        `userInfo`,
        `user`,
        `password`,
        `host`,
        `port`,
        `relative`,
        `path`,
        `directory`,
        `file`,
        `query`,
        `anchor`,
      ];
    t.exports = function (e) {
      var t = e,
        i = e.indexOf(`[`),
        a = e.indexOf(`]`);
      i != -1 &&
        a != -1 &&
        (e =
          e.substring(0, i) +
          e.substring(i, a).replace(/:/g, `;`) +
          e.substring(a, e.length));
      for (var o = n.exec(e || ``), s = {}, c = 14; c--; ) s[r[c]] = o[c] || ``;
      return (
        i != -1 &&
          a != -1 &&
          ((s.source = t),
          (s.host = s.host.substring(1, s.host.length - 1).replace(/;/g, `:`)),
          (s.authority = s.authority
            .replace(`[`, ``)
            .replace(`]`, ``)
            .replace(/;/g, `:`)),
          (s.ipv6uri = !0)),
        s
      );
    };
  }),
  nl = s((e, t) => {
    function n(e) {
      (n.debug = n),
        (n.default = n),
        (n.coerce = l),
        (n.disable = o),
        (n.enable = a),
        (n.enabled = s),
        (n.humanize = ws()),
        Object.keys(e).forEach((t) => {
          n[t] = e[t];
        }),
        (n.instances = []),
        (n.names = []),
        (n.skips = []),
        (n.formatters = {});
      function t(e) {
        let t = 0;
        for (let n = 0; n < e.length; n++)
          (t = (t << 5) - t + e.charCodeAt(n)), (t |= 0);
        return n.colors[Math.abs(t) % n.colors.length];
      }
      n.selectColor = t;
      function n(e) {
        let a;
        function o(...e) {
          if (!o.enabled) return;
          let t = o,
            r = Number(new Date());
          (t.diff = r - (a || r)),
            (t.prev = a),
            (t.curr = r),
            (a = r),
            (e[0] = n.coerce(e[0])),
            typeof e[0] != `string` && e.unshift(`%O`);
          let i = 0;
          (e[0] = e[0].replace(/%([a-zA-Z%])/g, (r, a) => {
            if (r === `%%`) return r;
            i++;
            let o = n.formatters[a];
            if (typeof o == `function`) {
              let n = e[i];
              (r = o.call(t, n)), e.splice(i, 1), i--;
            }
            return r;
          })),
            n.formatArgs.call(t, e),
            (t.log || n.log).apply(t, e);
        }
        return (
          (o.namespace = e),
          (o.enabled = n.enabled(e)),
          (o.useColors = n.useColors()),
          (o.color = t(e)),
          (o.destroy = r),
          (o.extend = i),
          typeof n.init == `function` && n.init(o),
          n.instances.push(o),
          o
        );
      }
      function r() {
        let e = n.instances.indexOf(this);
        return e === -1 ? !1 : (n.instances.splice(e, 1), !0);
      }
      function i(e, t) {
        let r = n(this.namespace + (t === void 0 ? `:` : t) + e);
        return (r.log = this.log), r;
      }
      function a(e) {
        n.save(e), (n.names = []), (n.skips = []);
        let t,
          r = (typeof e == `string` ? e : ``).split(/[\s,]+/),
          i = r.length;
        for (t = 0; t < i; t++)
          r[t] &&
            ((e = r[t].replace(/\*/g, `.*?`)),
            e[0] === `-`
              ? n.skips.push(RegExp(`^` + e.substr(1) + `$`))
              : n.names.push(RegExp(`^` + e + `$`)));
        for (t = 0; t < n.instances.length; t++) {
          let e = n.instances[t];
          e.enabled = n.enabled(e.namespace);
        }
      }
      function o() {
        let e = [...n.names.map(c), ...n.skips.map(c).map((e) => `-` + e)].join(
          `,`
        );
        return n.enable(``), e;
      }
      function s(e) {
        if (e[e.length - 1] === `*`) return !0;
        let t, r;
        for (t = 0, r = n.skips.length; t < r; t++)
          if (n.skips[t].test(e)) return !1;
        for (t = 0, r = n.names.length; t < r; t++)
          if (n.names[t].test(e)) return !0;
        return !1;
      }
      function c(e) {
        return e
          .toString()
          .substring(2, e.toString().length - 2)
          .replace(/\.\*\?$/, `*`);
      }
      function l(e) {
        return e instanceof Error ? e.stack || e.message : e;
      }
      return n.enable(n.load()), n;
    }
    t.exports = n;
  }),
  rl = s((e, t) => {
    (e.log = i),
      (e.formatArgs = r),
      (e.save = a),
      (e.load = o),
      (e.useColors = n),
      (e.storage = s()),
      (e.colors =
        `#0000CC.#0000FF.#0033CC.#0033FF.#0066CC.#0066FF.#0099CC.#0099FF.#00CC00.#00CC33.#00CC66.#00CC99.#00CCCC.#00CCFF.#3300CC.#3300FF.#3333CC.#3333FF.#3366CC.#3366FF.#3399CC.#3399FF.#33CC00.#33CC33.#33CC66.#33CC99.#33CCCC.#33CCFF.#6600CC.#6600FF.#6633CC.#6633FF.#66CC00.#66CC33.#9900CC.#9900FF.#9933CC.#9933FF.#99CC00.#99CC33.#CC0000.#CC0033.#CC0066.#CC0099.#CC00CC.#CC00FF.#CC3300.#CC3333.#CC3366.#CC3399.#CC33CC.#CC33FF.#CC6600.#CC6633.#CC9900.#CC9933.#CCCC00.#CCCC33.#FF0000.#FF0033.#FF0066.#FF0099.#FF00CC.#FF00FF.#FF3300.#FF3333.#FF3366.#FF3399.#FF33CC.#FF33FF.#FF6600.#FF6633.#FF9900.#FF9933.#FFCC00.#FFCC33`.split(
          `.`
        ));
    function n() {
      return typeof window < `u` &&
        window.process &&
        (window.process.type === `renderer` || window.process.__nwjs)
        ? !0
        : typeof navigator < `u` &&
          navigator.userAgent &&
          navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)
        ? !1
        : (typeof document < `u` &&
            document.documentElement &&
            document.documentElement.style &&
            document.documentElement.style.WebkitAppearance) ||
          (typeof window < `u` &&
            window.console &&
            (window.console.firebug ||
              (window.console.exception && window.console.table))) ||
          (typeof navigator < `u` &&
            navigator.userAgent &&
            navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) &&
            parseInt(RegExp.$1, 10) >= 31) ||
          (typeof navigator < `u` &&
            navigator.userAgent &&
            navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/));
    }
    function r(e) {
      if (
        ((e[0] =
          (this.useColors ? `%c` : ``) +
          this.namespace +
          (this.useColors ? ` %c` : ` `) +
          e[0] +
          (this.useColors ? `%c ` : ` `) +
          `+` +
          t.exports.humanize(this.diff)),
        !this.useColors)
      )
        return;
      let n = `color: ` + this.color;
      e.splice(1, 0, n, `color: inherit`);
      let r = 0,
        i = 0;
      e[0].replace(/%[a-zA-Z%]/g, (e) => {
        e !== `%%` && (r++, e === `%c` && (i = r));
      }),
        e.splice(i, 0, n);
    }
    function i(...e) {
      return typeof console == `object` && console.log && console.log(...e);
    }
    function a(t) {
      try {
        t ? e.storage.setItem(`debug`, t) : e.storage.removeItem(`debug`);
      } catch {}
    }
    function o() {
      let t;
      try {
        t = e.storage.getItem(`debug`);
      } catch {}
      return (
        !t && typeof process < `u` && `env` in process && (t = {}.DEBUG), t
      );
    }
    function s() {
      try {
        return localStorage;
      } catch {}
    }
    t.exports = nl()(e);
    var { formatters: c } = t.exports;
    c.j = function (e) {
      try {
        return JSON.stringify(e);
      } catch (e) {
        return `[UnexpectedJSONParseError]: ` + e.message;
      }
    };
  }),
  il = s((e, t) => {
    var n = tl(),
      r = rl()(`socket.io-client:url`);
    t.exports = i;
    function i(e, t) {
      var i = e;
      (t ||= typeof location < `u` && location),
        (e ??= t.protocol + `//` + t.host),
        typeof e == `string` &&
          (e.charAt(0) === `/` &&
            (e = e.charAt(1) === `/` ? t.protocol + e : t.host + e),
          /^(https?|wss?):\/\//.test(e) ||
            (r(`protocol-less url %s`, e),
            (e = t === void 0 ? `https://` + e : t.protocol + `//` + e)),
          r(`parse %s`, e),
          (i = n(e))),
        i.port ||
          (/^(http|ws)$/.test(i.protocol)
            ? (i.port = `80`)
            : /^(http|ws)s$/.test(i.protocol) && (i.port = `443`)),
        (i.path = i.path || `/`);
      var a = i.host.indexOf(`:`) === -1 ? i.host : `[` + i.host + `]`;
      return (
        (i.id = i.protocol + `://` + a + `:` + i.port),
        (i.href =
          i.protocol +
          `://` +
          a +
          (t && t.port === i.port ? `` : `:` + i.port)),
        i
      );
    }
  }),
  al = s((e, t) => {
    t.exports = (function () {
      return typeof self < `u`
        ? self
        : typeof window < `u`
        ? window
        : Function(`return this`)();
    })();
  }),
  ol = s((e, t) => {
    var n = zs(),
      r = al();
    t.exports = function (e) {
      var t = e.xdomain,
        i = e.xscheme,
        a = e.enablesXDR;
      try {
        if (typeof XMLHttpRequest < `u` && (!t || n))
          return new XMLHttpRequest();
      } catch {}
      try {
        if (typeof XDomainRequest < `u` && !i && a) return new XDomainRequest();
      } catch {}
      if (!t)
        try {
          return new r[[`Active`, `Object`].join(`X`)](`Microsoft.XMLHTTP`);
        } catch {}
    };
  }),
  sl = s((e, t) => {
    var n = Ys(),
      r = Ps();
    t.exports = i;
    function i(e) {
      (this.path = e.path),
        (this.hostname = e.hostname),
        (this.port = e.port),
        (this.secure = e.secure),
        (this.query = e.query),
        (this.timestampParam = e.timestampParam),
        (this.timestampRequests = e.timestampRequests),
        (this.readyState = ``),
        (this.agent = e.agent || !1),
        (this.socket = e.socket),
        (this.enablesXDR = e.enablesXDR),
        (this.withCredentials = e.withCredentials),
        (this.pfx = e.pfx),
        (this.key = e.key),
        (this.passphrase = e.passphrase),
        (this.cert = e.cert),
        (this.ca = e.ca),
        (this.ciphers = e.ciphers),
        (this.rejectUnauthorized = e.rejectUnauthorized),
        (this.forceNode = e.forceNode),
        (this.isReactNative = e.isReactNative),
        (this.extraHeaders = e.extraHeaders),
        (this.localAddress = e.localAddress);
    }
    r(i.prototype),
      (i.prototype.onError = function (e, t) {
        var n = Error(e);
        return (
          (n.type = `TransportError`),
          (n.description = t),
          this.emit(`error`, n),
          this
        );
      }),
      (i.prototype.open = function () {
        return (
          (this.readyState === `closed` || this.readyState === ``) &&
            ((this.readyState = `opening`), this.doOpen()),
          this
        );
      }),
      (i.prototype.close = function () {
        return (
          (this.readyState === `opening` || this.readyState === `open`) &&
            (this.doClose(), this.onClose()),
          this
        );
      }),
      (i.prototype.send = function (e) {
        if (this.readyState === `open`) this.write(e);
        else throw Error(`Transport not open`);
      }),
      (i.prototype.onOpen = function () {
        (this.readyState = `open`), (this.writable = !0), this.emit(`open`);
      }),
      (i.prototype.onData = function (e) {
        var t = n.decodePacket(e, this.socket.binaryType);
        this.onPacket(t);
      }),
      (i.prototype.onPacket = function (e) {
        this.emit(`packet`, e);
      }),
      (i.prototype.onClose = function () {
        (this.readyState = `closed`), this.emit(`close`);
      });
  }),
  cl = s((e, t) => {
    var n = sl(),
      r = Zs(),
      i = Ys(),
      a = Qs(),
      o = $s(),
      s = Ms()(`engine.io-client:polling`);
    t.exports = l;
    var c = (function () {
      return new (ol())({ xdomain: !1 }).responseType != null;
    })();
    function l(e) {
      var t = e && e.forceBase64;
      (!c || t) && (this.supportsBinary = !1), n.call(this, e);
    }
    a(l, n),
      (l.prototype.name = `polling`),
      (l.prototype.doOpen = function () {
        this.poll();
      }),
      (l.prototype.pause = function (e) {
        var t = this;
        this.readyState = `pausing`;
        function n() {
          s(`paused`), (t.readyState = `paused`), e();
        }
        if (this.polling || !this.writable) {
          var r = 0;
          this.polling &&
            (s(`we are currently polling - waiting to pause`),
            r++,
            this.once(`pollComplete`, function () {
              s(`pre-pause polling complete`), --r || n();
            })),
            this.writable ||
              (s(`we are currently writing - waiting to pause`),
              r++,
              this.once(`drain`, function () {
                s(`pre-pause writing complete`), --r || n();
              }));
        } else n();
      }),
      (l.prototype.poll = function () {
        s(`polling`), (this.polling = !0), this.doPoll(), this.emit(`poll`);
      }),
      (l.prototype.onData = function (e) {
        var t = this;
        s(`polling got data %s`, e),
          i.decodePayload(e, this.socket.binaryType, function (e, n, r) {
            if ((t.readyState === `opening` && t.onOpen(), e.type === `close`))
              return t.onClose(), !1;
            t.onPacket(e);
          }),
          this.readyState !== `closed` &&
            ((this.polling = !1),
            this.emit(`pollComplete`),
            this.readyState === `open`
              ? this.poll()
              : s(`ignoring poll - transport state "%s"`, this.readyState));
      }),
      (l.prototype.doClose = function () {
        var e = this;
        function t() {
          s(`writing close packet`), e.write([{ type: `close` }]);
        }
        this.readyState === `open`
          ? (s(`transport open - closing`), t())
          : (s(`transport not open - deferring close`), this.once(`open`, t));
      }),
      (l.prototype.write = function (e) {
        var t = this;
        this.writable = !1;
        var n = function () {
          (t.writable = !0), t.emit(`drain`);
        };
        i.encodePayload(e, this.supportsBinary, function (e) {
          t.doWrite(e, n);
        });
      }),
      (l.prototype.uri = function () {
        var e = this.query || {},
          t = this.secure ? `https` : `http`,
          n = ``;
        !1 !== this.timestampRequests && (e[this.timestampParam] = o()),
          !this.supportsBinary && !e.sid && (e.b64 = 1),
          (e = r.encode(e)),
          this.port &&
            ((t === `https` && Number(this.port) !== 443) ||
              (t === `http` && Number(this.port) !== 80)) &&
            (n = `:` + this.port),
          e.length && (e = `?` + e);
        var i = this.hostname.indexOf(`:`) !== -1;
        return (
          t +
          `://` +
          (i ? `[` + this.hostname + `]` : this.hostname) +
          n +
          this.path +
          e
        );
      });
  }),
  ll = s((e, t) => {
    var n = ol(),
      r = cl(),
      i = Ps(),
      a = Qs(),
      o = Ms()(`engine.io-client:polling-xhr`),
      s = al();
    (t.exports = l), (t.exports.Request = u);
    function c() {}
    function l(e) {
      if (
        (r.call(this, e),
        (this.requestTimeout = e.requestTimeout),
        (this.extraHeaders = e.extraHeaders),
        typeof location < `u`)
      ) {
        var t = location.protocol === `https:`,
          n = location.port;
        (n ||= t ? 443 : 80),
          (this.xd =
            (typeof location < `u` && e.hostname !== location.hostname) ||
            n !== e.port),
          (this.xs = e.secure !== t);
      }
    }
    a(l, r),
      (l.prototype.supportsBinary = !0),
      (l.prototype.request = function (e) {
        return (
          (e ||= {}),
          (e.uri = this.uri()),
          (e.xd = this.xd),
          (e.xs = this.xs),
          (e.agent = this.agent || !1),
          (e.supportsBinary = this.supportsBinary),
          (e.enablesXDR = this.enablesXDR),
          (e.withCredentials = this.withCredentials),
          (e.pfx = this.pfx),
          (e.key = this.key),
          (e.passphrase = this.passphrase),
          (e.cert = this.cert),
          (e.ca = this.ca),
          (e.ciphers = this.ciphers),
          (e.rejectUnauthorized = this.rejectUnauthorized),
          (e.requestTimeout = this.requestTimeout),
          (e.extraHeaders = this.extraHeaders),
          new u(e)
        );
      }),
      (l.prototype.doWrite = function (e, t) {
        var n = typeof e != `string` && e !== void 0,
          r = this.request({ method: `POST`, data: e, isBinary: n }),
          i = this;
        r.on(`success`, t),
          r.on(`error`, function (e) {
            i.onError(`xhr post error`, e);
          }),
          (this.sendXhr = r);
      }),
      (l.prototype.doPoll = function () {
        o(`xhr poll`);
        var e = this.request(),
          t = this;
        e.on(`data`, function (e) {
          t.onData(e);
        }),
          e.on(`error`, function (e) {
            t.onError(`xhr poll error`, e);
          }),
          (this.pollXhr = e);
      });
    function u(e) {
      (this.method = e.method || `GET`),
        (this.uri = e.uri),
        (this.xd = !!e.xd),
        (this.xs = !!e.xs),
        (this.async = !1 !== e.async),
        (this.data = e.data === void 0 ? null : e.data),
        (this.agent = e.agent),
        (this.isBinary = e.isBinary),
        (this.supportsBinary = e.supportsBinary),
        (this.enablesXDR = e.enablesXDR),
        (this.withCredentials = e.withCredentials),
        (this.requestTimeout = e.requestTimeout),
        (this.pfx = e.pfx),
        (this.key = e.key),
        (this.passphrase = e.passphrase),
        (this.cert = e.cert),
        (this.ca = e.ca),
        (this.ciphers = e.ciphers),
        (this.rejectUnauthorized = e.rejectUnauthorized),
        (this.extraHeaders = e.extraHeaders),
        this.create();
    }
    if (
      (i(u.prototype),
      (u.prototype.create = function () {
        var e = {
          agent: this.agent,
          xdomain: this.xd,
          xscheme: this.xs,
          enablesXDR: this.enablesXDR,
        };
        (e.pfx = this.pfx),
          (e.key = this.key),
          (e.passphrase = this.passphrase),
          (e.cert = this.cert),
          (e.ca = this.ca),
          (e.ciphers = this.ciphers),
          (e.rejectUnauthorized = this.rejectUnauthorized);
        var t = (this.xhr = new n(e)),
          r = this;
        try {
          o(`xhr open %s: %s`, this.method, this.uri),
            t.open(this.method, this.uri, this.async);
          try {
            if (this.extraHeaders)
              for (var i in (t.setDisableHeaderCheck &&
                t.setDisableHeaderCheck(!0),
              this.extraHeaders))
                this.extraHeaders.hasOwnProperty(i) &&
                  t.setRequestHeader(i, this.extraHeaders[i]);
          } catch {}
          if (this.method === `POST`)
            try {
              this.isBinary
                ? t.setRequestHeader(`Content-type`, `application/octet-stream`)
                : t.setRequestHeader(
                    `Content-type`,
                    `text/plain;charset=UTF-8`
                  );
            } catch {}
          try {
            t.setRequestHeader(`Accept`, `*/*`);
          } catch {}
          `withCredentials` in t && (t.withCredentials = this.withCredentials),
            this.requestTimeout && (t.timeout = this.requestTimeout),
            this.hasXDR()
              ? ((t.onload = function () {
                  r.onLoad();
                }),
                (t.onerror = function () {
                  r.onError(t.responseText);
                }))
              : (t.onreadystatechange = function () {
                  if (t.readyState === 2)
                    try {
                      var e = t.getResponseHeader(`Content-Type`);
                      ((r.supportsBinary && e === `application/octet-stream`) ||
                        e === `application/octet-stream; charset=UTF-8`) &&
                        (t.responseType = `arraybuffer`);
                    } catch {}
                  t.readyState === 4 &&
                    (t.status === 200 || t.status === 1223
                      ? r.onLoad()
                      : setTimeout(function () {
                          r.onError(typeof t.status == `number` ? t.status : 0);
                        }, 0));
                }),
            o(`xhr data %s`, this.data),
            t.send(this.data);
        } catch (e) {
          setTimeout(function () {
            r.onError(e);
          }, 0);
          return;
        }
        typeof document < `u` &&
          ((this.index = u.requestsCount++), (u.requests[this.index] = this));
      }),
      (u.prototype.onSuccess = function () {
        this.emit(`success`), this.cleanup();
      }),
      (u.prototype.onData = function (e) {
        this.emit(`data`, e), this.onSuccess();
      }),
      (u.prototype.onError = function (e) {
        this.emit(`error`, e), this.cleanup(!0);
      }),
      (u.prototype.cleanup = function (e) {
        if (!(this.xhr === void 0 || this.xhr === null)) {
          if (
            (this.hasXDR()
              ? (this.xhr.onload = this.xhr.onerror = c)
              : (this.xhr.onreadystatechange = c),
            e)
          )
            try {
              this.xhr.abort();
            } catch {}
          typeof document < `u` && delete u.requests[this.index],
            (this.xhr = null);
        }
      }),
      (u.prototype.onLoad = function () {
        var e;
        try {
          var t;
          try {
            t = this.xhr.getResponseHeader(`Content-Type`);
          } catch {}
          e =
            ((t === `application/octet-stream` ||
              t === `application/octet-stream; charset=UTF-8`) &&
              this.xhr.response) ||
            this.xhr.responseText;
        } catch (e) {
          this.onError(e);
        }
        e != null && this.onData(e);
      }),
      (u.prototype.hasXDR = function () {
        return typeof XDomainRequest < `u` && !this.xs && this.enablesXDR;
      }),
      (u.prototype.abort = function () {
        this.cleanup();
      }),
      (u.requestsCount = 0),
      (u.requests = {}),
      typeof document < `u`)
    ) {
      if (typeof attachEvent == `function`) attachEvent(`onunload`, f);
      else if (typeof addEventListener == `function`) {
        var d = `onpagehide` in s ? `pagehide` : `unload`;
        addEventListener(d, f, !1);
      }
    }
    function f() {
      for (var e in u.requests)
        u.requests.hasOwnProperty(e) && u.requests[e].abort();
    }
  }),
  ul = s((e, t) => {
    var n = cl(),
      r = Qs(),
      i = al();
    t.exports = l;
    var a = /\n/g,
      o = /\\n/g,
      s;
    function c() {}
    function l(e) {
      n.call(this, e),
        (this.query = this.query || {}),
        (s ||= i.___eio = i.___eio || []),
        (this.index = s.length);
      var t = this;
      s.push(function (e) {
        t.onData(e);
      }),
        (this.query.j = this.index),
        typeof addEventListener == `function` &&
          addEventListener(
            `beforeunload`,
            function () {
              t.script && (t.script.onerror = c);
            },
            !1
          );
    }
    r(l, n),
      (l.prototype.supportsBinary = !1),
      (l.prototype.doClose = function () {
        (this.script &&=
          (this.script.parentNode.removeChild(this.script), null)),
          this.form &&
            (this.form.parentNode.removeChild(this.form),
            (this.form = null),
            (this.iframe = null)),
          n.prototype.doClose.call(this);
      }),
      (l.prototype.doPoll = function () {
        var e = this,
          t = document.createElement(`script`);
        (this.script &&=
          (this.script.parentNode.removeChild(this.script), null)),
          (t.async = !0),
          (t.src = this.uri()),
          (t.onerror = function (t) {
            e.onError(`jsonp poll error`, t);
          });
        var n = document.getElementsByTagName(`script`)[0];
        n
          ? n.parentNode.insertBefore(t, n)
          : (document.head || document.body).appendChild(t),
          (this.script = t),
          typeof navigator < `u` &&
            /gecko/i.test(navigator.userAgent) &&
            setTimeout(function () {
              var e = document.createElement(`iframe`);
              document.body.appendChild(e), document.body.removeChild(e);
            }, 100);
      }),
      (l.prototype.doWrite = function (e, t) {
        var n = this;
        if (!this.form) {
          var r = document.createElement(`form`),
            i = document.createElement(`textarea`),
            s = (this.iframeId = `eio_iframe_` + this.index),
            c;
          (r.className = `socketio`),
            (r.style.position = `absolute`),
            (r.style.top = `-1000px`),
            (r.style.left = `-1000px`),
            (r.target = s),
            (r.method = `POST`),
            r.setAttribute(`accept-charset`, `utf-8`),
            (i.name = `d`),
            r.appendChild(i),
            document.body.appendChild(r),
            (this.form = r),
            (this.area = i);
        }
        this.form.action = this.uri();
        function l() {
          u(), t();
        }
        function u() {
          if (n.iframe)
            try {
              n.form.removeChild(n.iframe);
            } catch (e) {
              n.onError(`jsonp polling iframe removal error`, e);
            }
          try {
            var e = `<iframe src="javascript:0" name="` + n.iframeId + `">`;
            c = document.createElement(e);
          } catch {
            (c = document.createElement(`iframe`)),
              (c.name = n.iframeId),
              (c.src = `javascript:0`);
          }
          (c.id = n.iframeId), n.form.appendChild(c), (n.iframe = c);
        }
        u(),
          (e = e.replace(
            o,
            `\\
`
          )),
          (this.area.value = e.replace(a, `\\n`));
        try {
          this.form.submit();
        } catch {}
        this.iframe.attachEvent
          ? (this.iframe.onreadystatechange = function () {
              n.iframe.readyState === `complete` && l();
            })
          : (this.iframe.onload = l);
      });
  }),
  dl = s((e, t) => {
    var n = sl(),
      r = Ys(),
      i = Zs(),
      a = Qs(),
      o = $s(),
      s = Ms()(`engine.io-client:websocket`),
      c,
      l;
    if (
      (typeof WebSocket < `u`
        ? (c = WebSocket)
        : typeof self < `u` && (c = self.WebSocket || self.MozWebSocket),
      typeof window > `u`)
    )
      try {
        l = rc();
      } catch {}
    var u = c || l;
    t.exports = d;
    function d(e) {
      e && e.forceBase64 && (this.supportsBinary = !1),
        (this.perMessageDeflate = e.perMessageDeflate),
        (this.usingBrowserWebSocket = c && !e.forceNode),
        (this.protocols = e.protocols),
        this.usingBrowserWebSocket || (u = l),
        n.call(this, e);
    }
    a(d, n),
      (d.prototype.name = `websocket`),
      (d.prototype.supportsBinary = !0),
      (d.prototype.doOpen = function () {
        if (this.check()) {
          var e = this.uri(),
            t = this.protocols,
            n = {};
          this.isReactNative ||
            ((n.agent = this.agent),
            (n.perMessageDeflate = this.perMessageDeflate),
            (n.pfx = this.pfx),
            (n.key = this.key),
            (n.passphrase = this.passphrase),
            (n.cert = this.cert),
            (n.ca = this.ca),
            (n.ciphers = this.ciphers),
            (n.rejectUnauthorized = this.rejectUnauthorized)),
            this.extraHeaders && (n.headers = this.extraHeaders),
            this.localAddress && (n.localAddress = this.localAddress);
          try {
            this.ws =
              this.usingBrowserWebSocket && !this.isReactNative
                ? t
                  ? new u(e, t)
                  : new u(e)
                : new u(e, t, n);
          } catch (e) {
            return this.emit(`error`, e);
          }
          this.ws.binaryType === void 0 && (this.supportsBinary = !1),
            this.ws.supports && this.ws.supports.binary
              ? ((this.supportsBinary = !0),
                (this.ws.binaryType = `nodebuffer`))
              : (this.ws.binaryType = `arraybuffer`),
            this.addEventListeners();
        }
      }),
      (d.prototype.addEventListeners = function () {
        var e = this;
        (this.ws.onopen = function () {
          e.onOpen();
        }),
          (this.ws.onclose = function () {
            e.onClose();
          }),
          (this.ws.onmessage = function (t) {
            e.onData(t.data);
          }),
          (this.ws.onerror = function (t) {
            e.onError(`websocket error`, t);
          });
      }),
      (d.prototype.write = function (e) {
        var t = this;
        this.writable = !1;
        for (var n = e.length, i = 0, a = n; i < a; i++)
          (function (e) {
            r.encodePacket(e, t.supportsBinary, function (r) {
              if (!t.usingBrowserWebSocket) {
                var i = {};
                e.options && (i.compress = e.options.compress),
                  t.perMessageDeflate &&
                    (typeof r == `string` ? Buffer.byteLength(r) : r.length) <
                      t.perMessageDeflate.threshold &&
                    (i.compress = !1);
              }
              try {
                t.usingBrowserWebSocket ? t.ws.send(r) : t.ws.send(r, i);
              } catch {
                s(`websocket closed before onclose event`);
              }
              --n || o();
            });
          })(e[i]);
        function o() {
          t.emit(`flush`),
            setTimeout(function () {
              (t.writable = !0), t.emit(`drain`);
            }, 0);
        }
      }),
      (d.prototype.onClose = function () {
        n.prototype.onClose.call(this);
      }),
      (d.prototype.doClose = function () {
        this.ws !== void 0 && this.ws.close();
      }),
      (d.prototype.uri = function () {
        var e = this.query || {},
          t = this.secure ? `wss` : `ws`,
          n = ``;
        this.port &&
          ((t === `wss` && Number(this.port) !== 443) ||
            (t === `ws` && Number(this.port) !== 80)) &&
          (n = `:` + this.port),
          this.timestampRequests && (e[this.timestampParam] = o()),
          this.supportsBinary || (e.b64 = 1),
          (e = i.encode(e)),
          e.length && (e = `?` + e);
        var r = this.hostname.indexOf(`:`) !== -1;
        return (
          t +
          `://` +
          (r ? `[` + this.hostname + `]` : this.hostname) +
          n +
          this.path +
          e
        );
      }),
      (d.prototype.check = function () {
        return !!u && !(`__initialize` in u && this.name === d.prototype.name);
      });
  }),
  fl = s((e) => {
    var t = ol(),
      n = ll(),
      r = ul(),
      i = dl();
    (e.polling = a), (e.websocket = i);
    function a(e) {
      var i,
        a = !1,
        o = !1,
        s = !1 !== e.jsonp;
      if (typeof location < `u`) {
        var c = location.protocol === `https:`,
          l = location.port;
        (l ||= c ? 443 : 80),
          (a = e.hostname !== location.hostname || l !== e.port),
          (o = e.secure !== c);
      }
      if (
        ((e.xdomain = a),
        (e.xscheme = o),
        (i = new t(e)),
        `open` in i && !e.forceJSONP)
      )
        return new n(e);
      if (!s) throw Error(`JSONP disabled`);
      return new r(e);
    }
  }),
  pl = s((e, t) => {
    var n = fl(),
      r = Ps(),
      i = Ms()(`engine.io-client:socket`),
      a = oc(),
      o = Ys(),
      s = ks(),
      c = Zs();
    t.exports = l;
    function l(e, t) {
      if (!(this instanceof l)) return new l(e, t);
      (t ||= {}),
        e && typeof e == `object` && ((t = e), (e = null)),
        e
          ? ((e = s(e)),
            (t.hostname = e.host),
            (t.secure = e.protocol === `https` || e.protocol === `wss`),
            (t.port = e.port),
            e.query && (t.query = e.query))
          : t.host && (t.hostname = s(t.host).host),
        (this.secure =
          t.secure == null
            ? typeof location < `u` && location.protocol === `https:`
            : t.secure),
        t.hostname && !t.port && (t.port = this.secure ? `443` : `80`),
        (this.agent = t.agent || !1),
        (this.hostname =
          t.hostname ||
          (typeof location < `u` ? location.hostname : `localhost`)),
        (this.port =
          t.port ||
          (typeof location < `u` && location.port
            ? location.port
            : this.secure
            ? 443
            : 80)),
        (this.query = t.query || {}),
        typeof this.query == `string` && (this.query = c.decode(this.query)),
        (this.upgrade = !1 !== t.upgrade),
        (this.path = (t.path || `/engine.io`).replace(/\/$/, ``) + `/`),
        (this.forceJSONP = !!t.forceJSONP),
        (this.jsonp = !1 !== t.jsonp),
        (this.forceBase64 = !!t.forceBase64),
        (this.enablesXDR = !!t.enablesXDR),
        (this.withCredentials = !1 !== t.withCredentials),
        (this.timestampParam = t.timestampParam || `t`),
        (this.timestampRequests = t.timestampRequests),
        (this.transports = t.transports || [`polling`, `websocket`]),
        (this.transportOptions = t.transportOptions || {}),
        (this.readyState = ``),
        (this.writeBuffer = []),
        (this.prevBufferLen = 0),
        (this.policyPort = t.policyPort || 843),
        (this.rememberUpgrade = t.rememberUpgrade || !1),
        (this.binaryType = null),
        (this.onlyBinaryUpgrades = t.onlyBinaryUpgrades),
        (this.perMessageDeflate =
          !1 === t.perMessageDeflate ? !1 : t.perMessageDeflate || {}),
        !0 === this.perMessageDeflate && (this.perMessageDeflate = {}),
        this.perMessageDeflate &&
          this.perMessageDeflate.threshold == null &&
          (this.perMessageDeflate.threshold = 1024),
        (this.pfx = t.pfx || null),
        (this.key = t.key || null),
        (this.passphrase = t.passphrase || null),
        (this.cert = t.cert || null),
        (this.ca = t.ca || null),
        (this.ciphers = t.ciphers || null),
        (this.rejectUnauthorized =
          t.rejectUnauthorized === void 0 ? !0 : t.rejectUnauthorized),
        (this.forceNode = !!t.forceNode),
        (this.isReactNative =
          typeof navigator < `u` &&
          typeof navigator.product == `string` &&
          navigator.product.toLowerCase() === `reactnative`),
        (typeof self > `u` || this.isReactNative) &&
          (t.extraHeaders &&
            Object.keys(t.extraHeaders).length > 0 &&
            (this.extraHeaders = t.extraHeaders),
          t.localAddress && (this.localAddress = t.localAddress)),
        (this.id = null),
        (this.upgrades = null),
        (this.pingInterval = null),
        (this.pingTimeout = null),
        (this.pingIntervalTimer = null),
        (this.pingTimeoutTimer = null),
        this.open();
    }
    (l.priorWebsocketSuccess = !1),
      r(l.prototype),
      (l.protocol = o.protocol),
      (l.Socket = l),
      (l.Transport = sl()),
      (l.transports = fl()),
      (l.parser = Ys()),
      (l.prototype.createTransport = function (e) {
        i(`creating transport "%s"`, e);
        var t = u(this.query);
        (t.EIO = o.protocol), (t.transport = e);
        var r = this.transportOptions[e] || {};
        return (
          this.id && (t.sid = this.id),
          new n[e]({
            query: t,
            socket: this,
            agent: r.agent || this.agent,
            hostname: r.hostname || this.hostname,
            port: r.port || this.port,
            secure: r.secure || this.secure,
            path: r.path || this.path,
            forceJSONP: r.forceJSONP || this.forceJSONP,
            jsonp: r.jsonp || this.jsonp,
            forceBase64: r.forceBase64 || this.forceBase64,
            enablesXDR: r.enablesXDR || this.enablesXDR,
            withCredentials: r.withCredentials || this.withCredentials,
            timestampRequests: r.timestampRequests || this.timestampRequests,
            timestampParam: r.timestampParam || this.timestampParam,
            policyPort: r.policyPort || this.policyPort,
            pfx: r.pfx || this.pfx,
            key: r.key || this.key,
            passphrase: r.passphrase || this.passphrase,
            cert: r.cert || this.cert,
            ca: r.ca || this.ca,
            ciphers: r.ciphers || this.ciphers,
            rejectUnauthorized: r.rejectUnauthorized || this.rejectUnauthorized,
            perMessageDeflate: r.perMessageDeflate || this.perMessageDeflate,
            extraHeaders: r.extraHeaders || this.extraHeaders,
            forceNode: r.forceNode || this.forceNode,
            localAddress: r.localAddress || this.localAddress,
            requestTimeout: r.requestTimeout || this.requestTimeout,
            protocols: r.protocols || void 0,
            isReactNative: this.isReactNative,
          })
        );
      });
    function u(e) {
      var t = {};
      for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
      return t;
    }
    (l.prototype.open = function () {
      var e;
      if (
        this.rememberUpgrade &&
        l.priorWebsocketSuccess &&
        this.transports.indexOf(`websocket`) !== -1
      )
        e = `websocket`;
      else if (this.transports.length === 0) {
        var t = this;
        setTimeout(function () {
          t.emit(`error`, `No transports available`);
        }, 0);
        return;
      } else e = this.transports[0];
      this.readyState = `opening`;
      try {
        e = this.createTransport(e);
      } catch {
        this.transports.shift(), this.open();
        return;
      }
      e.open(), this.setTransport(e);
    }),
      (l.prototype.setTransport = function (e) {
        i(`setting transport %s`, e.name);
        var t = this;
        this.transport &&
          (i(`clearing existing transport %s`, this.transport.name),
          this.transport.removeAllListeners()),
          (this.transport = e),
          e
            .on(`drain`, function () {
              t.onDrain();
            })
            .on(`packet`, function (e) {
              t.onPacket(e);
            })
            .on(`error`, function (e) {
              t.onError(e);
            })
            .on(`close`, function () {
              t.onClose(`transport close`);
            });
      }),
      (l.prototype.probe = function (e) {
        i(`probing transport "%s"`, e);
        var t = this.createTransport(e, { probe: 1 }),
          n = !1,
          r = this;
        l.priorWebsocketSuccess = !1;
        function a() {
          if (r.onlyBinaryUpgrades) {
            var a = !this.supportsBinary && r.transport.supportsBinary;
            n ||= a;
          }
          n ||
            (i(`probe transport "%s" opened`, e),
            t.send([{ type: `ping`, data: `probe` }]),
            t.once(`packet`, function (a) {
              if (!n)
                if (a.type === `pong` && a.data === `probe`) {
                  if (
                    (i(`probe transport "%s" pong`, e),
                    (r.upgrading = !0),
                    r.emit(`upgrading`, t),
                    !t)
                  )
                    return;
                  (l.priorWebsocketSuccess = t.name === `websocket`),
                    i(`pausing current transport "%s"`, r.transport.name),
                    r.transport.pause(function () {
                      n ||
                        (r.readyState !== `closed` &&
                          (i(`changing transport and sending upgrade packet`),
                          f(),
                          r.setTransport(t),
                          t.send([{ type: `upgrade` }]),
                          r.emit(`upgrade`, t),
                          (t = null),
                          (r.upgrading = !1),
                          r.flush()));
                    });
                } else {
                  i(`probe transport "%s" failed`, e);
                  var o = Error(`probe error`);
                  (o.transport = t.name), r.emit(`upgradeError`, o);
                }
            }));
        }
        function o() {
          n || ((n = !0), f(), t.close(), (t = null));
        }
        function s(n) {
          var a = Error(`probe error: ` + n);
          (a.transport = t.name),
            o(),
            i(`probe transport "%s" failed because of error: %s`, e, n),
            r.emit(`upgradeError`, a);
        }
        function c() {
          s(`transport closed`);
        }
        function u() {
          s(`socket closed`);
        }
        function d(e) {
          t &&
            e.name !== t.name &&
            (i(`"%s" works - aborting "%s"`, e.name, t.name), o());
        }
        function f() {
          t.removeListener(`open`, a),
            t.removeListener(`error`, s),
            t.removeListener(`close`, c),
            r.removeListener(`close`, u),
            r.removeListener(`upgrading`, d);
        }
        t.once(`open`, a),
          t.once(`error`, s),
          t.once(`close`, c),
          this.once(`close`, u),
          this.once(`upgrading`, d),
          t.open();
      }),
      (l.prototype.onOpen = function () {
        if (
          (i(`socket open`),
          (this.readyState = `open`),
          (l.priorWebsocketSuccess = this.transport.name === `websocket`),
          this.emit(`open`),
          this.flush(),
          this.readyState === `open` && this.upgrade && this.transport.pause)
        ) {
          i(`starting upgrade probes`);
          for (var e = 0, t = this.upgrades.length; e < t; e++)
            this.probe(this.upgrades[e]);
        }
      }),
      (l.prototype.onPacket = function (e) {
        if (
          this.readyState === `opening` ||
          this.readyState === `open` ||
          this.readyState === `closing`
        )
          switch (
            (i(`socket receive: type "%s", data "%s"`, e.type, e.data),
            this.emit(`packet`, e),
            this.emit(`heartbeat`),
            e.type)
          ) {
            case `open`:
              this.onHandshake(JSON.parse(e.data));
              break;
            case `pong`:
              this.setPing(), this.emit(`pong`);
              break;
            case `error`:
              var t = Error(`server error`);
              (t.code = e.data), this.onError(t);
              break;
            case `message`:
              this.emit(`data`, e.data), this.emit(`message`, e.data);
              break;
          }
        else i(`packet received with socket readyState "%s"`, this.readyState);
      }),
      (l.prototype.onHandshake = function (e) {
        this.emit(`handshake`, e),
          (this.id = e.sid),
          (this.transport.query.sid = e.sid),
          (this.upgrades = this.filterUpgrades(e.upgrades)),
          (this.pingInterval = e.pingInterval),
          (this.pingTimeout = e.pingTimeout),
          this.onOpen(),
          this.readyState !== `closed` &&
            (this.setPing(),
            this.removeListener(`heartbeat`, this.onHeartbeat),
            this.on(`heartbeat`, this.onHeartbeat));
      }),
      (l.prototype.onHeartbeat = function (e) {
        clearTimeout(this.pingTimeoutTimer);
        var t = this;
        t.pingTimeoutTimer = setTimeout(function () {
          t.readyState !== `closed` && t.onClose(`ping timeout`);
        }, e || t.pingInterval + t.pingTimeout);
      }),
      (l.prototype.setPing = function () {
        var e = this;
        clearTimeout(e.pingIntervalTimer),
          (e.pingIntervalTimer = setTimeout(function () {
            i(
              `writing ping packet - expecting pong within %sms`,
              e.pingTimeout
            ),
              e.ping(),
              e.onHeartbeat(e.pingTimeout);
          }, e.pingInterval));
      }),
      (l.prototype.ping = function () {
        var e = this;
        this.sendPacket(`ping`, function () {
          e.emit(`ping`);
        });
      }),
      (l.prototype.onDrain = function () {
        this.writeBuffer.splice(0, this.prevBufferLen),
          (this.prevBufferLen = 0),
          this.writeBuffer.length === 0 ? this.emit(`drain`) : this.flush();
      }),
      (l.prototype.flush = function () {
        this.readyState !== `closed` &&
          this.transport.writable &&
          !this.upgrading &&
          this.writeBuffer.length &&
          (i(`flushing %d packets in socket`, this.writeBuffer.length),
          this.transport.send(this.writeBuffer),
          (this.prevBufferLen = this.writeBuffer.length),
          this.emit(`flush`));
      }),
      (l.prototype.write = l.prototype.send =
        function (e, t, n) {
          return this.sendPacket(`message`, e, t, n), this;
        }),
      (l.prototype.sendPacket = function (e, t, n, r) {
        if (
          (typeof t == `function` && ((r = t), (t = void 0)),
          typeof n == `function` && ((r = n), (n = null)),
          !(this.readyState === `closing` || this.readyState === `closed`))
        ) {
          (n ||= {}), (n.compress = !1 !== n.compress);
          var i = { type: e, data: t, options: n };
          this.emit(`packetCreate`, i),
            this.writeBuffer.push(i),
            r && this.once(`flush`, r),
            this.flush();
        }
      }),
      (l.prototype.close = function () {
        if (this.readyState === `opening` || this.readyState === `open`) {
          this.readyState = `closing`;
          var e = this;
          this.writeBuffer.length
            ? this.once(`drain`, function () {
                this.upgrading ? r() : t();
              })
            : this.upgrading
            ? r()
            : t();
        }
        function t() {
          e.onClose(`forced close`),
            i(`socket closing - telling transport to close`),
            e.transport.close();
        }
        function n() {
          e.removeListener(`upgrade`, n),
            e.removeListener(`upgradeError`, n),
            t();
        }
        function r() {
          e.once(`upgrade`, n), e.once(`upgradeError`, n);
        }
        return this;
      }),
      (l.prototype.onError = function (e) {
        i(`socket error %j`, e),
          (l.priorWebsocketSuccess = !1),
          this.emit(`error`, e),
          this.onClose(`transport error`, e);
      }),
      (l.prototype.onClose = function (e, t) {
        if (
          this.readyState === `opening` ||
          this.readyState === `open` ||
          this.readyState === `closing`
        ) {
          i(`socket close with reason: "%s"`, e);
          var n = this;
          clearTimeout(this.pingIntervalTimer),
            clearTimeout(this.pingTimeoutTimer),
            this.transport.removeAllListeners(`close`),
            this.transport.close(),
            this.transport.removeAllListeners(),
            (this.readyState = `closed`),
            (this.id = null),
            this.emit(`close`, e, t),
            (n.writeBuffer = []),
            (n.prevBufferLen = 0);
        }
      }),
      (l.prototype.filterUpgrades = function (e) {
        for (var t = [], n = 0, r = e.length; n < r; n++)
          ~a(this.transports, e[n]) && t.push(e[n]);
        return t;
      });
  }),
  ml = s((e, t) => {
    (t.exports = pl()), (t.exports.parser = Ys());
  }),
  hl = s((e, t) => {
    t !== void 0 && (t.exports = n);
    function n(e) {
      if (e) return r(e);
    }
    function r(e) {
      for (var t in n.prototype) e[t] = n.prototype[t];
      return e;
    }
    (n.prototype.on = n.prototype.addEventListener =
      function (e, t) {
        return (
          (this._callbacks = this._callbacks || {}),
          (this._callbacks[`$` + e] = this._callbacks[`$` + e] || []).push(t),
          this
        );
      }),
      (n.prototype.once = function (e, t) {
        function n() {
          this.off(e, n), t.apply(this, arguments);
        }
        return (n.fn = t), this.on(e, n), this;
      }),
      (n.prototype.off =
        n.prototype.removeListener =
        n.prototype.removeAllListeners =
        n.prototype.removeEventListener =
          function (e, t) {
            if (
              ((this._callbacks = this._callbacks || {}), arguments.length == 0)
            )
              return (this._callbacks = {}), this;
            var n = this._callbacks[`$` + e];
            if (!n) return this;
            if (arguments.length == 1)
              return delete this._callbacks[`$` + e], this;
            for (var r, i = 0; i < n.length; i++)
              if (((r = n[i]), r === t || r.fn === t)) {
                n.splice(i, 1);
                break;
              }
            return this;
          }),
      (n.prototype.emit = function (e) {
        this._callbacks = this._callbacks || {};
        var t = [].slice.call(arguments, 1),
          n = this._callbacks[`$` + e];
        if (n) {
          n = n.slice(0);
          for (var r = 0, i = n.length; r < i; ++r) n[r].apply(this, t);
        }
        return this;
      }),
      (n.prototype.listeners = function (e) {
        return (
          (this._callbacks = this._callbacks || {}),
          this._callbacks[`$` + e] || []
        );
      }),
      (n.prototype.hasListeners = function (e) {
        return !!this.listeners(e).length;
      });
  }),
  gl = s((e, t) => {
    t.exports = n;
    function n(e, t, n) {
      return (
        e.on(t, n),
        {
          destroy: function () {
            e.removeListener(t, n);
          },
        }
      );
    }
  }),
  _l = s((e) => {
    (e.encode = function (e) {
      var t = ``;
      for (var n in e)
        e.hasOwnProperty(n) &&
          (t.length && (t += `&`),
          (t += encodeURIComponent(n) + `=` + encodeURIComponent(e[n])));
      return t;
    }),
      (e.decode = function (e) {
        for (var t = {}, n = e.split(`&`), r = 0, i = n.length; r < i; r++) {
          var a = n[r].split(`=`);
          t[decodeURIComponent(a[0])] = decodeURIComponent(a[1]);
        }
        return t;
      });
  }),
  vl = s((e, t) => {
    var n = Rs(),
      r = hl(),
      i = lc(),
      a = gl(),
      o = dc(),
      s = rl()(`socket.io-client:socket`),
      c = _l(),
      l = Us();
    t.exports = e = f;
    var u = {
        connect: 1,
        connect_error: 1,
        connect_timeout: 1,
        connecting: 1,
        disconnect: 1,
        error: 1,
        reconnect: 1,
        reconnect_attempt: 1,
        reconnect_failed: 1,
        reconnect_error: 1,
        reconnecting: 1,
        ping: 1,
        pong: 1,
      },
      d = r.prototype.emit;
    function f(e, t, n) {
      (this.io = e),
        (this.nsp = t),
        (this.json = this),
        (this.ids = 0),
        (this.acks = {}),
        (this.receiveBuffer = []),
        (this.sendBuffer = []),
        (this.connected = !1),
        (this.disconnected = !0),
        (this.flags = {}),
        n && n.query && (this.query = n.query),
        this.io.autoConnect && this.open();
    }
    r(f.prototype),
      (f.prototype.subEvents = function () {
        if (!this.subs) {
          var e = this.io;
          this.subs = [
            a(e, `open`, o(this, `onopen`)),
            a(e, `packet`, o(this, `onpacket`)),
            a(e, `close`, o(this, `onclose`)),
          ];
        }
      }),
      (f.prototype.open = f.prototype.connect =
        function () {
          return this.connected
            ? this
            : (this.subEvents(),
              this.io.open(),
              this.io.readyState === `open` && this.onopen(),
              this.emit(`connecting`),
              this);
        }),
      (f.prototype.send = function () {
        var e = i(arguments);
        return e.unshift(`message`), this.emit.apply(this, e), this;
      }),
      (f.prototype.emit = function (e) {
        if (u.hasOwnProperty(e)) return d.apply(this, arguments), this;
        var t = i(arguments),
          r = {
            type: (this.flags.binary === void 0 ? l(t) : this.flags.binary)
              ? n.BINARY_EVENT
              : n.EVENT,
            data: t,
          };
        return (
          (r.options = {}),
          (r.options.compress = !this.flags || !1 !== this.flags.compress),
          typeof t[t.length - 1] == `function` &&
            (s(`emitting packet with ack id %d`, this.ids),
            (this.acks[this.ids] = t.pop()),
            (r.id = this.ids++)),
          this.connected ? this.packet(r) : this.sendBuffer.push(r),
          (this.flags = {}),
          this
        );
      }),
      (f.prototype.packet = function (e) {
        (e.nsp = this.nsp), this.io.packet(e);
      }),
      (f.prototype.onopen = function () {
        if ((s(`transport is open - connecting`), this.nsp !== `/`))
          if (this.query) {
            var e =
              typeof this.query == `object` ? c.encode(this.query) : this.query;
            s(`sending connect packet with query %s`, e),
              this.packet({ type: n.CONNECT, query: e });
          } else this.packet({ type: n.CONNECT });
      }),
      (f.prototype.onclose = function (e) {
        s(`close (%s)`, e),
          (this.connected = !1),
          (this.disconnected = !0),
          delete this.id,
          this.emit(`disconnect`, e);
      }),
      (f.prototype.onpacket = function (e) {
        var t = e.nsp === this.nsp,
          r = e.type === n.ERROR && e.nsp === `/`;
        if (!(!t && !r))
          switch (e.type) {
            case n.CONNECT:
              this.onconnect();
              break;
            case n.EVENT:
              this.onevent(e);
              break;
            case n.BINARY_EVENT:
              this.onevent(e);
              break;
            case n.ACK:
              this.onack(e);
              break;
            case n.BINARY_ACK:
              this.onack(e);
              break;
            case n.DISCONNECT:
              this.ondisconnect();
              break;
            case n.ERROR:
              this.emit(`error`, e.data);
              break;
          }
      }),
      (f.prototype.onevent = function (e) {
        var t = e.data || [];
        s(`emitting event %j`, t),
          e.id != null &&
            (s(`attaching ack callback to event`), t.push(this.ack(e.id))),
          this.connected ? d.apply(this, t) : this.receiveBuffer.push(t);
      }),
      (f.prototype.ack = function (e) {
        var t = this,
          r = !1;
        return function () {
          if (!r) {
            r = !0;
            var a = i(arguments);
            s(`sending ack %j`, a),
              t.packet({ type: l(a) ? n.BINARY_ACK : n.ACK, id: e, data: a });
          }
        };
      }),
      (f.prototype.onack = function (e) {
        var t = this.acks[e.id];
        typeof t == `function`
          ? (s(`calling ack %s with %j`, e.id, e.data),
            t.apply(this, e.data),
            delete this.acks[e.id])
          : s(`bad ack %s`, e.id);
      }),
      (f.prototype.onconnect = function () {
        (this.connected = !0),
          (this.disconnected = !1),
          this.emit(`connect`),
          this.emitBuffered();
      }),
      (f.prototype.emitBuffered = function () {
        var e;
        for (e = 0; e < this.receiveBuffer.length; e++)
          d.apply(this, this.receiveBuffer[e]);
        for (this.receiveBuffer = [], e = 0; e < this.sendBuffer.length; e++)
          this.packet(this.sendBuffer[e]);
        this.sendBuffer = [];
      }),
      (f.prototype.ondisconnect = function () {
        s(`server disconnect (%s)`, this.nsp),
          this.destroy(),
          this.onclose(`io server disconnect`);
      }),
      (f.prototype.destroy = function () {
        if (this.subs) {
          for (var e = 0; e < this.subs.length; e++) this.subs[e].destroy();
          this.subs = null;
        }
        this.io.destroy(this);
      }),
      (f.prototype.close = f.prototype.disconnect =
        function () {
          return (
            this.connected &&
              (s(`performing disconnect (%s)`, this.nsp),
              this.packet({ type: n.DISCONNECT })),
            this.destroy(),
            this.connected && this.onclose(`io client disconnect`),
            this
          );
        }),
      (f.prototype.compress = function (e) {
        return (this.flags.compress = e), this;
      }),
      (f.prototype.binary = function (e) {
        return (this.flags.binary = e), this;
      });
  }),
  yl = s((e, t) => {
    var n = ml(),
      r = vl(),
      i = hl(),
      a = Rs(),
      o = gl(),
      s = dc(),
      c = rl()(`socket.io-client:manager`),
      l = oc(),
      u = pc(),
      d = Object.prototype.hasOwnProperty;
    t.exports = f;
    function f(e, t) {
      if (!(this instanceof f)) return new f(e, t);
      e && typeof e == `object` && ((t = e), (e = void 0)),
        (t ||= {}),
        (t.path = t.path || `/socket.io`),
        (this.nsps = {}),
        (this.subs = []),
        (this.opts = t),
        this.reconnection(t.reconnection !== !1),
        this.reconnectionAttempts(t.reconnectionAttempts || 1 / 0),
        this.reconnectionDelay(t.reconnectionDelay || 1e3),
        this.reconnectionDelayMax(t.reconnectionDelayMax || 5e3),
        this.randomizationFactor(t.randomizationFactor || 0.5),
        (this.backoff = new u({
          min: this.reconnectionDelay(),
          max: this.reconnectionDelayMax(),
          jitter: this.randomizationFactor(),
        })),
        this.timeout(t.timeout == null ? 2e4 : t.timeout),
        (this.readyState = `closed`),
        (this.uri = e),
        (this.connecting = []),
        (this.lastPing = null),
        (this.encoding = !1),
        (this.packetBuffer = []);
      var n = t.parser || a;
      (this.encoder = new n.Encoder()),
        (this.decoder = new n.Decoder()),
        (this.autoConnect = t.autoConnect !== !1),
        this.autoConnect && this.open();
    }
    (f.prototype.emitAll = function () {
      for (var e in (this.emit.apply(this, arguments), this.nsps))
        d.call(this.nsps, e) &&
          this.nsps[e].emit.apply(this.nsps[e], arguments);
    }),
      (f.prototype.updateSocketIds = function () {
        for (var e in this.nsps)
          d.call(this.nsps, e) && (this.nsps[e].id = this.generateId(e));
      }),
      (f.prototype.generateId = function (e) {
        return (e === `/` ? `` : e + `#`) + this.engine.id;
      }),
      i(f.prototype),
      (f.prototype.reconnection = function (e) {
        return arguments.length
          ? ((this._reconnection = !!e), this)
          : this._reconnection;
      }),
      (f.prototype.reconnectionAttempts = function (e) {
        return arguments.length
          ? ((this._reconnectionAttempts = e), this)
          : this._reconnectionAttempts;
      }),
      (f.prototype.reconnectionDelay = function (e) {
        return arguments.length
          ? ((this._reconnectionDelay = e),
            this.backoff && this.backoff.setMin(e),
            this)
          : this._reconnectionDelay;
      }),
      (f.prototype.randomizationFactor = function (e) {
        return arguments.length
          ? ((this._randomizationFactor = e),
            this.backoff && this.backoff.setJitter(e),
            this)
          : this._randomizationFactor;
      }),
      (f.prototype.reconnectionDelayMax = function (e) {
        return arguments.length
          ? ((this._reconnectionDelayMax = e),
            this.backoff && this.backoff.setMax(e),
            this)
          : this._reconnectionDelayMax;
      }),
      (f.prototype.timeout = function (e) {
        return arguments.length ? ((this._timeout = e), this) : this._timeout;
      }),
      (f.prototype.maybeReconnectOnOpen = function () {
        !this.reconnecting &&
          this._reconnection &&
          this.backoff.attempts === 0 &&
          this.reconnect();
      }),
      (f.prototype.open = f.prototype.connect =
        function (e, t) {
          if (
            (c(`readyState %s`, this.readyState),
            ~this.readyState.indexOf(`open`))
          )
            return this;
          c(`opening %s`, this.uri), (this.engine = n(this.uri, this.opts));
          var r = this.engine,
            i = this;
          (this.readyState = `opening`), (this.skipReconnect = !1);
          var a = o(r, `open`, function () {
              i.onopen(), e && e();
            }),
            s = o(r, `error`, function (t) {
              if (
                (c(`connect_error`),
                i.cleanup(),
                (i.readyState = `closed`),
                i.emitAll(`connect_error`, t),
                e)
              ) {
                var n = Error(`Connection error`);
                (n.data = t), e(n);
              } else i.maybeReconnectOnOpen();
            });
          if (!1 !== this._timeout) {
            var l = this._timeout;
            c(`connect attempt will timeout after %d`, l);
            var u = setTimeout(function () {
              c(`connect attempt timed out after %d`, l),
                a.destroy(),
                r.close(),
                r.emit(`error`, `timeout`),
                i.emitAll(`connect_timeout`, l);
            }, l);
            this.subs.push({
              destroy: function () {
                clearTimeout(u);
              },
            });
          }
          return this.subs.push(a), this.subs.push(s), this;
        }),
      (f.prototype.onopen = function () {
        c(`open`),
          this.cleanup(),
          (this.readyState = `open`),
          this.emit(`open`);
        var e = this.engine;
        this.subs.push(o(e, `data`, s(this, `ondata`))),
          this.subs.push(o(e, `ping`, s(this, `onping`))),
          this.subs.push(o(e, `pong`, s(this, `onpong`))),
          this.subs.push(o(e, `error`, s(this, `onerror`))),
          this.subs.push(o(e, `close`, s(this, `onclose`))),
          this.subs.push(o(this.decoder, `decoded`, s(this, `ondecoded`)));
      }),
      (f.prototype.onping = function () {
        (this.lastPing = new Date()), this.emitAll(`ping`);
      }),
      (f.prototype.onpong = function () {
        this.emitAll(`pong`, new Date() - this.lastPing);
      }),
      (f.prototype.ondata = function (e) {
        this.decoder.add(e);
      }),
      (f.prototype.ondecoded = function (e) {
        this.emit(`packet`, e);
      }),
      (f.prototype.onerror = function (e) {
        c(`error`, e), this.emitAll(`error`, e);
      }),
      (f.prototype.socket = function (e, t) {
        var n = this.nsps[e];
        if (!n) {
          (n = new r(this, e, t)), (this.nsps[e] = n);
          var i = this;
          n.on(`connecting`, a),
            n.on(`connect`, function () {
              n.id = i.generateId(e);
            }),
            this.autoConnect && a();
        }
        function a() {
          ~l(i.connecting, n) || i.connecting.push(n);
        }
        return n;
      }),
      (f.prototype.destroy = function (e) {
        var t = l(this.connecting, e);
        ~t && this.connecting.splice(t, 1),
          !this.connecting.length && this.close();
      }),
      (f.prototype.packet = function (e) {
        c(`writing packet %j`, e);
        var t = this;
        e.query && e.type === 0 && (e.nsp += `?` + e.query),
          t.encoding
            ? t.packetBuffer.push(e)
            : ((t.encoding = !0),
              this.encoder.encode(e, function (n) {
                for (var r = 0; r < n.length; r++)
                  t.engine.write(n[r], e.options);
                (t.encoding = !1), t.processPacketQueue();
              }));
      }),
      (f.prototype.processPacketQueue = function () {
        if (this.packetBuffer.length > 0 && !this.encoding) {
          var e = this.packetBuffer.shift();
          this.packet(e);
        }
      }),
      (f.prototype.cleanup = function () {
        c(`cleanup`);
        for (var e = this.subs.length, t = 0; t < e; t++)
          this.subs.shift().destroy();
        (this.packetBuffer = []),
          (this.encoding = !1),
          (this.lastPing = null),
          this.decoder.destroy();
      }),
      (f.prototype.close = f.prototype.disconnect =
        function () {
          c(`disconnect`),
            (this.skipReconnect = !0),
            (this.reconnecting = !1),
            this.readyState === `opening` && this.cleanup(),
            this.backoff.reset(),
            (this.readyState = `closed`),
            this.engine && this.engine.close();
        }),
      (f.prototype.onclose = function (e) {
        c(`onclose`),
          this.cleanup(),
          this.backoff.reset(),
          (this.readyState = `closed`),
          this.emit(`close`, e),
          this._reconnection && !this.skipReconnect && this.reconnect();
      }),
      (f.prototype.reconnect = function () {
        if (this.reconnecting || this.skipReconnect) return this;
        var e = this;
        if (this.backoff.attempts >= this._reconnectionAttempts)
          c(`reconnect failed`),
            this.backoff.reset(),
            this.emitAll(`reconnect_failed`),
            (this.reconnecting = !1);
        else {
          var t = this.backoff.duration();
          c(`will wait %dms before reconnect attempt`, t),
            (this.reconnecting = !0);
          var n = setTimeout(function () {
            e.skipReconnect ||
              (c(`attempting reconnect`),
              e.emitAll(`reconnect_attempt`, e.backoff.attempts),
              e.emitAll(`reconnecting`, e.backoff.attempts),
              !e.skipReconnect &&
                e.open(function (t) {
                  t
                    ? (c(`reconnect attempt error`),
                      (e.reconnecting = !1),
                      e.reconnect(),
                      e.emitAll(`reconnect_error`, t.data))
                    : (c(`reconnect success`), e.onreconnect());
                }));
          }, t);
          this.subs.push({
            destroy: function () {
              clearTimeout(n);
            },
          });
        }
      }),
      (f.prototype.onreconnect = function () {
        var e = this.backoff.attempts;
        (this.reconnecting = !1),
          this.backoff.reset(),
          this.updateSocketIds(),
          this.emitAll(`reconnect`, e);
      });
  }),
  bl = s((e, t) => {
    var n = il(),
      r = Rs(),
      i = yl(),
      a = rl()(`socket.io-client`);
    t.exports = e = s;
    var o = (e.managers = {});
    function s(e, t) {
      typeof e == `object` && ((t = e), (e = void 0)), (t ||= {});
      var r = n(e),
        s = r.source,
        c = r.id,
        l = r.path,
        u = o[c] && l in o[c].nsps,
        d = t.forceNew || t[`force new connection`] || !1 === t.multiplex || u,
        f;
      return (
        d
          ? (a(`ignoring socket cache for %s`, s), (f = i(s, t)))
          : (o[c] || (a(`new io instance for %s`, s), (o[c] = i(s, t))),
            (f = o[c])),
        r.query && !t.query && (t.query = r.query),
        f.socket(r.path, t)
      );
    }
    (e.protocol = r.protocol),
      (e.connect = s),
      (e.Manager = yl()),
      (e.Socket = vl());
  }),
  xl = s((e) => {
    var t =
      (e && e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.fetchBalancerConfig = void 0);
    var n = Ds(),
      r = t(yc());
    e.fetchBalancerConfig = function (e) {
      return (
        (0, n.debug)(`using balancer ${e} to get websocket url`),
        (0, r.default)(`${e}`)
          .then(function (e) {
            return e.json();
          })
          .then(function (e) {
            return e?.url && e?.token
              ? ((0, n.debug)(
                  `balancer returns url ${e?.url} and token ${e?.token}`
                ),
                e)
              : ((0, n.debug)(`balancer returns invalid response`), null);
          })
          .catch(function (e) {
            return (0, n.debug)(`failed to resolve url: ${e.message}`), null;
          })
      );
    };
  }),
  Sl = s((e) => {
    var t =
        (e && e.__extends) ||
        (function () {
          var e = function (t, n) {
            return (
              (e =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t)
                    Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                }),
              e(t, n)
            );
          };
          return function (t, n) {
            if (typeof n != `function` && n !== null)
              throw TypeError(
                `Class extends value ` +
                  String(n) +
                  ` is not a constructor or null`
              );
            e(t, n);
            function r() {
              this.constructor = t;
            }
            t.prototype =
              n === null
                ? Object.create(n)
                : ((r.prototype = n.prototype), new r());
          };
        })(),
      n =
        (e && e.__spreadArray) ||
        function (e, t, n) {
          if (n || arguments.length === 2)
            for (var r = 0, i = t.length, a; r < i; r++)
              (a || !(r in t)) &&
                ((a ||= Array.prototype.slice.call(t, 0, r)), (a[r] = t[r]));
          return e.concat(a || Array.prototype.slice.call(t));
        },
      r =
        (e && e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.SocketMock = void 0);
    var i = Ds();
    e.SocketMock = (function (e) {
      t(r, e);
      function r(t) {
        var n = e.call(this) || this;
        return (
          (n.options = t),
          (n.id = `mock`),
          (n.connected = !1),
          (n.disconnected = !0),
          (n.binaryType = `blob`),
          n
        );
      }
      return (
        (r.prototype.open = function () {
          var e = this;
          return (
            (0, i.debug)(`SocketIOMock: connect`),
            this.once(`visitor.connect`, function (t, n) {
              n(null, e.options.connectData);
            }),
            (this.connected = !0),
            (this.disconnected = !1),
            this.emit(`connect`),
            this
          );
        }),
        (r.prototype.close = function () {
          return (
            (0, i.debug)(`SocketIOMock: disconnect`),
            (this.connected = !1),
            (this.disconnected = !1),
            this.emit(`disconnect`, `io client disconnect`),
            this
          );
        }),
        (r.prototype.emit = function (t) {
          var r = [...arguments].slice(1);
          return (
            i.debug.apply(void 0, n([`SocketIOMock: emit`], r, !1)),
            (t === `connect` ||
              t === `disconnect` ||
              t === `visitor.connect`) &&
              e.prototype.emit.apply(this, n([t], r, !1)),
            this
          );
        }),
        (r.prototype.send = function () {
          var e = [...arguments];
          return this.emit.apply(this, n([e[0]], e.slice(1), !1));
        }),
        (r.prototype.compress = function () {
          return this;
        }),
        (r.prototype.connect = function () {
          return this.open();
        }),
        (r.prototype.disconnect = function () {
          return this.close();
        }),
        (r.prototype.hasListeners = function (e) {
          return this.listenerCount(e) === 0;
        }),
        (r.prototype.addEventListener = function (e, t) {
          return this.addListener(e, t), this;
        }),
        (r.prototype.removeEventListener = function (e, t) {
          return this.removeListener(e, t), this;
        }),
        r
      );
    })(r(Os()).default);
  }),
  Cl = s((e) => {
    var t =
        (e && e.__assign) ||
        function () {
          return (
            (t =
              Object.assign ||
              function (e) {
                for (var t, n = 1, r = arguments.length; n < r; n++)
                  for (var i in ((t = arguments[n]), t))
                    Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                return e;
              }),
            t.apply(this, arguments)
          );
        },
      n =
        (e && e.__createBinding) ||
        (Object.create
          ? function (e, t, n, r) {
              r === void 0 && (r = n);
              var i = Object.getOwnPropertyDescriptor(t, n);
              (!i ||
                (`get` in i ? !t.__esModule : i.writable || i.configurable)) &&
                (i = {
                  enumerable: !0,
                  get: function () {
                    return t[n];
                  },
                }),
                Object.defineProperty(e, r, i);
            }
          : function (e, t, n, r) {
              r === void 0 && (r = n), (e[r] = t[n]);
            }),
      r =
        (e && e.__exportStar) ||
        function (e, t) {
          for (var r in e)
            r !== `default` &&
              !Object.prototype.hasOwnProperty.call(t, r) &&
              n(t, e, r);
        },
      i =
        (e && e.__awaiter) ||
        function (e, t, n, r) {
          function i(e) {
            return e instanceof n
              ? e
              : new n(function (t) {
                  t(e);
                });
          }
          return new (n ||= Promise)(function (n, a) {
            function o(e) {
              try {
                c(r.next(e));
              } catch (e) {
                a(e);
              }
            }
            function s(e) {
              try {
                c(r.throw(e));
              } catch (e) {
                a(e);
              }
            }
            function c(e) {
              e.done ? n(e.value) : i(e.value).then(o, s);
            }
            c((r = r.apply(e, t || [])).next());
          });
        },
      a =
        (e && e.__generator) ||
        function (e, t) {
          var n = {
              label: 0,
              sent: function () {
                if (a[0] & 1) throw a[1];
                return a[1];
              },
              trys: [],
              ops: [],
            },
            r,
            i,
            a,
            o = Object.create(
              (typeof Iterator == `function` ? Iterator : Object).prototype
            );
          return (
            (o.next = s(0)),
            (o.throw = s(1)),
            (o.return = s(2)),
            typeof Symbol == `function` &&
              (o[Symbol.iterator] = function () {
                return this;
              }),
            o
          );
          function s(e) {
            return function (t) {
              return c([e, t]);
            };
          }
          function c(s) {
            if (r) throw TypeError(`Generator is already executing.`);
            for (; o && ((o = 0), s[0] && (n = 0)), n; )
              try {
                if (
                  ((r = 1),
                  i &&
                    (a =
                      s[0] & 2
                        ? i.return
                        : s[0]
                        ? i.throw || ((a = i.return) && a.call(i), 0)
                        : i.next) &&
                    !(a = a.call(i, s[1])).done)
                )
                  return a;
                switch (((i = 0), a && (s = [s[0] & 2, a.value]), s[0])) {
                  case 0:
                  case 1:
                    a = s;
                    break;
                  case 4:
                    return n.label++, { value: s[1], done: !1 };
                  case 5:
                    n.label++, (i = s[1]), (s = [0]);
                    continue;
                  case 7:
                    (s = n.ops.pop()), n.trys.pop();
                    continue;
                  default:
                    if (
                      ((a = n.trys), !(a = a.length > 0 && a[a.length - 1])) &&
                      (s[0] === 6 || s[0] === 2)
                    ) {
                      n = 0;
                      continue;
                    }
                    if (s[0] === 3 && (!a || (s[1] > a[0] && s[1] < a[3]))) {
                      n.label = s[1];
                      break;
                    }
                    if (s[0] === 6 && n.label < a[1]) {
                      (n.label = a[1]), (a = s);
                      break;
                    }
                    if (a && n.label < a[2]) {
                      (n.label = a[2]), n.ops.push(s);
                      break;
                    }
                    a[2] && n.ops.pop(), n.trys.pop();
                    continue;
                }
                s = t.call(e, n);
              } catch (e) {
                (s = [6, e]), (i = 0);
              } finally {
                r = a = 0;
              }
            if (s[0] & 5) throw s[1];
            return { value: s[0] ? s[1] : void 0, done: !0 };
          }
        },
      o =
        (e && e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.SocketError = void 0);
    var s = Ds(),
      c = o(Os()),
      l = o(bl()),
      u = xl(),
      d = {
        transports: [`websocket`],
        path: `/socket`,
        reconnection: !0,
        reconnectionDelay: 1e3,
        reconnectionDelayMax: 5e3,
        reconnectionAttempts: 1 / 0,
      };
    e.default = (function () {
      function e(e) {
        (this.options = e),
          (this.initialized = !1),
          (this.forceReconnect = !1),
          (this.identity = null),
          (this.connection = null),
          (this.connectCallback = null),
          (this.disconnectCallback = null),
          (this.initData = null),
          (this.internalReconnection = !1),
          (this.internalReconnecting = !1),
          (this.internalReconnectingAttempt = 0),
          (this.emitter = new c.default()),
          (this.sendBuffer = []),
          (this.options.options = t(t(t({}, d), this.options.options), {
            autoConnect: !1,
          }));
      }
      return (
        (e.prototype.initConnection = function () {
          return i(this, void 0, void 0, function () {
            var e;
            return a(this, function (n) {
              switch (n.label) {
                case 0:
                  if (this.connection) throw Error(`Connection already exists`);
                  return this.options.socket
                    ? ((0, s.debug)(`using socket ${this.options.socket.id}`),
                      (this.internalReconnection = !1),
                      this.setConnection(this.options.socket),
                      [3, 4])
                    : [3, 1];
                case 1:
                  return this.options.balancerUrl
                    ? [4, (0, u.fetchBalancerConfig)(this.options.balancerUrl)]
                    : [3, 3];
                case 2:
                  return (
                    (e = n.sent()),
                    (0, s.debug)(
                      `creating socket to ${e.url} with token ${e.token}`
                    ),
                    (this.internalReconnection = !0),
                    this.setConnection(
                      (0, l.default)(
                        e.url,
                        t(t({}, this.options.options), {
                          autoConnect: !1,
                          reconnection: !1,
                          query: { token: e.token },
                        })
                      ),
                      !0
                    ),
                    [3, 4]
                  );
                case 3:
                  if (this.options.url)
                    (0, s.debug)(`creating socket to ${this.options.url}`),
                      (this.internalReconnection = !1),
                      this.setConnection(
                        (0, l.default)(
                          this.options.url,
                          t(t({}, this.options.options), { autoConnect: !1 })
                        )
                      );
                  else throw Error(`Missing required parameter url`);
                  n.label = 4;
                case 4:
                  return [2];
              }
            });
          });
        }),
        (e.prototype.setConnection = function (e, n) {
          var r = this;
          n === void 0 && (n = !1),
            (this.connection = e),
            (this.forceReconnect = !1),
            (this.internalReconnection = n),
            e.on(`connect_error`, function (e) {
              r.internalReconnection &&
                ((r.connectCallback = null),
                (0, s.debug)(`connection was not reconnected`),
                r.emitter.emit(`reconnect_error`, e),
                r.options.options.reconnectionAttempts >
                r.internalReconnectingAttempt + 1
                  ? r.reconnect(r.internalReconnectingAttempt + 1)
                  : r.emitter.emit(
                      `reconnect_failed`,
                      r.internalReconnectingAttempt
                    ));
            }),
            e.on(`connect`, function () {
              (0, s.debug)(`socket was connected`),
                (r.initialized = !1),
                r.internalReconnecting
                  ? ((0, s.debug)(`connection is reconnected`),
                    r.emitter.emit(`reconnect`),
                    (r.internalReconnecting = !1),
                    (r.internalReconnectingAttempt = 0))
                  : r.emitter.emit(`connect`),
                r
                  .initialize()
                  .then(function (e) {
                    return (
                      (0, s.debug)(`socket was initialized`),
                      r.onInitialized(e),
                      (r.connectCallback &&=
                        (r.connectCallback(null, e), null)),
                      e
                    );
                  })
                  .catch(function (e) {
                    (0, s.debug)(`socket was not initialized `, t({}, e)),
                      r.onInitializeError(e),
                      (r.connectCallback &&= (r.connectCallback(e), null));
                  });
            }),
            e.on(`disconnect`, function (e) {
              (0, s.debug)(`socket was disconnected reason='${e}'`),
                (r.initialized = !1),
                (!r.internalReconnecting ||
                  r.internalReconnectingAttempt === 1) &&
                  setTimeout(function () {
                    r.emitter.emit(`disconnect`, e),
                      (r.disconnectCallback &&= (r.disconnectCallback(), null));
                  }, 100),
                r.options.options.reconnection &&
                  r.internalReconnection &&
                  !r.internalReconnecting &&
                  (r.forceReconnect || e !== `io server disconnect`) &&
                  r.reconnect();
            }),
            e.on(`reconnecting`, function (e) {
              r.emitter.emit(`reconnecting`, e);
            }),
            e.on(`reconnect`, function () {
              r.emitter.emit(`reconnect`);
            }),
            e.on(`reconnect_attempt`, function (e) {
              r.emitter.emit(`reconnect_attempt`, e);
            }),
            e.on(`reconnect_error`, function (e) {
              r.emitter.emit(`reconnect_error`, e);
            }),
            e.on(`reconnect_failed`, function () {
              r.emitter.emit(`reconnect_failed`);
            }),
            e.on(`force_reconnect`, function () {
              (0, s.debug)(
                `received event force_reconnect, setting flag forceReconnect = true`
              ),
                (r.forceReconnect = !0);
            });
        }),
        (e.prototype.getConnection = function () {
          return this.connection;
        }),
        (e.prototype.isConnected = function () {
          return this.connection?.connected || !1;
        }),
        (e.prototype.isInitialized = function () {
          return this.initialized;
        }),
        (e.prototype.getInitData = function () {
          return this.initData;
        }),
        (e.prototype.connect = function () {
          return i(this, void 0, void 0, function () {
            var e = this;
            return a(this, function (t) {
              switch (t.label) {
                case 0:
                  return this.connection ? [3, 2] : [4, this.initConnection()];
                case 1:
                  t.sent(), (t.label = 2);
                case 2:
                  return [
                    2,
                    new Promise(function (t, n) {
                      e.initialized
                        ? t(e.initData)
                        : ((0, s.debug)(`starting connecting`),
                          (e.connectCallback = (0, s.createCallback)(t, n)),
                          e.connection.open());
                    }),
                  ];
              }
            });
          });
        }),
        (e.prototype.disconnect = function () {
          var e = this;
          return new Promise(function (t, n) {
            !e.connection || e.connection.disconnected
              ? ((e.connection = null), t())
              : ((0, s.debug)(`starting disconnecting`),
                (e.disconnectCallback = (0, s.createCallback)(t, n)),
                e.connection.close(),
                (e.connection = null));
          });
        }),
        (e.prototype.reconnect = function (e) {
          var t = this;
          return (
            e === void 0 && (e = 1),
            (this.internalReconnecting = !0),
            (this.internalReconnectingAttempt = e),
            this.disconnect()
              .then(function () {
                var n = Math.floor(
                  Math.random() *
                    (t.options.options.reconnectionDelayMax -
                      t.options.options.reconnectionDelay) +
                    t.options.options.reconnectionDelay
                );
                return (
                  (0, s.debug)(`connection will reconnect in ${n}ms`),
                  t.emitter.emit(`reconnecting`, e),
                  new Promise(function (e) {
                    setTimeout(e, n);
                  })
                );
              })
              .then(function () {
                return (
                  (0, s.debug)(`connection is starting reconnect`),
                  t.emitter.emit(`reconnect_attempt`, e),
                  t.connect()
                );
              })
          );
        }),
        (e.prototype.initialize = function () {
          return new Promise(function (e) {
            e({});
          });
        }),
        (e.prototype.onInitialized = function (e) {
          var t = this;
          this.initialized ||
            ((this.initialized = !0),
            (this.initData = e),
            (0, s.debug)(`emit initialized`),
            this.emitter.emit(`initialized`, e),
            setTimeout(function () {
              if (t.sendBuffer.length > 0) {
                (0, s.debug)(`sending buffered ${t.sendBuffer.length} events`);
                for (var e = 0; e < t.sendBuffer.length; e++) {
                  var n = t.sendBuffer[e];
                  t.connection.emit(n.name, n.data, n.callback);
                }
                t.sendBuffer = [];
              }
            }, 1));
        }),
        (e.prototype.onInitializeError = function (e) {
          this.disconnect(),
            (0, s.debug)(`emit initialize_error`, t({}, e)),
            this.emitter.emit(`initialize_error`, e);
        }),
        (e.prototype.send = function (e, t, n) {
          this.initialized
            ? this.connection.emit(e, t, n)
            : this.sendBuffer.push({ name: e, data: t, callback: n });
        }),
        (e.prototype.on = function (e, t) {
          return this.emitter.on(e, t), this;
        }),
        (e.prototype.once = function (e, t) {
          return this.emitter.once(e, t), this;
        }),
        (e.prototype.removeAllListeners = function () {
          for (var e, t = [], n = 0; n < arguments.length; n++)
            t[n] = arguments[n];
          return (e = this.emitter).removeAllListeners.apply(e, t), this;
        }),
        e
      );
    })();
    var f = Ds();
    Object.defineProperty(e, `SocketError`, {
      enumerable: !0,
      get: function () {
        return f.SocketError;
      },
    }),
      r(Sl(), e);
  }),
  wl = {
    authFormDrawer: `authFormDrawer`,
    authFormPrivacyNotice: `authFormPrivacyNotice`,
    authFormPrivacyNoticeSwitch: `authFormPrivacyNoticeSwitch`,
    authFormSubmitButton: `authFormSubmitButton`,
    avatarAgent: `avatarAgent`,
    avatarBot: `avatarBot`,
    avatarGroup: `avatarGroup`,
    avatarInfo: `avatarInfo`,
    buttonAttachment: `buttonAttachment`,
    buttonCloseChat: `buttonCloseChat`,
    buttonCloseDrawer: `buttonCloseDrawer`,
    buttonCollapseChat: `buttonCollapseChat`,
    buttonEmoji: `buttonEmoji`,
    buttonExpandChat: `buttonExpandChat`,
    buttonMinimizeChat: `buttonMinimizeChat`,
    buttonOptions: `buttonOptions`,
    buttonSend: `buttonSend`,
    chatRatingDrawer: `chatRatingDrawer`,
    chatRatingEmojiButton: `chatRatingEmoji`,
    chatRatingSendButton: `chatRatingSendButton`,
    chatRatingTextarea: `chatRatingTextarea`,
    chatRatingFeedbackButton: `chatRatingFeedbackButton`,
    chatRatingButtonAi: `chatRatingButtonAi`,
    chatRatingButtonAgent: `chatRatingButtonAgent`,
    closeChatConfirmButton: `closeChatConfirmButton`,
    closeChatDeclineButton: `closeChatDeclineButton`,
    closeChatDrawer: `closeChatDrawer`,
    flashMessage: `flashMessage`,
    gdprDrawer: `gdprDrawer`,
    headerTitle: `headerTitle`,
    headerStatus: `headerStatus`,
    headerBadge: `headerBadge`,
    inlineEmojiPicker: `inlineEmojiPicker`,
    messageAttachment: `messageAttachment`,
    messageAgent: `messageAgent`,
    messageBot: `messageBot`,
    messageBotReply: `messageBotReply`,
    messageBotBack: `messageBotBack`,
    messageContact: `messageContact`,
    messageFile: `messageFile`,
    messageGroup: `messageGroup`,
    messageImage: `messageImage`,
    optionsAccessibility: `optionsAccessibility`,
    optionsDrawer: `optionsDrawer`,
    optionsExpandChat: `optionsExpandChat`,
    optionsPrivacyNotice: `optionsPrivacyNotice`,
    optionsSounds: `optionsSounds`,
    optionsTranscript: `optionsTranscript`,
    popup: `popup`,
    popupMessage: `popupMessage`,
    popupButton: `popupButton`,
    popupButtonClose: `popupButtonClose`,
    productCard: `productCard`,
    productCardArrowLeft: `productCardArrowLeft`,
    productCardArrowRight: `productCardArrowRight`,
    productCardButton: `productCardButton`,
    productCardCarousel: `productCardCarousel`,
    productCardDescription: `productCardDescription`,
    productCardImage: `productCardImage`,
    productCardInfo: `productCardInfo`,
    productCardPrice: `productCardPrice`,
    productCardTitle: `productCardTitle`,
    systemMessage: `systemMessage`,
    textarea: `textarea`,
    textareaPreviewFile: `textareaPreviewFile`,
    textareaPreviewImage: `textareaPreviewImage`,
    transcriptInput: `transcriptInput`,
    transcriptSendButton: `transcriptSend`,
    ticketFormDrawer: `ticketFormDrawer`,
    ticketFormSubmitButton: `ticketFormSubmitButton`,
    widgetButton: `widgetButton`,
    widgetButtonFrame: `widgetButtonFrame`,
    widgetButtonText: `widgetButtontext`,
    widgetImagePreview: `widgetImagePreview`,
    widgetMessenger: `widgetMessenger`,
    widgetMessengerFrame: `widgetMessengerFrame`,
    widgetOnlineBadge: `widgetOnlineBadge`,
    widgetPopupFrame: `widgetPopupFrame`,
    widgetTypingFrame: `widgetTypingFrame`,
    widgetUnreadMessagesBadge: `widgetUnreadMessagesBadge`,
    widgetHeader: `widgetHeader`,
  },
  Tl = `https://www.smartsupp.com`,
  El = `/powered-by-smartsupp`,
  Dl = [`cs`, `es`, `fr`, `hu`, `it`, `de`, `nl`, `pl`],
  Ol = `https://www.smartsupp.com/my-data-and-gdpr`,
  kl = O(!1),
  Al = rs(U.SessionId, ``),
  jl = () => {
    let { protocol: e, host: t } = V.getOptions();
    return `${e === `http` ? `http` : `https`}://${t}`;
  },
  Ml = () => {
    let { mobileSdk: e, visitorId: t } = V.getOptions();
    if (e && t) return t;
    try {
      return $o();
    } catch (e) {
      return H(String(e)), null;
    }
  },
  Nl = (e, t) => {
    let n = fo().location.href;
    return (
      e && t && (n = `${n}${n.includes(`?`) ? `&` : `?`}ss-bot-run=${t}`), n
    );
  },
  Pl = () => {
    J.clearMessages(), Rd(), md.clearAssignedAgentIds(), Ro(), ko(U.VisitorId);
  },
  Fl = (e) => {
    try {
      es(e);
    } catch (e) {
      H(String(e));
    }
  },
  Il = async (e = !1) => {
    let {
      key: t,
      lang: n,
      isPreviewMode: r,
      previewWithoutReset: i,
      sitePlatform: a,
      triggerable: o,
      _chatMaxReopenTime: s,
      botId: c,
    } = V.getOptions();
    ((r && !i) || e) && Pl();
    let l = Ml(),
      u = A(Ub);
    return {
      key: t,
      id: l,
      clientFingerprint: await Qo(),
      isPreviewMode: r,
      sitePlatform: a,
      triggerable: o,
      _chatMaxReopenTime: s,
      name: u.name,
      email: u.email,
      phone: u.phone,
      group: u.group,
      lang: u.lang ?? n,
      variables: u.variables,
      widgetVersion: `3.0`,
      visits: ts(),
      isWidgetVisible: A(dv),
      isWidgetOpen: A(X),
      pageUrl: Nl(r, c),
      pageTitle: fo().document.title,
      domain: fo().location.hostname || `unknown`,
      referer: fo().document.referrer,
      bundleVersion: `a8df79ea7167743097e853e1113e6b55f860f7be`,
    };
  },
  Ll = (e, t) => {
    let { isPreviewMode: n } = V.getOptions();
    !e && t !== A(Al) && !n && (Pl(), A(X) && X.set(!1)), Al.set(t);
  },
  Rl = (() => {
    let { subscribe: e, set: t } = O();
    return { subscribe: e, initialize: (e) => t(e) };
  })(),
  zl = `FILE`,
  Bl = 2e3,
  Vl = (e) => e.split(`/`)[0] === `image`,
  Hl = (e) => !!e.match(/^video\/(?:mp4|webm|ogg){1}$/);
async function Ul(e) {
  if (!FileReader) return jo(`FileReader not supported`), null;
  let t = new FileReader();
  return new Promise((n) => {
    (t.onload = () => {
      if (!t.result) {
        n(null);
        return;
      }
      n(
        typeof t.result == `string` && t.result.startsWith(`data:image`)
          ? t.result
          : null
      );
    }),
      (t.onerror = () => {
        jo(`Failed to load image data`), n(null);
      }),
      t.readAsDataURL(e);
  });
}
async function Wl(e) {
  return new Promise((t) => {
    let n = document.createElement(`img`);
    (n.onload = () => {
      t({ width: n.width, height: n.height });
    }),
      (n.onerror = () => {
        jo(`Failed to obtain image dimensions`), t(null);
      }),
      (n.src = e);
  });
}
function Gl(e) {
  return { horizontal: e.width > e.height, vertical: e.height > e.width };
}
var Kl =
    `ar.az.bg.br.bs.ca.cn.cs.da.de.el.en.es.et.fa.fi.fil.fr.he.hi.hr.hu.is.it.ja.ka.lt.lv.mk.nl.no.pl.pt.ro.ru.sk.sl.sr.sv.th.tr.tw.uk`.split(
      `.`
    ),
  ql = s((e) => {
    var t =
      (e && e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.FetchAdapter = void 0);
    var n = t(rc());
    e.FetchAdapter = class e {
      constructor(e) {
        (this.options = {}), (this.options = e);
      }
      async request(e, t, r, i, a) {
        let o = { ...this.options, ...a },
          s = i ? `?` + n.default.stringify(i) : ``;
        try {
          let n = await fetch(`${o.baseURL || ``}${t}${s}`, {
            method: e,
            body: r ? JSON.stringify(r) : null,
            ...o,
          });
          return {
            status: n.status,
            statusText: n.statusText,
            data: await n.json(),
            headers: [...n.headers.entries()].reduce(
              (e, [t, n]) => ((e[t] = n), e),
              {}
            ),
          };
        } catch (e) {
          throw ((e.isOpenApiError = !0), e);
        }
      }
      withOptions(t) {
        return new e(t);
      }
    };
  }),
  Jl = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.ProjectName = e.ErrorCode = void 0),
      (e.ErrorCode = {
        BadRequest: `bad_request`,
        NotAllowed: `not_allowed`,
        NotFound: `not_found`,
        Forbidden: `forbidden`,
        TooManyRequests: `too_many_requests`,
        Unauthorized: `unauthorized`,
        Unprocessable: `unprocessable`,
      }),
      (e.ProjectName = { Widget: `widget`, Chatbot: `chatbot` });
  }),
  Yl = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.TranslationsClientRaw = e.TranslationsClient = void 0),
      (e.TranslationsClient = class {
        constructor(e) {
          (this.adapter = e), (this.raw = new t(this.adapter));
        }
        getDefaults(e, t, r) {
          return this.adapter
            .request(
              `get`,
              `/${e}/translations/lang/${t}/defaults`,
              null,
              null,
              r
            )
            .then(n);
        }
      });
    var t = class {
      constructor(e) {
        this.adapter = e;
      }
      getDefaults(e, t, n) {
        return this.adapter.request(
          `get`,
          `/${e}/translations/lang/${t}/defaults`,
          null,
          null,
          n
        );
      }
    };
    e.TranslationsClientRaw = t;
    function n(e) {
      return e.data;
    }
  }),
  Xl = s((e) => {
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      (e.SmartsuppTranslationsClientApi = void 0);
    var t = Yl(),
      n = class e {
        constructor(e) {
          (this.adapter = e), (this.translations = new t.TranslationsClient(e));
        }
        withOptions(t) {
          return new e(this.adapter.withOptions(t));
        }
      };
    (e.SmartsuppTranslationsClientApi = n), (e.default = n);
  }),
  Zl = s((e) => {
    var t =
        (e && e.__createBinding) ||
        (Object.create
          ? function (e, t, n, r) {
              r === void 0 && (r = n);
              var i = Object.getOwnPropertyDescriptor(t, n);
              (!i ||
                (`get` in i ? !t.__esModule : i.writable || i.configurable)) &&
                (i = {
                  enumerable: !0,
                  get: function () {
                    return t[n];
                  },
                }),
                Object.defineProperty(e, r, i);
            }
          : function (e, t, n, r) {
              r === void 0 && (r = n), (e[r] = t[n]);
            }),
      n =
        (e && e.__exportStar) ||
        function (e, n) {
          for (var r in e)
            r !== `default` &&
              !Object.prototype.hasOwnProperty.call(n, r) &&
              t(n, e, r);
        };
    Object.defineProperty(e, `__esModule`, { value: !0 }),
      n(Jl(), e),
      n(Xl(), e),
      n(Yl(), e),
      (e.default = Xl().SmartsuppTranslationsClientApi);
  }),
  Ql = ql(),
  $l = Zl(),
  eu = (e) => Kl.includes(e),
  tu = (e) => (eu(e) ? e : `en`),
  nu = () => {
    let { lang: e } = V.getOptions(),
      { lang: t } = A(Ub);
    return tu(t ?? e);
  };
function ru() {
  return new $l.TranslationsClient(
    new Ql.FetchAdapter({
      baseURL: `${V.getOptions().translationsBaseUrl}/api/v1`,
    })
  );
}
var iu = async (e) => ru().getDefaults($l.ProjectName.Widget, e),
  au = (e, t) => {
    let { translates: n } = V.getOptions();
    return { ...e, ...(n[t] && n[t]) };
  },
  ou = O(`en`),
  su = O({}),
  cu = async (e) => {
    try {
      let t = au(await iu(e), e);
      su.update((n) => ({ ...n, [e]: t }));
    } catch {
      jo(`Fetch translations of '${e}' language failed.`);
    }
  },
  lu = async (e) => {
    A(su)[e] || (await cu(e)), ou.set(e);
  },
  uu = async () => {
    let e = nu();
    ou.set(e), await cu(e);
  },
  du = (e) => {
    let t = A(ou),
      n = { ...A(su)[t], ...e };
    su.update((e) => ({ ...e, [t]: n }));
  },
  fu = (e, t, n) => {
    let r = A(su),
      i = `|${t}|`;
    if (Object.keys(r).length === 0) return i;
    let a = r[e]?.[t] || i;
    return (
      Object.keys(n).map((e) => {
        let t = RegExp(`{${e}}`, `g`);
        a = a.replace(t, n[e]);
      }),
      a
    );
  },
  W = k(
    [ou, su],
    ([e]) =>
      (t, n = {}) =>
        fu(e, t, n)
  ),
  pu = (() => {
    let e = O([]),
      { subscribe: t, update: n } = e,
      r = () => A(e).map((e) => e.file),
      i = (t, n) => (n || A(e)).find((e) => e.file.name === t) || null,
      a = (e) => ({
        file: e,
        preview: {},
        previewState: `none`,
        uploadStatus: `none`,
      }),
      o = (e) => {
        let t = Array.isArray(e) ? e : [e];
        n((e) =>
          e.length + t.length > 5
            ? (gs(`${A(W)(`fileUpload.tooManyFiles`)} 5`), e)
            : [...e, ...t.map(a)]
        ),
          m(t);
      },
      s = (e) => {
        n((t) => t.filter((t) => t.file !== e));
      },
      c = () => A(e).length,
      l = () => c() >= 5,
      u = () => e.set([]),
      d = () => {
        e.update(
          (e) => (e.forEach((e) => (e.uploadStatus = `in-progress`)), e)
        );
      },
      f = (t) => {
        e.update((e) => {
          let n = i(t, e);
          return n && (n.uploadStatus = `done`), e;
        });
      },
      p = (e) => i(e.name)?.previewState !== `none`,
      m = (e) => {
        e.forEach((e) => void h(e));
      },
      h = async (t) => {
        if (p(t)) return;
        let n = await Ul(t),
          r = n ? await Wl(n) : null,
          a = r ? Gl(r) : null;
        e.update((e) => {
          let o = i(t.name, e);
          return o
            ? ((o.previewState = `ready`),
              (o.preview = { data: n, dimensions: r, orientation: a }),
              [...e])
            : e;
        });
      };
    return {
      subscribe: t,
      getFiles: r,
      find: i,
      add: o,
      remove: s,
      count: c,
      isLimitReached: l,
      clear: u,
      setUploadingStatus: d,
      setFileUploaded: f,
    };
  })(),
  mu = (() => {
    let e = [];
    return Object.freeze({
      push: (t) => {
        e.push(t);
      },
      executeAll: () => {
        for (; e.length > 0; ) {
          let t = e.shift();
          t && t();
        }
      },
    });
  })(),
  hu = () => {
    let { widgetV3Url: e } = V.getOptions();
    return `${e}/assets/images/default-ai-identity.png`;
  },
  gu = (e) => ({ ...e, avatarUrl: e.avatarUrl || hu() }),
  G = u(Dc(), 1),
  _u = (() => {
    let { update: e, subscribe: t, set: n } = O({});
    return {
      subscribe: t,
      setIdentities: (e) => {
        n(Qc(`id`, e.map(gu)));
      },
      addIdentity: (t) => {
        e((e) => ({ ...e, [t.id]: t }));
      },
      updateIdentity: (t, n) => {
        e((e) => (e[t] ? { ...e, [t]: { ...e[t], ...n } } : e));
      },
      setActiveIdentity: (t) => {
        e((e) => {
          let n = {};
          return (
            Object.keys(e).forEach((r) => {
              n[r] = { ...e[r], isActive: r === t };
            }),
            n
          );
        });
      },
    };
  })(),
  vu = k([_u], ([e]) => Object.values(e).find((e) => e.isActive)?.authFormMode),
  K = Zc(),
  yu = (e) => {
    vo(`init data`, e), kl.set(!0), Ll(e.chat, e.sessionId);
    let t = e.visitor.id;
    Fl(t),
      ns(e.visitor.visits),
      td.setVisitorData(e.visitor),
      ho({ vid: t }),
      Rl.initialize(e.fileUpload),
      os.set(e.browser),
      ld.setAgents(e.account.agents),
      _u.setIdentities(e.account.botIdentities),
      e.chat?.virtualAgent !== void 0 &&
        ld.setVirtualAgent(e.chat?.virtualAgent),
      $c.setGroups(e.account.groups),
      zd(e.account.status),
      e.chat &&
        (bm() && Dd.set(e.chat.ratingSuggestedTarget || null),
        Cd.set(e.chat.status),
        Pd(e.chat.isClosed),
        Ed.set(e.chat.unreadInfo.lastReadAt),
        J.setMessages(e.chat.messages.filter((e) => !xp(e))),
        md.setAssignedAgentIds(e.chat.assignedIds ?? []),
        e.chat.widgetOptions && yd.updateGeneralOptions(e.chat.widgetOptions)),
      X_.set(!0),
      z.emit(`widgetInit`, !0),
      mu.executeAll();
  },
  bu = (e) => {
    console.error(e);
  },
  xu = () => {
    kl.set(!1);
  },
  Su = ({ chatId: e }) => {
    am.set(!1),
      Od.set(e),
      Cd.set(G.ChatStatus.Open),
      yd.setMessageOptions({ disableAttachments: !1 });
  },
  Cu = () => {
    Cd.set(G.ChatStatus.Served), _u.setActiveIdentity(null), Pd(!1);
  },
  wu = ({ message: e }) => {
    let { closeType: t, agentId: n } = e.content.data;
    (t === `agent_close` || t === `bot_close`) &&
      (md.setAssignedAgentIds([]),
      Cd.set(G.ChatStatus.Closed),
      J.addMessage(e),
      z.emit(`chatClosed`, e),
      t === `agent_close` && Th(n ? A(ud(n))?.fullname : void 0));
  },
  Tu = ({ message: e }) => {
    if (bm()) {
      let e = A(Dd);
      e && Wd(e), Sm(xs);
    }
    Pd(!0, { byVisitor: !0 }),
      J.addMessage(e),
      z.emit(`chatVisitorClosed`, e),
      wh();
  },
  Eu = ({ changes: e }) => {
    e.widgetOptions && yd.updateGeneralOptions(e.widgetOptions),
      e.isClosed !== void 0 && Pd(e.isClosed),
      e.virtualAgent !== void 0 && ld.setVirtualAgent(e.virtualAgent);
  },
  Du = async ({ message: e }) => {
    if (xp(e)) return;
    let t = A(fv) && yp(e);
    !A(X) && Sp(e) && !t ? rm(e) : await J.addMessage(e),
      Vd(),
      e.widgetOptions && yd.setMessageOptions(e.widgetOptions),
      t && gv(),
      z.emit(`messageReceived`, e);
  },
  Ou = (e) => {
    Du(e);
  },
  ku = ({ messageId: e, deletedAt: t }) => {
    A(J)[e]?.subType === K.MessageSubType.ChatResolve
      ? J.deleteMessage(e)
      : J.markMessageAsDeleted(e, t);
  },
  Au = ({ message: e }) => {
    J.replaceMessage(e),
      e.widgetOptions &&
        e.id === A(pm) &&
        yd.setMessageOptions(e.widgetOptions);
  },
  ju = ({ message: e, agent: t }) => {
    md.addAssignedAgentId(e.content.data.agentId),
      J.addMessage(e),
      z.emit(`agentJoined`, t);
  },
  Mu = ({ message: e }) => {
    md.removeAssignedAgentId(e.content.data.agentId), J.addMessage(e);
  },
  Nu = ({ message: e }) => {
    md.addAssignedAgentId(e.content.data.assigned), J.addMessage(e);
  },
  Pu = ({ message: e }) => {
    md.removeAssignedAgentId(e.content.data.unassigned), J.addMessage(e);
  },
  Fu = ({ message: e }) => {
    _u.setActiveIdentity(e.content.data.identityId), J.addMessage(e);
  },
  Iu = ({ message: e }) => {
    _u.setActiveIdentity(null), e && J.addMessage(e);
  },
  Lu = (e) => {
    (!e.typing.is && A(am)) || Td.set(e.typing.is);
  },
  Ru = (e) => {
    Ed.set(e.lastReadAt);
  },
  zu = ({ message: e, rating: t }) => {
    J.updateMessageRating(e), z.emit(`chatRated`, t);
  },
  Bu = (e) => {
    z.emit(`transcriptPdf`, e);
  },
  Vu = ({ id: e, changes: t }) => {
    ld.updateAgent(e, t);
  },
  Hu = ({ id: e, status: t }) => {
    ld.updateAgent(e, { status: t });
  },
  Uu = ({ status: e }) => {
    zd(e);
  },
  Wu = (e) => {
    td.updateVisitorData(e);
  },
  Gu = (e) => {
    z.emit(`contactAcquired`, e);
  },
  Ku = 2e3,
  qu = (e) => {
    setTimeout(() => Fc(Lc.AuthForm), Ku);
  },
  Ju = (e) => {
    (bm() || xm()) && Dd.set(e.ratingSuggestedTarget);
  },
  Yu = () => {
    A(Dd) && Dd.set(null);
  },
  Xu = ({ id: e, isActive: t, authFormMode: n }) => {
    _u.updateIdentity(e, { isActive: t, ...(n && { authFormMode: n }) });
  },
  Zu = Cl(),
  Qu = async (e) => {
    let t = await V.awaitOptions();
    return new G.WebsocketVisitorClient({
      data: e,
      connection: {
        url: jl(),
        socket: t.mock ? new Zu.SocketMock(t.mock) : void 0,
        balancerUrl: t.balancerUrl,
        options: { path: `/socket`, autoConnect: !1, reconnection: !0 },
      },
    });
  },
  $u = () => {
    let e = null,
      t = () => !!e,
      n = () => {
        if (!e) throw Error(`Visitor client is not initialized`);
        return e;
      },
      r = async (t) => {
        (e = await Qu(await Il(t))),
          e &&
            (ed(e),
            await e.connect().catch((e) => {
              jo(`Failed connect to server.`, e);
            }));
      };
    return Object.freeze({
      getClient: n,
      initClient: r,
      reloadClient: async (t, n) => {
        await e?.disconnect(), t && V.updateOptions({ mock: t }), await r(n);
      },
      isInitialized: t,
    });
  },
  ed = (e) => {
    e.on(`initialized`, yu),
      e.on(`error`, bu),
      e.on(`disconnect`, xu),
      e.on(`chat.opened`, Su),
      e.on(`chat.served`, Cu),
      e.on(`chat.closed`, wu),
      e.on(`chat.visitor_closed`, Tu),
      e.on(`chat.updated`, Eu),
      e.on(`chat.message_received`, Ou),
      e.on(`chat.message_updated`, Au),
      e.on(`chat.message_deleted`, ku),
      e.on(`chat.agent_joined`, ju),
      e.on(`chat.agent_left`, Mu),
      e.on(`chat.agent_assigned`, Nu),
      e.on(`chat.agent_unassigned`, Pu),
      e.on(`chat.bot_assigned`, Fu),
      e.on(`chat.bot_unassigned`, Iu),
      e.on(`chat.agent_typing`, Lu),
      e.on(`chat.contact_read`, Ru),
      e.on(`chat.rated`, zu),
      e.on(`chat.rating_suggested`, Ju),
      e.on(`chat.rating_cancelled`, Yu),
      e.on(`chat.transcript_pdf`, Bu),
      e.on(`chat.auth_form_requested`, qu),
      e.on(`agent.updated`, Vu),
      e.on(`agent.status_updated`, Hu),
      e.on(`account.updated`, Uu),
      e.on(`visitor.updated`, Wu),
      e.on(`contact.acquired`, Gu),
      e.on(`identity.status_updated`, Xu);
  },
  q = $u(),
  td = (() => {
    let e = O(null),
      { subscribe: t, set: n, update: r } = e,
      i = (e) => {
        n(e);
      },
      a = (e) => {
        r((t) => (t ? { ...t, ...e } : null));
      },
      o = (e, t) => {
        try {
          q.getClient().update({ [e]: t });
        } catch (t) {
          jo(`Update of visitor property '${e}' failed.`, String(t));
        }
      };
    return {
      subscribe: t,
      setVisitorData: i,
      updateVisitorData: a,
      updateVisitorProperty: (e, t) => {
        if (!A(X_)) {
          Wb(e, t);
          return;
        }
        a({ [e]: t }), o(e, t);
      },
      updateVisitorVariables: (t) => {
        if (!A(X_)) {
          Wb(`variables`, t);
          return;
        }
        let n = A(e);
        if (!n) return;
        let r = n.variables;
        a({ variables: { ...r, ...t } });
        let i = {};
        Object.keys(t).forEach((e) => {
          t[e] !== r[e] && (i = { ...i, [e]: t[e] });
        }),
          Object.keys(i).length !== 0 && o(`variables`, i);
      },
      updateVisitorContactData: (t) => {
        if (!A(X_)) {
          Wb(`contactData`, { properties: t });
          return;
        }
        let n = A(e);
        if (!n) return;
        let r = n?.contactData?.properties;
        a({ variables: { ...r, ...t } });
        let i = {};
        Object.keys(t).forEach((e) => {
          (!r || t[e] !== r[e]) && (i = { ...i, [e]: t[e] });
        }),
          Object.keys(i).length !== 0 && o(`contactData`, { properties: t });
      },
    };
  })(),
  nd = (e, t) => e.hasOwnProperty(t),
  rd = (e) => typeof e == `boolean`,
  id = (e) => typeof e == `number`,
  ad = (e) => typeof e == `object` && !!e && !Array.isArray(e),
  od = (e) => typeof e == `string` || e instanceof String,
  sd = (e) => od(e) || id(e) || rd(e),
  cd = (e) => {
    let t = {};
    return (
      Object.keys(e).forEach((n) => {
        let r = e[n];
        sd(r)
          ? (t[n] = r)
          : ad(r) && nd(r, `value`) && sd(r.value) && (t[n] = r.value);
      }),
      t
    );
  },
  ld = (() => {
    let { update: e, subscribe: t, set: n } = O({});
    return {
      subscribe: t,
      setAgents: (e) => {
        n(Qc(`id`, e));
      },
      addAgent: (t) => {
        e((e) => ({ ...e, [t.id]: t }));
      },
      updateAgent: (t, n) => {
        e((e) => (e[t] ? { ...e, [t]: { ...e[t], ...n } } : e));
      },
      setVirtualAgent: (t) => {
        if (!t) return;
        let { description: n, avatar: r, name: i } = t,
          a = {};
        n && (a.description = n),
          r && (a.avatar = r),
          i && (a.fullname = i),
          e(
            (e) => (
              Object.keys(e).forEach((t) => {
                e[t] = { ...e[t], ...a };
              }),
              e
            )
          );
      },
    };
  })(),
  ud = (e) => k([ld], ([t]) => t[e] ?? null),
  dd = k(
    [k([ld], ([e]) => Object.values(e).filter((e) => !e.disabled)), td],
    ([e, t]) => {
      let n = t?.group;
      return !n || n === `default`
        ? e
        : e.filter((e) => e.groups.length === 0 || e.groups.includes(n));
    }
  ),
  fd = k([dd], ([e]) => e.filter((e) => e.status === G.AgentStatus.Online)),
  pd = (e) => {
    if (e) return `${e}?size=80`;
    let { widgetV3Url: t } = V.getOptions();
    return `${t}/assets/images/default-avatar.png`;
  },
  md = (() => {
    let { subscribe: e, set: t, update: n } = O([]);
    return {
      subscribe: e,
      setAssignedAgentIds: (e) => {
        t(e);
      },
      addAssignedAgentId: (e) => {
        n((t) => [...new Set([...t, e])]);
      },
      removeAssignedAgentId: (e) => {
        n((t) => t.filter((t) => t !== e));
      },
      clearAssignedAgentIds: () => {
        t([]);
      },
    };
  })(),
  hd = k([md, ld], ([e, t]) => e.map((e) => t[e]).filter(Boolean)),
  gd = k([hd], ([e]) => e.length > 0),
  _d = k([hd], ([e]) => e.filter((e) => !e.disabled)),
  vd = k([hd], ([e]) => e.some((e) => e.status === G.AgentStatus.Online)),
  yd = (() => {
    let e = O({
        disableAttachments: !1,
        disableAuthentication: !1,
        disableInput: !1,
      }),
      t = O({});
    return {
      subscribe: k([e, t], ([e, t]) => ({ ...e, ...t })).subscribe,
      updateGeneralOptions: (t) => {
        e.update((e) => ({ ...e, ...t }));
      },
      setMessageOptions: (e) => {
        t.set(e);
      },
    };
  })(),
  bd = k([yd], ([e]) => e.disableAttachments),
  xd = (function (e) {
    return (
      (e[(e.Open = 0)] = `Open`),
      (e[(e.Closed = 1)] = `Closed`),
      (e[(e.ClosedByVisitor = 2)] = `ClosedByVisitor`),
      e
    );
  })({}),
  Sd = O(G.AccountStatus.Offline),
  Cd = O(null),
  wd = O(xd.Open),
  Td = O(!1),
  Ed = O(null),
  Dd = O(null),
  Od = O(``),
  kd = k([Cd], ([e]) => e === G.ChatStatus.Pending);
k([Cd], ([e]) => e !== null);
var Ad = k([Cd], ([e]) => e === G.ChatStatus.Served),
  jd = k([Cd], ([e]) => e === G.ChatStatus.Open),
  Md = k([Cd], ([e]) => e === G.ChatStatus.Closed),
  Nd = k([Ad, wd], ([e, t]) => e && t === xd.Open),
  Pd = (e, { byVisitor: t = !1 } = {}) => {
    e ? wd.set(t ? xd.ClosedByVisitor : xd.Closed) : wd.set(xd.Open);
  },
  Fd = k([Sd, _d], ([e, t]) =>
    t.length === 0
      ? e === G.AccountStatus.Online
      : t.some((e) => e.status === G.AgentStatus.Online)
  ),
  Id = k([yd], ([e]) => e.disableAuthentication),
  Ld = k([yd], ([e]) => !!e.requireAuthentication),
  Rd = () => {
    Td.set(!1), Cd.set(null), Pd(!1), Ed.set(null);
  },
  zd = (e) => {
    e === G.AccountStatus.OfflineWithAI
      ? Sd.set(G.AccountStatus.Online)
      : Sd.set(e);
  },
  Bd = () => {
    Ed.set(new Date().toISOString()), q.getClient().chatRead();
  },
  Vd = () => {
    let e = po().visibilityState === `visible`;
    !A(um) || !A(X) || !e || !A(ov) || Bd();
  },
  Hd = (e) => ({
    ...Ss,
    chatId: A(Od),
    createdAt: new Date().toISOString(),
    content: { ...Ss.content, data: { target: e } },
  }),
  Ud = () => {
    Pd(!0, { byVisitor: !0 }), q.getClient().chatClose(), Ic(), bm() || _v();
  },
  Wd = async (e) => {
    await J.addMessage(Hd(e));
  },
  Gd = () => {
    J.deleteMessage(xs);
  };
function Kd(e) {
  return e.length === 0 ? null : e[e.length - 1];
}
var qd = (e) => e.slice(((e.lastIndexOf(`.`) - 1) >>> 0) + 2).toLowerCase(),
  Jd = (e) => {
    let t = e,
      n = 0,
      r = [`B`, `KB`, `MB`, `GB`];
    for (; t >= 1024 && n < r.length - 1; ) (t /= 1024), n++;
    return { size: Math.floor(t), unit: r[n] };
  },
  Yd = (e) => {
    let t = Kd(e.split(`.`));
    return t ? t.toUpperCase() : zl;
  },
  Xd = (e, t) => `${e}?name=${t}`,
  Zd = async (e, t) => {
    let n = q.getClient(),
      r = [];
    for (let { file: i } of e) {
      let e = await n.chatUploadInit(),
        a = new FormData();
      a.append(`file`, i, i.name);
      try {
        if (!(await fetch(e.url, { method: `post`, body: a })).ok)
          throw Error(`Upload failed`);
        r.push(e.token);
      } catch {
        jo(`File [${i.name}] upload failed`),
          gs(A(W)(`fileUpload.filesWerentProcessed`));
      } finally {
        t(i);
      }
    }
    return r;
  },
  Qd = async (e) => {
    let t = q.getClient();
    try {
      await t.chatUploadFinish(e);
    } catch {
      jo(`Failed to finish file upload for ${e}`);
    }
  },
  $d = 1e3,
  ef = 6e4,
  tf = 36e5,
  nf = 864e5,
  rf = 2628e6,
  af = 31536e6,
  of = (e) => Math.floor(e / ef) * ef,
  sf = (e, t) => of(new Date(e).getTime()) === of(new Date(t).getTime()),
  cf = (e, t) => {
    let n = new Date(e),
      r = new Date(t);
    return (
      n.getDate() === r.getDate() &&
      n.getMonth() === r.getMonth() &&
      n.getFullYear() === r.getFullYear()
    );
  },
  lf = (e, t) => e.getTime() - t.getTime(),
  uf = new Intl.DateTimeFormat(void 0, { hour: `numeric`, minute: `numeric` }),
  df = new Intl.DateTimeFormat(void 0, {
    year: `numeric`,
    month: `numeric`,
    day: `numeric`,
    hour: `numeric`,
    minute: `numeric`,
  }),
  ff = (e) => (cf(new Date(), e) ? uf : df),
  pf = () => typeof Intl < `u` && `RelativeTimeFormat` in Intl,
  mf = (e) =>
    pf() ? new Intl.RelativeTimeFormat(e, { numeric: `auto` }) : null,
  hf = [
    { unit: `year`, amount: af },
    { unit: `month`, amount: rf },
    { unit: `day`, amount: nf },
    { unit: `hour`, amount: tf },
    { unit: `minute`, amount: ef },
    { unit: `second`, amount: $d },
  ],
  gf = (e, t) => {
    let n = mf(t);
    if (!n) return H(`Relative time format not supported`), ``;
    for (let { unit: t, amount: r } of hf) {
      if (t === `second`) return n.format(0, `second`);
      if (Math.abs(e) > r) return n.format(Math.round(e / r), t);
    }
    return ``;
  },
  _f = (e, t = 300) => {
    let n;
    return (...r) => {
      n ||= (e(...r), setTimeout(() => (n = null), t));
    };
  },
  vf =
    /[\0-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/,
  yf = /[\0-\x1F\x7F-\x9F]/,
  bf =
    /[!-#%-\*,-\/:;\?@\[-\]_\{\}\xA1\xA7\xAB\xB6\xB7\xBB\xBF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061D-\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u09FD\u0A76\u0AF0\u0C77\u0C84\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1B7D\u1B7E\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E4F\u2E52-\u2E5D\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]|\uD800[\uDD00-\uDD02\uDF9F\uDFD0]|\uD801\uDD6F|\uD802[\uDC57\uDD1F\uDD3F\uDE50-\uDE58\uDE7F\uDEF0-\uDEF6\uDF39-\uDF3F\uDF99-\uDF9C]|\uD803[\uDEAD\uDF55-\uDF59\uDF86-\uDF89]|\uD804[\uDC47-\uDC4D\uDCBB\uDCBC\uDCBE-\uDCC1\uDD40-\uDD43\uDD74\uDD75\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDDF\uDE38-\uDE3D\uDEA9]|\uD805[\uDC4B-\uDC4F\uDC5A\uDC5B\uDC5D\uDCC6\uDDC1-\uDDD7\uDE41-\uDE43\uDE60-\uDE6C\uDEB9\uDF3C-\uDF3E]|\uD806[\uDC3B\uDD44-\uDD46\uDDE2\uDE3F-\uDE46\uDE9A-\uDE9C\uDE9E-\uDEA2\uDF00-\uDF09]|\uD807[\uDC41-\uDC45\uDC70\uDC71\uDEF7\uDEF8\uDF43-\uDF4F\uDFFF]|\uD809[\uDC70-\uDC74]|\uD80B[\uDFF1\uDFF2]|\uD81A[\uDE6E\uDE6F\uDEF5\uDF37-\uDF3B\uDF44]|\uD81B[\uDE97-\uDE9A\uDFE2]|\uD82F\uDC9F|\uD836[\uDE87-\uDE8B]|\uD83A[\uDD5E\uDD5F]/,
  xf = /[ \xA0\u1680\u2000-\u200A\u2028\u2029\u202F\u205F\u3000]/;
function Sf(e) {
  let t = {};
  (e ||= {}),
    (t.src_Any = vf.source),
    (t.src_Cc = yf.source),
    (t.src_Z = xf.source),
    (t.src_P = bf.source),
    (t.src_ZPCc = [t.src_Z, t.src_P, t.src_Cc].join(`|`)),
    (t.src_ZCc = [t.src_Z, t.src_Cc].join(`|`));
  let n = `[><｜]`;
  return (
    (t.src_pseudo_letter =
      `(?:(?!` + n + `|` + t.src_ZPCc + `)` + t.src_Any + `)`),
    (t.src_ip4 = `(?:(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)`),
    (t.src_auth = `(?:(?:(?!` + t.src_ZCc + `|[@/\\[\\]()]).)+@)?`),
    (t.src_port = `(?::(?:6(?:[0-4]\\d{3}|5(?:[0-4]\\d{2}|5(?:[0-2]\\d|3[0-5])))|[1-5]?\\d{1,4}))?`),
    (t.src_host_terminator =
      `(?=$|` +
      n +
      `|` +
      t.src_ZPCc +
      `)(?!` +
      (e[`---`] ? `-(?!--)|` : `-|`) +
      `_|:\\d|\\.-|\\.(?!$|` +
      t.src_ZPCc +
      `))`),
    (t.src_path =
      `(?:[/?#](?:(?!` +
      t.src_ZCc +
      `|[><｜]|[()[\\]{}.,"'?!\\-;]).|\\[(?:(?!` +
      t.src_ZCc +
      `|\\]).)*\\]|\\((?:(?!` +
      t.src_ZCc +
      `|[)]).)*\\)|\\{(?:(?!` +
      t.src_ZCc +
      `|[}]).)*\\}|\\"(?:(?!` +
      t.src_ZCc +
      `|["]).)+\\"|\\'(?:(?!` +
      t.src_ZCc +
      `|[']).)+\\'|\\'(?=` +
      t.src_pseudo_letter +
      `|[-])|\\.{2,}[a-zA-Z0-9%/&]|\\.(?!` +
      t.src_ZCc +
      `|[.]|$)|` +
      (e[`---`] ? `\\-(?!--(?:[^-]|$))(?:-*)|` : `\\-+|`) +
      `,(?!` +
      t.src_ZCc +
      `|$)|;(?!` +
      t.src_ZCc +
      `|$)|\\!+(?!` +
      t.src_ZCc +
      `|[!]|$)|\\?(?!` +
      t.src_ZCc +
      `|[?]|$))+|\\/)?`),
    (t.src_email_name = `[\\-;:&=\\+\\$,\\.a-zA-Z0-9_][\\-;:&=\\+\\$,\\"\\.a-zA-Z0-9_]*`),
    (t.src_xn = `xn--[a-z0-9\\-]{1,59}`),
    (t.src_domain_root =
      `(?:` + t.src_xn + `|` + t.src_pseudo_letter + `{1,63})`),
    (t.src_domain =
      `(?:` +
      t.src_xn +
      `|(?:` +
      t.src_pseudo_letter +
      `)|(?:` +
      t.src_pseudo_letter +
      `(?:-|` +
      t.src_pseudo_letter +
      `){0,61}` +
      t.src_pseudo_letter +
      `))`),
    (t.src_host =
      `(?:(?:(?:(?:` + t.src_domain + `)\\.)*` + t.src_domain + `))`),
    (t.tpl_host_fuzzy =
      `(?:` + t.src_ip4 + `|(?:(?:(?:` + t.src_domain + `)\\.)+(?:%TLDS%)))`),
    (t.tpl_host_no_ip_fuzzy = `(?:(?:(?:` + t.src_domain + `)\\.)+(?:%TLDS%))`),
    (t.src_host_strict = t.src_host + t.src_host_terminator),
    (t.tpl_host_fuzzy_strict = t.tpl_host_fuzzy + t.src_host_terminator),
    (t.src_host_port_strict = t.src_host + t.src_port + t.src_host_terminator),
    (t.tpl_host_port_fuzzy_strict =
      t.tpl_host_fuzzy + t.src_port + t.src_host_terminator),
    (t.tpl_host_port_no_ip_fuzzy_strict =
      t.tpl_host_no_ip_fuzzy + t.src_port + t.src_host_terminator),
    (t.tpl_host_fuzzy_test =
      `localhost|www\\.|\\.\\d{1,3}\\.|(?:\\.(?:%TLDS%)(?:` +
      t.src_ZPCc +
      `|>|$))`),
    (t.tpl_email_fuzzy =
      `(^|` +
      n +
      `|"|\\(|` +
      t.src_ZCc +
      `)(` +
      t.src_email_name +
      `@` +
      t.tpl_host_fuzzy_strict +
      `)`),
    (t.tpl_link_fuzzy =
      "(^|(?![.:/\\-_@])(?:[$+<=>^`|｜]|" +
      t.src_ZPCc +
      "))((?![$+<=>^`|｜])" +
      t.tpl_host_port_fuzzy_strict +
      t.src_path +
      `)`),
    (t.tpl_link_no_ip_fuzzy =
      "(^|(?![.:/\\-_@])(?:[$+<=>^`|｜]|" +
      t.src_ZPCc +
      "))((?![$+<=>^`|｜])" +
      t.tpl_host_port_no_ip_fuzzy_strict +
      t.src_path +
      `)`),
    t
  );
}
function Cf(e) {
  return (
    Array.prototype.slice.call(arguments, 1).forEach(function (t) {
      t &&
        Object.keys(t).forEach(function (n) {
          e[n] = t[n];
        });
    }),
    e
  );
}
function wf(e) {
  return Object.prototype.toString.call(e);
}
function Tf(e) {
  return wf(e) === `[object String]`;
}
function Ef(e) {
  return wf(e) === `[object Object]`;
}
function Df(e) {
  return wf(e) === `[object RegExp]`;
}
function Of(e) {
  return wf(e) === `[object Function]`;
}
function kf(e) {
  return e.replace(/[.?*+^$[\]\\(){}|-]/g, `\\$&`);
}
var Af = { fuzzyLink: !0, fuzzyEmail: !0, fuzzyIP: !1 };
function jf(e) {
  return Object.keys(e || {}).reduce(function (e, t) {
    return e || Af.hasOwnProperty(t);
  }, !1);
}
var Mf = {
    "http:": {
      validate: function (e, t, n) {
        let r = e.slice(t);
        return (
          n.re.http ||
            (n.re.http = RegExp(
              `^\\/\\/` +
                n.re.src_auth +
                n.re.src_host_port_strict +
                n.re.src_path,
              `i`
            )),
          n.re.http.test(r) ? r.match(n.re.http)[0].length : 0
        );
      },
    },
    "https:": `http:`,
    "ftp:": `http:`,
    "//": {
      validate: function (e, t, n) {
        let r = e.slice(t);
        return (
          n.re.no_http ||
            (n.re.no_http = RegExp(
              `^` +
                n.re.src_auth +
                `(?:localhost|(?:(?:` +
                n.re.src_domain +
                `)\\.)+` +
                n.re.src_domain_root +
                `)` +
                n.re.src_port +
                n.re.src_host_terminator +
                n.re.src_path,
              `i`
            )),
          n.re.no_http.test(r)
            ? (t >= 3 && e[t - 3] === `:`) || (t >= 3 && e[t - 3] === `/`)
              ? 0
              : r.match(n.re.no_http)[0].length
            : 0
        );
      },
    },
    "mailto:": {
      validate: function (e, t, n) {
        let r = e.slice(t);
        return (
          n.re.mailto ||
            (n.re.mailto = RegExp(
              `^` + n.re.src_email_name + `@` + n.re.src_host_strict,
              `i`
            )),
          n.re.mailto.test(r) ? r.match(n.re.mailto)[0].length : 0
        );
      },
    },
  },
  Nf = `a[cdefgilmnoqrstuwxz]|b[abdefghijmnorstvwyz]|c[acdfghiklmnoruvwxyz]|d[ejkmoz]|e[cegrstu]|f[ijkmor]|g[abdefghilmnpqrstuwy]|h[kmnrtu]|i[delmnoqrst]|j[emop]|k[eghimnprwyz]|l[abcikrstuvy]|m[acdeghklmnopqrstuvwxyz]|n[acefgilopruz]|om|p[aefghklmnrstwy]|qa|r[eosuw]|s[abcdeghijklmnortuvxyz]|t[cdfghjklmnortvwz]|u[agksyz]|v[aceginu]|w[fs]|y[et]|z[amw]`,
  Pf =
    `biz|com|edu|gov|net|org|pro|web|xxx|aero|asia|coop|info|museum|name|shop|рф`.split(
      `|`
    );
function Ff(e) {
  (e.__index__ = -1), (e.__text_cache__ = ``);
}
function If(e) {
  return function (t, n) {
    let r = t.slice(n);
    return e.test(r) ? r.match(e)[0].length : 0;
  };
}
function Lf() {
  return function (e, t) {
    t.normalize(e);
  };
}
function Rf(e) {
  let t = (e.re = Sf(e.__opts__)),
    n = e.__tlds__.slice();
  e.onCompile(),
    e.__tlds_replaced__ || n.push(Nf),
    n.push(t.src_xn),
    (t.src_tlds = n.join(`|`));
  function r(e) {
    return e.replace(`%TLDS%`, t.src_tlds);
  }
  (t.email_fuzzy = RegExp(r(t.tpl_email_fuzzy), `i`)),
    (t.link_fuzzy = RegExp(r(t.tpl_link_fuzzy), `i`)),
    (t.link_no_ip_fuzzy = RegExp(r(t.tpl_link_no_ip_fuzzy), `i`)),
    (t.host_fuzzy_test = RegExp(r(t.tpl_host_fuzzy_test), `i`));
  let i = [];
  e.__compiled__ = {};
  function a(e, t) {
    throw Error(`(LinkifyIt) Invalid schema "` + e + `": ` + t);
  }
  Object.keys(e.__schemas__).forEach(function (t) {
    let n = e.__schemas__[t];
    if (n === null) return;
    let r = { validate: null, link: null };
    if (((e.__compiled__[t] = r), Ef(n))) {
      Df(n.validate)
        ? (r.validate = If(n.validate))
        : Of(n.validate)
        ? (r.validate = n.validate)
        : a(t, n),
        Of(n.normalize)
          ? (r.normalize = n.normalize)
          : n.normalize
          ? a(t, n)
          : (r.normalize = Lf());
      return;
    }
    if (Tf(n)) {
      i.push(t);
      return;
    }
    a(t, n);
  }),
    i.forEach(function (t) {
      e.__compiled__[e.__schemas__[t]] &&
        ((e.__compiled__[t].validate =
          e.__compiled__[e.__schemas__[t]].validate),
        (e.__compiled__[t].normalize =
          e.__compiled__[e.__schemas__[t]].normalize));
    }),
    (e.__compiled__[``] = { validate: null, normalize: Lf() });
  let o = Object.keys(e.__compiled__)
    .filter(function (t) {
      return t.length > 0 && e.__compiled__[t];
    })
    .map(kf)
    .join(`|`);
  (e.re.schema_test = RegExp(
    `(^|(?!_)(?:[><｜]|` + t.src_ZPCc + `))(` + o + `)`,
    `i`
  )),
    (e.re.schema_search = RegExp(
      `(^|(?!_)(?:[><｜]|` + t.src_ZPCc + `))(` + o + `)`,
      `ig`
    )),
    (e.re.schema_at_start = RegExp(`^` + e.re.schema_search.source, `i`)),
    (e.re.pretest = RegExp(
      `(` +
        e.re.schema_test.source +
        `)|(` +
        e.re.host_fuzzy_test.source +
        `)|@`,
      `i`
    )),
    Ff(e);
}
function zf(e, t) {
  let n = e.__index__,
    r = e.__last_index__,
    i = e.__text_cache__.slice(n, r);
  (this.schema = e.__schema__.toLowerCase()),
    (this.index = n + t),
    (this.lastIndex = r + t),
    (this.raw = i),
    (this.text = i),
    (this.url = i);
}
function Bf(e, t) {
  let n = new zf(e, t);
  return e.__compiled__[n.schema].normalize(n, e), n;
}
function Vf(e, t) {
  if (!(this instanceof Vf)) return new Vf(e, t);
  t || (jf(e) && ((t = e), (e = {}))),
    (this.__opts__ = Cf({}, Af, t)),
    (this.__index__ = -1),
    (this.__last_index__ = -1),
    (this.__schema__ = ``),
    (this.__text_cache__ = ``),
    (this.__schemas__ = Cf({}, Mf, e)),
    (this.__compiled__ = {}),
    (this.__tlds__ = Pf),
    (this.__tlds_replaced__ = !1),
    (this.re = {}),
    Rf(this);
}
(Vf.prototype.add = function (e, t) {
  return (this.__schemas__[e] = t), Rf(this), this;
}),
  (Vf.prototype.set = function (e) {
    return (this.__opts__ = Cf(this.__opts__, e)), this;
  }),
  (Vf.prototype.test = function (e) {
    if (((this.__text_cache__ = e), (this.__index__ = -1), !e.length))
      return !1;
    let t, n, r, i, a, o, s, c, l;
    if (this.re.schema_test.test(e)) {
      for (
        s = this.re.schema_search, s.lastIndex = 0;
        (t = s.exec(e)) !== null;

      )
        if (((i = this.testSchemaAt(e, t[2], s.lastIndex)), i)) {
          (this.__schema__ = t[2]),
            (this.__index__ = t.index + t[1].length),
            (this.__last_index__ = t.index + t[0].length + i);
          break;
        }
    }
    return (
      this.__opts__.fuzzyLink &&
        this.__compiled__[`http:`] &&
        ((c = e.search(this.re.host_fuzzy_test)),
        c >= 0 &&
          (this.__index__ < 0 || c < this.__index__) &&
          (n = e.match(
            this.__opts__.fuzzyIP
              ? this.re.link_fuzzy
              : this.re.link_no_ip_fuzzy
          )) !== null &&
          ((a = n.index + n[1].length),
          (this.__index__ < 0 || a < this.__index__) &&
            ((this.__schema__ = ``),
            (this.__index__ = a),
            (this.__last_index__ = n.index + n[0].length)))),
      this.__opts__.fuzzyEmail &&
        this.__compiled__[`mailto:`] &&
        ((l = e.indexOf(`@`)),
        l >= 0 &&
          (r = e.match(this.re.email_fuzzy)) !== null &&
          ((a = r.index + r[1].length),
          (o = r.index + r[0].length),
          (this.__index__ < 0 ||
            a < this.__index__ ||
            (a === this.__index__ && o > this.__last_index__)) &&
            ((this.__schema__ = `mailto:`),
            (this.__index__ = a),
            (this.__last_index__ = o)))),
      this.__index__ >= 0
    );
  }),
  (Vf.prototype.pretest = function (e) {
    return this.re.pretest.test(e);
  }),
  (Vf.prototype.testSchemaAt = function (e, t, n) {
    return this.__compiled__[t.toLowerCase()]
      ? this.__compiled__[t.toLowerCase()].validate(e, n, this)
      : 0;
  }),
  (Vf.prototype.match = function (e) {
    let t = [],
      n = 0;
    this.__index__ >= 0 &&
      this.__text_cache__ === e &&
      (t.push(Bf(this, n)), (n = this.__last_index__));
    let r = n ? e.slice(n) : e;
    for (; this.test(r); )
      t.push(Bf(this, n)),
        (r = r.slice(this.__last_index__)),
        (n += this.__last_index__);
    return t.length ? t : null;
  }),
  (Vf.prototype.matchAtStart = function (e) {
    if (((this.__text_cache__ = e), (this.__index__ = -1), !e.length))
      return null;
    let t = this.re.schema_at_start.exec(e);
    if (!t) return null;
    let n = this.testSchemaAt(e, t[2], t[0].length);
    return n
      ? ((this.__schema__ = t[2]),
        (this.__index__ = t.index + t[1].length),
        (this.__last_index__ = t.index + t[0].length + n),
        Bf(this, 0))
      : null;
  }),
  (Vf.prototype.tlds = function (e, t) {
    return (
      (e = Array.isArray(e) ? e : [e]),
      t
        ? ((this.__tlds__ = this.__tlds__
            .concat(e)
            .sort()
            .filter(function (e, t, n) {
              return e !== n[t - 1];
            })
            .reverse()),
          Rf(this),
          this)
        : ((this.__tlds__ = e.slice()),
          (this.__tlds_replaced__ = !0),
          Rf(this),
          this)
    );
  }),
  (Vf.prototype.normalize = function (e) {
    e.schema || (e.url = `http://` + e.url),
      e.schema === `mailto:` &&
        !/^mailto:/i.test(e.url) &&
        (e.url = `mailto:` + e.url);
  }),
  (Vf.prototype.onCompile = function () {});
var Hf = JSON.parse(
    `["aaa","aarp","abb","abbott","abbvie","abc","able","abogado","abudhabi","ac","academy","accenture","accountant","accountants","aco","actor","ad","ads","adult","ae","aeg","aero","aetna","af","afl","africa","ag","agakhan","agency","ai","aig","airbus","airforce","airtel","akdn","al","alibaba","alipay","allfinanz","allstate","ally","alsace","alstom","am","amazon","americanexpress","americanfamily","amex","amfam","amica","amsterdam","analytics","android","anquan","anz","ao","aol","apartments","app","apple","aq","aquarelle","ar","arab","aramco","archi","army","arpa","art","arte","as","asda","asia","associates","at","athleta","attorney","au","auction","audi","audible","audio","auspost","author","auto","autos","aw","aws","ax","axa","az","azure","ba","baby","baidu","banamex","band","bank","bar","barcelona","barclaycard","barclays","barefoot","bargains","baseball","basketball","bauhaus","bayern","bb","bbc","bbt","bbva","bcg","bcn","bd","be","beats","beauty","beer","berlin","best","bestbuy","bet","bf","bg","bh","bharti","bi","bible","bid","bike","bing","bingo","bio","biz","bj","black","blackfriday","blockbuster","blog","bloomberg","blue","bm","bms","bmw","bn","bnpparibas","bo","boats","boehringer","bofa","bom","bond","boo","book","booking","bosch","bostik","boston","bot","boutique","box","br","bradesco","bridgestone","broadway","broker","brother","brussels","bs","bt","build","builders","business","buy","buzz","bv","bw","by","bz","bzh","ca","cab","cafe","cal","call","calvinklein","cam","camera","camp","canon","capetown","capital","capitalone","car","caravan","cards","care","career","careers","cars","casa","case","cash","casino","cat","catering","catholic","cba","cbn","cbre","cc","cd","center","ceo","cern","cf","cfa","cfd","cg","ch","chanel","channel","charity","chase","chat","cheap","chintai","christmas","chrome","church","ci","cipriani","circle","cisco","citadel","citi","citic","city","ck","cl","claims","cleaning","click","clinic","clinique","clothing","cloud","club","clubmed","cm","cn","co","coach","codes","coffee","college","cologne","com","commbank","community","company","compare","computer","comsec","condos","construction","consulting","contact","contractors","cooking","cool","coop","corsica","country","coupon","coupons","courses","cpa","cr","credit","creditcard","creditunion","cricket","crown","crs","cruise","cruises","cu","cuisinella","cv","cw","cx","cy","cymru","cyou","cz","dad","dance","data","date","dating","datsun","day","dclk","dds","de","deal","dealer","deals","degree","delivery","dell","deloitte","delta","democrat","dental","dentist","desi","design","dev","dhl","diamonds","diet","digital","direct","directory","discount","discover","dish","diy","dj","dk","dm","dnp","do","docs","doctor","dog","domains","dot","download","drive","dtv","dubai","dupont","durban","dvag","dvr","dz","earth","eat","ec","eco","edeka","edu","education","ee","eg","email","emerck","energy","engineer","engineering","enterprises","epson","equipment","er","ericsson","erni","es","esq","estate","et","eu","eurovision","eus","events","exchange","expert","exposed","express","extraspace","fage","fail","fairwinds","faith","family","fan","fans","farm","farmers","fashion","fast","fedex","feedback","ferrari","ferrero","fi","fidelity","fido","film","final","finance","financial","fire","firestone","firmdale","fish","fishing","fit","fitness","fj","fk","flickr","flights","flir","florist","flowers","fly","fm","fo","foo","food","football","ford","forex","forsale","forum","foundation","fox","fr","free","fresenius","frl","frogans","frontier","ftr","fujitsu","fun","fund","furniture","futbol","fyi","ga","gal","gallery","gallo","gallup","game","games","gap","garden","gay","gb","gbiz","gd","gdn","ge","gea","gent","genting","george","gf","gg","ggee","gh","gi","gift","gifts","gives","giving","gl","glass","gle","global","globo","gm","gmail","gmbh","gmo","gmx","gn","godaddy","gold","goldpoint","golf","goo","goodyear","goog","google","gop","got","gov","gp","gq","gr","grainger","graphics","gratis","green","gripe","grocery","group","gs","gt","gu","gucci","guge","guide","guitars","guru","gw","gy","hair","hamburg","hangout","haus","hbo","hdfc","hdfcbank","health","healthcare","help","helsinki","here","hermes","hiphop","hisamitsu","hitachi","hiv","hk","hkt","hm","hn","hockey","holdings","holiday","homedepot","homegoods","homes","homesense","honda","horse","hospital","host","hosting","hot","hotels","hotmail","house","how","hr","hsbc","ht","hu","hughes","hyatt","hyundai","ibm","icbc","ice","icu","id","ie","ieee","ifm","ikano","il","im","imamat","imdb","immo","immobilien","in","inc","industries","infiniti","info","ing","ink","institute","insurance","insure","int","international","intuit","investments","io","ipiranga","iq","ir","irish","is","ismaili","ist","istanbul","it","itau","itv","jaguar","java","jcb","je","jeep","jetzt","jewelry","jio","jll","jm","jmp","jnj","jo","jobs","joburg","jot","joy","jp","jpmorgan","jprs","juegos","juniper","kaufen","kddi","ke","kerryhotels","kerryproperties","kfh","kg","kh","ki","kia","kids","kim","kindle","kitchen","kiwi","km","kn","koeln","komatsu","kosher","kp","kpmg","kpn","kr","krd","kred","kuokgroup","kw","ky","kyoto","kz","la","lacaixa","lamborghini","lamer","land","landrover","lanxess","lasalle","lat","latino","latrobe","law","lawyer","lb","lc","lds","lease","leclerc","lefrak","legal","lego","lexus","lgbt","li","lidl","life","lifeinsurance","lifestyle","lighting","like","lilly","limited","limo","lincoln","link","live","living","lk","llc","llp","loan","loans","locker","locus","lol","london","lotte","lotto","love","lpl","lplfinancial","lr","ls","lt","ltd","ltda","lu","lundbeck","luxe","luxury","lv","ly","ma","madrid","maif","maison","makeup","man","management","mango","map","market","marketing","markets","marriott","marshalls","mattel","mba","mc","mckinsey","md","me","med","media","meet","melbourne","meme","memorial","men","menu","merckmsd","mg","mh","miami","microsoft","mil","mini","mint","mit","mitsubishi","mk","ml","mlb","mls","mm","mma","mn","mo","mobi","mobile","moda","moe","moi","mom","monash","money","monster","mormon","mortgage","moscow","moto","motorcycles","mov","movie","mp","mq","mr","ms","msd","mt","mtn","mtr","mu","museum","music","mv","mw","mx","my","mz","na","nab","nagoya","name","navy","nba","nc","ne","nec","net","netbank","netflix","network","neustar","new","news","next","nextdirect","nexus","nf","nfl","ng","ngo","nhk","ni","nico","nike","nikon","ninja","nissan","nissay","nl","no","nokia","norton","now","nowruz","nowtv","np","nr","nra","nrw","ntt","nu","nyc","nz","obi","observer","office","okinawa","olayan","olayangroup","ollo","om","omega","one","ong","onl","online","ooo","open","oracle","orange","org","organic","origins","osaka","otsuka","ott","ovh","pa","page","panasonic","paris","pars","partners","parts","party","pay","pccw","pe","pet","pf","pfizer","pg","ph","pharmacy","phd","philips","phone","photo","photography","photos","physio","pics","pictet","pictures","pid","pin","ping","pink","pioneer","pizza","pk","pl","place","play","playstation","plumbing","plus","pm","pn","pnc","pohl","poker","politie","porn","post","pr","praxi","press","prime","pro","prod","productions","prof","progressive","promo","properties","property","protection","pru","prudential","ps","pt","pub","pw","pwc","py","qa","qpon","quebec","quest","racing","radio","re","read","realestate","realtor","realty","recipes","red","redumbrella","rehab","reise","reisen","reit","reliance","ren","rent","rentals","repair","report","republican","rest","restaurant","review","reviews","rexroth","rich","richardli","ricoh","ril","rio","rip","ro","rocks","rodeo","rogers","room","rs","rsvp","ru","rugby","ruhr","run","rw","rwe","ryukyu","sa","saarland","safe","safety","sakura","sale","salon","samsclub","samsung","sandvik","sandvikcoromant","sanofi","sap","sarl","sas","save","saxo","sb","sbi","sbs","sc","scb","schaeffler","schmidt","scholarships","school","schule","schwarz","science","scot","sd","se","search","seat","secure","security","seek","select","sener","services","seven","sew","sex","sexy","sfr","sg","sh","shangrila","sharp","shell","shia","shiksha","shoes","shop","shopping","shouji","show","si","silk","sina","singles","site","sj","sk","ski","skin","sky","skype","sl","sling","sm","smart","smile","sn","sncf","so","soccer","social","softbank","software","sohu","solar","solutions","song","sony","soy","spa","space","sport","spot","sr","srl","ss","st","stada","staples","star","statebank","statefarm","stc","stcgroup","stockholm","storage","store","stream","studio","study","style","su","sucks","supplies","supply","support","surf","surgery","suzuki","sv","swatch","swiss","sx","sy","sydney","systems","sz","tab","taipei","talk","taobao","target","tatamotors","tatar","tattoo","tax","taxi","tc","tci","td","tdk","team","tech","technology","tel","temasek","tennis","teva","tf","tg","th","thd","theater","theatre","tiaa","tickets","tienda","tips","tires","tirol","tj","tjmaxx","tjx","tk","tkmaxx","tl","tm","tmall","tn","to","today","tokyo","tools","top","toray","toshiba","total","tours","town","toyota","toys","tr","trade","trading","training","travel","travelers","travelersinsurance","trust","trv","tt","tube","tui","tunes","tushu","tv","tvs","tw","tz","ua","ubank","ubs","ug","uk","unicom","university","uno","uol","ups","us","uy","uz","va","vacations","vana","vanguard","vc","ve","vegas","ventures","verisign","vermögensberater","vermögensberatung","versicherung","vet","vg","vi","viajes","video","vig","viking","villas","vin","vip","virgin","visa","vision","viva","vivo","vlaanderen","vn","vodka","volvo","vote","voting","voto","voyage","vu","wales","walmart","walter","wang","wanggou","watch","watches","weather","weatherchannel","webcam","weber","website","wed","wedding","weibo","weir","wf","whoswho","wien","wiki","williamhill","win","windows","wine","winners","wme","wolterskluwer","woodside","work","works","world","wow","ws","wtc","wtf","xbox","xerox","xihuan","xin","xxx","xyz","yachts","yahoo","yamaxun","yandex","ye","yodobashi","yoga","yokohama","you","youtube","yt","yun","za","zappos","zara","zero","zip","zm","zone","zuerich","zw","ελ","ευ","бг","бел","дети","ею","католик","ком","мкд","мон","москва","онлайн","орг","рус","рф","сайт","срб","укр","қаз","հայ","ישראל","קום","ابوظبي","ارامكو","الاردن","البحرين","الجزائر","السعودية","العليان","المغرب","امارات","ایران","بارت","بازار","بيتك","بھارت","تونس","سودان","سورية","شبكة","عراق","عرب","عمان","فلسطين","قطر","كاثوليك","كوم","مصر","مليسيا","موريتانيا","موقع","همراه","پاکستان","ڀارت","कॉम","नेट","भारत","भारतम्","भारोत","संगठन","বাংলা","ভারত","ভাৰত","ਭਾਰਤ","ભારત","ଭାରତ","இந்தியா","இலங்கை","சிங்கப்பூர்","భారత్","ಭಾರತ","ഭാരതം","ලංකා","คอม","ไทย","ລາວ","გე","みんな","アマゾン","クラウド","グーグル","コム","ストア","セール","ファッション","ポイント","世界","中信","中国","中國","中文网","亚马逊","企业","佛山","信息","健康","八卦","公司","公益","台湾","台灣","商城","商店","商标","嘉里","嘉里大酒店","在线","大拿","天主教","娱乐","家電","广东","微博","慈善","我爱你","手机","招聘","政务","政府","新加坡","新闻","时尚","書籍","机构","淡马锡","游戏","澳門","点看","移动","组织机构","网址","网店","网站","网络","联通","谷歌","购物","通販","集团","電訊盈科","飞利浦","食品","餐厅","香格里拉","香港","닷넷","닷컴","삼성","한국"]`
  ),
  Uf =
    /^[-!#$%&'*+/0-9=?A-Z^_a-z`{|}~](\.?[-!#$%&'*+/0-9=?A-Z^_a-z`{|}~])*@[a-zA-Z0-9](-*\.?[a-zA-Z0-9])*\.[a-zA-Z](-?[a-zA-Z0-9])+$/,
  Wf = /((?:www.)?[^\s.]+\.[^\s/]+\/[^\s.]+)/,
  Gf = /[&<>"']/g,
  Kf = (e) => {
    let t = {
        "&": `&amp;`,
        "<": `&lt;`,
        ">": `&gt;`,
        '"': `&quot;`,
        "'": `&#39;`,
      },
      n = RegExp(Gf.source);
    return e && n.test(e) ? e.replace(Gf, (e) => t[e]) : e || ``;
  },
  qf = `overflow: hidden; display: -webkit-inline-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1; line-clamp: 1; word-break: break-all;`,
  Jf = new Vf().tlds(Hf).set({ fuzzyIP: !0 }),
  Yf = new Vf().tlds(Hf),
  Xf = (e, t, n) => {
    let r = B().location.hostname;
    return `<a href="${e}" target="${
      r.length > 0 && e.includes(r) ? `_parent` : `_blank`
    }" rel="noreferrer noopener" title="${e}" style="${
      n?.clamp && !n?.replaceText ? qf : ``
    }">${t}</a>`;
  },
  Zf = (e, t) => {
    if (e === ``) return e;
    let n = Jf.match(e);
    if (!n) return Kf(e);
    let r = ``,
      i = 0;
    return (
      n.forEach((n) => {
        let a = ``,
          o = ``,
          s = Qf(e, n),
          c = t?.clamp && n.text.length > 30 && !s;
        n.index > i && (a = e.substring(i, n.index)),
          (o = Xf(n.url, n.text, { ...t, clamp: c })),
          (i = n.lastIndex),
          s && ((a = a.substring(0, a.length - 1)), (i += 1)),
          c &&
            !$f(e, n) &&
            ((o = `\n${o}\n`),
            (a = a.trimEnd()),
            e[i]?.match(/\s/) && (i += 1)),
          (r += Kf(a) + o);
      }),
      e.length > i && (r += Kf(e.substring(i))),
      r
    );
  },
  Qf = (e, t) => e[t.index - 1] === `"` && e[t.lastIndex] === `"`,
  $f = (e, t) =>
    !!(
      (t.index <= 1 &&
        e.substring(t.lastIndex, t.lastIndex + 3).match(/[\n\r]+/)) ||
      (e.substring(t.index - 3, t.index).match(/[\n\r]+/) &&
        e.substring(t.lastIndex, t.lastIndex + 3).match(/[\n\r]+/)) ||
      (e.substring(t.index - 3, t.index).match(/[\n\r]+/) &&
        t.lastIndex > e.length - 3) ||
      (t.index <= 1 && t.lastIndex >= e.length - 2)
    ),
  ep = (e) =>
    e
      .replace(/^https?:\/\//, ``)
      .replace(/^www\./, ``)
      .replace(/\/+$/, ``)
      .toLowerCase(),
  tp = (e) => {
    let t = [`mailto:`, `ftp:`, `//`],
      n = Yf.match(e);
    if (!n) return null;
    let r = new Set();
    return n.filter((e) => {
      if (t.includes(e.schema)) return !1;
      let n = ep(e.url);
      return r.has(n) ? !1 : (r.add(n), !0);
    });
  },
  np = () => Po(`cards`),
  rp = (e) => {
    Fo({ ...e }, `cards`);
  },
  ip = async (e) => {
    let t = new Headers(),
      { widgetApiUrl: n } = V.getOptions();
    t.append(`Content-Type`, `application/json`);
    let r = JSON.stringify({ links: e });
    try {
      let e = await fetch(`${n}/links/preview`, {
        method: `POST`,
        headers: t,
        body: r,
      });
      return e.ok && e.json ? await e.json() : null;
    } catch {
      return null;
    }
  },
  ap = (e) => e.find((e) => e.type === `open_url`)?.value || ``,
  op = (e) => {
    let t = e.filter((e) => e.title && e.image && !cp(ap(e.actions)));
    return t.length && e.length > 1 ? e : t.length === 1 ? t : [];
  },
  sp = (e) => {
    let t = new Date().getTime();
    return (
      Object.keys(e).forEach((n) => {
        (!e[n].expiration || (e[n].expiration && e[n].expiration < t)) &&
          delete e[n];
      }),
      e
    );
  },
  cp = (e) => {
    let { acceptedFileExtensions: t } = A(Rl),
      n = e.match(/(\.)([^.]{3,4})$/m);
    return n && n[2] && t.includes(n[2]);
  },
  lp = async (e) => {
    try {
      await q.getClient().linkOpened({ url: e });
    } catch (e) {
      jo(`Sending link opened analytics event failed`, String(e));
    }
  },
  up = (e, t) => {
    if (!t) return;
    let n = async (n) => {
        let r = n.target.closest(`a`);
        r && e.contains(r) && t && (await lp(r.href));
      },
      r = (e) => void n(e),
      i = (e) => {
        e.button !== 2 && n(e);
      },
      a = (e) => void n(e);
    return (
      e.addEventListener(`click`, r),
      e.addEventListener(`auxclick`, i),
      e.addEventListener(`contextmenu`, a),
      {
        destroy() {
          e.removeEventListener(`click`, r),
            e.removeEventListener(`auxclick`, i),
            e.removeEventListener(`contextmenu`, a);
        },
      }
    );
  },
  dp = !1,
  fp = O(),
  pp = O(!1),
  mp = O(!1),
  hp = (e, t, n) => {
    let r = {},
      i = new Date().getTime() + nf;
    e.forEach((e, n) => (r[e] = { expiration: i, card: t[n] }));
    let a = { ...n, ...r };
    fp.set(a), rp(a);
  },
  gp = async (e, t, n = !1) => {
    let r = [],
      i = { type: `cards`, layout: `carousel`, items: [] };
    dp ||= (fp.set(np()), !0);
    let a = tp(e);
    if (!a) return null;
    let o = sp(A(fp)),
      s = [];
    if (
      (a.forEach((t) => {
        Qf(e, t) || (o[t.url] ? r.push(o[t.url].card) : s.push(t.url));
      }),
      s.length > 0)
    ) {
      t && pp.set(!0), n && mp.set(!0);
      let e = await ip(s);
      e && (hp(s, e, o), (r = [...r, ...e]));
    }
    return (
      (i.items = op(r)), pp.set(!1), mp.set(!1), i.items.length > 0 ? i : null
    );
  },
  _p = (function (e) {
    return (
      (e.ContactMessage = `contact-message`),
      (e.AgentMessage = `agent-message`),
      (e.BotMessage = `bot-message`),
      (e.BotReplies = `bot-replies`),
      e
    );
  })({}),
  vp = async ({ text: e, quickReply: t }) => {
    try {
      let n = B().location.href;
      return (
        (await q
          .getClient()
          .chatMessage({
            content: { type: K.MessageContentType.Text, text: e },
            quickReply: t,
            pageUrl: n,
          })) ?? null
      );
    } catch {
      return null;
    }
  },
  yp = (e) =>
    e.subType === K.MessageSubType.Bot ||
    e.subType === K.MessageSubType.Trigger,
  bp = (e) => e.subType === K.MessageSubType.System,
  xp = (e) => e.type === K.MessageType.Note,
  Sp = (e) =>
    !e.deletedAt && !xp(e) && (e.subType === K.MessageSubType.Agent || yp(e)),
  Cp = (e) => `html` in e && !!e.html,
  wp = (e) => `text` in e && !!e.text,
  Tp = (e, t) =>
    new Date(e.createdAt).getTime() - new Date(t.createdAt).getTime(),
  Ep = (e, t) => (t === _p.BotReplies ? `${e.id}-replies` : e.id),
  Dp = (e) => {
    let t = { isRight: !1, isLeft: !1 },
      n = { isPrimary: !1, isSecondary: !1 };
    switch (e) {
      case _p.ContactMessage:
        (t.isRight = !0), (n.isPrimary = !0);
        break;
      default:
        (t.isLeft = !0), (n.isSecondary = !0);
    }
    return { align: t, variant: n };
  },
  Op = (e) =>
    !!e.agentId ||
    (e.subType === K.MessageSubType.Bot &&
      e.content.type !== K.MessageContentType.TicketForm),
  kp = (e, t) =>
    e.subType === K.MessageSubType.System ||
    t === _p.BotReplies ||
    e.content.type === K.MessageContentType.TicketForm,
  Ap = (e) => {
    let t = [],
      n = null,
      r = null;
    for (let i of e) {
      if (
        i.content.type === K.MessageContentType.RateForm &&
        ((i.content.data.target === K.RatingTarget.Ai && !xm()) ||
          (i.content.data.target === K.RatingTarget.Agent && !bm()))
      )
        continue;
      n && !zp(i, n) && (t.push(n), (n = null), (r = null)), (n ||= jp(i));
      let e = Np(i, n);
      if (r) {
        let t = Hp(r),
          n = Fp(r);
        (e.neighbors.hasTop = t),
          (n.any.neighbors.hasBottom = t),
          n.attachmentContext &&
            (n.attachmentContext.extraSpaces.hasBottom = Wp(
              n.attachmentContext.attachment
            ));
      }
      let a = Ip(i);
      if (
        (a && Pp(a, e, r),
        n.messagesContext.push(e),
        (r = e),
        (yp(i) || bp(i)) && Xp(i))
      ) {
        t.push(n);
        let e = Mp(i);
        e.messagesContext.push(Np(i, e)), t.push(e), (n = null);
      }
    }
    return n && t.push(n), t;
  },
  jp = (e) => {
    let t = Vp(e),
      n =
        e.subType === K.MessageSubType.Bot ||
        e.subType === K.MessageSubType.Trigger,
      { align: r, variant: i } = Dp(t);
    return {
      type: t,
      isBot: n,
      id: Ep(e, t),
      date: e.createdAt,
      agentId: e.agentId,
      align: r,
      variant: i,
      messagesContext: [],
      showAvatar: Op(e),
      useFullWidth: kp(e, t),
    };
  },
  Mp = (e) => {
    let t = _p.BotReplies,
      { align: n, variant: r } = Dp(t);
    return {
      type: _p.BotReplies,
      isBot: !0,
      id: Ep(e, t),
      date: e.createdAt,
      agentId: e.agentId,
      align: n,
      variant: r,
      messagesContext: [],
      showAvatar: !1,
      useFullWidth: kp(e, t),
    };
  },
  Np = (e, t) => ({
    group: t,
    message: e,
    neighbors: { hasTop: !1, hasBottom: !1 },
    attachmentsContext: [],
  }),
  Pp = (e, t, n) => {
    let r = null;
    for (let i of e) {
      let e = Up(i),
        a = { hasTop: !1, hasBottom: !1 },
        o = Wp(i),
        s = { hasTop: o, hasBottom: !1 };
      if (r) {
        let t = Up(r.attachment),
          n = Wp(r.attachment);
        (r.neighbors.hasBottom = t && e),
          (a.hasTop = t && e),
          (r.extraSpaces.hasBottom = !o && n);
      } else if (((t.neighbors.hasBottom = e), (a.hasTop = e), Lp(t.message)))
        if (
          ((a.hasTop = !1),
          (t.neighbors.hasTop = !1),
          (t.neighbors.hasBottom = !1),
          n)
        ) {
          let t = Hp(n),
            r = Fp(n);
          (a.hasTop = t && e), (r.any.neighbors.hasBottom = t && e);
          let i = r.attachmentContext;
          i && (i.extraSpaces.hasBottom = !o && Wp(i.attachment));
        } else s.hasTop = !1;
      let c = {
        attachment: i,
        neighbors: a,
        extraSpaces: s,
        messageContext: t,
      };
      t.attachmentsContext.push(c), (r = { ...c });
    }
  },
  Fp = (e) => {
    let t = Kd(e.attachmentsContext) || void 0;
    return { attachmentContext: t, any: t || e };
  },
  Ip = (e) =>
    e
      ? e.content?.type === K.MessageContentType.Upload
        ? [e.content.data]
        : e.attachments
      : [],
  Lp = (e) => !e.content.text,
  Rp = (e) => {
    try {
      let t = B().location.hostname,
        n = new DOMParser().parseFromString(e, `text/html`);
      return (
        n.querySelectorAll(`a[href]`).forEach((e) => {
          let n = e.getAttribute(`href`) || ``;
          (n = n.replace(/^https?:\/\/"?https?:\/\//, `https://`)),
            (n = n.replace(/^"+|"+$/g, ``)),
            e.setAttribute(`href`, n);
          let r = t.length > 0 && n.includes(t);
          e.hasAttribute(`target`) ||
            e.setAttribute(`target`, r ? `_parent` : `_blank`),
            e.hasAttribute(`rel`) ||
              e.setAttribute(`rel`, `noopener noreferrer`);
        }),
        n.body.innerHTML
      );
    } catch {
      return e;
    }
  },
  zp = (e, t) => {
    let n = Vp(e),
      r = n === _p.AgentMessage && e.agentId === t.agentId,
      i = n === _p.ContactMessage,
      a =
        e.subType !== K.MessageSubType.Bot ||
        !(`quickReplies` in e.content) ||
        (e.content.quickReplies || []).length === 0,
      o = Bp(e.virtualAgent, t.messagesContext[0]?.message.virtualAgent);
    return t.type === n && (r || i) && a && o && sf(t.date, e.createdAt);
  },
  Bp = (e, t) =>
    !e || !t
      ? !e && !t
      : e.name === t.name &&
        e.description === t.description &&
        e.avatar === t.avatar,
  Vp = (e) => {
    switch (e.subType) {
      case K.MessageSubType.Agent:
        return _p.AgentMessage;
      case K.MessageSubType.Contact:
        return _p.ContactMessage;
      case K.MessageSubType.Bot:
        return _p.BotMessage;
    }
    return null;
  },
  Hp = (e) => {
    let t = e.attachmentsContext.length;
    return !(
      t > 0 &&
      e.attachmentsContext[t - 1].attachment.type === K.AttachmentType.File
    );
  },
  Up = (e) =>
    e.type !== K.AttachmentType.File && e.type !== K.AttachmentType.Cards,
  Wp = (e) =>
    !!e &&
    (e.type === K.AttachmentType.File || e.type === K.AttachmentType.Cards),
  Gp = () => {
    let e = U_();
    (e.volume = Hc),
      e.addEventListener(`canplaythrough`, () => {
        e.play().catch((e) => H(`Could not play message sound.`, e));
      });
  },
  Kp = _f(Gp, Uc),
  qp = (e) =>
    e.filter(
      (e) =>
        e.type === K.MessageType.Message &&
        (e.subType === K.MessageSubType.Agent ||
          e.subType === K.MessageSubType.Contact)
    ),
  Jp = (e, t = !0) => {
    let n = e.reduce(
      (e, t) => (
        e.push(t),
        t.content.type === K.MessageContentType.ChatClose ||
        t.content.type === K.MessageContentType.ChatVisitorClose
          ? []
          : e
      ),
      []
    );
    return t
      ? n.filter(
          (e) =>
            e.type === K.MessageType.Message &&
            e.subType !== K.MessageSubType.System
        )
      : n;
  },
  Yp = (e) => {
    let t = {};
    return (
      e.forEach((e) => {
        e.trigger && (t[e.trigger.id] = { sent: !0 });
      }),
      t
    );
  },
  Xp = (e) =>
    `quickReplies` in e.content &&
    !!e.content.quickReplies &&
    e.content.quickReplies.length > 0,
  Zp = async (e, t = !1) => {
    let n = Sp(e),
      r = !t && n;
    if (
      (`html` in e.content &&
        e.content.html &&
        (e.content.html = Rp(e.content.html)),
      e.content?.text &&
        V.getOptions().urlCardsEnabled &&
        e.attachments.length === 0)
    ) {
      let t = await gp(
        e.content.text,
        e.subType === K.MessageSubType.Contact,
        r
      );
      t && t.items.length > 0 && e.attachments.push(t);
    }
    return Td.set(!1), e;
  },
  Qp = async (e) => (
    V.getOptions().urlCardsEnabled &&
      (await Promise.all(e.map(async (e) => await Zp(e)))),
    e
  ),
  $p = (e) => e.findIndex((e) => e.message.channel.type === `email`) > -1,
  em = (e) =>
    e.find((e) => e.message?.trigger?.identityId)?.message?.trigger?.identityId,
  tm = (e) => e[0]?.message.virtualAgent ?? void 0,
  nm = (e, t) => {
    let n = t.findIndex((t) => t.id === e.id);
    for (let e = n - 1; e >= 0; e--) {
      let n = t[e];
      if (n.content.type === K.MessageContentType.BotAssign)
        return n.content.data.identityId;
      if (n.subType === K.MessageSubType.Bot && n.trigger?.identityId)
        return n.trigger.identityId;
    }
    return null;
  },
  J = (() => {
    let e = O({}),
      { subscribe: t, update: n, set: r } = e,
      i = async (e) => {
        r(Qc(`id`, await Qp(e)));
      },
      a = async (e) => {
        let t = await Zp(e);
        yp(e) && am.set(!1), n((n) => ({ ...n, [e.id]: t })), im(t);
      },
      o = async (e) => {
        if (!A(dm).some((t) => t.id === e.id)) return;
        let t = A(pm) === e.id ? await Zp(e, !0) : e;
        n((n) => ({ ...n, [e.id]: t }));
      };
    return {
      subscribe: t,
      setMessages: i,
      addMessage: a,
      deleteMessage: (e) => {
        n((t) => {
          let { [e]: n, ...r } = t;
          return r;
        });
      },
      markMessageAsDeleted: (t, r) => {
        let i = A(e)[t];
        i &&
          n((e) => ({
            ...e,
            [i.id]: { ...i, deletedAt: r ?? new Date().toISOString() },
          }));
      },
      replaceMessage: o,
      updateMessageRating: (e) => {
        A(Dd) === e.content.data?.target && Gd(),
          n((t) =>
            !e || e.content.type !== K.MessageContentType.RateForm
              ? { ...t }
              : (t[e.id] || Sm(e.id), { ...t, [e.id]: e })
          );
      },
      sendMessage: async (e, t) => {
        ym.set(e);
        let n = await vp({ text: e });
        n && (ym.set(null), await a(n), z.emit(`messageSent`, n), Zh(A(Sd))),
          await Promise.all(t.map((e) => Qd(e)));
      },
      sendBotReply: async (e, t, n) => {
        let r = await vp({ text: t, quickReply: { replyTo: e, payload: n } });
        n.isGoBackButton || xh(t), r && (await o(r));
      },
      clearMessages: () => {
        r({});
      },
    };
  })(),
  rm = (e) => {
    A(dv) || lv(),
      Mv(),
      setTimeout(() => {
        J.addMessage(e), Nv();
      }, 1600);
  },
  im = (e) => {
    e && A(ev) && A(dv) && !(A(nv) && A(X)) && W_(e) && Kp();
  },
  am = O(!1),
  om = k([J], ([e]) => {
    let t = Object.values(e).filter(Sp);
    return t
      ? Kd(
          t.sort(
            (e, t) =>
              new Date(e.createdAt).getTime() - new Date(t.createdAt).getTime()
          )
        )
      : null;
  }),
  sm = k([J, Ed], ([e, t]) => {
    let n = Object.values(e).filter(Sp);
    return t ? n.filter((e) => new Date(e.createdAt) > new Date(t)) : n;
  }),
  cm = k([sm], ([e]) => Kd(e)),
  lm = k([sm], ([e]) => e.length),
  um = k([lm], ([e]) => e > 0),
  dm = k([J], ([e]) => Object.values(e).sort(Tp)),
  fm = k([dm], ([e]) => Ap(e)),
  pm = k([dm], ([e]) => Kd(e)?.id ?? null),
  mm = k(
    [J],
    ([e]) =>
      Kd(
        Object.values(e).filter(
          (e) => typeof e.widgetOptions?.disableInput == `boolean`
        )
      )?.widgetOptions?.disableInput ?? !1
  ),
  hm = k(
    [J],
    ([e]) =>
      Object.values(e).filter(
        (e) => e.subType === `contact` || e.subType === `agent`
      ).length > 0
  ),
  gm = k(
    [J],
    ([e]) =>
      Object.values(e).filter((e) => e.subType === K.MessageSubType.Contact)
        .length > 0
  ),
  _m = k([J, Cs], ([e, t], n) => {
    if (t) {
      let r = e[t];
      r &&
        r.content.type === K.MessageContentType.RateForm &&
        n({
          messageId: r.id,
          value: r.content.data?.value,
          text: r.content.data?.text,
          target: r.content.data?.target,
        });
    } else n(null);
  }),
  vm = k(
    [dm],
    ([e]) =>
      e
        .slice()
        .reverse()
        .find((e) => e.subType === K.MessageSubType.Contact) || null
  ),
  ym = O(null),
  bm = () => !!V.getOptions().ratingEnabled,
  xm = () => !!V.getOptions().aiRatingEnabled,
  Sm = (e) => {
    Cs.set(e), Fc(Lc.ChatRating);
  },
  Cm = async ({
    messageId: e,
    rating: { text: t, value: n },
    onSuccess: r,
  }) => {
    let i = A(J)[e],
      a = e === `rate_form_id` ? void 0 : e;
    try {
      await q
        .getClient()
        .chatRate({ messageId: a, value: n, text: t ?? void 0 }),
        r && r();
    } catch (e) {
      i && (await J.replaceMessage(i)),
        jo(`Chat rating failed.`, String(e)),
        gs(A(W)(`form.submit.error`));
    }
  },
  wm = (e) => {
    let { widgetV3Url: t } = V.getOptions();
    return `${t}/assets/images/rating/${e}.svg`;
  },
  Tm = /(G-([A-Z,0-9]*))/g,
  Em = [],
  Dm = !1,
  Om,
  km = !1,
  Am,
  jm = (e) => e.match(Tm),
  Mm = () => {
    let { googleAnalyticsEnabled: e } = V.getOptions();
    (Om = window.top || window),
      e &&
        (Om.gtag && ((Am = Om.gtag), (km = !0)),
        z.on(`analyticsConsentChanged`, Nm),
        !Dm && Uo() && Pm());
  },
  Nm = (e) => {
    !Dm && e && Pm();
  },
  Pm = () => {
    let {
        gaKey: e,
        gaOptions: t,
        googleAnalyticsManual: n,
        googleAnalyticsMeasurementIds: r,
      } = V.getOptions(),
      i = t || { cookieDomain: `auto` };
    if (e) jm(e) && Em.push({ key: e, options: i });
    else if (n && r)
      r.forEach((e) => {
        jm(e) && Em.push({ key: e, options: i });
      });
    else
      try {
        Em.push(...Fm());
      } catch (e) {
        vo(
          `Error during getting GA top trackers`,
          e instanceof Error ? e.message : e
        );
      }
    Em.length > 0 && !km && Im(),
      Em.length === 0
        ? vo(`No GA to setup`)
        : (Rm(), (Dm = !0), vo(`GA initialized`));
  },
  Fm = () => {
    let e = [];
    return (
      Om.google_tag_manager &&
        Object.keys(Om.google_tag_manager).forEach((t) => {
          jm(t) && e.push({ key: t, options: { cookieDomain: `auto` } });
        }),
      e
    );
  },
  Im = () => {
    let e = Om.document,
      { head: t } = e,
      n = e.createElement(`script`);
    (n.id = `gtag`),
      (n.type = `text/javascript`),
      (n.async = !0),
      (n.src = `https://www.googletagmanager.com/gtag/js`),
      t.insertBefore(n, t.firstChild),
      (Om.dataLayer = Om.dataLayer || []),
      (Om.gtag = function () {
        Om.dataLayer.push(arguments);
      }),
      (Am = Om.gtag),
      Am(`js`, new Date());
  },
  Lm = () => {
    let e = [];
    if (km) {
      let t = Fm();
      Em.forEach((n) => {
        t.find(({ key: e }) => e === n.key) || e.push(n);
      });
    } else e = [...Em];
    return e;
  },
  Rm = () => {
    Lm().forEach((e) => {
      let { key: t, options: n } = e,
        r = {};
      n
        ? ((r = { cookie_domain: n.cookieDomain }), n.name && (r.name = n.name))
        : (r = { cookie_domain: Om?.location.hostname || `` }),
        (r.send_page_view = !1),
        Am(`config`, t, r);
    });
  },
  zm = (e, t) => {
    let { googleAnalyticsEnabled: n } = V.getOptions();
    if (!(!n || !Om.gtag || !Uo() || Om.document.hidden))
      try {
        Em.forEach((n) => {
          (t.send_to = n.key),
            Am(`event`, e, t),
            vo(`Smartsupp: GA event ${e} - ${JSON.stringify(t)}`);
        });
      } catch (e) {
        vo(`Smartsupp: GA error:`, e instanceof Error ? e.message : e);
      }
  },
  Bm = `Visitor_started_conversation`,
  Vm = `Visitor_closed_conversation`,
  Hm = `Trigger_message_sent`,
  Um = `Trigger_message_viewed`,
  Wm = `Trigger_visitor_reaction`,
  Gm = `Auto_message_sent`,
  Km = `Auto_message_viewed`,
  qm = `Auto_message_visitor_reaction`,
  Jm = `Chatbot_sent`,
  Ym = `Chatbot_viewed`,
  Xm = `Chatbot_interaction`,
  Zm = `Chatbot_button_interaction`,
  Qm = `Chatbot_visitor_reaction`,
  $m = `Ai_chatbot_sent`,
  eh = `Ai_chatbot_interaction`,
  th = `Ai_chatbot_visitor_reaction`,
  nh = `Agent_served_conversation`,
  rh = `Agent_closed_conversation`,
  ih = `Contact_acquired`,
  ah = `Auth_form_filled`,
  oh = `Offline_message_sent`,
  sh = `Feedback_sent`,
  ch = `Feedback_text_sent`,
  lh = `Url_card_opened`,
  uh = `Chatbox_opened`,
  dh = { event_category: `Smartsupp_v3`, non_interaction: !0 },
  Y = (e, t) => {
    zm(e, { ...dh, ...t });
  },
  fh = (e = ``) => Y(Hm, { event_label: e }),
  ph = (e) => Y(Um, { event_label: e }),
  mh = (e = ``) => Y(Wm, { event_label: e }),
  hh = (e = ``) => Y(Gm, { event_label: e }),
  gh = (e) => Y(Km, { event_label: e }),
  _h = (e = ``) => Y(qm, { event_label: e }),
  vh = (e = ``) => Y(Jm, { event_label: e }),
  yh = (e) => Y(Ym, { event_label: e }),
  bh = (e = ``) => Y(Xm, { event_label: e }),
  xh = (e = ``) => Y(Zm, { event_label: e }),
  Sh = (e = ``) => Y(Qm, { event_label: e }),
  Ch = () => Y(Bm),
  wh = () => Y(Vm),
  Th = (e) => Y(rh, { event_label: e }),
  Eh = (e) => Y(nh, { event_label: e }),
  Dh = () => Y(ah),
  Oh = () => Y(oh),
  kh = (e, t) => {
    let n = { event_label: t || vs[e] || ``, value: e };
    Y(t ? ch : sh, n);
  },
  Ah = (e) => Y(ih, { event_label: e }),
  jh = (e) => Y(lh, { event_label: e }),
  Mh = (e = ``) => Y($m, { event_label: e }),
  Nh = (e = ``) => Y(eh, { event_label: e }),
  Ph = (e = ``) => Y(th, { event_label: e }),
  Fh = () => Y(uh),
  Ih = !1,
  Lh = {},
  Rh = () => {
    Ih = !1;
  },
  zh = () => {
    Lh = Yp(A(dm));
  },
  Bh = (e, t) =>
    Ih
      ? !1
      : Jp(e).length === 1 && t === K.MessageSubType.Contact
      ? ((Ih = !0), !0)
      : !1,
  Vh = (e, t) => {
    let n = e.trigger?.id || ``;
    return t.subType === K.MessageSubType.Contact &&
      e.subType === K.MessageSubType.Trigger &&
      !Lh[n]?.visitorResponded
      ? ((Lh[n].visitorResponded = !0), !0)
      : !1;
  },
  Hh = (e, t) => {
    let n = e.trigger?.id || ``;
    return t.subType === K.MessageSubType.Contact &&
      !(t.content.quickReplies || t.content.quickReply) &&
      e.subType === K.MessageSubType.Bot &&
      !Lh[n]?.visitorResponded &&
      n
      ? ((Lh[n].visitorResponded = !0), !0)
      : !1;
  },
  Uh = (e, t) => {
    let n = e.trigger?.id || ``;
    return t.subType === K.MessageSubType.Contact &&
      e.trigger?.groupType === K.GroupType.chatbot &&
      !Lh[n]?.reacted
      ? ((Lh[n].reacted = !0), !0)
      : !1;
  },
  Wh = (e) => {
    let t = e.trigger?.id || ``;
    return e.trigger?.groupType === K.GroupType.ai && !Lh[t]?.reacted
      ? ((Lh[t].reacted = !0), !0)
      : !1;
  },
  Gh = (e, t, n = !1) => {
    if (e.length > 0 && !n) {
      let t = e.slice(-2).filter((e) => e.trigger);
      return t ? t[t.length - 1].trigger?.name : ``;
    } else return t.trigger ? t.trigger.name : ``;
  },
  Kh = (e) => {
    let t = A(dm);
    Jh(t, e), Yh(t, e), Bh(t, e.subType) && Ch();
  },
  qh = (e) => {
    let t = e,
      n = A(dm).filter((e) => e.trigger);
    n && n.length > 0 && (t = n[n.length - 1].trigger?.name ?? e), Ah(t);
  },
  Jh = (e, t) => {
    let n = t.trigger?.id || ``;
    t.subType === K.MessageSubType.Bot &&
      !Lh[n]?.sent &&
      (t.trigger?.groupType === K.GroupType.chatbot &&
        (vh(Gh(e, t, !0)), (Lh[n] = { sent: !0 })),
      t.trigger?.groupType === K.GroupType.message &&
        (hh(Gh(e, t, !0)), (Lh[n] = { sent: !0 })),
      t.trigger?.groupType === K.GroupType.ai &&
        (Mh(Gh(e, t, !0)), (Lh[n] = { sent: !0 })));
    let r = e.length > 1 ? e[e.length - 2] : void 0;
    r &&
      (Hh(r, t)
        ? (r.trigger?.groupType === K.GroupType.chatbot && Sh(Gh(e, t)),
          r.trigger?.groupType === K.GroupType.message && _h(Gh(e, t)),
          r.trigger?.groupType === K.GroupType.ai && Ph(Gh(e, t)))
        : Uh(r, t)
        ? bh(Gh(e, t))
        : Wh(t) && Nh(Gh(e, t)));
  },
  Yh = (e, t) => {
    t.subType === K.MessageSubType.Trigger &&
      (fh(t?.trigger?.name), (Lh[t.trigger?.id || ``] = { sent: !0 }));
    let n = e.length > 1 ? e[e.length - 2] : void 0;
    n && Vh(n, t) && mh(Gh(e, t));
  },
  Xh = () => {
    let e = A(sm).filter((e) => e.trigger),
      t = e[e.length - 1];
    t &&
      t.trigger &&
      (t.subType === K.MessageSubType.Bot &&
      `quickReplies` in t.content &&
      t.content.quickReplies
        ? yh(t.trigger.name)
        : t.subType === K.MessageSubType.Bot
        ? gh(t.trigger.name)
        : t.subType === K.MessageSubType.Trigger && ph(t.trigger.name));
  },
  Zh = (e) => {
    e === G.AccountStatus.Offline && Oh();
  };
z.on(`messageReceived`, Kh),
  z.on(`agentJoined`, (e) => {
    Eh(e.fullname);
  }),
  z.on(`chatRated`, (e) => {
    kh(e.value, e.text);
  }),
  z.on(`chatClosed`, () => {
    Rh();
  }),
  z.on(`chatVisitorClosed`, () => {
    Rh();
  }),
  z.on(`contactAcquired`, ({ acquiredBy: e }) => {
    qh(e);
  }),
  mu.push(zh);
var Qh = {
    ArrowDown: `ArrowDown`,
    ArrowUp: `ArrowUp`,
    Enter: `Enter`,
    Escape: `Escape`,
    Tab: `Tab`,
  },
  $h = 2e3,
  eg = 2e3,
  tg = (e) =>
    e
      .filter((e) => !e.isHidden)
      .reduce((e, t) => ((e[t.name] = t.value), e), {}),
  ng = (e) => e.reduce((e, t) => ((e[t.name] = t.validators), e), {}),
  rg = (e, t, n) => {
    e.update((e) => ({ ...e, [t]: n }));
  },
  ig = (e, t) => {
    let n = {};
    for (let r in e) n[r] = t;
    return n;
  },
  ag = () => Math.random().toString(36),
  og = (e) => {
    if (!e) return !1;
    let t = e.split(`@`);
    if (t.length !== 2) return !1;
    let n = t[0],
      r = t[1];
    return n.length > 64 ||
      r.length > 255 ||
      r.split(`.`).some((e) => e.length > 63)
      ? !1
      : Uf.test(e);
  },
  sg = null,
  cg = (e) => {
    let t = e.initialValues || {},
      { validators: n, onChange: r, onSubmit: i } = e,
      a = () => ({ ...t }),
      o = ig(t, sg),
      s = O(a()),
      c = O(o),
      l = O(ig(t, !1)),
      u = O(!1),
      d = k(c, (e) => Object.values(e).every((e) => e === sg)),
      f = () => {
        Object.entries(A(s)).forEach(([e, t]) => {
          ee(e, t);
        });
      },
      p = (e) => {
        let t = e.target;
        t && _(t.name || t.id, t.value);
      },
      m = async (e) => {
        if (
          (e && e.preventDefault && e.preventDefault(), u.set(!0), f(), !A(d))
        ) {
          u.set(!1);
          return;
        }
        c.set(o), await i(A(s)), u.set(!1);
      },
      h = (e, { shouldValidate: t = !1 } = {}) => {
        s.update((t) => ({ ...t, ...e })), t && f();
      },
      g = (e, t) => {
        _(e, t);
      },
      _ = (e, t) => {
        v(e, t), ee(e, t), r && r(e, t);
      },
      v = (e, t) => {
        rg(s, e, t);
      },
      y = (e, t) => {
        rg(l, e, t);
      },
      ee = (e, t) => {
        y(e, t);
        let r = n[e];
        if (r)
          for (let n of r) {
            let { type: r, isValid: i } = n(t);
            if ((rg(c, e, i ? sg : r), !i)) return;
          }
      };
    return {
      form: s,
      errors: c,
      isValid: d,
      isSubmitting: u,
      handleChange: p,
      handleSubmit: m,
      setFieldValue: g,
      setValues: h,
    };
  },
  lg = (function (e) {
    return (
      (e.Text = `text`), (e.Checkbox = `checkbox`), (e.Select = `select`), e
    );
  })({}),
  ug = () => (e) => {
    let t = !0;
    return (
      e ?? (t = !1),
      od(e) && (t = e.trim().length > 0),
      { type: `required`, isValid: t }
    );
  },
  dg = () => (e) => ({
    type: `checked`,
    isValid: od(e) ? e === `true` : e === !0,
  }),
  fg = () => (e) => ({ type: `email`, isValid: og(String(e)) }),
  pg = () => (e) => ({
    type: `phone`,
    isValid: /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-s./0-9]*$/.test(String(e)),
  }),
  mg = O(void 0),
  hg = (e) => {
    let { emailControl: t } = V.getOptions(),
      n = !!e?.email;
    return t && !n;
  },
  gg = (e) => {
    let { nameControl: t } = V.getOptions(),
      n = !!e?.name;
    return t && !n;
  },
  _g = (e) => {
    let { numberControl: t } = V.getOptions(),
      n = !!e?.phone;
    return !!t && !n;
  },
  vg = () => {
    let { groupSelectEnabled: e } = V.getOptions(),
      t = A(el);
    return !!e && t.length > 0;
  },
  yg = () => {
    let { privacyNoticeEnabled: e, privacyNoticeCheckRequired: t } =
        V.getOptions(),
      n = Fg();
    return !!e && t && !n;
  },
  bg = (e) => {
    let { privacyNoticeEnabled: t } = V.getOptions(),
      n = !!e?.variables?.personalDataProcessingConsent;
    return !!t && !n;
  },
  xg = () => ({
    type: lg.Text,
    subType: `email`,
    name: `email`,
    label: `authForm.label.email`,
    placeholder: `authForm.yourEmail`,
    value: ``,
    validators: [ug(), fg()],
    maxLength: 255,
  }),
  Sg = () => ({
    type: lg.Text,
    subType: `text`,
    name: `name`,
    label: `authForm.label.name`,
    placeholder: `authForm.yourName`,
    value: ``,
    validators: [ug()],
    maxLength: 255,
  }),
  Cg = () => ({
    type: lg.Text,
    subType: `tel`,
    name: `phone`,
    label: `authForm.label.phone`,
    placeholder: `authForm.yourPhone`,
    value: ``,
    validators: [ug(), pg()],
    maxLength: 32,
  }),
  wg = (e) => {
    let t = A(el);
    return {
      type: lg.Select,
      name: `group`,
      label: `authForm.label.group`,
      placeholder: `authForm.group`,
      value: e?.group ?? ``,
      validators: [ug()],
      options: t.map((e) => ({ text: e.name, value: e.key })),
    };
  },
  Tg = () => ({
    type: lg.Checkbox,
    name: `personalDataProcessingConsent`,
    label: `authForm.acceptTerms`,
    value: !1,
    validators: [dg()],
  }),
  Eg = () => ({
    type: lg.Checkbox,
    name: `personalDataProcessingConsent`,
    label: `topBar.gdprTitle`,
    value: !1,
    validators: [],
    isHidden: !0,
  }),
  Dg = (e) => ({
    showEmail: hg(e),
    showName: gg(e),
    showPhone: _g(e),
    showGroups: vg(),
    showConsent: yg(),
  }),
  Og = (e) => ({
    showEmail: !!e.emailControl,
    showName: !!e.nameControl,
    showPhone: !!e.numberControl,
    showGroups: !!e.groupSelectEnabled,
    showConsent: !!e.privacyNoticeEnabled && e.privacyNoticeCheckRequired,
  }),
  kg = (e) => Object.values(Dg(e)).some((e) => e),
  Ag = (e, t) => {
    let n = [],
      {
        showEmail: r,
        showName: i,
        showPhone: a,
        showGroups: o,
        showConsent: s,
      } = t ? Og(t) : Dg(e);
    return (
      i && n.push(Sg()),
      r && n.push(xg()),
      a && n.push(Cg()),
      o && n.push(wg(e)),
      s
        ? n.push(Tg())
        : n.length > 0 && (t ? t?.privacyNoticeEnabled : bg(e)) && n.push(Eg()),
      n
    );
  },
  jg = () => {
    let e = zo(U.AuthForm);
    if (!e) return null;
    try {
      return JSON.parse(e);
    } catch {
      return null;
    }
  },
  Mg = (e, t) => {
    let n = jg(),
      r = { [e]: t },
      i = n ? { ...n, ...r } : r;
    Bo({ name: U.AuthForm, value: JSON.stringify(i) });
  },
  Ng = () => {
    Lo(U.AuthForm);
  },
  Pg = () => !!A(td)?.variables?.authenticated,
  Fg = () => A(td)?.gdprApproved || !1,
  Ig = () => {
    let { isPreviewMode: e } = V.getOptions();
    if (e || Pg() || !kg(A(td))) return !1;
    if (A(Ld)) return !0;
    if (A(Id)) return !1;
    let t = A(vu);
    if (t) return t === G.AuthFormMode.Enabled;
    let { requireLogin: n } = V.getOptions(),
      r = A(Sd) === G.AccountStatus.Offline,
      i = A(fd).length > 0;
    return !!n || r || (!r && !i);
  },
  Lg = async (e) => {
    let { privacyNoticeCheckRequired: t } = V.getOptions(),
      n = A(td),
      r = n?.name ?? e.name,
      i = n?.email ?? e.email,
      a = n?.phone ?? e.phone,
      o = e.group ?? n?.group,
      s = e.personalDataProcessingConsent,
      c = {
        ...(r && { name: r }),
        ...(i && { email: i }),
        ...(a && { phone: a }),
        ...(o && { group: o }),
        ...(s && t && { personalDataProcessingConsent: s }),
      };
    await q.getClient().authenticate(c), Dh(), await L_(), Ic();
  },
  Rg = `https://cdn.jsdelivr.net/npm/@emoji-mart/data`,
  zg = RegExp(`:([a-zA-Z0-9_-]+):`, `g`),
  Bg = null,
  Vg = null,
  Hg = null,
  Ug = O([]),
  Wg = async () =>
    Bg ||
    Hg ||
    ((Hg = fetch(Rg)
      .then((e) => e.json())
      .then((e) => ((Bg = e), e))
      .catch((e) => {
        throw (vo(`Failed to load emoji data`, e), (Hg = null), e);
      })),
    Hg),
  Gg = (e) =>
    Object.values(e.emojis).map((e) => ({
      id: e.id,
      name: e.name,
      native: e.skins[0]?.native ?? ``,
      keywords: e.keywords ?? [],
    })),
  Kg = {
    subscribe: Ug.subscribe,
    async loadRawData() {
      return Wg();
    },
    async loadData() {
      return Vg || ((Vg = Gg(await Wg())), Ug.set(Vg), Vg);
    },
    getById(e) {
      let t = e.toLowerCase();
      return Vg?.find((e) => e.id.toLowerCase() === t);
    },
    isLoaded() {
      return Vg !== null;
    },
  },
  qg = (e) =>
    Kg.isLoaded()
      ? e.replace(zg, (e, t) => {
          let n = Kg.getById(t);
          return n ? n.native : e;
        })
      : e,
  Jg = 20,
  Yg = {
    ":)": `🙂`,
    ":-)": `🙂`,
    ":D": `😀`,
    ":-D": `😀`,
    ";)": `😉`,
    ";-)": `😉`,
    "<3": `❤️`,
    ":(": `😞`,
    ":-(": `😞`,
    ":P": `😛`,
    ":-P": `😛`,
    ":-o": `😮`,
    ":O": `😮`,
    ":/": `😕`,
    ":-/": `😕`,
  },
  Xg = (e) => {
    let t = `(${e ? `$|` : ``} )`;
    return new RegExp(
      Object.keys(Yg)
        .map((e) => `${e.replace(/[.*+?^${}()|[\]\\]/g, `\\$&`)}${t}`)
        .join(`|`),
      `gi`
    );
  },
  Zg = (e, t = !1) => {
    let n = Xg(t);
    return e.replace(n, (e) => {
      let t = Object.keys(Yg).find((t) => e.toUpperCase().includes(t));
      if (!t) return e;
      let n = e.endsWith(` `) ? ` ` : ``;
      return `${Yg[t]}${n}`;
    });
  },
  Qg = (e, t, n = Jg) => {
    if (!e || e.length < 2) return [];
    let r = e.toLowerCase(),
      i = [],
      a = [],
      o = [],
      s = [];
    for (let e of t) {
      let t = e.id.toLowerCase(),
        n = e.name.toLowerCase();
      if (t.startsWith(r)) {
        i.push(e);
        continue;
      }
      if (t.includes(r)) {
        a.push(e);
        continue;
      }
      if (n.includes(r)) {
        o.push(e);
        continue;
      }
      e.keywords.some((e) => e.toLowerCase().includes(r)) && s.push(e);
    }
    return [...i, ...a, ...o, ...s].slice(0, n);
  },
  $g = (e, t) => {
    let n = e.slice(0, t),
      r = n.lastIndexOf(`:`);
    if (r === -1) return null;
    let i = n.slice(r + 1);
    return RegExp(`^[a-zA-Z0-9_-]*$`).test(i) && i.length >= 2 ? i : null;
  },
  e_ = (e, t, n) => {
    let r = e.slice(0, t),
      i = e.slice(t),
      a = r.lastIndexOf(`:`);
    if (a === -1) return { newText: e, newCursorPosition: t };
    let o = e.slice(0, a),
      s = i.length === 0 ? n + ` ` : n;
    return { newText: o + s + i, newCursorPosition: a + s.length };
  },
  t_ = (e, t = 300) => {
    let n;
    return (...r) => {
      clearTimeout(n), (n = setTimeout(() => e(...r), t));
    };
  },
  n_ = 3e3,
  r_ = [`smartsupp.dev`, `smartsuppchat.loc`],
  i_ = (function (e) {
    return (e.Default = `blackberry2.mp3`), e;
  })({}),
  a_ = (function (e) {
    return (
      (e.Connecting = `connecting`),
      (e.Connected = `connected`),
      (e.Disconnected = `disconnected`),
      e
    );
  })({}),
  o_ = (function (e) {
    return (e.Image = `image`), (e.Video = `video`), e;
  })({}),
  s_ = O(!1),
  c_ = O(!1),
  l_ = O(!1);
B().addEventListener(`offline`, () => s_.set(!0)),
  B().addEventListener(`online`, () => s_.set(!1));
var u_ = k(
    [kl, s_, l_],
    ([e, t, n]) =>
      n ? a_.Connected : !e || t ? a_.Disconnected : a_.Connected,
    a_.Connecting
  ),
  d_,
  f_ = t_((e) => {
    e && !d_ && (d_ = _s(A(W)(`error.noInternet`), 0)),
      !e && d_ && (d_(), (d_ = void 0));
  }, n_);
u_.subscribe((e) => {
  e === a_.Disconnected && (c_.set(!0), f_(!0)),
    e === a_.Connected && (c_.set(!1), f_(!1));
});
var p_ = (e, t, n) => e === a_.Disconnected || !t || n,
  m_ = () => p_(A(u_), A(hm), A(yd).disableAttachments),
  h_ = O(!1),
  g_ = (e) => {
    if (A(h_)) {
      H(`There is already file upload in progress`);
      return;
    }
    if (e.length === 0) return;
    let t = __(e);
    t.length > 0 && pu.add(t);
  },
  __ = (e) =>
    e.length > 5
      ? (gs(`${A(W)(`fileUpload.tooManyFiles`)} 5`), [])
      : e.filter((e) => v_(e)),
  v_ = (e) => {
    let {
      acceptedFileExtensions: t,
      acceptedFileTypes: n,
      maxFileSize: r,
    } = A(Rl);
    if (!e) return !1;
    let i = t.includes(qd(e.name)),
      a = n.some((t) => t === e.type);
    if (m_()) return H(`File upload is disabled`), !1;
    if (!A(hm)) return gs(A(W)(`warningBar.uploadFileNotFirst`)), !1;
    if (e.size > r) {
      let e = Jd(r);
      return gs(`${A(W)(`fileUpload.fileTooBig`)} ${e.size} ${e.unit}`), !1;
    }
    return i || a ? !0 : (gs(A(W)(`fileUpload.badFileType`)), !1);
  },
  y_ = () =>
    pu.count() === 0
      ? []
      : (pu.setUploadingStatus(), Zd(A(pu), (e) => pu.setFileUploaded(e.name))),
  b_ = 10,
  x_ = 1e4,
  S_ = 3e4,
  C_ = 20,
  w_ = (e) => {
    if (e.length > 0 && e.length % b_ === 0) {
      let t = e.slice(-b_),
        n = new Date(e[e.length - 1].createdAt).getTime();
      if (
        new Date().getTime() - n > S_ ||
        !t.every((e) => e.subType === K.MessageSubType.Contact)
      )
        return !1;
      if (n - new Date(t[0].createdAt).getTime() < x_) return !0;
    }
    return !1;
  },
  T_ = (e) => {
    let t = tp(e);
    return t ? t.length > C_ : !1;
  },
  E_ = O(),
  D_ = O(!1),
  O_ = O(),
  k_ = 200,
  A_ = O(!1),
  j_ = k([E_], ([e]) => (e === void 0 ? zo(U.Message) ?? `` : e)),
  M_ = k([j_], ([e]) => e.trim().length === 0),
  N_ = (e) => {
    E_.set(qg(Zg(e)));
  },
  P_ = (e, t) => {
    let n = A(j_) ?? ``,
      r = `${n.slice(0, t)}${e}${n.slice(t)}`;
    E_.set(r);
  },
  F_ = () => {
    A(D_) || (q.getClient().chatTyping(!0), D_.set(!0));
  },
  I_ = () => {
    A(D_) && (q.getClient().chatTyping(!1), D_.set(!1));
  },
  L_ = async (e = []) => {
    if (A(M_) && e.length === 0) return;
    let t = qg(Zg(A(j_), !0)).trim();
    await J.sendMessage(t, e), N_(``), I_(), A_.set(!0), Bd();
  },
  R_ = t_(async () => {
    let e = pu.count() > 0;
    if (A(M_) && !e) return;
    if ((!A(X) && Ig() && gv(), z_() && !e)) {
      _s(A(W)(`warningBar.sameMessageTwice`));
      return;
    }
    if (w_(A(dm))) {
      _s(A(W)(`warningBar.spamProtection`));
      return;
    }
    if (A(h_)) {
      jo(A(W)(`chat.fileUpload.error.stillUploading`));
      return;
    }
    if (A(pp)) {
      _s(A(W)(`card.sendingInProgress`));
      return;
    }
    if (T_(A(j_))) {
      _s(A(W)(`card.linksLimitReached`));
      return;
    }
    if (Ig()) {
      Fc(Lc.AuthForm);
      return;
    }
    let t = [];
    e && (h_.set(!0), (t = await y_()), pu.clear(), h_.set(!1)), await L_(t);
  }, k_),
  z_ = () => {
    let e = A(vm),
      t = A(ym),
      n = A(j_).trim();
    return (e && n === e.content.text) || (t && n === t);
  },
  B_ = (e) => {
    let t = () => {
      Vd();
    };
    so(
      () => (
        e.addEventListener(`visibilitychange`, t),
        () => e.removeEventListener(`visibilitychange`, t)
      )
    );
  },
  V_ = (e) => {
    let t = () => {
      A(X) && _v(!0);
    };
    so(
      () => (
        e.addEventListener(`popstate`, t),
        () => e.removeEventListener(`popstate`, t)
      )
    );
  },
  H_ = () => {
    let e = B()._smartsupp || {};
    (e.appVersion = `0.0.1`),
      (e.commitHash = `a8df79ea7167743097e853e1113e6b55f860f7be`),
      (e.commitInfo = `a8df79ea7167743097e853e1113e6b55f860f7be - Merge pull request #473 from smartsupp/develop - 2026-09-24 11:23:38 +0200`),
      (B()._smartsupp = e);
  },
  U_ = (e = i_.Default) => {
    let { widgetV3Url: t } = V.getOptions(),
      n = new Audio(`${t}/assets/sounds/${e}`);
    return (n.crossOrigin = `anonymous`), n.load(), n;
  },
  W_ = (e) =>
    e.subType !== K.MessageSubType.Contact &&
    ![
      K.MessageContentType.RateForm,
      K.MessageContentType.AgentJoin,
      K.MessageContentType.AgentLeave,
      K.MessageContentType.AgentAssign,
      K.MessageContentType.AgentUnassign,
      K.MessageContentType.BotAssign,
      K.MessageContentType.BotUnassign,
    ].includes(e.content.type),
  G_ = (e) => {
    q.isInitialized() && q.getClient().notify(e);
  },
  K_ = () => {
    V.getOptions().isPreviewMode ||
      G_(G.WebsocketVisitorClient.EventName.WidgetOpen);
  },
  q_ = () => G_(G.WebsocketVisitorClient.EventName.WidgetShow),
  J_ = () => document.visibilityState === `visible`,
  Y_ = () => {
    if (A(ss)) {
      Q_.set(!0);
      let e = B();
      e.history.pushState(null, ``, e.location.href);
    }
  },
  X_ = O(!1),
  Z_ = O(!1),
  Q_ = O(!1),
  $_ = (e) => !!r_.find((t) => e.includes(t)),
  ev = O(!0);
V.awaitOptions().then((e) => {
  let t = zo(U.SoundsEnabled);
  t
    ? ev.set(t === `true`)
    : typeof e.enableSounds == `boolean` && ev.set(e.enableSounds),
    Z_.set($_(e.bootstrapUrl));
});
var tv = (e) => {
    ev.set(e), Bo({ name: U.SoundsEnabled, value: e.toString() }), e && Gp();
  },
  nv = O(J_()),
  rv = t_(() => nv.set(J_()), 500);
B().addEventListener(`visibilitychange`, () => {
  rv();
});
var iv = O(0),
  av = () => iv.update((e) => e + 1),
  ov = O(!0),
  sv = (e, t) => (
    vo(`widget visible: ${String(t)} => reason: ${e}`),
    t && t !== A(dv) && q_(),
    t
  ),
  cv = O(),
  lv = () => cv.set(!0),
  uv = () => cv.set(!1),
  dv = k(
    [
      td,
      ss,
      cv,
      Cd,
      kd,
      k([Sd, dm, M_, kd], ([e, t, n, r]) => {
        let { hideOfflineChat: i, isPreviewMode: a } = V.getOptions();
        return (
          e === G.AccountStatus.Offline &&
          !!i &&
          qp(t).length === 0 &&
          n &&
          !r &&
          !a
        );
      }),
    ],
    ([e, t, n, r, i, a]) => {
      let { hideMobileWidget: o, hideWidget: s } = V.getOptions();
      return e?.bannedAt
        ? sv(`visitor is banned`, !1)
        : t && o
        ? sv(`option 'hideMobileWidget' is true`, !1)
        : typeof n == `boolean`
        ? sv(`set by API command`, n)
        : r && !i
        ? sv(`chat status is not pending`, !0)
        : a
        ? sv(`option 'hideOfflineChat' is true`, !1)
        : sv(`option 'hideWidget' is ${String(s)}`, !s);
    }
  ),
  fv = k([ss], ([e]) => {
    let { openOnTrigger: t } = V.getOptions();
    return t && !e;
  }),
  pv = [],
  mv = (e) => (
    pv.push(e),
    () => {
      let t = pv.indexOf(e);
      t !== -1 && pv.splice(t, 1);
    }
  ),
  hv = () => (pv.length === 0 ? !1 : (pv.pop()(), !0)),
  X = rs(U.IsMessengerFrameOpened, !1, (e) => !A(ss) && e === `true`),
  gv = (e = !1) => {
    let { widgetBlockingOptions: t } = V.getOptions();
    (t?.disableOpenMessenger && !e) ||
      (Fh(), Y_(), X.set(!0), Pv(), Xh(), K_());
  },
  _v = (e) => {
    if (A(ss) && A(Q_) && !e) return Q_.set(!1), B().history.back();
    z.emit(`messengerClose`, !0), X.set(!1);
  },
  vv = (e) => {
    if (!e) return;
    let { widgetBlockingOptions: t } = V.getOptions(),
      n = (e) => {
        if (e.key === Qh.Escape) {
          if (hv() || t?.disableCloseButton) return;
          _v();
        }
      },
      r = e.ownerDocument;
    return (
      r.addEventListener(`keydown`, n, !0),
      {
        destroy() {
          r.removeEventListener(`keydown`, n, !0);
        },
      }
    );
  },
  yv = k([X_, dv, X], ([e, t, n]) => e && t && n);
function bv() {
  let e = O(!1),
    { subscribe: t } = e,
    n = null;
  return {
    subscribe: t,
    handleDragOver: (t, r = !0) => {
      r && t.preventDefault(),
        A(e) || e.set(!0),
        n && clearTimeout(n),
        (n = window.setTimeout(() => {
          e.set(!1);
        }, 200));
    },
    handleDrop: (t) => {
      t.preventDefault(), n && clearTimeout(n), e.set(!1);
      let r = t.dataTransfer?.files ? [...t.dataTransfer.files] : [];
      return (
        r.length === 0 && _s(`Dropped item(s) are not processable files`),
        { droppedFiles: r }
      );
    },
  };
}
var xv = bv(),
  Sv = k([X_, dv, X], ([e, t, n]) => e && t && !n),
  Cv = `smartsupp-mobile-messenger-active`,
  wv = `smartsupp-scroll-lock-style`,
  Tv = `smartsuppScrollLock`,
  Ev = `
html.${Cv},
html.${Cv} > body {
	position: static !important;
	overflow: hidden !important;
	min-height: 0 !important;
	max-height: none !important;
	transform: none !important;
	translate: none !important;
	rotate: none !important;
	scale: none !important;
	perspective: none !important;
	filter: none !important;
	backdrop-filter: none !important;
	-webkit-backdrop-filter: none !important;
	will-change: auto !important;
	contain: none !important;
	content-visibility: visible !important;
}
html.${Cv} > body {
	height: 0 !important;
	margin: 0 !important;
	padding: 0 !important;
	border: 0 !important;
}`,
  Dv = (e) => {
    if (e.getElementById(wv)) return;
    let t = e.createElement(`style`);
    (t.id = wv), (t.textContent = Ev), e.head.appendChild(t);
  },
  Ov = () => {
    let e = po(),
      t = e.documentElement;
    t.dataset[Tv] === void 0 &&
      ((t.dataset[Tv] = String(B().scrollY)), Dv(e), t.classList.add(Cv));
  },
  kv = () => {
    let e = po().documentElement,
      t = e.dataset[Tv];
    t !== void 0 &&
      (e.classList.remove(Cv),
      delete e.dataset[Tv],
      B().scrollTo({ top: Number(t), left: 0, behavior: `instant` }));
  },
  Av = O(!1),
  jv = O(!1),
  Mv = () => {
    Av.set(!0), jv.set(!1);
  },
  Nv = () => {
    jv.set(!0), Av.set(!1);
  },
  Pv = (e = !1) => {
    jv.set(!1),
      e && Bo({ name: U.PopupClosedAt, value: new Date().toISOString() });
  },
  Fv = k([ss], ([e]) => {
    let { mobilePopupsEnabled: t } = V.getOptions();
    return e ? !!t : !0;
  }),
  Iv = k([om], ([e]) => {
    let t = zo(U.PopupClosedAt) ?? null;
    return !t || !e
      ? !0
      : new Date(e.createdAt).getTime() > new Date(t).getTime();
  }),
  Lv = k([X_, dv, Av, X, Fv], ([e, t, n, r, i]) => e && t && n && !r && i),
  Rv = k(
    [X_, dv, jv, X, om, Iv, Fv, mp],
    ([e, t, n, r, i, a, o, s]) => e && t && n && i && a && !r && o && !s
  ),
  zv = {
    white: `#ffffff`,
    slate100: `#f1f5f9`,
    slate200: `#e2e8f0`,
    slate300: `#cbd5e1`,
    slate900: `#0f172a`,
    blue700: `#1d4ed8`,
    smartsuppBlue: `#1233df`,
  };
function Z(e, t) {
  Vv(e) && (e = `100%`);
  let n = Hv(e);
  return (
    (e = t === 360 ? e : Math.min(t, Math.max(0, parseFloat(e)))),
    n && (e = parseInt(String(e * t), 10) / 100),
    Math.abs(e - t) < 1e-6
      ? 1
      : ((e =
          t === 360
            ? (e < 0 ? (e % t) + t : e % t) / parseFloat(String(t))
            : (e % t) / parseFloat(String(t))),
        e)
  );
}
function Bv(e) {
  return Math.min(1, Math.max(0, e));
}
function Vv(e) {
  return typeof e == `string` && e.indexOf(`.`) !== -1 && parseFloat(e) === 1;
}
function Hv(e) {
  return typeof e == `string` && e.indexOf(`%`) !== -1;
}
function Uv(e) {
  return (e = parseFloat(e)), (isNaN(e) || e < 0 || e > 1) && (e = 1), e;
}
function Wv(e) {
  return Number(e) <= 1 ? `${Number(e) * 100}%` : e;
}
function Gv(e) {
  return e.length === 1 ? `0` + e : String(e);
}
function Kv(e, t, n) {
  return { r: Z(e, 255) * 255, g: Z(t, 255) * 255, b: Z(n, 255) * 255 };
}
function qv(e, t, n) {
  (e = Z(e, 255)), (t = Z(t, 255)), (n = Z(n, 255));
  let r = Math.max(e, t, n),
    i = Math.min(e, t, n),
    a = 0,
    o = 0,
    s = (r + i) / 2;
  if (r === i) (o = 0), (a = 0);
  else {
    let c = r - i;
    switch (((o = s > 0.5 ? c / (2 - r - i) : c / (r + i)), r)) {
      case e:
        a = (t - n) / c + (t < n ? 6 : 0);
        break;
      case t:
        a = (n - e) / c + 2;
        break;
      case n:
        a = (e - t) / c + 4;
        break;
      default:
        break;
    }
    a /= 6;
  }
  return { h: a, s: o, l: s };
}
function Jv(e, t, n) {
  return (
    n < 0 && (n += 1),
    n > 1 && --n,
    n < 1 / 6
      ? e + (t - e) * (6 * n)
      : n < 1 / 2
      ? t
      : n < 2 / 3
      ? e + (t - e) * (2 / 3 - n) * 6
      : e
  );
}
function Yv(e, t, n) {
  let r, i, a;
  if (((e = Z(e, 360)), (t = Z(t, 100)), (n = Z(n, 100)), t === 0))
    (i = n), (a = n), (r = n);
  else {
    let o = n < 0.5 ? n * (1 + t) : n + t - n * t,
      s = 2 * n - o;
    (r = Jv(s, o, e + 1 / 3)), (i = Jv(s, o, e)), (a = Jv(s, o, e - 1 / 3));
  }
  return { r: r * 255, g: i * 255, b: a * 255 };
}
function Xv(e, t, n) {
  (e = Z(e, 255)), (t = Z(t, 255)), (n = Z(n, 255));
  let r = Math.max(e, t, n),
    i = Math.min(e, t, n),
    a = 0,
    o = r,
    s = r - i,
    c = r === 0 ? 0 : s / r;
  if (r === i) a = 0;
  else {
    switch (r) {
      case e:
        a = (t - n) / s + (t < n ? 6 : 0);
        break;
      case t:
        a = (n - e) / s + 2;
        break;
      case n:
        a = (e - t) / s + 4;
        break;
      default:
        break;
    }
    a /= 6;
  }
  return { h: a, s: c, v: o };
}
function Zv(e, t, n) {
  (e = Z(e, 360) * 6), (t = Z(t, 100)), (n = Z(n, 100));
  let r = Math.floor(e),
    i = e - r,
    a = n * (1 - t),
    o = n * (1 - i * t),
    s = n * (1 - (1 - i) * t),
    c = r % 6,
    l = [n, o, a, a, s, n][c],
    u = [s, n, n, o, a, a][c],
    d = [a, a, s, n, n, o][c];
  return { r: l * 255, g: u * 255, b: d * 255 };
}
function Qv(e, t, n, r) {
  let i = [
    Gv(Math.round(e).toString(16)),
    Gv(Math.round(t).toString(16)),
    Gv(Math.round(n).toString(16)),
  ];
  return r &&
    i[0].startsWith(i[0].charAt(1)) &&
    i[1].startsWith(i[1].charAt(1)) &&
    i[2].startsWith(i[2].charAt(1))
    ? i[0].charAt(0) + i[1].charAt(0) + i[2].charAt(0)
    : i.join(``);
}
function $v(e, t, n, r, i) {
  let a = [
    Gv(Math.round(e).toString(16)),
    Gv(Math.round(t).toString(16)),
    Gv(Math.round(n).toString(16)),
    Gv(ny(r)),
  ];
  return i &&
    a[0].startsWith(a[0].charAt(1)) &&
    a[1].startsWith(a[1].charAt(1)) &&
    a[2].startsWith(a[2].charAt(1)) &&
    a[3].startsWith(a[3].charAt(1))
    ? a[0].charAt(0) + a[1].charAt(0) + a[2].charAt(0) + a[3].charAt(0)
    : a.join(``);
}
function ey(e, t, n, r) {
  let i = e / 100,
    a = t / 100,
    o = n / 100,
    s = r / 100;
  return {
    r: 255 * (1 - i) * (1 - s),
    g: 255 * (1 - a) * (1 - s),
    b: 255 * (1 - o) * (1 - s),
  };
}
function ty(e, t, n) {
  let r = 1 - e / 255,
    i = 1 - t / 255,
    a = 1 - n / 255,
    o = Math.min(r, i, a);
  return (
    o === 1
      ? ((r = 0), (i = 0), (a = 0))
      : ((r = ((r - o) / (1 - o)) * 100),
        (i = ((i - o) / (1 - o)) * 100),
        (a = ((a - o) / (1 - o)) * 100)),
    (o *= 100),
    { c: Math.round(r), m: Math.round(i), y: Math.round(a), k: Math.round(o) }
  );
}
function ny(e) {
  return Math.round(parseFloat(e) * 255).toString(16);
}
function ry(e) {
  return iy(e) / 255;
}
function iy(e) {
  return parseInt(e, 16);
}
function ay(e) {
  return { r: e >> 16, g: (e & 65280) >> 8, b: e & 255 };
}
var oy = {
  aliceblue: `#f0f8ff`,
  antiquewhite: `#faebd7`,
  aqua: `#00ffff`,
  aquamarine: `#7fffd4`,
  azure: `#f0ffff`,
  beige: `#f5f5dc`,
  bisque: `#ffe4c4`,
  black: `#000000`,
  blanchedalmond: `#ffebcd`,
  blue: `#0000ff`,
  blueviolet: `#8a2be2`,
  brown: `#a52a2a`,
  burlywood: `#deb887`,
  cadetblue: `#5f9ea0`,
  chartreuse: `#7fff00`,
  chocolate: `#d2691e`,
  coral: `#ff7f50`,
  cornflowerblue: `#6495ed`,
  cornsilk: `#fff8dc`,
  crimson: `#dc143c`,
  cyan: `#00ffff`,
  darkblue: `#00008b`,
  darkcyan: `#008b8b`,
  darkgoldenrod: `#b8860b`,
  darkgray: `#a9a9a9`,
  darkgreen: `#006400`,
  darkgrey: `#a9a9a9`,
  darkkhaki: `#bdb76b`,
  darkmagenta: `#8b008b`,
  darkolivegreen: `#556b2f`,
  darkorange: `#ff8c00`,
  darkorchid: `#9932cc`,
  darkred: `#8b0000`,
  darksalmon: `#e9967a`,
  darkseagreen: `#8fbc8f`,
  darkslateblue: `#483d8b`,
  darkslategray: `#2f4f4f`,
  darkslategrey: `#2f4f4f`,
  darkturquoise: `#00ced1`,
  darkviolet: `#9400d3`,
  deeppink: `#ff1493`,
  deepskyblue: `#00bfff`,
  dimgray: `#696969`,
  dimgrey: `#696969`,
  dodgerblue: `#1e90ff`,
  firebrick: `#b22222`,
  floralwhite: `#fffaf0`,
  forestgreen: `#228b22`,
  fuchsia: `#ff00ff`,
  gainsboro: `#dcdcdc`,
  ghostwhite: `#f8f8ff`,
  goldenrod: `#daa520`,
  gold: `#ffd700`,
  gray: `#808080`,
  green: `#008000`,
  greenyellow: `#adff2f`,
  grey: `#808080`,
  honeydew: `#f0fff0`,
  hotpink: `#ff69b4`,
  indianred: `#cd5c5c`,
  indigo: `#4b0082`,
  ivory: `#fffff0`,
  khaki: `#f0e68c`,
  lavenderblush: `#fff0f5`,
  lavender: `#e6e6fa`,
  lawngreen: `#7cfc00`,
  lemonchiffon: `#fffacd`,
  lightblue: `#add8e6`,
  lightcoral: `#f08080`,
  lightcyan: `#e0ffff`,
  lightgoldenrodyellow: `#fafad2`,
  lightgray: `#d3d3d3`,
  lightgreen: `#90ee90`,
  lightgrey: `#d3d3d3`,
  lightpink: `#ffb6c1`,
  lightsalmon: `#ffa07a`,
  lightseagreen: `#20b2aa`,
  lightskyblue: `#87cefa`,
  lightslategray: `#778899`,
  lightslategrey: `#778899`,
  lightsteelblue: `#b0c4de`,
  lightyellow: `#ffffe0`,
  lime: `#00ff00`,
  limegreen: `#32cd32`,
  linen: `#faf0e6`,
  magenta: `#ff00ff`,
  maroon: `#800000`,
  mediumaquamarine: `#66cdaa`,
  mediumblue: `#0000cd`,
  mediumorchid: `#ba55d3`,
  mediumpurple: `#9370db`,
  mediumseagreen: `#3cb371`,
  mediumslateblue: `#7b68ee`,
  mediumspringgreen: `#00fa9a`,
  mediumturquoise: `#48d1cc`,
  mediumvioletred: `#c71585`,
  midnightblue: `#191970`,
  mintcream: `#f5fffa`,
  mistyrose: `#ffe4e1`,
  moccasin: `#ffe4b5`,
  navajowhite: `#ffdead`,
  navy: `#000080`,
  oldlace: `#fdf5e6`,
  olive: `#808000`,
  olivedrab: `#6b8e23`,
  orange: `#ffa500`,
  orangered: `#ff4500`,
  orchid: `#da70d6`,
  palegoldenrod: `#eee8aa`,
  palegreen: `#98fb98`,
  paleturquoise: `#afeeee`,
  palevioletred: `#db7093`,
  papayawhip: `#ffefd5`,
  peachpuff: `#ffdab9`,
  peru: `#cd853f`,
  pink: `#ffc0cb`,
  plum: `#dda0dd`,
  powderblue: `#b0e0e6`,
  purple: `#800080`,
  rebeccapurple: `#663399`,
  red: `#ff0000`,
  rosybrown: `#bc8f8f`,
  royalblue: `#4169e1`,
  saddlebrown: `#8b4513`,
  salmon: `#fa8072`,
  sandybrown: `#f4a460`,
  seagreen: `#2e8b57`,
  seashell: `#fff5ee`,
  sienna: `#a0522d`,
  silver: `#c0c0c0`,
  skyblue: `#87ceeb`,
  slateblue: `#6a5acd`,
  slategray: `#708090`,
  slategrey: `#708090`,
  snow: `#fffafa`,
  springgreen: `#00ff7f`,
  steelblue: `#4682b4`,
  tan: `#d2b48c`,
  teal: `#008080`,
  thistle: `#d8bfd8`,
  tomato: `#ff6347`,
  turquoise: `#40e0d0`,
  violet: `#ee82ee`,
  wheat: `#f5deb3`,
  white: `#ffffff`,
  whitesmoke: `#f5f5f5`,
  yellow: `#ffff00`,
  yellowgreen: `#9acd32`,
};
function sy(e) {
  let t = { r: 0, g: 0, b: 0 },
    n = 1,
    r = null,
    i = null,
    a = null,
    o = !1,
    s = !1;
  return (
    typeof e == `string` && (e = fy(e)),
    typeof e == `object` &&
      (py(e.r) && py(e.g) && py(e.b)
        ? ((t = Kv(e.r, e.g, e.b)),
          (o = !0),
          (s = String(e.r).substr(-1) === `%` ? `prgb` : `rgb`))
        : py(e.h) && py(e.s) && py(e.v)
        ? ((r = Wv(e.s)),
          (i = Wv(e.v)),
          (t = Zv(e.h, r, i)),
          (o = !0),
          (s = `hsv`))
        : py(e.h) && py(e.s) && py(e.l)
        ? ((r = Wv(e.s)),
          (a = Wv(e.l)),
          (t = Yv(e.h, r, a)),
          (o = !0),
          (s = `hsl`))
        : py(e.c) &&
          py(e.m) &&
          py(e.y) &&
          py(e.k) &&
          ((t = ey(e.c, e.m, e.y, e.k)), (o = !0), (s = `cmyk`)),
      Object.prototype.hasOwnProperty.call(e, `a`) && (n = e.a)),
    (n = Uv(n)),
    {
      ok: o,
      format: e.format || s,
      r: Math.min(255, Math.max(t.r, 0)),
      g: Math.min(255, Math.max(t.g, 0)),
      b: Math.min(255, Math.max(t.b, 0)),
      a: n,
    }
  );
}
var cy = `(?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?)`,
  ly =
    `[\\s|\\(]+(` +
    cy +
    `)[,|\\s]+((?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?))[,|\\s]+((?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?))\\s*\\)?`,
  uy =
    `[\\s|\\(]+(` +
    cy +
    `)[,|\\s]+((?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?))[,|\\s]+((?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?))[,|\\s]+((?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?))\\s*\\)?`,
  dy = {
    CSS_UNIT: new RegExp(cy),
    rgb: RegExp(`rgb` + ly),
    rgba: RegExp(`rgba` + uy),
    hsl: RegExp(`hsl` + ly),
    hsla: RegExp(`hsla` + uy),
    hsv: RegExp(`hsv` + ly),
    hsva: RegExp(`hsva` + uy),
    cmyk: RegExp(`cmyk` + uy),
    hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
    hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
  };
function fy(e) {
  if (((e = e.trim().toLowerCase()), e.length === 0)) return !1;
  let t = !1;
  if (oy[e]) (e = oy[e]), (t = !0);
  else if (e === `transparent`)
    return { r: 0, g: 0, b: 0, a: 0, format: `name` };
  let n = dy.rgb.exec(e);
  return n
    ? { r: n[1], g: n[2], b: n[3] }
    : ((n = dy.rgba.exec(e)),
      n
        ? { r: n[1], g: n[2], b: n[3], a: n[4] }
        : ((n = dy.hsl.exec(e)),
          n
            ? { h: n[1], s: n[2], l: n[3] }
            : ((n = dy.hsla.exec(e)),
              n
                ? { h: n[1], s: n[2], l: n[3], a: n[4] }
                : ((n = dy.hsv.exec(e)),
                  n
                    ? { h: n[1], s: n[2], v: n[3] }
                    : ((n = dy.hsva.exec(e)),
                      n
                        ? { h: n[1], s: n[2], v: n[3], a: n[4] }
                        : ((n = dy.cmyk.exec(e)),
                          n
                            ? { c: n[1], m: n[2], y: n[3], k: n[4] }
                            : ((n = dy.hex8.exec(e)),
                              n
                                ? {
                                    r: iy(n[1]),
                                    g: iy(n[2]),
                                    b: iy(n[3]),
                                    a: ry(n[4]),
                                    format: t ? `name` : `hex8`,
                                  }
                                : ((n = dy.hex6.exec(e)),
                                  n
                                    ? {
                                        r: iy(n[1]),
                                        g: iy(n[2]),
                                        b: iy(n[3]),
                                        format: t ? `name` : `hex`,
                                      }
                                    : ((n = dy.hex4.exec(e)),
                                      n
                                        ? {
                                            r: iy(n[1] + n[1]),
                                            g: iy(n[2] + n[2]),
                                            b: iy(n[3] + n[3]),
                                            a: ry(n[4] + n[4]),
                                            format: t ? `name` : `hex8`,
                                          }
                                        : ((n = dy.hex3.exec(e)),
                                          n
                                            ? {
                                                r: iy(n[1] + n[1]),
                                                g: iy(n[2] + n[2]),
                                                b: iy(n[3] + n[3]),
                                                format: t ? `name` : `hex`,
                                              }
                                            : !1))))))))));
}
function py(e) {
  return typeof e == `number` ? !Number.isNaN(e) : dy.CSS_UNIT.test(e);
}
var my = class e {
  constructor(t = ``, n = {}) {
    if (t instanceof e) return t;
    typeof t == `number` && (t = ay(t)), (this.originalInput = t);
    let r = sy(t);
    (this.originalInput = t),
      (this.r = r.r),
      (this.g = r.g),
      (this.b = r.b),
      (this.a = r.a),
      (this.roundA = Math.round(100 * this.a) / 100),
      (this.format = n.format ?? r.format),
      (this.gradientType = n.gradientType),
      this.r < 1 && (this.r = Math.round(this.r)),
      this.g < 1 && (this.g = Math.round(this.g)),
      this.b < 1 && (this.b = Math.round(this.b)),
      (this.isValid = r.ok);
  }
  isDark() {
    return this.getBrightness() < 128;
  }
  isLight() {
    return !this.isDark();
  }
  getBrightness() {
    let e = this.toRgb();
    return (e.r * 299 + e.g * 587 + e.b * 114) / 1e3;
  }
  getLuminance() {
    let e = this.toRgb(),
      t,
      n,
      r,
      i = e.r / 255,
      a = e.g / 255,
      o = e.b / 255;
    return (
      (t = i <= 0.03928 ? i / 12.92 : ((i + 0.055) / 1.055) ** 2.4),
      (n = a <= 0.03928 ? a / 12.92 : ((a + 0.055) / 1.055) ** 2.4),
      (r = o <= 0.03928 ? o / 12.92 : ((o + 0.055) / 1.055) ** 2.4),
      0.2126 * t + 0.7152 * n + 0.0722 * r
    );
  }
  getAlpha() {
    return this.a;
  }
  setAlpha(e) {
    return (
      (this.a = Uv(e)), (this.roundA = Math.round(100 * this.a) / 100), this
    );
  }
  isMonochrome() {
    let { s: e } = this.toHsl();
    return e === 0;
  }
  toHsv() {
    let e = Xv(this.r, this.g, this.b);
    return { h: e.h * 360, s: e.s, v: e.v, a: this.a };
  }
  toHsvString() {
    let e = Xv(this.r, this.g, this.b),
      t = Math.round(e.h * 360),
      n = Math.round(e.s * 100),
      r = Math.round(e.v * 100);
    return this.a === 1
      ? `hsv(${t}, ${n}%, ${r}%)`
      : `hsva(${t}, ${n}%, ${r}%, ${this.roundA})`;
  }
  toHsl() {
    let e = qv(this.r, this.g, this.b);
    return { h: e.h * 360, s: e.s, l: e.l, a: this.a };
  }
  toHslString() {
    let e = qv(this.r, this.g, this.b),
      t = Math.round(e.h * 360),
      n = Math.round(e.s * 100),
      r = Math.round(e.l * 100);
    return this.a === 1
      ? `hsl(${t}, ${n}%, ${r}%)`
      : `hsla(${t}, ${n}%, ${r}%, ${this.roundA})`;
  }
  toHex(e = !1) {
    return Qv(this.r, this.g, this.b, e);
  }
  toHexString(e = !1) {
    return `#` + this.toHex(e);
  }
  toHex8(e = !1) {
    return $v(this.r, this.g, this.b, this.a, e);
  }
  toHex8String(e = !1) {
    return `#` + this.toHex8(e);
  }
  toHexShortString(e = !1) {
    return this.a === 1 ? this.toHexString(e) : this.toHex8String(e);
  }
  toRgb() {
    return {
      r: Math.round(this.r),
      g: Math.round(this.g),
      b: Math.round(this.b),
      a: this.a,
    };
  }
  toRgbString() {
    let e = Math.round(this.r),
      t = Math.round(this.g),
      n = Math.round(this.b);
    return this.a === 1
      ? `rgb(${e}, ${t}, ${n})`
      : `rgba(${e}, ${t}, ${n}, ${this.roundA})`;
  }
  toPercentageRgb() {
    let e = (e) => `${Math.round(Z(e, 255) * 100)}%`;
    return { r: e(this.r), g: e(this.g), b: e(this.b), a: this.a };
  }
  toPercentageRgbString() {
    let e = (e) => Math.round(Z(e, 255) * 100);
    return this.a === 1
      ? `rgb(${e(this.r)}%, ${e(this.g)}%, ${e(this.b)}%)`
      : `rgba(${e(this.r)}%, ${e(this.g)}%, ${e(this.b)}%, ${this.roundA})`;
  }
  toCmyk() {
    return { ...ty(this.r, this.g, this.b) };
  }
  toCmykString() {
    let { c: e, m: t, y: n, k: r } = ty(this.r, this.g, this.b);
    return `cmyk(${e}, ${t}, ${n}, ${r})`;
  }
  toName() {
    if (this.a === 0) return `transparent`;
    if (this.a < 1) return !1;
    let e = `#` + Qv(this.r, this.g, this.b, !1);
    for (let [t, n] of Object.entries(oy)) if (e === n) return t;
    return !1;
  }
  toString(e) {
    let t = !!e;
    e ??= this.format;
    let n = !1,
      r = this.a < 1 && this.a >= 0;
    return !t && r && (e.startsWith(`hex`) || e === `name`)
      ? e === `name` && this.a === 0
        ? this.toName()
        : this.toRgbString()
      : (e === `rgb` && (n = this.toRgbString()),
        e === `prgb` && (n = this.toPercentageRgbString()),
        (e === `hex` || e === `hex6`) && (n = this.toHexString()),
        e === `hex3` && (n = this.toHexString(!0)),
        e === `hex4` && (n = this.toHex8String(!0)),
        e === `hex8` && (n = this.toHex8String()),
        e === `name` && (n = this.toName()),
        e === `hsl` && (n = this.toHslString()),
        e === `hsv` && (n = this.toHsvString()),
        e === `cmyk` && (n = this.toCmykString()),
        n || this.toHexString());
  }
  toNumber() {
    return (
      (Math.round(this.r) << 16) +
      (Math.round(this.g) << 8) +
      Math.round(this.b)
    );
  }
  clone() {
    return new e(this.toString());
  }
  lighten(t = 10) {
    let n = this.toHsl();
    return (n.l += t / 100), (n.l = Bv(n.l)), new e(n);
  }
  brighten(t = 10) {
    let n = this.toRgb();
    return (
      (n.r = Math.max(0, Math.min(255, n.r - Math.round(255 * -(t / 100))))),
      (n.g = Math.max(0, Math.min(255, n.g - Math.round(255 * -(t / 100))))),
      (n.b = Math.max(0, Math.min(255, n.b - Math.round(255 * -(t / 100))))),
      new e(n)
    );
  }
  darken(t = 10) {
    let n = this.toHsl();
    return (n.l -= t / 100), (n.l = Bv(n.l)), new e(n);
  }
  tint(e = 10) {
    return this.mix(`white`, e);
  }
  shade(e = 10) {
    return this.mix(`black`, e);
  }
  desaturate(t = 10) {
    let n = this.toHsl();
    return (n.s -= t / 100), (n.s = Bv(n.s)), new e(n);
  }
  saturate(t = 10) {
    let n = this.toHsl();
    return (n.s += t / 100), (n.s = Bv(n.s)), new e(n);
  }
  greyscale() {
    return this.desaturate(100);
  }
  spin(t) {
    let n = this.toHsl(),
      r = (n.h + t) % 360;
    return (n.h = r < 0 ? 360 + r : r), new e(n);
  }
  mix(t, n = 50) {
    let r = this.toRgb(),
      i = new e(t).toRgb(),
      a = n / 100;
    return new e({
      r: (i.r - r.r) * a + r.r,
      g: (i.g - r.g) * a + r.g,
      b: (i.b - r.b) * a + r.b,
      a: (i.a - r.a) * a + r.a,
    });
  }
  analogous(t = 6, n = 30) {
    let r = this.toHsl(),
      i = 360 / n,
      a = [this];
    for (r.h = (r.h - ((i * t) >> 1) + 720) % 360; --t; )
      (r.h = (r.h + i) % 360), a.push(new e(r));
    return a;
  }
  complement() {
    let t = this.toHsl();
    return (t.h = (t.h + 180) % 360), new e(t);
  }
  monochromatic(t = 6) {
    let n = this.toHsv(),
      { h: r } = n,
      { s: i } = n,
      { v: a } = n,
      o = [],
      s = 1 / t;
    for (; t--; ) o.push(new e({ h: r, s: i, v: a })), (a = (a + s) % 1);
    return o;
  }
  splitcomplement() {
    let t = this.toHsl(),
      { h: n } = t;
    return [
      this,
      new e({ h: (n + 72) % 360, s: t.s, l: t.l }),
      new e({ h: (n + 216) % 360, s: t.s, l: t.l }),
    ];
  }
  onBackground(t) {
    let n = this.toRgb(),
      r = new e(t).toRgb(),
      i = n.a + r.a * (1 - n.a);
    return new e({
      r: (n.r * n.a + r.r * r.a * (1 - n.a)) / i,
      g: (n.g * n.a + r.g * r.a * (1 - n.a)) / i,
      b: (n.b * n.a + r.b * r.a * (1 - n.a)) / i,
      a: i,
    });
  }
  triad() {
    return this.polyad(3);
  }
  tetrad() {
    return this.polyad(4);
  }
  polyad(t) {
    let n = this.toHsl(),
      { h: r } = n,
      i = [this],
      a = 360 / t;
    for (let o = 1; o < t; o++)
      i.push(new e({ h: (r + o * a) % 360, s: n.s, l: n.l }));
    return i;
  }
  equals(t) {
    let n = new e(t);
    return this.format === `cmyk` || n.format === `cmyk`
      ? this.toCmykString() === n.toCmykString()
      : this.toRgbString() === n.toRgbString();
  }
};
function hy(e, t) {
  let n = new my(e),
    r = new my(t);
  return (
    (Math.max(n.getLuminance(), r.getLuminance()) + 0.05) /
    (Math.min(n.getLuminance(), r.getLuminance()) + 0.05)
  );
}
var gy = 0.299,
  _y = 0.587,
  vy = 0.114,
  yy = 180,
  by = -20,
  xy = -0.25,
  Sy = 0.2,
  Cy = -5,
  wy = 0.03,
  Ty = 0.5,
  Ey = 5,
  Dy = (e, t) => new my(e).darken(t).toHexString(),
  Oy = (e) => {
    let t = new my(e).toRgb();
    return `${t.r}, ${t.g}, ${t.b}`;
  },
  ky = (e) => /^#[0-9A-F]{6}$/i.test(e),
  Ay = (e) => {
    let { r: t, g: n, b: r } = new my(e).toRgb();
    return Math.sqrt(t * t * gy + n * n * _y + r * r * vy) > yy;
  },
  jy = (e) => {
    let t = new my(e),
      { s: n, l: r } = t.toHsl();
    return t
      .spin(by)
      .desaturate(n * xy)
      .lighten(r * Sy)
      .toHexString();
  },
  My = (e, t = Ty) => {
    let n = new my(e),
      { s: r, l: i } = n.toHsl();
    return n
      .spin(Cy)
      .saturate(r * wy)
      .darken(i * t)
      .toHexString();
  },
  Ny = (e) => {
    let { color: t, color2: n, colorGradient: r } = e;
    return r
      ? n
        ? { from: t, to: n }
        : Ay(t)
        ? { from: t, to: My(t) }
        : { from: jy(t), to: t }
      : { from: t, to: t };
  },
  Py = (e) => (Ay(e) ? zv.slate900 : zv.white),
  Fy = (e) => (Ay(e) ? 0.1 : 0.2),
  Iy = (e) => {
    if (Ay(e)) {
      let t = new my(e).getLuminance();
      return t > 0.8 ? Dy(e, (10 * t) ** t) : e;
    }
    return e;
  },
  Ly = (e, t) => {
    let n = t?.backgroundColor ?? e,
      r = 0,
      i = new my(e),
      a = hy(n, i),
      o = t?.forceLightBg ?? new my(n).isLight();
    for (; a < 3.75 && r < 20; )
      (i = o ? i.darken(5) : i.lighten(5)), (a = hy(n, i)), r++;
    return i.toHexString();
  },
  Ry = (e, t) => {
    let n = Ly(e, { backgroundColor: zv.white }),
      r = Ly(e),
      i = new my(e).isLight(),
      a = new my(t).isLight();
    return (
      i && a
        ? (r = Ly(t))
        : !i && !a
        ? (r = Ly(e))
        : i && !a
        ? (r = Ly(t, { forceLightBg: !0 }))
        : !i && a && (r = Ly(e, { forceLightBg: !1 })),
      { primary: n, secondary: r }
    );
  },
  Q = (e, t, n) => {
    e.documentElement.style.setProperty(t, n);
  },
  zy = (e, t) => {
    let { color: n } = t,
      r = Ny(t),
      i =
        r.from === `#ffffff` && r.from === r.to
          ? { from: zv.slate300, to: zv.slate300 }
          : r,
      a = Py(n);
    Q(e, `--color-primary`, n),
      Q(e, `--color-primary-content`, a),
      Q(e, `--color-primary-content-rgb`, Oy(a)),
      Q(e, `--color-primary-gradient-from`, r.from),
      Q(e, `--color-primary-gradient-to`, r.to),
      Q(e, `--color-primary-gradient-button-from`, i.from),
      Q(e, `--color-primary-gradient-button-to`, i.to),
      Q(e, `--color-primary-gradient-hover-from`, Dy(r.from, Ey)),
      Q(e, `--color-primary-gradient-hover-to`, Dy(r.to, Ey));
    let o = Iy(n);
    Q(e, `--color-primary-button`, o),
      Q(e, `--color-primary-button-hover`, Dy(o, 10)),
      Q(e, `--color-primary-button-content`, a),
      Q(e, `--opacity-primary-content`, String(Fy(n)));
    let s = Ry(r.from, r.to);
    Q(e, `--color-primary-focus`, s.primary),
      Q(e, `--color-secondary-focus`, s.secondary);
  },
  By = (() => {
    let { subscribe: e, set: t } = O({
      color: zv.smartsuppBlue,
      color2: null,
      colorGradient: !0,
    });
    return {
      subscribe: e,
      setThemeColor: (e) => {
        let { color: n, color2: r, colorGradient: i } = e;
        if (!ky(n)) {
          H(
            `Provided color '${n}' is not valid. Default color will be used instead.`
          );
          return;
        } else if (i && r && !ky(r)) {
          H(
            `Provided color '${r}' is not valid. Default color will be used instead.`
          );
          return;
        }
        t({ color: n, color2: r, colorGradient: i });
      },
    };
  })(),
  Vy = 24,
  Hy = 12,
  Uy = 72,
  Wy = 380,
  Gy = 672,
  Ky = 560,
  qy = 840,
  Jy = (e) => `${e}px`,
  Yy = (e) => {
    if (e) return od(e) ? parseInt(e, 10) : e;
  },
  Xy = (e, t) => {
    let { widgetBlockingOptions: n } = V.getOptions();
    return e || n?.headlessMode
      ? { width: `100%`, height: `100%` }
      : t
      ? { width: Ky, height: qy }
      : { width: Wy, height: Gy };
  },
  Zy = (e) => {
    let { widgetBlockingOptions: t } = V.getOptions();
    (e.style.borderRadius = Jy(20)),
      t?.headlessMode
        ? (e.style.boxShadow = `none`)
        : t?.limitShadow
        ? (e.style.boxShadow = `rgba(0, 0, 0, 0.25) 0px 5px 12px`)
        : (e.style.boxShadow = `rgba(0, 0, 0, 0.16) 0px 5px 40px`);
  },
  Qy = () => {
    let { offsetY: e } = V.getOptions();
    return Yy(e) ?? Vy;
  },
  $y = () => {
    let { offsetX: e } = V.getOptions();
    return Yy(e) ?? Hy;
  },
  eb = (e) => {
    let { widgetBlockingOptions: t } = V.getOptions();
    return e || t?.headlessMode ? 0 : Vy;
  },
  tb = (e) => {
    let { widgetBlockingOptions: t } = V.getOptions();
    return e || t?.headlessMode ? 0 : Hy;
  },
  nb = () => {
    let { position: e } = V.getOptions();
    return e === `fixed`;
  },
  rb = (e) => {
    nb() && (e.style.position = `fixed`);
  },
  ib = (e, t) => {
    nb() && (e.style.bottom = Jy(t));
  },
  ab = (e, t) => {
    if (nb()) {
      let { orientation: n } = V.getOptions();
      n === `right`
        ? ((e.style.left = `initial`), (e.style.right = Jy(t)))
        : ((e.style.left = Jy(t)), (e.style.right = `initial`));
    }
  },
  ob = (e) => {
    let { zIndex: t } = V.getOptions();
    e.style.zIndex = String(t ?? `auto`);
  },
  sb = (e) => {
    let t = document.createElement(`iframe`);
    return (
      (t.style.position = `absolute`),
      (t.style.width = `100%`),
      (t.style.height = `100%`),
      (t.style.border = `none`),
      (t.style.display = `block`),
      (t.style.textAlign = `left`),
      (t.style.margin = `0`),
      (t.style.padding = `0`),
      (t.style.top = `0`),
      (t.style.left = `0`),
      (t.style.opacity = `1`),
      e && e(t),
      t.getAttribute(`style`) ?? ``
    );
  },
  cb = (e) => {
    rb(e), ib(e, Qy()), ab(e, $y()), ob(e);
  },
  lb = (e, t) => {
    rb(e), ib(e, eb(t)), ab(e, tb(t)), ob(e), t || Zy(e);
  },
  ub = (e) => {
    rb(e), ib(e, Qy() + Uy), ab(e, $y()), ob(e);
  },
  db = (e) => {
    (e.style.position = `fixed`),
      (e.style.width = `100%`),
      (e.style.height = `100%`),
      ib(e, 0),
      ab(e, 0),
      ob(e);
  },
  fb = (e) => {
    cb(e);
  },
  pb = (e, t) => {
    lb(e, t);
  },
  mb = (e) => {
    ub(e);
  },
  hb = (e) => {
    ub(e);
  },
  gb = (e) => {
    db(e);
  },
  _b = O(300),
  vb = O(166),
  yb = O(!1),
  bb = O(void 0),
  xb = k([ss, bb], ([e, t]) => {
    let { buttonStyle: n } = V.getOptions();
    return t ? t === `bubble` : e || n === `bubble`;
  }),
  Sb = k([xb, _b], ([e, t]) => (e ? 56 : t)),
  Cb = O(void 0),
  wb = k([cs, Cb], ([e, t]) =>
    e ? !0 : (t ?? V.getOptions().headerStyle) === `compact`
  ),
  Tb = k([wb], ([e]) => (e ? 76 : 114)),
  Eb = O(),
  Db = k([Eb], ([e]) =>
    e === void 0 ? zo(U.IsMessengerFrameExpanded) === `true` : e
  ),
  Ob = (e) => {
    Bo({ name: U.IsMessengerFrameExpanded, value: e.toString() }), Eb.set(e);
  },
  $ = (function (e) {
    return (
      (e.Name = `name`),
      (e.Group = `group`),
      (e.Email = `email`),
      (e.Phone = `phone`),
      (e.Variables = `variables`),
      (e.ContactData = `contactData`),
      (e.Language = `language`),
      (e.ChatClose = `chat:close`),
      (e.ChatOpen = `chat:open`),
      (e.ChatShow = `chat:show`),
      (e.ChatHide = `chat:hide`),
      (e.ThemeColor = `theme:color`),
      (e.ChatMessage = `chat:message`),
      (e.ChatSend = `chat:send`),
      (e.HtmlApply = `html:apply`),
      (e.On = `on`),
      (e.AnalyticsConsent = `analyticsConsent`),
      (e.MarketingConsent = `marketingConsent`),
      (e.OpenRateForm = `openRateForm`),
      (e.OpenAuthForm = `openAuthForm`),
      (e.WidgetStatus = `widgetStatus`),
      (e.Translations = `translations`),
      (e.AuthFormFields = `authFormFields`),
      (e.ButtonStyle = `buttonStyle`),
      (e.HeaderStyle = `headerStyle`),
      (e.PreviewTranslate = `previewTranslate`),
      (e.DisableConnectionStatus = `disableConnectionStatus`),
      (e.ReloadWithMockData = `reloadWithMockData`),
      (e.Reload = `reload`),
      (e.BotIdentityUpdate = `botIdentity:update`),
      e
    );
  })({}),
  kb = (function (e) {
    return (
      (e.MessageSent = `message_sent`),
      (e.MessageReceived = `message_received`),
      (e.MessengerClose = `messenger_close`),
      (e.WidgetInit = `widget_init`),
      e
    );
  })({}),
  Ab = (e) => {
    z.on(`messageSent`, e);
  },
  jb = (e) => {
    z.on(`messageReceived`, e);
  },
  Mb = (e) => {
    z.on(`messengerClose`, e);
  },
  Nb = (e) => {
    z.on(`widgetInit`, e);
  },
  Pb = {
    [kb.MessageSent]: Ab,
    [kb.MessageReceived]: jb,
    [kb.MessengerClose]: Mb,
    [kb.WidgetInit]: Nb,
  },
  Fb = (e, t) => {
    let n = Pb[e];
    n && n(t);
  },
  Ib = `https://docs.smartsupp.com/chat-box/`,
  Lb = `${Ib}localization/#supported-languages`,
  Rb = `${Ib}visitor-identification/#custom-visitor-data`,
  zb = `${Ib}visitor-identification/#custom-contact-data`,
  Bb = `${Ib}javascript-api/events/`,
  Vb = `https://www.smartsupp.com/help/cookie-consent/#where-to-enable-cookie-consent-in-smartsupp`,
  Hb = `https://www.smartsupp.com/pricing`,
  Ub = O({}),
  Wb = (e, t) => {
    Ub.update((n) => ({ ...n, [e]: t }));
  },
  Gb = (e) => Object.values($).some((t) => t === e),
  Kb = (e, t) =>
    od(t)
      ? !0
      : (H(
          `Parameter of '${e}' API command must be type string. See ${Ib} for more information.`
        ),
        !1),
  qb = (e, t) =>
    rd(t)
      ? !0
      : (H(
          `Parameter of '${e}' API command must be type boolean. See ${Ib} for more information.`
        ),
        !1),
  Jb = (e, t) =>
    typeof t == `function`
      ? !0
      : (H(
          `Parameter of '${e}' API command must be type function. See ${Ib} for more information.`
        ),
        !1),
  Yb = (e, t) =>
    ad(t)
      ? !0
      : (H(
          `Parameter of '${e}' API command must be type object. See ${Rb} for more information.`
        ),
        !1),
  Xb = (e, t) =>
    ad(t)
      ? !0
      : (H(
          `Parameter of '${e}' API command must be type object. See ${zb} for more information.`
        ),
        !1),
  Zb = (e, t) =>
    ad(t)
      ? !0
      : (H(`Parameter of '${e}' API command must be type object.`), !1),
  Qb = (e, t) =>
    !ad(t) || !(`id` in t) || !od(t.id)
      ? (H(
          `Parameter of '${e}' API command must be type object and has a valid 'id' property.`
        ),
        !1)
      : `name` in t && !od(t.name)
      ? (H(
          `Parameter of '${e}' API command must have a valid 'name' property.`
        ),
        !1)
      : `avatarUrl` in t && !od(t.avatarUrl)
      ? (H(
          `Parameter of '${e}' API command must have a valid 'avatarUrl' property.`
        ),
        !1)
      : !0,
  $b = (e, t) => {
    let n = Object.values(kb);
    return n.includes(t)
      ? !0
      : (H(
          `Unknown event: '${t}'. Available event names are: ${n.join(
            `, `
          )}. See ${Bb} for more information.`
        ),
        !1);
  },
  ex = (e) => {
    H(
      `Unknown API command: '${e}'. See ${Ib} to check available API commands.`
    );
  },
  tx = () => !!V.getOptions().features?.api,
  nx = () => !!V.getOptions().features?.groups,
  rx = () => V.getOptions().isPreviewMode,
  ix = () =>
    !tx() && !rx()
      ? (H(
          `Chat box API feature is not enabled. See ${Hb} to upgrade your package.`
        ),
        !1)
      : !0,
  ax = () =>
    !tx() || !nx()
      ? (H(
          `Chat box Groups feature is not enabled. See ${Hb} to upgrade your package.`
        ),
        !1)
      : !0,
  ox = () => {
    Ho() ||
      H(
        `Enable managing cookie consent in widget settings to allow this command. See ${Vb} for more information.`
      );
  },
  sx = () => {
    let e = () => {
      gv(!0), lv();
    };
    if (!A(X_)) {
      mu.push(e);
      return;
    }
    e();
  },
  cx = () => {
    if (ix()) {
      if (!A(X_)) {
        mu.push(_v);
        return;
      }
      _v();
    }
  },
  lx = () => {
    ix() && lv();
  },
  ux = () => {
    ix() && uv();
  },
  dx = (e, t) => {
    if (ix() && e === $.Language && Kb(e, t)) {
      if (!eu(t)) {
        H(
          `Provided language '${t}' is not supported. See ${Lb} to check supported languages.`
        );
        return;
      }
      if (!A(X_)) {
        Wb(`lang`, t);
        return;
      }
      lu(t);
    }
  },
  fx = (e, t) => {
    let n,
      r = null,
      i = !0;
    if (ix()) {
      if (typeof t == `string` && Kb(e, t)) n = t;
      else if (Yb(e, t)) {
        if (((n = t.color), (r = t.color2), (i = t.colorGradient), !qb(e, i)))
          return;
      } else return;
      if (!ky(n)) {
        H(`Provided color '${n}' is not valid. Please use hex color code.`);
        return;
      } else if (i && r && !ky(r)) {
        H(
          `Provided color '${r}' is not valid. Default color will be used instead.`
        );
        return;
      }
      By.setThemeColor({ color: n, color2: r, colorGradient: i });
    }
  },
  px = (e, t) => {
    ix() && Kb(e, t) && N_(t);
  },
  mx = (e, t) => {
    ix() && Kb(e, t) && (N_(t), R_());
  },
  hx = (e, t, n) => {
    Kb(e, t) && $b(e, t) && Jb(e, n) && Fb(t, n);
  },
  gx = (e, t) => {
    Yb(e, t) && td.updateVisitorVariables(cd(t));
  },
  _x = (e, t) => {
    (e !== $.Name && e !== $.Email && e !== $.Phone && e !== $.Group) ||
      (Kb(e, t) && td.updateVisitorProperty(e, t));
  },
  vx = (e, t) => {
    if (!ax() || !Kb(e, t)) return;
    let n = A($c)[t];
    if (A(X_) && !n) {
      H(
        `Group with key '${t}' does not exist. Please provide correct group key from your group settings.`
      );
      return;
    }
    _x(e, t);
  },
  yx = (e, t) => {
    Xb(e, t) && td.updateVisitorContactData(t);
  },
  bx = (e, t) => {
    qb(e, t) && (ox(), z.emit(`analyticsConsentChanged`, !!t));
  },
  xx = (e, t) => {
    qb(e, t) && (ox(), z.emit(`marketingConsentChanged`, !!t));
  },
  Sx = () => {
    Sm(A(pm) || ``);
  },
  Cx = () => {
    Fc(Lc.AuthForm);
  },
  wx = (e, t) => {
    Kb(e, t) &&
      ((t !== G.AccountStatus.Online && t !== G.AccountStatus.Offline) ||
        Sd.set(t));
  },
  Tx = (e, t) => {
    Yb(e, t) && du(t);
  },
  Ex = (e, t) => {
    Yb(e, t) &&
      (A(mg) || mg.set(V.getOptions()), mg.update((e) => ({ ...e, ...t })));
  },
  Dx = (e, t) => {
    Kb(e, t) && bb.set(t);
  },
  Ox = (e, t) => {
    if (e === $.HeaderStyle && Kb(e, t)) {
      if (t !== `compact` && t !== `standard`) {
        H(
          `Provided header style '${t}' is not valid. Use 'compact' or 'standard'.`
        );
        return;
      }
      Cb.set(t);
    }
  },
  kx = () => {
    let e = () => {};
    e = ou.subscribe(() => {
      A(dm).forEach((e) => {
        let t = e.content?.data || ``;
        typeof t == `string` &&
          t.match(/widgetPreview\..*/) &&
          ((e.content.text = A(W)(t)), J.replaceMessage(e));
      }),
        e();
    });
  },
  Ax = (e, t) => {
    qb(e, t) && l_.set(t);
  },
  jx = (e, t) => {
    Zb(e, t) && q.reloadClient(t);
  },
  Mx = (e, t) => {
    qb(e, t) && q.reloadClient(void 0, t);
  },
  Nx = (e, t) => {
    if (!Qb(e, t)) return;
    let { id: n, ...r } = t;
    _u.updateIdentity(n, r);
  },
  Px = {
    version: `a8df79ea7167743097e853e1113e6b55f860f7be`,
    execute: (e) => {
      let t = e[0];
      if (typeof t == `function`) {
        Lx(t);
        return;
      }
      if (!Gb(t)) {
        ex(String(t));
        return;
      }
      Ix(t, e[1], ...e.slice(2));
    },
    exec: function (...e) {
      this.execute(e);
    },
  },
  Fx = {
    [$.ChatOpen]: sx,
    [$.ChatClose]: cx,
    [$.ChatShow]: lx,
    [$.ChatHide]: ux,
    [$.ChatMessage]: px,
    [$.ChatSend]: mx,
    [$.Language]: dx,
    [$.ThemeColor]: fx,
    [$.HeaderStyle]: Ox,
    [$.On]: hx,
    [$.Variables]: gx,
    [$.ContactData]: yx,
    [$.Name]: _x,
    [$.Group]: vx,
    [$.Email]: _x,
    [$.Phone]: _x,
    [$.AnalyticsConsent]: bx,
    [$.MarketingConsent]: xx,
    [$.HtmlApply]: null,
    [$.OpenRateForm]: Sx,
    [$.OpenAuthForm]: Cx,
    [$.WidgetStatus]: wx,
    [$.Translations]: Tx,
    [$.AuthFormFields]: Ex,
    [$.ButtonStyle]: Dx,
    [$.PreviewTranslate]: kx,
    [$.DisableConnectionStatus]: Ax,
    [$.ReloadWithMockData]: jx,
    [$.Reload]: Mx,
    [$.BotIdentityUpdate]: Nx,
  },
  Ix = (e, t, ...n) => {
    let r = Fx[e];
    if (r === void 0) {
      ex(e);
      return;
    }
    r !== null && (r(e, t, ...n), vo(`🧙‍♂️[API] ${e}${t ? `:` : ``}`, t ?? ``));
  },
  Lx = (e) => {
    A(X_) ? e() : mu.push(e);
  };
typeof window < `u` && ((window.__svelte ??= {}).v ??= new Set()).add(`5`);
var Rx = (e) => e;
function zx(e) {
  let t = e - 1;
  return t * t * t + 1;
}
function Bx(e) {
  let t = typeof e == `string` && e.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return t ? [parseFloat(t[1]), t[2] || `px`] : [e, `px`];
}
function Vx(e, { delay: t = 0, duration: n = 400, easing: r = Rx } = {}) {
  let i = +getComputedStyle(e).opacity;
  return { delay: t, duration: n, easing: r, css: (e) => `opacity: ${e * i}` };
}
function Hx(
  e,
  {
    delay: t = 0,
    duration: n = 400,
    easing: r = zx,
    x: i = 0,
    y: a = 0,
    opacity: o = 0,
  } = {}
) {
  let s = getComputedStyle(e),
    c = +s.opacity,
    l = s.transform === `none` ? `` : s.transform,
    u = c * (1 - o),
    [d, f] = Bx(i),
    [p, m] = Bx(a);
  return {
    delay: t,
    duration: n,
    easing: r,
    css: (e, t) => `
			transform: ${l} translate(${(1 - e) * d}${f}, ${(1 - e) * p}${m});
			opacity: ${c - u * t}`,
  };
}
function Ux(
  e,
  { delay: t = 0, duration: n = 400, easing: r = zx, axis: i = `y` } = {}
) {
  let a = getComputedStyle(e),
    o = +a.opacity,
    s = i === `y` ? `height` : `width`,
    c = parseFloat(a[s]),
    l = i === `y` ? [`top`, `bottom`] : [`left`, `right`],
    u = l.map((e) => `${e[0].toUpperCase()}${e.slice(1)}`),
    d = parseFloat(a[`padding${u[0]}`]),
    f = parseFloat(a[`padding${u[1]}`]),
    p = parseFloat(a[`margin${u[0]}`]),
    m = parseFloat(a[`margin${u[1]}`]),
    h = parseFloat(a[`border${u[0]}Width`]),
    g = parseFloat(a[`border${u[1]}Width`]);
  return {
    delay: t,
    duration: n,
    easing: r,
    css: (e) =>
      `overflow: hidden;opacity: ${Math.min(e * 20, 1) * o};${s}: ${
        e * c
      }px;padding-${l[0]}: ${e * d}px;padding-${l[1]}: ${e * f}px;margin-${
        l[0]
      }: ${e * p}px;margin-${l[1]}: ${e * m}px;border-${l[0]}-width: ${
        e * h
      }px;border-${l[1]}-width: ${e * g}px;min-${s}: 0`,
  };
}
function Wx(
  e,
  {
    delay: t = 0,
    duration: n = 400,
    easing: r = zx,
    start: i = 0,
    opacity: a = 0,
  } = {}
) {
  let o = getComputedStyle(e),
    s = +o.opacity,
    c = o.transform === `none` ? `` : o.transform,
    l = 1 - i,
    u = s * (1 - a);
  return {
    delay: t,
    duration: n,
    easing: r,
    css: (e, t) => `
			transform: ${c} scale(${1 - l * t});
			opacity: ${s - u * t}
		`,
  };
}
at();
var Gx = wi(`<div></div>`);
function Kx(e, t) {
  lt(t, !0);
  let n = oo(t, `height`, 3, 20),
    r = oo(t, `width`, 3, `100%`),
    i = oo(t, `colorScheme`, 3, `gray`),
    a = oo(t, `roundedStyle`, 3, `rounded-full`),
    o = fn(() => `${a()} animate-pulse`);
  var s = Gx();
  let c;
  pr(
    (e) => {
      ba(
        s,
        1,
        ma([
          L(o),
          i() === `gray` && `bg-gray-200`,
          i() === `darkGray` && `bg-gray-300`,
        ])
      ),
        (c = Sa(s, ``, c, e));
    },
    [() => ({ height: Jy(n()), width: id(r()) ? Jy(r()) : r() })]
  ),
    ki(e, s),
    ut();
}
function qx(e, t) {
  let n = oo(t, `size`, 3, 20);
  Kx(e, {
    colorScheme: `darkGray`,
    get width() {
      return n();
    },
    get height() {
      return n();
    },
  });
}
var Jx = Ei(
  `<svg><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 6L6 18M6 6l12 12"></path></svg>`
);
function Yx(e, t) {
  let n = ro(t, [`$$slots`, `$$events`, `$$legacy`]);
  var r = Jx();
  Va(r, () => ({
    viewBox: `0 0 24 24`,
    width: `1.2em`,
    height: `1.2em`,
    ...n,
  })),
    ki(e, r);
}
var Xx = wi(`<button type="button" tabindex="0"><div><!></div></button>`);
function Zx(e, t) {
  lt(t, !0);
  let n = oo(t, `iconOrientation`, 3, `right`),
    r = oo(t, `iconAnimation`, 3, `none`),
    i = oo(t, `iconScale`, 3, !1),
    a = oo(t, `size`, 3, `md`),
    o = oo(t, `variant`, 3, `ghost`),
    s = oo(t, `focus`, 3, `primary`),
    c = fn(() => (n() === `right` ? 1 : -1)),
    l = fn(() => (i() ? 1.4 : 1.2)),
    u = fn(() => t.icon),
    d = (e) => {
      e.stopPropagation(), t.onClick && t.onClick(e);
    };
  var f = Xx(),
    p = Vn(f);
  $i(
    Vn(p),
    () => L(u),
    (e, t) => {
      t(e, { width: `1em`, height: `1em` });
    }
  ),
    Xe(p),
    Xe(f),
    pr(
      (e) => {
        ba(f, 1, e, `svelte-ywofml`),
          (f.disabled = t.disabled),
          za(f, `data-testid`, t.testId),
          za(f, `aria-label`, t.iconDescription),
          za(f, `aria-disabled`, t.disabled),
          ba(
            p,
            1,
            ma([
              `w-full h-full flex items-center justify-center`,
              r() === `spin` && `animate-spin`,
            ])
          ),
          Sa(p, `transform: scale(${L(l)}) scaleX(${L(c)});`);
      },
      [
        () =>
          ma([
            `btn btn-${o()} btn-${a()}`,
            !!t.disabled && `btn-disabled`,
            is() ? `cursor-auto` : `cursor-pointer`,
            s() === `primary` && `button-focus`,
            s() === `secondary` && `button-focus-secondary`,
          ]),
      ]
    ),
    _i(`click`, f, d),
    ki(e, f),
    ut();
}
vi([`click`]);
export {
  M_ as $,
  Mt as $i,
  nu as $n,
  so as $r,
  em as $t,
  Nv as A,
  Ei as Ai,
  Td as An,
  _s as Ar,
  ng as At,
  gv as B,
  or as Bi,
  gd as Bn,
  Bo as Br,
  _m as Bt,
  hb as C,
  Ri as Ci,
  Ud as Cn,
  Cs as Cr,
  Ng as Ct,
  By as D,
  ki as Di,
  Sd as Dn,
  gs as Dr,
  lg as Dt,
  Jy as E,
  Ii as Ei,
  Vd as En,
  bs as Er,
  ug as Et,
  Sv as F,
  mi as Fi,
  Dd as Fn,
  as as Fr,
  jh as Ft,
  iv as G,
  Un as Gi,
  od as Gn,
  yo as Gr,
  pm as Gt,
  yv as H,
  Xn as Hi,
  dd as Hn,
  Lo as Hr,
  hm as Ht,
  _v as I,
  L as Ii,
  bd as In,
  is as Ir,
  Mm as It,
  U_ as J,
  Tn as Ji,
  _u as Jn,
  po as Jr,
  J as Jt,
  ev as K,
  jn as Ki,
  td as Kn,
  V as Kr,
  cm as Kt,
  xv as L,
  Zr as Li,
  md as Ln,
  Jo as Lr,
  wm as Lt,
  Lv as M,
  vi as Mi,
  jd as Mn,
  cs as Mr,
  Qh as Mt,
  Ov as N,
  _i as Ni,
  Ad as Nn,
  ss as Nr,
  eg as Nt,
  zy as O,
  Oi,
  Nd as On,
  fs as Or,
  cg as Ot,
  kv as P,
  gi as Pi,
  Fd as Pn,
  us as Pr,
  $h as Pt,
  P_ as Q,
  fn as Qi,
  W as Qn,
  co as Qr,
  lm as Qt,
  X as R,
  ei as Ri,
  hd as Rn,
  zo as Rr,
  Sm as Rt,
  mb as S,
  Bi as Si,
  Wd as Sn,
  Dc as Sr,
  jg as St,
  Xy as T,
  ji as Ti,
  Bd as Tn,
  ys as Tr,
  fg as Tt,
  av as U,
  Vn as Ui,
  fd as Un,
  jo as Ur,
  mm as Ut,
  mv as V,
  cr as Vi,
  pd as Vn,
  U as Vr,
  gm as Vt,
  ov as W,
  Hn as Wi,
  ud as Wn,
  H as Wr,
  am as Wt,
  V_ as X,
  On as Xi,
  uu as Xn,
  mo as Xr,
  dm as Xt,
  H_ as Y,
  Cn as Yi,
  pu as Yn,
  B as Yr,
  om as Yt,
  B_ as Z,
  pn as Zi,
  ou as Zn,
  z as Zr,
  sm as Zt,
  vb as _,
  $i as _i,
  pf as _n,
  Ic as _r,
  Qg as _t,
  Vx as a,
  O as aa,
  Ya as ai,
  Xp as an,
  Ol as ar,
  I_ as at,
  pb as b,
  Gi as bi,
  Jd as bn,
  Oc as br,
  Ag as bt,
  Ux as c,
  lt as ca,
  Va as ci,
  ap as cn,
  Dl as cr,
  h_ as ct,
  Sb as d,
  Xe as da,
  Ta as di,
  Zf as dn,
  qc as dr,
  u_ as dt,
  At as ea,
  oo as ei,
  nm as en,
  Vl as er,
  j_ as et,
  yb as f,
  x as fa,
  Sa as fi,
  Kf as fn,
  Rc as fr,
  c_ as ft,
  Tb as g,
  ca as gi,
  ff as gn,
  Lc as gr,
  e_ as gt,
  xb as h,
  ua as hi,
  gf as hn,
  Bc as hr,
  $g as ht,
  Kx as i,
  A as ia,
  $a as ii,
  wp as in,
  kl as ir,
  F_ as it,
  Rv as j,
  Di as ji,
  Md as jn,
  ls as jr,
  tg as jt,
  Pv as k,
  wi as ki,
  Cd as kn,
  hs as kr,
  ag as kt,
  Px as l,
  ct as la,
  za as li,
  up as ln,
  wl as lr,
  p_ as lt,
  Db as m,
  ma as mi,
  lf as mn,
  zc as mr,
  t_ as mt,
  Yx as n,
  jt as na,
  ao as ni,
  $p as nn,
  Bl as nr,
  N_ as nt,
  Hx as o,
  st as oa,
  Ja as oi,
  _p as on,
  El as or,
  O_ as ot,
  wb as p,
  u as pa,
  ba as pi,
  Wf as pn,
  Vc as pr,
  o_ as pt,
  tv as q,
  wn as qi,
  q as qn,
  vo as qr,
  fm as qt,
  qx as r,
  k as ra,
  eo as ri,
  Cp as rn,
  Rl as rr,
  A_ as rt,
  Wx as s,
  ut as sa,
  qa as si,
  pp as sn,
  Tl as sr,
  g_ as st,
  Zx as t,
  Pt as ta,
  ro as ti,
  tm as tn,
  Hl as tr,
  R_ as tt,
  _b as u,
  Ze as ua,
  La as ui,
  lp as un,
  Zc as ur,
  m_ as ut,
  Ob as v,
  Qi as vi,
  uf as vn,
  Pc as vr,
  Kg as vt,
  sb as w,
  Mi as wi,
  Gd as wn,
  xs as wr,
  Mg as wt,
  gb as x,
  Vi as xi,
  Yd as xn,
  kc as xr,
  mg as xt,
  fb as y,
  Zi as yi,
  Xd as yn,
  Fc as yr,
  Lg as yt,
  vv as z,
  pr as zi,
  vd as zn,
  Vo as zr,
  Cm as zt,
};
//# sourceMappingURL=shared-C4Ptsyox.js.map
