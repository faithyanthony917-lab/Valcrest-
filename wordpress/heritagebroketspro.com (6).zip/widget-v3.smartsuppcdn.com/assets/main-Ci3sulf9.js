const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      window.parent.smartsupp.getAssetUrl("assets/WidgetMessenger-Dh01C8DW.js"),
      window.parent.smartsupp.getAssetUrl("assets/shared-C4Ptsyox.js"),
      window.parent.smartsupp.getAssetUrl(
        "assets/WidgetMessengerInput-B6HgtRrM.js"
      ),
      window.parent.smartsupp.getAssetUrl("assets/WidgetPopup-D8ThpTcT.js"),
    ])
) => i.map((i) => d[i]);
import {
  $i as e,
  $r as t,
  A as n,
  Ai as r,
  B as i,
  Bi as a,
  C as o,
  Ci as s,
  D as c,
  Di as l,
  E as u,
  Ei as d,
  F as f,
  Gi as p,
  Gn as m,
  Gr as h,
  H as g,
  Ii as _,
  It as v,
  Ji as y,
  Jr as b,
  Ki as x,
  Kr as S,
  Kt as ee,
  Li as te,
  Lr as ne,
  M as re,
  Mi as ie,
  Mr as ae,
  Mt as oe,
  N as se,
  Ni as C,
  Nr as ce,
  O as le,
  Oi as w,
  P as ue,
  Pi as T,
  Pn as de,
  Qi as E,
  Qn as D,
  Qr as fe,
  Qt as pe,
  R as me,
  S as he,
  Si as ge,
  T as _e,
  Ti as O,
  Ui as k,
  Wi as A,
  X as ve,
  Xn as ye,
  Y as be,
  Yi as j,
  Yr as xe,
  Z as Se,
  Zi as Ce,
  _ as we,
  _i as Te,
  a as Ee,
  aa as De,
  b as Oe,
  ca as M,
  d as ke,
  da as N,
  ea as P,
  ei as F,
  f as Ae,
  fa as je,
  fi as I,
  gi as L,
  h as Me,
  hi as R,
  i as z,
  ia as Ne,
  ii as B,
  j as Pe,
  jr as Fe,
  ki as V,
  l as Ie,
  li as H,
  lr as U,
  m as Le,
  mi as Re,
  n as ze,
  o as W,
  pi as G,
  pt as Be,
  qi as Ve,
  qn as He,
  r as K,
  ra as Ue,
  ri as q,
  s as We,
  sa as J,
  t as Ge,
  u as Ke,
  vi as Y,
  w as X,
  wi as qe,
  x as Je,
  y as Ye,
  zi as Z,
} from "./shared-C4Ptsyox.js";
var Xe = V(`<div><!></div>`);
function Ze(e, n) {
  M(n, !0);
  let r = j(null),
    i = `${
      xe().SMARTSUPP_AUTOCREATE === !1 ? h(window).id : `smartsupp`
    }-widget-container`;
  t(() => {
    _(r) && b().body.appendChild(_(r));
  }),
    fe(() => {
      b().getElementById(i)?.remove();
    });
  var a = Xe();
  Y(k(a), () => n.children ?? je),
    N(a),
    B(
      a,
      (e) => y(r, e),
      () => _(r)
    ),
    Z(() => H(a, `id`, i)),
    l(e, a),
    J();
}
var Qe = V(`<iframe allowfullscreen="" scrolling="no"></iframe>`);
function Q(n, r) {
  M(r, !0);
  let i = () => P(c, `$themeColor`, o),
    [o, s] = e(),
    u = j(void 0),
    f = j(null),
    p;
  a(() => {
    _(f) && m(_(f));
  }),
    a(() => {
      _(f) && h(i());
    });
  let m = async (e) => {
      p && (await d(p)),
        e && r.component && (p = qe(r.component, { target: e.body }));
    },
    h = (e) => {
      _(f) && le(_(f), e);
    },
    g = (e) => {
      if (!_(f)) return;
      let t = _(f).createElement(`style`);
      return (t.textContent = e), _(f).head.appendChild(t), t;
    },
    v = () => {
      for (let e of window.document.styleSheets) {
        let t = ``;
        try {
          t = [...e.cssRules].map((e) => e.cssText).join(``);
        } catch {
          continue;
        }
        if (!g(t)) return;
      }
    },
    b = () => {
      !_(u) || !_(u).contentDocument || (y(f, _(u).contentDocument, !0), v());
    };
  t(async () => {
    await te(),
      _(u)?.contentDocument &&
      _(u).contentDocument.readyState === `complete` &&
      _(u).contentDocument.defaultView
        ? b()
        : _(u)?.addEventListener(`load`, b);
  }),
    fe(async () => {
      _(u) && _(u).removeEventListener(`load`, b), p && (await d(p));
    });
  var x = Qe();
  B(
    x,
    (e) => y(u, e),
    () => _(u)
  ),
    Z(() => {
      H(x, `id`, r.id), H(x, `title`, r.title), I(x, r.frameStyle);
    }),
    l(n, x),
    J(),
    s();
}
var $e = r(
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="currentColor" preserveAspectRatio="xMidYMid meet"><path d="M63.113,18.51v-.16C60.323,7.05,44.582,3,31.972,3S3.582,7,.792,18.5a66.22,66.22,0,0,0,0,20.46c1.18,4.74,5.05,8.63,11.36,11.41l-4,5A3.47,3.47,0,0,0,10.882,61a3.39,3.39,0,0,0,1.44-.31L26.862,54c1.79.18,3.49.27,5.07.27,11.04.04,28.41-4.04,31.18-15.43a60.33,60.33,0,0,0,0-20.33Z"></path></svg>`
);
function et(e, t) {
  let n = F(t, `iconSize`, 3, 16);
  var r = $e();
  Z(() => {
    H(r, `width`, n()), H(r, `height`, n());
  }),
    l(e, r);
}
function tt(e, n) {
  M(n, !0);
  let r = j(!1);
  t(() => {
    y(r, !0);
  });
  var i = w(),
    a = A(i),
    o = (e) => {
      var t = w();
      Y(A(t), () => n.children ?? je), l(e, t);
    };
  s(a, (e) => {
    _(r) && e(o);
  }),
    l(e, i),
    J();
}
var nt = V(
  `<div class="transform transition-transform duration-300 group-hover:scale-115"><!></div>`
);
function rt(e) {
  tt(e, {
    children: (e, t) => {
      var n = nt();
      et(k(n), { iconSize: 24 }),
        N(n),
        L(
          3,
          n,
          () => We,
          () => ({ delay: 200, duration: 300, start: 0.6, opacity: 0.8 })
        ),
        l(e, n);
    },
    $$slots: { default: !0 },
  });
}
var it = V(
  `<div class="p-1"><div class="flex-center w-12 h-12 bg-white bg-opacity-10 rounded-full"><!></div></div>`
);
function at(e) {
  var t = it(),
    n = k(t);
  rt(k(n), {}), N(n), N(t), l(e, t);
}
var ot = V(
  `<div class="flex"><div class="flex-center whitespace-nowrap pl-4 pr-1"> </div> <!></div>`
);
function st(n, r) {
  M(r, !1);
  let i = () => P(D, `$t`, a),
    [a, o] = e(),
    s = Ve();
  t(() => {
    let e = Math.ceil(_(s).getBoundingClientRect().width);
    Ke.set(e);
  }),
    q();
  var c = ot(),
    u = k(c),
    d = k(u, !0);
  N(u),
    at(p(u, 2), {}),
    N(c),
    B(
      c,
      (e) => y(s, e),
      () => _(s)
    ),
    Z(
      (e) => {
        H(u, `data-testid`, U.widgetButtonText), O(d, e);
      },
      [() => i()(`button.greeting`)]
    ),
    l(n, c),
    J(),
    o();
}
var ct = V(
  `<div id="widget-online-badge" class="absolute left-0 bottom-0 w-2 h-2 p-1.5 bg-green-400 rounded-full border-2 border-white"></div>`
);
function lt(t, n) {
  M(n, !1);
  let r = () => P(de, `$isWidgetOnline`, i),
    [i, a] = e();
  q();
  var o = w(),
    c = A(o),
    u = (e) => {
      var t = ct();
      Z(() => H(t, `data-testid`, U.widgetOnlineBadge)),
        L(3, t, () => We),
        l(e, t);
    };
  s(c, (e) => {
    r() && e(u);
  }),
    l(t, o),
    J(),
    a();
}
var ut = V(
  `<div id="widget-unread-messages-badge" class="absolute right-0 top-0 min-w-5 h-5 flex-center px-1 text-white bg-red-600 text-xs rounded-full shadow"> </div>`
);
function dt(t, n) {
  M(n, !0);
  let r = () => P(pe, `$unreadMessagesCount`, i),
    [i, a] = e(),
    o = E(() => r() > 0);
  var c = w(),
    u = A(c),
    d = (e) => {
      var t = ut(),
        n = k(t, !0);
      N(t),
        Z(() => {
          H(t, `data-testid`, U.widgetUnreadMessagesBadge),
            O(n, r() > 99 ? `99+` : r());
        }),
        L(3, t, () => We),
        l(e, t);
    };
  s(u, (e) => {
    _(o) && e(d);
  }),
    l(t, c),
    J(),
    a();
}
var ft = V(
  `<div class="h-full w-full fixed flex justify-end border-rounded-full"><div role="button" class="group flex-center w-full bg-primary-gradient bg-primary-gradient-hover text-primary-content rounded-full overflow-hidden cursor-pointer content-focus-secondary"><!> <!></div> <!></div>`
);
function pt(t, n) {
  M(n, !1);
  let r = () => P(D, `$t`, o),
    a = () => P(Me, `$isWidgetButtonBubble`, o),
    [o, c] = e();
  q();
  var u = ft(),
    d = k(u);
  H(d, `tabindex`, 0);
  var f = k(d),
    m = (e) => {
      rt(e, {});
    },
    h = (e) => {
      st(e, {});
    };
  s(f, (e) => {
    a() ? e(m) : e(h, -1);
  }),
    lt(p(f, 2), {}),
    N(d),
    dt(p(d, 2), {}),
    N(u),
    Z(
      (e) => {
        H(d, `aria-label`, e), H(d, `data-testid`, U.widgetButton);
      },
      [() => r()(`ariaLabel.openChat`)]
    ),
    C(`click`, d, () => i()),
    T(`keypress`, d, (e) => e.key === oe.Enter && i()),
    l(t, u),
    J(),
    c();
}
ie([`click`]);
var mt = V(`<div><!></div>`);
function ht(t, n) {
  M(n, !0);
  let r = () => P(ke, `$buttonFrameWidth`, d),
    i = () => P(f, `$shouldRenderButtonFrame`, d),
    o = () => P(Me, `$isWidgetButtonBubble`, d),
    c = () => P(D, `$t`, d),
    [d, p] = e(),
    m = j(void 0),
    h = (e) => {
      _(m) && (_(m).style.width = `${e}px`);
    },
    { widgetBlockingOptions: g } = S.getOptions();
  a(() => {
    _(m) && h(r());
  });
  var v = w(),
    b = A(v),
    x = (e) => {
      var t = mt();
      let n;
      ge(
        k(t),
        () => o() || c(),
        (e) => {
          {
            let t = E(X);
            Q(e, {
              get component() {
                return pt;
              },
              get id() {
                return U.widgetButtonFrame;
              },
              title: `Smartsupp widget button`,
              get frameStyle() {
                return _(t);
              },
            });
          }
        }
      ),
        N(t),
        B(
          t,
          (e) => y(m, e),
          () => _(m)
        ),
        R(t, (e) => Ye?.(e)),
        Z(
          (e) => {
            (n = I(
              t,
              `border-radius: 9999px; box-shadow: rgb(0 0 0 / 6%) 0px 1px 6px, rgb(0 0 0 / ${
                g?.limitShadow ? `20%) 0px 2px 12px` : `12%) 0px 2px 32px`
              }; color-scheme: normal;`,
              n,
              e
            )),
              H(t, `data-testid`, U.widgetButtonFrame);
          },
          [() => ({ height: u(56) })]
        ),
        L(
          1,
          t,
          () => W,
          () => ({ y: 20, delay: 150, duration: 300 })
        ),
        L(
          2,
          t,
          () => Ee,
          () => ({ duration: 250 })
        ),
        l(e, t);
    };
  s(b, (e) => {
    i() && e(x);
  }),
    l(t, v),
    J(),
    p();
}
var $ = (function (e) {
    return (
      (e[(e.Initialized = 0)] = `Initialized`),
      (e[(e.Loading = 1)] = `Loading`),
      (e[(e.Success = 2)] = `Success`),
      (e[(e.Error = 3)] = `Error`),
      e
    );
  })({}),
  gt = new Map(),
  _t = async (e) => {
    let t = (await e()).default;
    return gt.set(e, t), t;
  };
function vt(e, n) {
  M(n, !0);
  let r = F(n, `delay`, 3, 200),
    i = j(x($.Initialized)),
    a = j(void 0),
    o = j(void 0),
    c = j(void 0),
    u = E(() => _(a)),
    d = () => {
      window.clearTimeout(_(c));
    },
    f = async () => {
      d(),
        y(o, void 0),
        y(a, void 0),
        r() > 0
          ? (y(i, $.Initialized, !0),
            y(
              c,
              window.setTimeout(() => {
                y(i, $.Loading, !0);
              }, r()),
              !0
            ))
          : y(i, $.Loading, !0);
      try {
        y(a, await _t(n.loader), !0), y(i, $.Success, !0);
      } catch (e) {
        if ((y(i, $.Error, !0), e instanceof Error)) y(o, e, !0);
        else throw e;
      }
      d();
    };
  gt.has(n.loader)
    ? (y(i, $.Success, !0), y(a, gt.get(n.loader), !0))
    : t(() => {
        f();
      });
  var p = w(),
    m = A(p),
    h = (e) => {
      var t = w();
      Y(
        A(t),
        () => n.error,
        () => ({ error: _(o) })
      ),
        l(e, t);
    },
    g = (e) => {
      var t = w();
      Y(A(t), () => n.loading), l(e, t);
    },
    v = (e) => {
      var t = w();
      Te(
        A(t),
        () => _(u),
        (e, t) => {
          t(e, {});
        }
      ),
        l(e, t);
    };
  s(m, (e) => {
    _(i) === $.Error && n.error
      ? e(h)
      : _(i) === $.Loading
      ? e(g, 1)
      : _(i) === $.Success && e(v, 2);
  }),
    l(e, p),
    J();
}
var yt = () =>
    ne(
      () => import(`./WidgetMessenger-Dh01C8DW.js`),
      __vite__mapDeps([0, 1, 2]),
      import.meta.url
    ),
  bt = (e) => {
    var t = St(),
      n = k(t),
      r = k(n);
    K(k(r), { size: 32 }), N(r);
    var i = p(r, 2),
      a = k(i);
    K(a, { size: 32 });
    var o = p(a, 2);
    K(o, { size: 32 }), K(p(o, 2), { size: 32 }), N(i), N(n);
    var s = p(n, 2),
      c = k(s);
    K(k(c), { size: 44 }), N(c);
    var u = p(c, 2),
      d = k(u);
    z(d, { height: 20, width: 270 }),
      z(p(d, 2), { height: 20, width: 122 }),
      N(u),
      N(s);
    var f = p(s, 2),
      m = k(f);
    K(k(m), { size: 28 }), N(m);
    var h = p(m, 2);
    z(k(h), { height: 112, width: 295, roundedStyle: `rounded-6` }), N(h), N(f);
    var g = p(f, 2),
      _ = k(g);
    z(_, { height: 32, width: 295 });
    var v = p(_, 2);
    z(v, { height: 32, width: 148 }),
      z(p(v, 2), { height: 32, width: 224 }),
      N(g),
      N(t),
      l(e, t);
  },
  xt = (e, t) => {
    let n = () => t?.().error;
    var r = Ct(),
      i = p(k(r), 2),
      a = k(i, !0);
    N(i), N(r), Z(() => O(a, n())), l(e, r);
  },
  St = V(
    `<div class="h-full p-2 bg-white" id="TODO test"><div class="flex justify-between"><div class="flex"><!></div> <div class="flex space-x-2"><!> <!> <!></div></div> <div class="flex mt-2"><div class="flex ml-1 mr-2"><!></div> <div class="flex-bottom space-y-2"><!> <!></div></div> <div class="flex items-baseline mt-8"><div class="flex ml-1 mr-2"><!></div> <div class="space-y-2"><!></div></div> <div class="flex flex-col items-end space-y-5 mt-8 mr-1"><!> <!> <!></div></div>`
  ),
  Ct = V(
    `<div class="h-full p-4 bg-white text-red-500"><div class="text-lg font-bold">Failed to load widget</div> <div class="text-xs"> </div></div>`
  );
function wt(e) {
  vt(e, {
    get loader() {
      return yt;
    },
    delay: 0,
    get error() {
      return xt;
    },
    get loading() {
      return bt;
    },
  });
}
var Tt = V(`<div><!></div>`);
function Et(t, n) {
  M(n, !0);
  let r = () => P(ae, `$isFullScreenEnabled`, d),
    i = () => P(Le, `$isMessengerFrameExpanded`, d),
    o = () => P(ce, `$isMobileDevice`, d),
    c = () => P(g, `$shouldRenderMessengerFrame`, d),
    [d, f] = e(),
    p = j(void 0),
    h = (e, t) => {
      if (!_(p)) return;
      let { widgetBlockingOptions: n } = S.getOptions(),
        { width: r, height: i } = _e(e, t);
      (_(p).style.maxHeight = m(i) ? i : u(i)),
        (_(p).style.width = m(r) ? r : u(r)),
        (_(p).style.height =
          e || n?.headlessMode ? `100%` : `calc(100% - 40px)`);
    };
  a(() => {
    _(p) && h(r(), i());
  }),
    a(() => {
      if (o() && c()) return se(), () => ue();
    });
  var v = w(),
    b = A(v),
    x = (e) => {
      var t = Tt();
      I(
        t,
        ``,
        {},
        {
          transition: `max-height 250ms ease-in-out, width 250ms ease-in-out`,
          overflow: `hidden`,
        }
      );
      var n = k(t);
      {
        let e = E(X);
        Q(n, {
          get component() {
            return wt;
          },
          get id() {
            return U.widgetMessengerFrame;
          },
          title: `Smartsupp widget messenger`,
          get frameStyle() {
            return _(e);
          },
        });
      }
      N(t),
        R(t, (e, t) => Oe?.(e, t), r),
        B(
          t,
          (e) => y(p, e),
          () => _(p)
        ),
        Z(() => H(t, `data-testid`, U.widgetMessengerFrame)),
        L(
          1,
          t,
          () => W,
          () => ({ y: 20, duration: 200 })
        ),
        L(
          2,
          t,
          () => W,
          () => ({ y: 10, duration: 150 })
        ),
        l(e, t);
    };
  s(b, (e) => {
    c() && e(x);
  }),
    l(t, v),
    J(),
    f();
}
var Dt = () =>
    ne(
      () => import(`./WidgetPopup-D8ThpTcT.js`),
      __vite__mapDeps([3, 1, 2]),
      import.meta.url
    ),
  Ot = (e) => {
    var t = kt(),
      n = k(t);
    K(n, { size: 44 });
    var r = p(n, 2),
      i = k(r);
    z(i, { height: 20, width: 270 });
    var a = p(i, 2);
    z(a, { height: 20, width: 270 }),
      z(p(a, 2), { height: 20, width: 122 }),
      N(r),
      N(t),
      l(e, t);
  },
  kt = V(
    `<div class="h-full p-2 bg-white"><!> <div class="mt-4 space-y-2"><!> <!> <!></div></div>`
  );
function At(e) {
  vt(e, {
    get loader() {
      return Dt;
    },
    delay: 0,
    get loading() {
      return Ot;
    },
  });
}
var jt = V(`<div><!></div>`);
function Mt(t, n) {
  M(n, !0);
  let r = () => P(we, `$popupFrameHeight`, c),
    i = () => P(Ae, `$hasPopupFrameHover`, c),
    o = () => P(Pe, `$shouldRenderPopupFrame`, c),
    [c, d] = e(),
    f = j(void 0),
    p = (e) => {
      _(f) && (_(f).style.maxHeight = `${e}px`);
    },
    { widgetBlockingOptions: m } = S.getOptions();
  a(() => {
    _(f) && p(r());
  });
  let h = E(() => (i() ? 0.28 : 0.16));
  var g = w(),
    v = A(g),
    b = (e) => {
      var t = jt();
      let n;
      var r = k(t);
      {
        let e = E(X);
        Q(r, {
          get component() {
            return At;
          },
          get id() {
            return U.widgetPopupFrame;
          },
          title: `Smartsupp widget popup`,
          get frameStyle() {
            return _(e);
          },
        });
      }
      N(t),
        B(
          t,
          (e) => y(f, e),
          () => _(f)
        ),
        R(t, (e) => he?.(e)),
        Z(
          (e) => {
            (n = I(
              t,
              `height: calc(100% - 40px); transition: box-shadow 0.2s ease-in-out, max-height 250ms ease-in-out`,
              n,
              e
            )),
              H(t, `data-testid`, U.widgetPopupFrame);
          },
          [
            () => ({
              width: u(300),
              "border-radius": u(20),
              overflow: `hidden`,
              "box-shadow": `rgba(0, 0, 0, ${
                m?.limitShadow ? `0.2) 0px 3px 12px` : `${_(h)}) 0px 3px 16px`
              }`,
            }),
          ]
        ),
        L(
          1,
          t,
          () => W,
          () => ({ y: 20, delay: 300, duration: 400 })
        ),
        L(
          2,
          t,
          () => W,
          () => ({ y: 10, duration: 400 })
        ),
        l(e, t);
    };
  s(v, (e) => {
    o() && e(b);
  }),
    l(t, g),
    J(),
    d();
}
var Nt = V(`<div class="flex p-2"><div></div> <div></div> <div></div></div>`);
function Pt(e, t) {
  let n = F(t, `size`, 3, `md`),
    r = F(t, `color`, 3, `black`),
    i = E(() => t.iterations ?? `infinite`);
  var a = Nt(),
    o = k(a);
  let s;
  var c = p(o, 2);
  let u;
  var d = p(c, 2);
  let f;
  N(a),
    Z(() => {
      G(
        o,
        1,
        `typing-indicator ${n()} indicator-color-${r()} animate-typing`,
        `svelte-s40xgk`
      ),
        (s = I(o, ``, s, { "animation-iteration-count": _(i) })),
        G(
          c,
          1,
          `typing-indicator ${n()} indicator-color-${r()} typing-indicator-second animate-typing`,
          `svelte-s40xgk`
        ),
        (u = I(c, ``, u, { "animation-iteration-count": _(i) })),
        G(
          d,
          1,
          `typing-indicator ${n()} indicator-color-${r()} typing-indicator-third animate-typing`,
          `svelte-s40xgk`
        ),
        (f = I(d, ``, f, { "animation-iteration-count": _(i) }));
    }),
    l(e, a);
}
var Ft = V(`<div class="flex-center h-full bg-white rounded-lg"><!></div>`);
function It(e) {
  var t = Ft();
  Pt(k(t), { iterations: 2 }), N(t), l(e, t);
}
var Lt = V(`<div><!></div>`);
function Rt(t, n) {
  M(n, !1);
  let r = () => P(re, `$shouldRenderTypingFrame`, i),
    [i, a] = e(),
    { widgetBlockingOptions: c } = S.getOptions();
  q();
  var d = w(),
    f = A(d),
    p = (e) => {
      var t = Lt();
      let n;
      var r = k(t);
      {
        let e = Ce(X);
        Q(r, {
          get component() {
            return It;
          },
          get id() {
            return U.widgetTypingFrame;
          },
          title: `Smartsupp widget typing`,
          get frameStyle() {
            return _(e);
          },
        });
      }
      N(t),
        R(t, (e) => o?.(e)),
        Z(
          (e) => {
            (n = I(
              t,
              `box-shadow: rgba(0, 0, 0, 0.2) ${
                c?.limitShadow ? `0px 3px 12px` : `0px 3px 16px`
              }; border-radius: 24px;`,
              n,
              e
            )),
              H(t, `data-testid`, U.widgetTypingFrame);
          },
          [() => ({ height: u(40), width: u(70), overflow: `hidden` })]
        ),
        L(
          1,
          t,
          () => W,
          () => ({ y: 20, delay: 300, duration: 400 })
        ),
        L(
          2,
          t,
          () => W,
          () => ({ y: 10, duration: 250 })
        ),
        l(e, t);
    };
  s(f, (e) => {
    r() && e(p);
  }),
    l(t, d),
    J(),
    a();
}
var zt = De(null),
  Bt = Ue([zt], ([e]) => !!e),
  Vt = V(
    `<img class="m-auto max-h-full max-w-full select-none bg-black" width="auto" height="auto"/>`
  ),
  Ht = V(
    `<video controls="" class="m-auto max-h-full max-w-full bg-black object-contain"><track kind="captions"/> <source/></video>`,
    2
  ),
  Ut = V(
    `<div class="w-full h-full flex flex-col"><div class="flex-shrink flex flex-row w-full bg-black text-white"><div class="flex-grow flex items-center text-md px-4 overflow-hidden"><span class="whitespace-nowrap text-ellipsis overflow-hidden"> </span></div> <div class="flex-shrink"><!></div></div> <div><!></div></div>`
  );
function Wt(t, n) {
  M(n, !0);
  let r = () => P(Fe, `$isDesktop`, o),
    i = () => P(zt, `$previewedMedia`, o),
    a = () => P(D, `$t`, o),
    [o, c] = e(),
    u = E(r),
    d = (e) => {
      (e === `overlay` && !_(u)) || zt.set(null);
    };
  var f = Ut(),
    m = k(f),
    h = k(m),
    g = k(h),
    v = k(g, !0);
  N(g), N(h);
  var y = p(h, 2),
    b = k(y);
  {
    let e = E(() => a()(`tooltip.close`));
    Ge(b, {
      onClick: () => d(`button`),
      get icon() {
        return ze;
      },
      get iconDescription() {
        return _(e);
      },
      iconScale: !0,
      size: `xl`,
    });
  }
  N(y), N(m);
  var x = p(m, 2),
    S = k(x),
    ee = (e) => {
      var t = Vt();
      Z(() => {
        H(t, `src`, i()?.attachment.url), H(t, `alt`, i()?.attachment.fileName);
      }),
        C(`click`, t, (e) => e.stopPropagation()),
        T(`keypress`, t, () => {}),
        l(e, t);
    },
    te = (e) => {
      var t = Ht();
      (t.autoplay = !0), (t.loop = !0);
      var n = p(k(t), 2);
      N(t),
        Z(() => H(n, `src`, i().attachment.url)),
        C(`click`, t, (e) => e.stopPropagation()),
        T(`keypress`, t, () => {}),
        l(e, t);
    };
  s(S, (e) => {
    i()?.type === Be.Image ? e(ee) : i()?.type === Be.Video && e(te, 1);
  }),
    N(x),
    N(f),
    Z(() => {
      O(v, i()?.attachment.fileName),
        G(
          x,
          1,
          Re([
            `relative overflow-hidden flex-grow flex items-center bg-black/80 z-10`,
            r() ? `p-8` : `p-4`,
          ])
        );
    }),
    C(`click`, x, () => d(`overlay`)),
    T(`keypress`, x, () => {}),
    L(
      1,
      f,
      () => W,
      () => ({ y: 20, delay: 300, duration: 400 })
    ),
    L(
      2,
      f,
      () => W,
      () => ({ y: 10, duration: 250 })
    ),
    l(t, f),
    J(),
    c();
}
ie([`click`]);
var Gt = V(`<div><!></div>`);
function Kt(t, n) {
  M(n, !1);
  let r = () => P(Bt, `$shouldRenderMediaPreview`, i),
    [i, a] = e();
  q();
  var o = w(),
    c = A(o),
    u = (e) => {
      var t = Gt();
      I(
        t,
        ``,
        {},
        { transition: `max-height 250ms ease-in-out, width 250ms ease-in-out` }
      );
      var n = k(t);
      {
        let e = Ce(() =>
          X((e) => {
            e.style.position = `fixed`;
          })
        );
        Q(n, {
          get component() {
            return Wt;
          },
          get id() {
            return U.widgetImagePreview;
          },
          title: `Smartsupp widget image preview`,
          get frameStyle() {
            return _(e);
          },
        });
      }
      N(t),
        R(t, (e) => Je?.(e)),
        Z(() => H(t, `data-testid`, U.widgetImagePreview)),
        L(
          1,
          t,
          () => W,
          () => ({ y: 20, delay: 100, duration: 250 })
        ),
        L(
          2,
          t,
          () => W,
          () => ({ y: 10, duration: 250 })
        ),
        l(e, t);
    };
  s(c, (e) => {
    r() && e(u);
  }),
    l(t, o),
    J(),
    a();
}
var qt = V(`<!> <!> <!> <!> <!>`, 1);
function Jt(r, i) {
  M(i, !0);
  let o = () => P(ee, `$lastUnreadMessage`, c),
    s = () => P(me, `$isMessengerFrameOpen`, c),
    [c, u] = e();
  t(() => {
    (async () => {
      await ye(), await He.initClient();
    })();
  }),
    a(() => {
      o() && !s() && n();
    }),
    Se(xe()),
    Ne(ce) && ve(xe()),
    Ze(r, {
      children: (e, t) => {
        var n = qt(),
          r = A(n);
        Rt(r, {});
        var i = p(r, 2);
        Mt(i, {});
        var a = p(i, 2);
        ht(a, {});
        var o = p(a, 2);
        Et(o, {}), Kt(p(o, 2), {}), l(e, n);
      },
      $$slots: { default: !0 },
    }),
    J(),
    u();
}
var Yt = h(window);
S.init(Yt.options),
  Yt.installApi(Ie),
  c.setThemeColor(Yt.options),
  be(),
  v(),
  qe(Jt, { target: document.getElementById(`app`) });
export { Pt as n, zt as t };
//# sourceMappingURL=main-Ci3sulf9.js.map
