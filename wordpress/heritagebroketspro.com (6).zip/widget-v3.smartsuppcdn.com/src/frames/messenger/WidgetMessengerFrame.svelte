<script lang="ts">
import { fly } from 'svelte/transition'

import Frame from '@/components/Frame.svelte'
import { testIds } from '@/constants'
import { lockHostScroll, shouldRenderMessengerFrame, unlockHostScroll } from '@/modules/app'
import { isFullScreenEnabled, isMobileDevice } from '@/modules/device'
import {
	getIframeDefaultStyles,
	getMessengerFrameDimensions,
	isMessengerFrameExpanded,
	messengerFrameStyle,
	px,
} from '@/modules/frames'
import { widgetOptions } from '@/modules/options'
import { isString } from '@/utils/isString'

import WidgetMessengerLazy from './WidgetMessengerLazy.svelte'

let containerRef: HTMLDivElement | undefined = $state()

const resizeContainer = (isFullScreenEnabled: boolean, isMessengerFrameExpanded: boolean) => {
	if (!containerRef) return
	const { widgetBlockingOptions } = widgetOptions.getOptions()
	const { width, height } = getMessengerFrameDimensions(isFullScreenEnabled, isMessengerFrameExpanded)
	containerRef.style.maxHeight = isString(height) ? height : px(height)
	containerRef.style.width = isString(width) ? width : px(width)
	containerRef.style.height = isFullScreenEnabled || widgetBlockingOptions?.headlessMode ? '100%' : 'calc(100% - 40px)'
}

$effect(() => {
	containerRef && resizeContainer($isFullScreenEnabled, $isMessengerFrameExpanded)
})

// Lock host-page scrolling while the fullscreen messenger is open on mobile — iOS Safari keeps the
// document scrollable whenever the software keyboard is open, so overflow: hidden alone is bypassed.
// See hostScrollLock for the mechanism.
$effect(() => {
	if (!($isMobileDevice && $shouldRenderMessengerFrame)) return
	lockHostScroll()
	return () => unlockHostScroll()
})
</script>

{#if $shouldRenderMessengerFrame}
	<div
		use:messengerFrameStyle={$isFullScreenEnabled}
		bind:this={containerRef}
		style:transition="max-height 250ms ease-in-out, width 250ms ease-in-out"
		style:overflow="hidden"
		in:fly={{ y: 20, duration: 200 }}
		out:fly={{ y: 10, duration: 150 }}
		data-testid={testIds.widgetMessengerFrame}
	>
		<Frame
			component={WidgetMessengerLazy}
			id={testIds.widgetMessengerFrame}
			title="Smartsupp widget messenger"
			frameStyle={getIframeDefaultStyles()}
		/>
	</div>
{/if}
