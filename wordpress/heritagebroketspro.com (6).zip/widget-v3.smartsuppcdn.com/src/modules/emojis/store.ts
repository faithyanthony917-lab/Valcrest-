import type { EmojiMartData } from 'emoji-mart'
import { writable } from 'svelte/store'

import { debugWidget } from '@/utils/debug'

import type { EmojiItem } from './types'

const EMOJI_DATA_URL = 'https://cdn.jsdelivr.net/npm/@emoji-mart/data'
export const EMOJI_ALLOWED_SHORTCODE_CHARACTERS = 'a-zA-Z0-9_-'
const EMOJI_SHORTCODE_REGEX = new RegExp(`:([${EMOJI_ALLOWED_SHORTCODE_CHARACTERS}]+):`, 'g')

// Cached data
let rawDataCache: EmojiMartData | null = null
let transformedDataCache: EmojiItem[] | null = null
let fetchPromise: Promise<EmojiMartData> | null = null

// Svelte store for reactive updates
const emojiData = writable<EmojiItem[]>([])

const fetchEmojiData = async (): Promise<EmojiMartData> => {
	if (rawDataCache) {
		return rawDataCache
	}

	if (fetchPromise) {
		return fetchPromise
	}

	fetchPromise = fetch(EMOJI_DATA_URL)
		.then((response) => response.json() as Promise<EmojiMartData>)
		.then((data) => {
			rawDataCache = data
			return data
		})
		.catch((error) => {
			debugWidget('Failed to load emoji data', error)
			fetchPromise = null
			throw error
		})

	return fetchPromise
}

const transformEmojiData = (rawData: EmojiMartData): EmojiItem[] => {
	return Object.values(rawData.emojis).map((emoji) => ({
		id: emoji.id,
		name: emoji.name,
		native: emoji.skins[0]?.native ?? '',
		keywords: emoji.keywords ?? [],
	}))
}

export const emojiStore = {
	subscribe: emojiData.subscribe,

	async loadRawData(): Promise<EmojiMartData> {
		return fetchEmojiData()
	},

	async loadData(): Promise<EmojiItem[]> {
		if (transformedDataCache) {
			return transformedDataCache
		}

		const rawData = await fetchEmojiData()
		transformedDataCache = transformEmojiData(rawData)
		emojiData.set(transformedDataCache)
		return transformedDataCache
	},

	getById(id: string): EmojiItem | undefined {
		const lowerId = id.toLowerCase()
		return transformedDataCache?.find((emoji) => emoji.id.toLowerCase() === lowerId)
	},

	isLoaded(): boolean {
		return transformedDataCache !== null
	},
}

export const replaceEmojiShortcodes = (text: string): string => {
	if (!emojiStore.isLoaded()) {
		return text
	}

	return text.replace(EMOJI_SHORTCODE_REGEX, (match, id: string) => {
		const emoji = emojiStore.getById(id)
		return emoji ? emoji.native : match
	})
}
