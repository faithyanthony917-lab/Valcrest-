import { EMOJI_ALLOWED_SHORTCODE_CHARACTERS } from './store'
import type { EmojiItem } from './types'

const MAX_DISPLAYED_EMOJIS = 20

// Emoji shortcodes utilities
const emojiMap: Record<string, string> = {
	':)': '🙂',
	':-)': '🙂',
	':D': '😀',
	':-D': '😀',
	';)': '😉',
	';-)': '😉',
	'<3': '❤️',
	':(': '😞',
	':-(': '😞',
	':P': '😛',
	':-P': '😛',
	':-o': '😮',
	':O': '😮',
	':/': '😕',
	':-/': '😕',
}

const createEmojiRegExp = (includeEndOfLine: boolean): RegExp => {
	const capturingGroup = `(${includeEndOfLine ? '$|' : ''} )`
	return new RegExp(
		Object.keys(emojiMap)
			.map((key) => `${key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}${capturingGroup}`)
			.join('|'),
		'gi',
	)
}

export const replaceEmoticonsByEmojis = (text: string, includeEndOfLine = false): string => {
	const emojiRegExp = createEmojiRegExp(includeEndOfLine)
	return text.replace(emojiRegExp, (match) => {
		const emojiKey = Object.keys(emojiMap).find((key) => match.toUpperCase().includes(key))
		if (!emojiKey) return match

		const afterString = match.endsWith(' ') ? ' ' : ''
		return `${emojiMap[emojiKey]}${afterString}`
	})
}

// Emoji inline picker functions
export const searchEmojis = (
	query: string,
	emojis: EmojiItem[],
	maxResults: number = MAX_DISPLAYED_EMOJIS,
): EmojiItem[] => {
	if (!query || query.length < 2) {
		return []
	}

	const lowerQuery = query.toLowerCase()

	const startsWithId: EmojiItem[] = []
	const matchesId: EmojiItem[] = []
	const matchesName: EmojiItem[] = []
	const matchesKeyword: EmojiItem[] = []

	for (const emoji of emojis) {
		const lowerId = emoji.id.toLowerCase()
		const lowerName = emoji.name.toLowerCase()

		// 1. Starts with ID
		if (lowerId.startsWith(lowerQuery)) {
			startsWithId.push(emoji)
			continue
		}

		// 2. ID matches (contains)
		if (lowerId.includes(lowerQuery)) {
			matchesId.push(emoji)
			continue
		}

		// 3. Name matches
		if (lowerName.includes(lowerQuery)) {
			matchesName.push(emoji)
			continue
		}

		// 4. Keyword matches
		const keywordMatch = emoji.keywords.some((keyword) => keyword.toLowerCase().includes(lowerQuery))
		if (keywordMatch) {
			matchesKeyword.push(emoji)
		}
	}

	// Combine results in priority order
	const results = [...startsWithId, ...matchesId, ...matchesName, ...matchesKeyword]

	return results.slice(0, maxResults)
}

export const getEmojiColonMatch = (text: string, cursorPosition: number): string | null => {
	// Find the text before cursor
	const textBeforeCursor = text.slice(0, cursorPosition)

	// Find the last colon that starts a potential emoji search
	const colonIndex = textBeforeCursor.lastIndexOf(':')

	if (colonIndex === -1) {
		return null
	}

	// Get text after the colon
	const afterColon = textBeforeCursor.slice(colonIndex + 1)

	// Check if the text after colon is valid (only letters, numbers, underscores, hyphens, no spaces)
	if (!new RegExp(`^[${EMOJI_ALLOWED_SHORTCODE_CHARACTERS}]*$`).test(afterColon)) {
		return null
	}

	// Return the search query if it has at least 2 characters
	if (afterColon.length >= 2) {
		return afterColon
	}

	return null
}

export const replaceEmojiColon = (
	text: string,
	cursorPosition: number,
	emoji: string,
): { newText: string; newCursorPosition: number } => {
	const textBeforeCursor = text.slice(0, cursorPosition)
	const textAfterCursor = text.slice(cursorPosition)

	// Find the colon that starts the emoji search
	const colonIndex = textBeforeCursor.lastIndexOf(':')

	if (colonIndex === -1) {
		return { newText: text, newCursorPosition: cursorPosition }
	}

	const beforeColon = text.slice(0, colonIndex)

	// Only add space after emoji if there's no text after cursor
	const needsSpace = textAfterCursor.length === 0
	const emojiWithOptionalSpace = needsSpace ? emoji + ' ' : emoji
	const newText = beforeColon + emojiWithOptionalSpace + textAfterCursor
	const newCursorPosition = colonIndex + emojiWithOptionalSpace.length

	return { newText, newCursorPosition }
}
