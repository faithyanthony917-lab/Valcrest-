import { derived, writable } from 'svelte/store'

import { isFullScreenEnabled, isMobileDevice } from '@/modules/device'
import { widgetOptions } from '@/modules/options'

import { getFromStorage, setToStorage } from '../storage'
import { StorageItem } from '../storage/types'
import {
	BUTTON_FRAME_BUBBLE_SIZE,
	BUTTON_FRAME_DEFAULT_WIDTH,
	MESSENGER_FRAME_HEADER_COMPACT_HEIGHT,
	MESSENGER_FRAME_HEADER_HEIGHT,
	POPUP_FRAME_DEFAULT_HEIGHT,
} from './frameStyles'
import type { ButtonType, HeaderStyle } from './types'

export const buttonFrameGreetingWidth = writable(BUTTON_FRAME_DEFAULT_WIDTH)

export const popupFrameHeight = writable(POPUP_FRAME_DEFAULT_HEIGHT)
export const hasPopupFrameHover = writable(false)

export const buttonStyleOverriden = writable<ButtonType | undefined>(undefined)

export const isWidgetButtonBubble = derived(
	[isMobileDevice, buttonStyleOverriden],
	([$isMobileDevice, $buttonStyleOverriden]) => {
		const { buttonStyle } = widgetOptions.getOptions()
		if ($buttonStyleOverriden) return $buttonStyleOverriden === 'bubble'
		// On mobile devices button frame is always a bubble
		return $isMobileDevice || buttonStyle === 'bubble'
	},
)

export const buttonFrameWidth = derived(
	[isWidgetButtonBubble, buttonFrameGreetingWidth],
	([$isWidgetButtonBubble, $buttonFrameGreetingWidth]) => {
		return $isWidgetButtonBubble ? BUTTON_FRAME_BUBBLE_SIZE : $buttonFrameGreetingWidth
	},
)

// Runtime override set via the `headerStyle` API command; takes precedence over the config option.
export const headerStyleOverride = writable<HeaderStyle | undefined>(undefined)

// Header layout flag, decoupled from the fullscreen feature. Fullscreen (mobile/config) is always compact
export const isCompactHeader = derived(
	[isFullScreenEnabled, headerStyleOverride],
	([$isFullScreenEnabled, $headerStyleOverride]) => {
		if ($isFullScreenEnabled) return true
		const headerStyle = $headerStyleOverride ?? widgetOptions.getOptions().headerStyle
		return headerStyle === 'compact'
	},
)

export const messengerHeaderHeight = derived([isCompactHeader], ([$isCompactHeader]) =>
	$isCompactHeader ? MESSENGER_FRAME_HEADER_COMPACT_HEIGHT : MESSENGER_FRAME_HEADER_HEIGHT,
)

const messengerFrameExpanded = writable<boolean>()

export const isMessengerFrameExpanded = derived([messengerFrameExpanded], ([$messengerFrameExpanded]) => {
	if (typeof $messengerFrameExpanded === 'undefined') {
		const stored = getFromStorage(StorageItem.IsMessengerFrameExpanded)
		return stored === true.toString() ? true : false
	}
	return $messengerFrameExpanded
})

export const setMessengerFrameExpanded = (isExpanded: boolean): void => {
	setToStorage({
		name: StorageItem.IsMessengerFrameExpanded,
		value: isExpanded.toString(),
	})
	messengerFrameExpanded.set(isExpanded)
}
