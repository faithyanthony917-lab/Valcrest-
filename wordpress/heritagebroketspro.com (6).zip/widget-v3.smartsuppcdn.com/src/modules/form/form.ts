import { derived, get, writable } from 'svelte/store'

import type { FieldValue, FieldValues, FormErrors, FormValidators } from './types'
import { initObjectValues, updateStoreValue } from './utils'

export interface FormOptions<TFieldValues, TFormField> {
	initialValues: TFieldValues
	validators: FormValidators
	onChange?: (field: TFormField, value: string) => void
	onSubmit: (values: TFieldValues) => void | Promise<void>
}

const NO_ERROR = null
const IS_TOUCHED = true

export const createForm = <
	TFieldValues extends FieldValues = FieldValues,
	TFormField extends keyof TFieldValues = string,
>(
	options: FormOptions<TFieldValues, TFormField>,
) => {
	const initialValues: TFieldValues = options.initialValues || {}
	const { validators, onChange, onSubmit } = options

	const getInitFormValues = () => {
		return { ...initialValues }
	}

	const initialErrors = initObjectValues(initialValues, NO_ERROR)

	const form = writable(getInitFormValues())
	const errors = writable<FormErrors>(initialErrors)
	const touched = writable(initObjectValues(initialValues, !IS_TOUCHED))
	const isSubmitting = writable(false)

	const isValid = derived(errors, ($errors): boolean => {
		return Object.values($errors).every((field) => field === NO_ERROR)
	})

	const validateForm = () => {
		Object.entries(get(form)).forEach(([field, value]) => {
			validateFieldValue(field, value as FieldValue<TFieldValues>)
		})
	}

	const handleChange = (event: Event) => {
		const el = event.target as HTMLInputElement | null
		if (!el) return

		const field = el.name || el.id
		updateFieldWithValidation(field, el.value as FieldValue<TFieldValues>)
	}

	const handleSubmit = async (event: Event) => {
		if (event && event.preventDefault) {
			event.preventDefault()
		}

		isSubmitting.set(true)

		validateForm()
		const isFormValid = get(isValid)
		if (!isFormValid) {
			isSubmitting.set(false)
			return
		}

		errors.set(initialErrors)
		await onSubmit(get(form))
		isSubmitting.set(false)
	}

	const setValues = (values: TFieldValues, { shouldValidate = false } = {}) => {
		form.update((state) => ({ ...state, ...values }))
		if (shouldValidate) validateForm()
	}

	const setFieldValue = (field: string, value: FieldValue<TFieldValues>) => {
		updateFieldWithValidation(field, value)
	}

	const updateFieldWithValidation = (field: string, value: FieldValue<TFieldValues>) => {
		updateField(field, value)
		validateFieldValue(field, value)
		onChange && onChange(field as TFormField, value)
	}

	const updateField = (field: string, value: string) => {
		updateStoreValue(form, field, value)
	}

	const updateTouched = (field: string, value: string) => {
		updateStoreValue(touched, field, value)
	}

	const validateFieldValue = (field: string, value: FieldValue<TFieldValues>) => {
		updateTouched(field, value)

		const fieldValidators = validators[field]
		if (!fieldValidators) return

		for (const validatorFn of fieldValidators) {
			const { type, isValid } = validatorFn(value)
			const fieldValue = !isValid ? type : NO_ERROR
			updateStoreValue(errors, field, fieldValue)
			if (!isValid) return
		}
	}

	return {
		form,
		errors,
		isValid,
		isSubmitting,
		handleChange,
		handleSubmit,
		setFieldValue,
		setValues,
	}
}
