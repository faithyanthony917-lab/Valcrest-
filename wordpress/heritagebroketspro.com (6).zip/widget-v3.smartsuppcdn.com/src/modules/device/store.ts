import { derived, writable } from 'svelte/store'

import type { Dimensions } from '@/types'
import { getHostWindow } from '@/utils/window'

import { widgetOptions } from '../options'
import type { BrowserInfo } from './types'
import { isIOsDevice, isTouchDevice } from './utils'

export const BREAKPOINT_WIDTH_MD = 450
export const BREAKPOINT_HEIGHT_MD = 500

export const browserInfo = writable<BrowserInfo | null>(null)

export const windowSize = writable<Dimensions>({
	width: getHostWindow().innerWidth,
	height: getHostWindow().innerHeight,
})

export const isMobileDevice = derived([browserInfo, windowSize], ([$browserInfo, $windowSize]) => {
	const { widgetBlockingOptions } = widgetOptions.getOptions()
	if (widgetBlockingOptions?.enforceDesktopMode) return false
	if ($browserInfo) {
		const { isMobile, isTablet } = $browserInfo
		if (isTablet) return false
		if (isMobile) return true
	}

	return $windowSize.width < BREAKPOINT_WIDTH_MD || $windowSize.height < BREAKPOINT_HEIGHT_MD
})

export const isFullScreenEnabled = derived([isMobileDevice], ([$isMobileDevice]) => {
	const { fullScreenEnabled } = widgetOptions.getOptions()
	if ($isMobileDevice || fullScreenEnabled) {
		return true
	}
	return false
})

export const isDesktop = derived([browserInfo], ([$browserInfo]): boolean => {
	// Browser info arrives with the websocket connection — until then fall back to local touch detection,
	// so touch devices are never treated as desktop while (or if) the connection is pending
	if (!$browserInfo) return !isTouchDevice()
	return !!$browserInfo?.isDesktop && !isIOsDevice() // iPad 13+ is incorrectly detected as desktop
})

// Inputs may use a font size below 16px only when focusing them cannot trigger auto-zoom (Mobile browsers
// zooms into inputs with a smaller font). Fullscreen widgets always keep the zoom-safe size.
export const isSmallInputFontEnabled = derived(
	[isDesktop, isFullScreenEnabled],
	([$isDesktop, $isFullScreenEnabled]) => $isDesktop && !$isFullScreenEnabled,
)

export const isTablet = derived([browserInfo], ([$browserInfo]): boolean => {
	return !!$browserInfo?.isTablet
})
