import { getHostDocument, getHostWindow } from '@/utils/window'

// Applied to the host <html> to activate the lock; the CSS below is scoped to it.
const LOCK_CLASS = 'smartsupp-mobile-messenger-active'
const LOCK_STYLE_ID = 'smartsupp-scroll-lock-style'
// Stored on the host <html> so the scroll offset to restore survives remounts/HMR.
const SCROLL_OFFSET_DATA_KEY = 'smartsuppScrollLock'

// iOS Safari keeps the root document scrollable whenever the software keyboard is open, so
// `overflow: hidden` alone is bypassed and the page behind the widget can still be panned.
// Collapsing the body to `height: 0` removes the document's scroll range entirely, which is the
// reliable lock on iOS. Everything is `!important` and scoped to a class so it wins against host
// page CSS. Notes on the individual declarations:
//   - position: static — keeps the body in normal flow (unlike a position: fixed lock, which is
//     the historically fragile approach) so host layout/scripts are disturbed as little as possible.
//   - min-height/max-height/padding/border reset — a host `body { min-height: 100vh }` (or padding)
//     would otherwise keep the box tall enough to preserve a scroll range despite `height: 0`.
//   - transform/translate/rotate/scale/perspective/filter/backdrop-filter/will-change/contain/
//     content-visibility reset — any of these on <html>/<body> makes it the containing block for the
//     widget's fixed frames; once that block is collapsed + overflow-hidden it would clip the
//     messenger to nothing. Neutralizing them keeps the frames anchored to the viewport.
const LOCK_CSS = `
html.${LOCK_CLASS},
html.${LOCK_CLASS} > body {
	position: static !important;
	overflow: hidden !important;
	min-height: 0 !important;
	max-height: none !important;
	transform: none !important;
	translate: none !important;
	rotate: none !important;
	scale: none !important;
	perspective: none !important;
	filter: none !important;
	backdrop-filter: none !important;
	-webkit-backdrop-filter: none !important;
	will-change: auto !important;
	contain: none !important;
	content-visibility: visible !important;
}
html.${LOCK_CLASS} > body {
	height: 0 !important;
	margin: 0 !important;
	padding: 0 !important;
	border: 0 !important;
}`

// Inject the lock stylesheet once and leave it in place; the class toggles it on and off.
const ensureLockStyle = (doc: Document) => {
	if (doc.getElementById(LOCK_STYLE_ID)) return
	const style = doc.createElement('style')
	style.id = LOCK_STYLE_ID
	style.textContent = LOCK_CSS
	doc.head.appendChild(style)
}

/**
 * Locks scrolling of the host page while the fullscreen messenger is open on mobile, preserving the
 * current scroll offset so it can be reapplied by {@link unlockHostScroll}.
 */
export const lockHostScroll = () => {
	const doc = getHostDocument()
	const html = doc.documentElement

	// Already locked — don't overwrite the stored offset with the (now collapsed) scroll position.
	if (html.dataset[SCROLL_OFFSET_DATA_KEY] !== undefined) return

	html.dataset[SCROLL_OFFSET_DATA_KEY] = String(getHostWindow().scrollY)
	ensureLockStyle(doc)
	html.classList.add(LOCK_CLASS)
}

/**
 * Releases the host page scroll lock and restores the scroll position captured by {@link lockHostScroll}.
 */
export const unlockHostScroll = () => {
	const doc = getHostDocument()
	const html = doc.documentElement

	const storedOffset = html.dataset[SCROLL_OFFSET_DATA_KEY]
	if (storedOffset === undefined) return

	html.classList.remove(LOCK_CLASS)
	delete html.dataset[SCROLL_OFFSET_DATA_KEY]

	// behavior: 'instant' overrides any `scroll-behavior: smooth` the host set on the root element,
	// which would otherwise animate this restore and look janky as the messenger closes.
	getHostWindow().scrollTo({ top: Number(storedOffset), left: 0, behavior: 'instant' })
}
