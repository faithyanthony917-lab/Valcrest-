import { AuthFormMode, type BotIdentity } from '@smartsupp/websocket-client-visitor'
import { derived, writable } from 'svelte/store'

import type { Dictionary } from '@/types'
import { normalize } from '@/utils/normalize'

import { processBotIdentity } from './utils'

const createIdentitiesStore = () => {
	const identities = writable<Dictionary<BotIdentity>>({})
	const { update, subscribe, set } = identities

	const setIdentities = (agents: BotIdentity[]) => {
		set(normalize('id', agents.map(processBotIdentity)))
	}

	const addIdentity = (agent: BotIdentity) => {
		update((state) => ({ ...state, [agent.id]: agent }))
	}

	const updateIdentity = (id: BotIdentity['id'], changes: Partial<Omit<BotIdentity, 'id'>>) => {
		update((state) => {
			if (!state[id]) return state
			return { ...state, [id]: { ...state[id], ...changes } }
		})
	}

	// Only one bot identity can drive the conversation at a time, so activating one deactivates the rest.
	const setActiveIdentity = (id: BotIdentity['id'] | null) => {
		update((state) => {
			const next: Dictionary<BotIdentity> = {}
			Object.keys(state).forEach((identityId) => {
				next[identityId] = { ...state[identityId], isActive: identityId === id }
			})
			return next
		})
	}

	return {
		subscribe,
		setIdentities,
		addIdentity,
		updateIdentity,
		setActiveIdentity,
	}
}

export const botIdentities = createIdentitiesStore()

export const activeBotAuthFormMode = derived([botIdentities], ([$botIdentities]): AuthFormMode | undefined => {
	const activeBot = Object.values($botIdentities).find((identity) => identity.isActive)
	return activeBot?.authFormMode
})
