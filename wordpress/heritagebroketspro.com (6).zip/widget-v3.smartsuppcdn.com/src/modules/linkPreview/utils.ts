import type { Card, CardAction } from '@smartsupp/smartsupp-message'
import { get } from 'svelte/store'

import { printError } from '@/utils/console'

import { fileUploadConfig } from '../fileUpload'
import { widgetOptions } from '../options'
import { getLocalStorageData, setToLocalStorage } from '../storage'
import { visitorClientProvider } from '../websocketClient'

export type StoredCards = { [key: string]: { expiration: number; card: Card } }

export const getCardsFromStorage = (): StoredCards => {
	const data = getLocalStorageData('cards')
	return data as StoredCards
}

export const setCardsToStorage = (Cards: StoredCards) => {
	setToLocalStorage({ ...Cards }, 'cards')
}

export const processLinks = async (links: string[]): Promise<Card[] | null> => {
	const headers = new Headers()
	const { widgetApiUrl } = widgetOptions.getOptions()
	headers.append('Content-Type', 'application/json')

	const body: string = JSON.stringify({
		links: links,
	})
	try {
		const response = await fetch(`${widgetApiUrl}/links/preview`, {
			method: 'POST',
			headers,
			body,
		})
		if (response.ok && response.json) {
			const attachments = (await response.json()) as Card[]
			return attachments
		} else {
			return null
		}
	} catch {
		return null
	}
}

export const getCardUrl = (actions: CardAction[]): string => {
	const openUrlAction = actions.find((action) => action.type === 'open_url')
	return openUrlAction?.value || ''
}

export const processFileAndEmptyCards = (cards: Card[]): Card[] => {
	const filteredCards = cards.filter((card) => card.title && card.image && !hasFileExtension(getCardUrl(card.actions)))
	if (filteredCards.length && cards.length > 1) {
		return cards
	} else {
		return filteredCards.length === 1 ? filteredCards : []
	}
}

export const filterOldLinks = (cards: StoredCards) => {
	const time = new Date().getTime()
	const keys = Object.keys(cards)
	keys.forEach((key) => {
		if (!cards[key].expiration || (cards[key].expiration && cards[key].expiration < time)) {
			delete cards[key]
		}
	})
	return cards
}

export const hasFileExtension = (link: string) => {
	const { acceptedFileExtensions } = get(fileUploadConfig)
	const extension = link.match(/(\.)([^.]{3,4})$/m)
	return extension && extension[2] && acceptedFileExtensions.includes(extension[2])
}

export const sendLinkOpenedEvent = async (link: string) => {
	try {
		const client = visitorClientProvider.getClient()
		await client.linkOpened({ url: link })
	} catch (error) {
		printError('Sending link opened analytics event failed', String(error))
	}
}

export const linkOpenEvent = (node: HTMLDivElement, shouldSendLinkOpenedEvent: boolean) => {
	if (!shouldSendLinkOpenedEvent) return

	const handleClick = async (event: MouseEvent) => {
		const target = (event.target as HTMLElement).closest('a')
		if (target && node.contains(target) && shouldSendLinkOpenedEvent) {
			await sendLinkOpenedEvent(target.href)
		}
	}

	const onClick = (event: MouseEvent) => void handleClick(event)
	const onAuxClick = (event: MouseEvent) => {
		event.button !== 2 && void handleClick(event)
	}
	const onContextMenu = (event: MouseEvent) => void handleClick(event)

	node.addEventListener('click', onClick)
	node.addEventListener('auxclick', onAuxClick)
	node.addEventListener('contextmenu', onContextMenu)

	return {
		destroy() {
			node.removeEventListener('click', onClick)
			node.removeEventListener('auxclick', onAuxClick)
			node.removeEventListener('contextmenu', onContextMenu)
		},
	}
}
