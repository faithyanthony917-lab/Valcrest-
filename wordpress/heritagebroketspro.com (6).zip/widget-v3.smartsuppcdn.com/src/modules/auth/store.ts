import { AccountStatus, AuthFormMode } from '@smartsupp/websocket-client-visitor'
import { get } from 'svelte/store'

import { activeOnlineAgentsByGroup } from '@/modules/agents'
import { activeBotAuthFormMode } from '@/modules/botIdentities/store'
import { accountStatus, isAuthenticationDisabled, isAuthenticationRequired } from '@/modules/chat'
import { closeDrawer } from '@/modules/drawers'
import { authFormFilledGA } from '@/modules/googleAnalytics'
import { widgetOptions } from '@/modules/options'
import { sendMessage } from '@/modules/textarea'
import { visitor } from '@/modules/visitor'
import { visitorClientProvider } from '@/modules/websocketClient'

import type { AuthFormValues } from './types'
import { shouldCreateAuthFormControls } from './utils'

const isVisitorAuthenticated = (): boolean => {
	const visitorData = get(visitor)
	return !!visitorData?.variables?.authenticated
}

export const isGdprApproved = (): boolean => {
	return get(visitor)?.gdprApproved || false
}

export const shouldShowAuthForm = (): boolean => {
	const { isPreviewMode } = widgetOptions.getOptions()
	if (isPreviewMode) return false
	if (isVisitorAuthenticated()) return false

	const visitorData = get(visitor)
	if (!shouldCreateAuthFormControls(visitorData)) return false

	// Server-driven requirement (e.g. paused handover) — wins over disableAuthentication per the client contract
	if (get(isAuthenticationRequired)) return true
	if (get(isAuthenticationDisabled)) return false

	// The active bot's setting takes priority; without it (no active bot, or an older server
	// that sends no authFormMode) the account-level conditions below apply as before
	const botAuthFormMode = get(activeBotAuthFormMode)
	if (botAuthFormMode) return botAuthFormMode === AuthFormMode.Enabled

	const { requireLogin } = widgetOptions.getOptions()
	const isAccountOffline = get(accountStatus) === AccountStatus.Offline
	const hasOnlineAgents = get(activeOnlineAgentsByGroup).length > 0
	return !!requireLogin || isAccountOffline || (!isAccountOffline && !hasOnlineAgents)
}

export const submitAuthForm = async (values: AuthFormValues) => {
	const { privacyNoticeCheckRequired } = widgetOptions.getOptions()
	const visitorData = get(visitor)
	const name = visitorData?.name ?? (values.name as string | undefined)
	const email = visitorData?.email ?? (values.email as string | undefined)
	const phone = visitorData?.phone ?? (values.phone as string | undefined)
	const group = (values.group as string | undefined) ?? visitorData?.group
	const personalDataProcessingConsent = values.personalDataProcessingConsent as string | undefined

	const authenticateValues = {
		...(name && { name }),
		...(email && { email }),
		...(phone && { phone }),
		...(group && { group }),
		...(personalDataProcessingConsent && privacyNoticeCheckRequired && { personalDataProcessingConsent }),
	}

	await visitorClientProvider.getClient().authenticate(authenticateValues)
	authFormFilledGA()
	await sendMessage()
	closeDrawer()
}
