import { type Message, MessageSubType } from '@smartsupp/smartsupp-message'

import { getCardLinksFromText } from '@/utils/linkify'

const SPAMMING_MESSAGE_COUNT = 10
const SPAMMING_MESSAGES_DELAY = 10000
const SPAMMING_BLOCKING_TIME = 30000
const LINKS_LIMIT = 20

// TODO create test fo this method
export const isMessageSpamming = (messages: Message[]) => {
	if (messages.length > 0 && messages.length % SPAMMING_MESSAGE_COUNT === 0) {
		const last10Messages = messages.slice(-SPAMMING_MESSAGE_COUNT)
		const lastMessageTime = new Date(messages[messages.length - 1].createdAt).getTime()
		if (new Date().getTime() - lastMessageTime > SPAMMING_BLOCKING_TIME) return false
		if (!last10Messages.every((message) => message.subType === MessageSubType.Contact)) return false
		const last10MessageTime = new Date(last10Messages[0].createdAt).getTime()
		if (lastMessageTime - last10MessageTime < SPAMMING_MESSAGES_DELAY) {
			return true
		}
	}
	return false
}

export const isReachLinksLimit = (text: string): boolean => {
	const links = getCardLinksFromText(text)
	if (!links) return false
	return links.length > LINKS_LIMIT
}
