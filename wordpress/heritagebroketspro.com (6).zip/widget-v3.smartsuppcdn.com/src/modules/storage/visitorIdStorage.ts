import { getFromStorage, setToStorage } from './storage'
import { StorageItem } from './types'

export const getVisitorIdFromStorage = (): string | null => {
	return getFromStorage(StorageItem.VisitorId) || null
}

export const setVisitorIdToStorage = (visitorId: string): void => {
	return setToStorage({ name: StorageItem.VisitorId, value: String(visitorId) })
}
