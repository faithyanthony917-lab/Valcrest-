import { widgetOptions } from '@/modules/options'
import { printWarning } from '@/utils/console'
import { debugWidget } from '@/utils/debug'

const isCrossDomainEnabled = (): boolean => {
	return !!widgetOptions.getOptions().crossDomainEnabled
}

const hasAllowedDomains = () => {
	return widgetOptions.getOptions().allowedDomains.length > 0
}

const getClientFingerprint = async (): Promise<string | undefined> => {
	try {
		const ThumbmarkJS = await import('@thumbmarkjs/thumbmarkjs')
		const thumbmark = new ThumbmarkJS.Thumbmark()
		const tm = (await thumbmark.get()) as { thumbmark: string }
		debugWidget('Visitor fingerprint created', tm.thumbmark)
		return tm.thumbmark
	} catch (error) {
		printWarning('Failed to generate fingerprint:', error)
	}
}

export const getFingerprint = async (): Promise<string | undefined> => {
	if (!isCrossDomainEnabled() || !hasAllowedDomains()) return

	return getClientFingerprint()
}
