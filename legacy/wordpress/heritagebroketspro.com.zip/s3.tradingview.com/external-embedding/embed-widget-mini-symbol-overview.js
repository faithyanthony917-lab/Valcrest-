(() => {
  "use strict";
  var t = (function (t) {
    return (
      (t.AdvancedChart = "advanced-chart"),
      (t.TechnicalAnalysis = "technical-analysis"),
      (t.MarketOverview = "market-overview"),
      (t.MarketQuotes = "market-quotes"),
      (t.Hotlists = "hotlists"),
      (t.EconomicCalendar = "events"),
      (t.Ticker = "tickers"),
      (t.TickerTape = "ticker-tape"),
      (t.SingleQuote = "single-quote"),
      (t.MiniSymbolOverview = "mini-symbol-overview"),
      (t.SymbolOverview = "symbol-overview"),
      (t.SymbolInfo = "symbol-info"),
      (t.ForexCrossRates = "forex-cross-rates"),
      (t.ForexHeatMap = "forex-heat-map"),
      (t.Screener = "screener"),
      (t.CryptoMktScreener = "crypto-mkt-screener"),
      (t.Financials = "financials"),
      (t.SymbolProfile = "symbol-profile"),
      (t.TimelineWidget = "timeline"),
      (t.StockHeatmap = "stock-heatmap"),
      (t.CryptoCoinsHeatmap = "crypto-coins-heatmap"),
      (t.EtfHeatmap = "etf-heatmap"),
      t
    );
  })({});
  function e(t, e) {
    if (null === t) throw new Error(`${e ?? "Value"} is null`);
    return t;
  }
  const i = {
    "color-cold-gray-300": "#B2B5BE",
    "color-brand": "#2962FF",
    "color-brand-hover": "#1E53E5",
    "color-brand-active": "#1848CC",
  };
  const r = JSON.parse(
    '{"crypto-mkt-screener":{"width":1000,"height":490,"defaultColumn":"overview","market":"crypto","screener_type":"crypto_mkt","displayCurrency":"USD","isTransparent":false},"events":{"width":510,"height":600,"isTransparent":false,"hideImportanceIndicator":false,"autosize":false},"forex-cross-rates":{"width":770,"height":400,"isTransparent":false,"currencies":["EUR","USD","JPY","GBP","CHF","AUD","CAD","NZD"],"frameElementId":null,"autosize":false},"forex-heat-map":{"width":770,"height":400,"isTransparent":false,"currencies":["EUR","USD","JPY","GBP","CHF","AUD","CAD","NZD","CNY"],"frameElementId":null,"autosize":false},"hotlists":{"width":400,"height":600,"isTransparent":false,"dateRange":"12M","showSymbolLogo":false},"market-overview":{"width":400,"height":650,"isTransparent":false,"dateRange":"12M","showSymbolLogo":true},"market-quotes":{"width":770,"height":450,"isTransparent":false,"showSymbolLogo":false},"mini-symbol-overview":{"width":350,"height":220,"symbol":"FX:EURUSD","dateRange":"12M","isTransparent":false,"autosize":false,"largeChartUrl":""},"symbol-overview":{"width":1000,"height":500,"symbols":[["Apple","AAPL|1D"],["Google","GOOGL|1D"],["Microsoft","MSFT|1D"]],"autosize":false,"chartOnly":false,"hideDateRanges":false,"hideMarketStatus":false,"hideSymbolLogo":false,"scalePosition":"right","scaleMode":"Normal","fontFamily":"-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif","fontSize":"10","noTimeScale":false,"chartType":"area","valuesTracking":"0","changeMode":"price-and-percent"},"advanced-chart":{"bodyId":"widget-container","bodyClasses":["chart-page","unselectable","on-widget"]},"screener":{"width":1100,"height":523,"defaultColumn":"overview","defaultScreen":"general","market":"forex","showToolbar":true,"isTransparent":false},"single-quote":{"width":350,"symbol":"FX:EURUSD","isTransparent":false},"symbol-profile":{"width":480,"height":650,"symbol":"NASDAQ:AAPL","isTransparent":false},"symbol-info":{"width":1000,"symbol":"NASDAQ:AAPL","isTransparent":false},"technical-analysis":{"interval":"1m","width":425,"isTransparent":false,"height":450,"symbol":"NASDAQ:AAPL","showIntervalTabs":true,"displayMode":"single"},"ticker-tape":{"isTransparent":false,"displayMode":"adaptive","showSymbolLogo":false},"tickers":{"isTransparent":false,"showSymbolLogo":false},"financials":{"width":480,"height":830,"autosize":false,"symbol":"NASDAQ:AAPL","isTransparent":false,"displayMode":"regular","largeChartUrl":""},"timeline":{"width":480,"height":830,"autosize":false,"isTransparent":false,"displayMode":"regular","feedMode":"all_symbols"},"stock-heatmap":{"width":500,"height":500,"autosize":true,"dataSource":"SPX500","exchanges":[],"grouping":"sector","blockSize":"market_cap_basic","blockColor":"change","hasTopBar":false,"isDataSetEnabled":false,"isZoomEnabled":true,"hasSymbolTooltip":true,"symbolUrl":"","isMonoSize":false},"crypto-coins-heatmap":{"width":500,"height":500,"autosize":true,"dataSource":"Crypto","blockSize":"market_cap_calc","blockColor":"24h_close_change|5","hasTopBar":false,"isDataSetEnabled":false,"isZoomEnabled":true,"hasSymbolTooltip":true,"symbolUrl":"","isMonoSize":false},"etf-heatmap":{"width":500,"height":500,"autosize":true,"dataSource":"AllUSEtf","blockSize":"volume","blockColor":"change","grouping":"asset_class","hasTopBar":false,"isDataSetEnabled":false,"isZoomEnabled":true,"hasSymbolTooltip":true,"symbolUrl":"","isMonoSize":false}}'
  );
  var s = (function (t) {
    return (
      (t.SymbolClick = "tv-widget-symbol-click"),
      (t.WidgetLoad = "tv-widget-load"),
      (t.WidgetReady = "tv-widget-ready"),
      (t.ResizeIframe = "tv-widget-resize-iframe"),
      (t.NoData = "tv-widget-no-data"),
      t
    );
  })({});
  const n = "__FAIL__",
    o = "__NHTTP__",
    a = new RegExp("^http(s)?:(//)?");
  function l(t = location.href) {
    const e = (function (t) {
      try {
        const e = new URL(t);
        return a.test(e.protocol) ? null : o;
      } catch (t) {
        return n;
      }
    })(t);
    return e || t.replace(a, "");
  }
  const c = globalThis;
  const h = { widgetHost: "https://www.tradingview-widget.com", env: "BATTLE" };
  function d(t, e = h) {
    if ("BATTLE" === e.env) {
      const e = c["WIDGET_HOST"];
      if (e) return e;
      if (t.host.match(/\.\wst\w*\.\wv$/i))
        return `https://${(function (t, e) {
          return t.split(".").slice(-e).join(".");
        })(t.host, 3)
          .replace(/^beta0(?=\.xstaging\.tv$)/i, "beta0-xstaging")
          .replace(/\.(\w)v$/i, (t, e) => `-widget.${e}v`)}`;
    }
    return e.widgetHost;
  }
  const g = ["locale", "symbol", "market"];
  class u {
    hasCopyright() {
      return !!this._copyrightContainer;
    }
    get widgetId() {
      throw new Error("Method must be overridden");
    }
    widgetUtmName() {
      return this.widgetId;
    }
    get defaultSettings() {
      return r[this.widgetId];
    }
    get propertiesToWorkWith() {
      return [];
    }
    get useParamsForConnectSocket() {
      return !1;
    }
    get useSnowplowPageView() {
      return !1;
    }
    useQueryStringParameters(t) {
      return {};
    }
    filterRawSettings(t) {
      const e = {},
        i = { ...t, ...this.useQueryStringParameters(t) },
        r = Object.keys(i),
        s = new Set(this.propertiesToWorkWith);
      return (
        r.forEach((t) => {
          s.has(t) && (e[t] = i[t]);
        }),
        e
      );
    }
    get shouldListenToIframeResize() {
      return !0;
    }
    get propertiesToSkipInHash() {
      return ["customer", "locale"];
    }
    get propertiesToAddToGetParams() {
      return ["locale"];
    }
    shouldAddCopyrightStyles() {
      return !0;
    }
    _defaultWidth() {}
    _defaultHeight() {}
    _getScriptInfo() {
      const t = document.currentScript;
      if (!t || !t.src)
        return (
          console.error(
            "Could not self-replace the script, widget embedding has been aborted"
          ),
          null
        );
      return {
        scriptURL: (function (t) {
          const e = new URL(t, document.baseURI);
          return {
            host: e.host,
            pathname: e.pathname,
            href: e.href,
            protocol: e.protocol,
          };
        })(t.src),
        scriptElement: t,
        id: t.id,
        rawSettings: this._scriptContentToJSON(t),
        overrideHost: t.getAttribute("override-host"),
      };
    }
    _replaceScript(t) {
      const {
          scriptURL: r,
          scriptElement: n,
          rawSettings: o,
          id: a,
          overrideHost: l,
        } = t,
        c = l || d(r),
        h = n.parentNode;
      o && "timeline" === this.widgetUtmName() && (o.locale = "en");
      const g = n.nonce || n.getAttribute("nonce"),
        u = (function (t) {
          if (null === t) return null;
          const e = t.querySelector("#tradingview-copyright"),
            i = t.querySelector("#tradingview-quotes"),
            r = e || i;
          return r && t.removeChild(r), r;
        })(h),
        m = h.querySelector(".tradingview-widget-copyright");
      this._copyrightContainer = u || m;
      const p = h.classList.contains("tradingview-widget-container");
      (this.iframeContainer = h && p ? h : document.createElement("div")),
        o && (this.settings = this.filterRawSettings(o)),
        (o && this._validateSettings()) ||
          (console.error("Invalid settings provided, fall back to defaults"),
          (this.settings = this.filterRawSettings(this.defaultSettings)));
      const f = "32px",
        { width: w, height: y } = this.settings,
        b = void 0 === y ? void 0 : `${y}${Number.isInteger(y) ? "px" : ""}`,
        S = void 0 === w ? void 0 : `${w}${Number.isInteger(w) ? "px" : ""}`;
      if (
        (void 0 !== S && (this.iframeContainer.style.width = S),
        void 0 !== b && (this.iframeContainer.style.height = b),
        this.shouldAddCopyrightStyles())
      ) {
        const t = (function () {
          const t = document.createElement("style");
          return (
            (t.innerHTML = `\n\t.tradingview-widget-copyright {\n\t\tfont-size: 13px !important;\n\t\tline-height: 32px !important;\n\t\ttext-align: center !important;\n\t\tvertical-align: middle !important;\n\t\t/* @mixin sf-pro-display-font; */\n\t\tfont-family: -apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif !important;\n\t\tcolor: ${i["color-cold-gray-300"]} !important;\n\t}\n\n\t.tradingview-widget-copyright .blue-text {\n\t\tcolor: ${i["color-brand"]} !important;\n\t}\n\n\t.tradingview-widget-copyright a {\n\t\ttext-decoration: none !important;\n\t\tcolor: ${i["color-cold-gray-300"]} !important;\n\t}\n\n\t.tradingview-widget-copyright a:visited {\n\t\tcolor: ${i["color-cold-gray-300"]} !important;\n\t}\n\n\t.tradingview-widget-copyright a:hover .blue-text {\n\t\tcolor: ${i["color-brand-hover"]} !important;\n\t}\n\n\t.tradingview-widget-copyright a:active .blue-text {\n\t\tcolor: ${i["color-brand-active"]} !important;\n\t}\n\n\t.tradingview-widget-copyright a:visited .blue-text {\n\t\tcolor: ${i["color-brand"]} !important;\n\t}\n\t`),
            t
          );
        })();
        g && t.setAttribute("nonce", g), this.iframeContainer.appendChild(t);
      }
      const v = this.hasCopyright() ? `calc(100% - ${f})` : "100%",
        C = location.hostname,
        T = m ? "widget_new" : "widget",
        _ = this.widgetUtmName();
      (this.settings.utm_source = C),
        (this.settings.utm_medium = T),
        (this.settings.utm_campaign = _),
        this._updateCopyrightHrefParams(C, T, _);
      const k =
          this.settings.iframeTitle ||
          `${this.widgetId.replace("-", " ")} TradingView widget`,
        A = this.settings.iframeLang || "en";
      (this.iframe = this._createIframe(v, c, a, k, A)),
        this._addCSPErrorListener(c),
        g && this.iframe.setAttribute("nonce", g);
      const L = this.iframeContainer.querySelector(
        ".tradingview-widget-container__widget"
      );
      if (
        (L
          ? (e(L.parentElement).replaceChild(this.iframe, L), n?.remove())
          : p
          ? (this.iframeContainer.appendChild(this.iframe), n?.remove())
          : (this.iframeContainer.appendChild(this.iframe),
            h.replaceChild(this.iframeContainer, e(n))),
        this.shouldListenToIframeResize &&
          (function (t, e, i) {
            const r = e.contentWindow;
            if (!r)
              return (
                console.error(
                  "Cannot listen to the event from the provided iframe, contentWindow is not available"
                ),
                () => {}
              );
            function s(e) {
              e.source &&
                e.source === r &&
                e.data &&
                e.data.name &&
                e.data.name === t &&
                i(e.data.data);
            }
            window.addEventListener("message", s, !1);
          })(s.ResizeIframe, this.iframe, (t) => {
            t.width &&
              ((this.iframe.style.width = t.width + "px"),
              (this.iframeContainer.style.width = t.width + "px")),
              (this.iframe.style.height = t.height + "px"),
              (this.iframeContainer.style.height =
                t.height + (this.hasCopyright() ? 32 : 0) + "px");
          }),
        u)
      ) {
        const t = document.createElement("div");
        (t.style.height = f),
          (t.style.lineHeight = f),
          void 0 !== S && (t.style.width = S),
          (t.style.textAlign = "center"),
          (t.style.verticalAlign = "middle"),
          (t.innerHTML = u.innerHTML),
          this.iframeContainer.appendChild(t);
      }
    }
    _iframeSrcBase(t) {
      let e = `${t}/embed-widget/${this.widgetId}/`;
      return (
        this.settings.customer &&
          -1 !== this.propertiesToSkipInHash.indexOf("customer") &&
          (e += `${this.settings.customer}/`),
        e
      );
    }
    _validateSettings() {
      const t = (t, e) => {
          if (void 0 === t) return e;
          const i = String(t);
          return /^\d+$/.test(i)
            ? parseInt(i)
            : /^(\d+%|auto)$/.test(i)
            ? i
            : null;
        },
        e = t(this.settings.width, this._defaultWidth()),
        i = t(this.settings.height, this._defaultHeight());
      return (
        null !== e &&
        null !== i &&
        ((this.settings.width = e), (this.settings.height = i), !0)
      );
    }
    _setSettingsQueryString(t) {
      const e = this.propertiesToAddToGetParams.filter(
          (t) => -1 !== g.indexOf(t)
        ),
        i = (function (t, e) {
          const i = Object.create(Object.getPrototypeOf(t));
          for (const r of e)
            Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
          return i;
        })(this.settings, e);
      for (const [e, r] of Object.entries(i)) t.searchParams.append(e, r);
    }
    _setHashString(t, e) {
      const i = {};
      e && (i.frameElementId = e),
        Object.keys(this.settings).forEach((t) => {
          -1 === this.propertiesToSkipInHash.indexOf(t) &&
            (i[t] = this.settings[t]);
        }),
        (this.useParamsForConnectSocket || this.useSnowplowPageView) &&
          (i["page-uri"] = l());
      Object.keys(i).length > 0 &&
        (t.hash = encodeURIComponent(JSON.stringify(i)));
    }
    _scriptContentToJSON(t) {
      const e = t.innerHTML.trim();
      try {
        return JSON.parse(e);
      } catch (t) {
        return console.error(`Widget settings parse error: ${t}`), null;
      }
    }
    _createIframe(t, e, i, r, s) {
      const n = document.createElement("iframe");
      i && (n.id = i),
        this.settings.enableScrolling || n.setAttribute("scrolling", "no"),
        n.setAttribute("allowtransparency", "true"),
        n.setAttribute("frameborder", "0"),
        (n.style.userSelect = "none"),
        (n.style.boxSizing = "border-box"),
        (n.style.display = "block"),
        (n.style.height = t),
        (n.style.width = "100%");
      const o = new URL(this._iframeSrcBase(e));
      return (
        this._setSettingsQueryString(o),
        this._setHashString(o, i),
        n.setAttribute("src", o.toString()),
        (n.title = r),
        (n.lang = s),
        n
      );
    }
    _addCSPErrorListener(t) {
      document.addEventListener("securitypolicyviolation", (e) => {
        e.blockedURI.includes(t) &&
          (this._tryFixCSPIssueWithFallback(t),
          console.warn(
            "Please update your CSP rules to allow the tradingview-widget.com origin for frame-src."
          ));
      });
    }
    _tryFixCSPIssueWithFallback(t) {
      const e = this.iframe.getAttribute("src");
      if (e) {
        const i = new URL(e.replace(t, "https://s.tradingview.com"));
        this.iframe.setAttribute("src", i.href);
      }
    }
    _updateCopyrightHrefParams(t, e, i) {
      if (this._copyrightContainer) {
        const r = this._copyrightContainer.querySelectorAll("a");
        r &&
          r.forEach((r) => {
            const s = r.getAttribute("href");
            if (s)
              try {
                const n = new URL(s);
                n.searchParams.set("utm_source", t),
                  n.searchParams.set("utm_medium", e),
                  n.searchParams.set("utm_campaign", i),
                  r.setAttribute("href", n.toString());
              } catch (t) {
                console.log(`Cannot update link UTM params, href="${s}"`);
              }
          });
      }
    }
    constructor(t) {
      this._copyrightContainer = null;
      const e = t ?? this._getScriptInfo();
      e && this._replaceScript(e);
    }
  }
  const m = [
    "customer",
    "symbol",
    "dateRange",
    "trendLineColor",
    "fallingTrendLineColor",
    "growingTrendLineColor",
    "lineWidth",
    "underLineColor",
    "underLineBottomColor",
    "width",
    "height",
    "locale",
    "colorTheme",
    "isTransparent",
    "noTimeScale",
    "chartOnly",
    "autosize",
    "largeChartUrl",
    "scalePosition",
    "useLastSession",
  ];
  new (class extends u {
    get widgetId() {
      return t.MiniSymbolOverview;
    }
    get useSnowplowPageView() {
      return !0;
    }
    get useParamsForConnectSocket() {
      return !0;
    }
    get propertiesToWorkWith() {
      return m;
    }
    useQueryStringParameters() {
      return (function (t) {
        try {
          const e = new URL(window.location.href),
            i = {};
          for (const [r, s] of Object.entries(t)) {
            const t = e.searchParams.get(s);
            t && (i[r] = t);
          }
          return i;
        } catch {
          return {};
        }
      })({ symbol: "tvwidgetsymbol" });
    }
  })();
})();
