(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [97509],
  {
    329807(e) {
      e.exports = {
        "css-value-copyright-transition-params-half-time":
          ".3s 0s cubic-bezier(.4, .01, .22, 1)",
        label: "label-fJv7c5zd",
        logoWrap: "logoWrap-fJv7c5zd",
        svgTextWrap: "svgTextWrap-fJv7c5zd",
        large: "large-fJv7c5zd",
      };
    },
    515901(e, t, r) {
      "use strict";
      r.d(t, { getLocalizedDomain: () => c });
      const n = {
        ar_AE: "ar",
        de_DE: "de",
        en: "www",
        es: "es",
        ca_ES: "es",
        fr: "fr",
        he_IL: "il",
        id: "id",
        in: "in",
        it: "it",
        ja: "jp",
        kr: "kr",
        ms_MY: "my",
        pl: "pl",
        br: "br",
        ru: "ru",
        th_TH: "th",
        tr: "tr",
        vi_VN: "vn",
        zh_CN: "cn",
        zh_TW: "tw",
      };
      function c(e) {
        return n[e] || "www";
      }
    },
    280677(e, t, r) {
      "use strict";
      r.d(t, { getTVHostFromLocale: () => c });
      var n = r(515901);
      function c(e) {
        return (0, n.getLocalizedDomain)(e) + ".tradingview.com";
      }
    },
    80595(e, t, r) {
      "use strict";
      r.d(t, { getTradingViewCopyrightData: () => l });
      var n = r(766840),
        c = r(329807),
        i = r(959992),
        o = r(212961);
      function l(e, t) {
        return {
          ...{ icon: i, svgText: o },
          theme: c,
          url: (0, n.getLocalizedTvHostWithUtm)(e, t),
        };
      }
    },
    766840(e, t, r) {
      "use strict";
      r.d(t, { getLocalizedTvHostWithUtm: () => i });
      var n = r(280677),
        c = r(201109);
      function i(e, t) {
        return `https://${(0, n.getTVHostFromLocale)(e || "en")}${
          t ? (0, c.utmQueryString)(t, !0) : ""
        }`;
      }
    },
    201109(e, t, r) {
      "use strict";
      r.d(t, { utmQueryString: () => c });
      var n = r(533618);
      function c(e, t = !1) {
        const r = (0, n.createUrlParams)(e);
        return r && t ? `?${r}` : r;
      }
    },
    533618(e, t, r) {
      "use strict";
      function n(e) {
        return decodeURIComponent(e.replace(/\+/g, " ")).replace(
          /<\/?[^>]+(>|$)/g,
          ""
        );
      }
      function c(e) {
        const t = /([^&=]+)=?([^&]*)/g,
          r = {};
        if (!e) return r;
        let c = t.exec(e);
        for (; c; ) (r[n(c[1])] = n(c[2])), (c = t.exec(e));
        return r;
      }
      function i() {
        return c(window.location.search.substring(1));
      }
      function o() {
        const e = window.location.href.split("#")[0];
        window.history.replaceState("", document.title, e);
      }
      function l(e) {
        const t = [];
        for (const r in e)
          if (e.hasOwnProperty(r) && null != e[r]) {
            const n = e[r],
              c = "object" == typeof n ? JSON.stringify(n) : String(n);
            t.push({
              key: r,
              pair: encodeURIComponent(r) + "=" + encodeURIComponent(c),
            });
          }
        return t
          .sort((e, t) => (e.key > t.key ? 1 : e.key < t.key ? -1 : 0))
          .map((e) => e.pair)
          .join("&");
      }
      r.d(t, {
        createUrlParams: () => l,
        getUrlParams: () => i,
        removeHashFromUrl: () => o,
      });
    },
    959992(e) {
      e.exports =
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 10" width="17" height="10" fill="none"><path fill="#131722" fill-rule="evenodd" clip-rule="evenodd" d="M13.42 9.04H9.47l3.56-9h3.94l-3.55 9ZM7 .04H0v3h4v6h3v-9Zm2.5 3a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"/></svg>';
    },
    212961(e) {
      e.exports =
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 71 13" width="71" height="13" fill="none"><path fill="#131722" d="M53.1 2c0 .57-.49 1.03-1.09 1.03-.58 0-1.07-.46-1.07-1.03 0-.57.5-1.04 1.07-1.04.6 0 1.08.47 1.08 1.04ZM52.9 10h-1.76V3.65h1.76V10ZM26.47 3.03c.6 0 1.08-.46 1.08-1.03 0-.57-.48-1.03-1.08-1.03-.58 0-1.07.46-1.07 1.03 0 .57.49 1.03 1.07 1.03ZM25.57 10h1.74V3.5h-1.74V10ZM4.07 10H2.33V2.74H0V1h6.4v1.74H4.06V10ZM8.14 10 6.39 10V3.49h1.75v1.1c.2-.58.77-1.02 1.46-1.02h.02c.18 0 .35 0 .55.05v1.66a2.33 2.33 0 0 0-.76-.12c-.8 0-1.27.58-1.27 1.57V10ZM30.22 10h-1.75V3.5h1.75v.57c.33-.47.89-.7 1.69-.7 1.48 0 2.37 1.04 2.37 2.59V10h-1.74V6.4c0-.86-.33-1.55-1.03-1.55-.78 0-1.3.54-1.3 1.68V10ZM46.95 10l3.6-9h-2.03L46.2 7.27 43.58 1h-2.03l3.66 9h1.74ZM68.25 10h-1.7l-1.18-3.75L64.21 10h-1.7l-2.08-6.5h1.83l1.19 4.1 1.26-4.1h1.31l1.28 4.1 1.17-4.1h1.84L68.25 10Z"/><path fill="#131722" fill-rule="evenodd" clip-rule="evenodd" d="M13.32 10.02c.88 0 1.5-.44 1.79-.85V10h1.79V3.5H15.1v.7a2.2 2.2 0 0 0-1.8-.85c-1.7 0-3 1.54-3 3.34 0 1.8 1.3 3.33 3 3.33Zm.37-1.6c-.97 0-1.61-.72-1.61-1.73s.64-1.74 1.6-1.74c.98 0 1.62.73 1.62 1.74 0 1-.64 1.74-1.61 1.74ZM22.66 9.17c-.3.4-.9.85-1.79.85-1.7 0-3-1.53-3-3.33s1.3-3.34 3-3.34c.88 0 1.5.45 1.8.86V1h1.74v9h-1.75v-.83Zm-3.03-2.48c0 1 .64 1.74 1.61 1.74.97 0 1.61-.73 1.61-1.74s-.64-1.74-1.6-1.74c-.98 0-1.62.73-1.62 1.74ZM38.48 12.68c1.96 0 3.42-1 3.42-3.3V3.5h-1.8v.72a2.1 2.1 0 0 0-1.78-.86c-1.68 0-3.02 1.43-3.02 3.24 0 1.79 1.34 3.3 3.02 3.3a2.2 2.2 0 0 0 1.78-.93v.44c0 1.02-.6 1.75-1.64 1.75-.72 0-1.43-.24-2-.8l-.95 1.31c.72.7 1.86 1.02 2.97 1.02Zm.2-4.46a1.6 1.6 0 0 1-1.62-1.63c0-.99.75-1.64 1.63-1.64.88 0 1.62.65 1.62 1.64a1.6 1.6 0 0 1-1.62 1.63ZM60.3 8.56A3.47 3.47 0 0 1 57.35 10c-1.9 0-3.39-1.31-3.39-3.33 0-1.9 1.42-3.34 3.37-3.34 1.67 0 3.14 1.06 3.14 3.15v.09c0 .15 0 .35-.02.56h-4.79c.1.86.86 1.28 1.7 1.28.81 0 1.36-.36 1.65-.81l1.3.97Zm-3.04-3.8c-.65 0-1.38.34-1.54 1.12h2.99c-.15-.77-.8-1.11-1.45-1.11Z"/></svg>';
    },
  },
]);
