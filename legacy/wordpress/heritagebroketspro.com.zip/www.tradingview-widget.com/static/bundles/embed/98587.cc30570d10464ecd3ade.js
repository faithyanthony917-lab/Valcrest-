(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [98587],
  {
    585752(e) {
      e.exports = {
        pair: "pair-xwGsSXR0",
        xxceptionallysmalldonotusebrv1023:
          "xxceptionallysmalldonotusebrv1023-xwGsSXR0",
        xxxxsmall: "xxxxsmall-xwGsSXR0",
        xxxsmall: "xxxsmall-xwGsSXR0",
        xxsmall: "xxsmall-xwGsSXR0",
        xsmall: "xsmall-xwGsSXR0",
        small: "small-xwGsSXR0",
        medium: "medium-xwGsSXR0",
        large: "large-xwGsSXR0",
        xlarge: "xlarge-xwGsSXR0",
        xxlarge: "xxlarge-xwGsSXR0",
        xxxlarge: "xxxlarge-xwGsSXR0",
        logo: "logo-xwGsSXR0",
        skeleton: "skeleton-xwGsSXR0",
        empty: "empty-xwGsSXR0",
      };
    },
    294088(e) {
      e.exports = {
        logo: "logo-VCNKubWq",
        hidden: "hidden-VCNKubWq",
        xxceptionallysmalldonotusebrv1023:
          "xxceptionallysmalldonotusebrv1023-VCNKubWq",
        xxxxsmall: "xxxxsmall-VCNKubWq",
        xxxsmall: "xxxsmall-VCNKubWq",
        xxsmall: "xxsmall-VCNKubWq",
        xsmall: "xsmall-VCNKubWq",
        small: "small-VCNKubWq",
        medium: "medium-VCNKubWq",
        large: "large-VCNKubWq",
        xlarge: "xlarge-VCNKubWq",
        xxlarge: "xxlarge-VCNKubWq",
        xxxlarge: "xxxlarge-VCNKubWq",
        skeleton: "skeleton-VCNKubWq",
        letter: "letter-VCNKubWq",
      };
    },
    987712(e) {
      e.exports = {
        wrapper: "wrapper-hct2yJvK",
        animated: "animated-hct2yJvK",
        pulsation: "pulsation-hct2yJvK",
      };
    },
    743618(e, t, i) {
      "use strict";
      i.d(t, { getLogoUrlsHook: () => o });
      var r = i(881014),
        s = i(137139);
      const n = (0, s.getLogoUrlResolver)();
      function l(e, t = s.LogoSize.Medium) {
        return ("pair" === e.style ? [e.logoid, e.logoid2] : [e.logoid])
          .map((e) => n.getSymbolLogoUrl(e, t))
          .filter(r.notNull);
      }
      function o(e, t) {
        let i = !1;
        return (r, s, n) => {
          if (!i && (r.logo || n)) {
            i = !0;
            const s = r.logo ? l(r.logo, t) : [];
            e(s);
          }
        };
      }
    },
    298441(e, t, i) {
      "use strict";
      i.d(t, { trackWidgetLoadMetaInfo: () => s });
      var r = i(498728);
      async function s(e) {
        Math.random() > 0.005 ||
          (await (0, r.getUnboundTracker)())?.trackSelfDesc(
            "iglu:com.tradingview/widget_load_meta_info/jsonschema/1-0-0",
            e
          );
      }
    },
    485393(e, t, i) {
      "use strict";
      i.d(t, { defaultVolumeOptions: () => n });
      var r = i(778738),
        s = (i(798975), i(714945));
      const n = {
        scaleMargins: { top: 0.8, bottom: 0 },
        priceScaleId: "overlay",
        upColor: (0, s.applyTransparency)(
          r.colorsPalette["color-minty-green-500"],
          50
        ),
        downColor: (0, s.applyTransparency)(
          r.colorsPalette["color-ripe-red-500"],
          50
        ),
        visible: !1,
        lastValueVisible: !1,
        priceLineVisible: !1,
      };
    },
    511538(e, t, i) {
      "use strict";
      i.d(t, {
        ChartType: () => r,
        NoDataReason: () => s,
        SessionPhase: () => n,
      });
      var r = (function (e) {
          return (
            (e.Line = "line"),
            (e.Area = "area"),
            (e.Bars = "bars"),
            (e.Candlesticks = "candlesticks"),
            (e.Histogram = "histogram"),
            (e.Baseline = "baseline"),
            (e.PrettyHistogram = "pretty-histogram"),
            e
          );
        })({}),
        s = (function (e) {
          return (
            (e[(e.NoSuchSymbol = 0)] = "NoSuchSymbol"),
            (e[(e.NoPermission = 1)] = "NoPermission"),
            (e[(e.NoData = 2)] = "NoData"),
            (e[(e.DataError = 3)] = "DataError"),
            (e[(e.IntradaySpreadError = 4)] = "IntradaySpreadError"),
            e
          );
        })({}),
        n = (function (e) {
          return (
            (e[(e.Pre = 0)] = "Pre"),
            (e[(e.Post = 1)] = "Post"),
            (e[(e.Regular = 2)] = "Regular"),
            (e[(e.Night = 3)] = "Night"),
            e
          );
        })({});
    },
    834758(e, t, i) {
      "use strict";
      function r(e, t, i, r = 0, s = e.length) {
        return (function (e, t, i, r, s) {
          let n = s - r;
          for (; 0 < n; ) {
            const s = n >> 1,
              l = r + s;
            i(e(l), t) ? ((r = l + 1), (n -= s + 1)) : (n = s);
          }
          return r;
        })((t) => e[t], t, i, r, s);
      }
      function s(e, t, i, r = 0, s = e.length) {
        let n = s - r;
        for (; 0 < n; ) {
          const s = n >> 1,
            l = r + s;
          i(t, e[l]) ? (n = s) : ((r = l + 1), (n -= s + 1));
        }
        return r;
      }
      i.d(t, { lowerbound: () => r, upperbound: () => s });
    },
    521239(e, t, i) {
      "use strict";
      i.d(t, { combine: () => n });
      var r = i(140136);
      function s(e, t, ...i) {
        let s = null;
        const n = (...t) => e(...t.map((e) => e.value()), s?.value()),
          l = (s = new r.WatchedValue(n(...i))),
          o = () => {
            const e = i.map((e, t) => e.value());
            t(...e) && l.setValue(n(...i));
          },
          a = i.map((e) => e.spawn());
        for (const e of a) e.subscribe(o);
        return l.readonly().spawn(() => {
          a.forEach((e) => e.destroy()), i.forEach((e) => e.release());
        });
      }
      function n(e, ...t) {
        return s(e, () => !0, ...t);
      }
    },
    253808(e, t, i) {
      "use strict";
      i.d(t, {
        dateFormatFunctions: () => x,
        getDateFormatWithWeekday: () => M,
      });
      var r = i(383636),
        s = i(948102),
        n = i(135277);
      const l = {
          1: () => r.t(null, void 0, i(657374)),
          2: () => r.t(null, void 0, i(617341)),
          3: () => r.t(null, void 0, i(103305)),
          4: () => r.t(null, void 0, i(526785)),
          5: () => r.t(null, { context: "short" }, i(734750)),
          6: () => r.t(null, void 0, i(87745)),
          7: () => r.t(null, void 0, i(183959)),
          8: () => r.t(null, void 0, i(93762)),
          9: () => r.t(null, void 0, i(178469)),
          10: () => r.t(null, void 0, i(728337)),
          11: () => r.t(null, void 0, i(646545)),
          12: () => r.t(null, void 0, i(769036)),
        },
        o = {
          1: () => r.t(null, void 0, i(89767)),
          2: () => r.t(null, void 0, i(948923)),
          3: () => r.t(null, void 0, i(367935)),
          4: () => r.t(null, void 0, i(175507)),
        },
        a = (e, t) => (t ? e.getMonth() : e.getUTCMonth()) + 1,
        u = (e, t) => (t ? e.getDate() : e.getUTCDate()),
        c = (e, t) => (t ? e.getFullYear() : e.getUTCFullYear()),
        d = (e, t) =>
          e.toLocaleDateString(
            (0, n.getLanguage)()
              ? (0, n.mapLanguageCode)((0, n.getLanguage)())
              : void 0,
            { weekday: "short", timeZone: "local" === t ? void 0 : t }
          ),
        m = (e, t) => o[((e, t) => Math.floor((a(e, t) - 1) / 3) + 1)(e, t)](),
        g = (e, t) => (0, s.numberToStringWithLeadingZero)(u(e, t), 2),
        h = (e, t) => l[a(e, t)](),
        p = (e, t) => (0, s.numberToStringWithLeadingZero)(a(e, t), 2),
        y = (e, t) => (0, s.numberToStringWithLeadingZero)(c(e, t) % 100, 2),
        v = (e, t) => (0, s.numberToStringWithLeadingZero)(c(e, t), 4),
        x = {
          "qq 'yy": (e, t) => `${m(e, t)} '${y(e, t)}`,
          "qq yyyy": (e, t) => `${m(e, t)} ${v(e, t)}`,
          "dd MMM 'yy": (e, t) => `${g(e, t)} ${h(e, t)} '${y(e, t)}`,
          "MMM 'yy": (e, t) => `${h(e, t)} '${y(e, t)}`,
          "MMM dd, yyyy": (e, t) => `${h(e, t)} ${g(e, t)}, ${v(e, t)}`,
          "MMM d, yyyy": (e, t) =>
            `${h(e, t)} ${((e, t) =>
              (0, s.numberToStringWithLeadingZero)(u(e, t), 0))(e, t)}, ${v(
              e,
              t
            )}`,
          "MMM yyyy": (e, t) => `${h(e, t)} ${v(e, t)}`,
          "MMM dd": (e, t) => `${h(e, t)} ${g(e, t)}`,
          "dd MMM": (e, t) => `${g(e, t)} ${h(e, t)}`,
          "yyyy-MM-dd": (e, t) => `${v(e, t)}-${p(e, t)}-${g(e, t)}`,
          "yy-MM-dd": (e, t) => `${y(e, t)}-${p(e, t)}-${g(e, t)}`,
          "yy/MM/dd": (e, t) => `${y(e, t)}/${p(e, t)}/${g(e, t)}`,
          "yyyy/MM/dd": (e, t) => `${v(e, t)}/${p(e, t)}/${g(e, t)}`,
          "dd-MM-yyyy": (e, t) => `${g(e, t)}-${p(e, t)}-${v(e, t)}`,
          "dd-MM-yy": (e, t) => `${g(e, t)}-${p(e, t)}-${y(e, t)}`,
          "dd/MM/yy": (e, t) => `${g(e, t)}/${p(e, t)}/${y(e, t)}`,
          "dd/MM/yyyy": (e, t) => `${g(e, t)}/${p(e, t)}/${v(e, t)}`,
          "MM/dd/yy": (e, t) => `${p(e, t)}/${g(e, t)}/${y(e, t)}`,
          "MM/dd/yyyy": (e, t) => `${p(e, t)}/${g(e, t)}/${v(e, t)}`,
        };
      function M(e, t) {
        return "ja" === (0, n.getLanguage)()
          ? (i, r) => `${x[e](i, r)} (${d(i, t)})`
          : (i, r) => `${d(i, t)} ${x[e](i, r)}`;
      }
      Object.keys(x);
    },
    769215(e, t, i) {
      "use strict";
      i.d(t, { prepareCurrencyValue: () => s });
      var r = i(383636);
      function s(e) {
        let t = [];
        const i = e.currency_code
            ? n(e.currency_code)
            : n(e.value_unit_id || "", e.value_unit_info),
          r = e.unit_info?.name || e.unit_id;
        switch (e.measure) {
          case "price":
          case "unit":
            t = [i, r];
            break;
          default:
            t = [i];
        }
        return t.filter(Boolean).join(" / ");
      }
      function n(e, t) {
        switch (e) {
          case "PCT":
          case "PCTPAR":
            return "%";
          case "PCTGDP":
            return r.t(null, { context: "_max_len_9" }, i(558412));
          case "DEGC":
            return "℃";
          default:
            return t?.name || e;
        }
      }
    },
    365907(e, t, i) {
      "use strict";
      i.d(t, { createSeriesFormatter: () => l });
      var r = i(958633),
        s = i(377979),
        n = i(174673);
      function l(e, t, i = !1) {
        const {
          priceScale: l,
          minMove: o,
          fractional: a,
          minMove2: u,
          variableMinTick: c,
          noExponentialForm: d,
        } = (function (e, t = "default", i = !1) {
          let r,
            s,
            n,
            l,
            o = 100,
            a = 1;
          if ("default" === t)
            null != e &&
              (({ pricescale: o, minmov: a, minmove2: s, fractional: r } = e),
              (n = e.variable_tick_size || void 0));
          else {
            let e = t.split(",");
            3 !== e.length && (e = ["100", "1", "false"]),
              (o = parseInt(e[0])),
              (a = parseInt(e[1])),
              (r = "true" === e[2]),
              (l = !0);
          }
          return (
            i && (a = 1),
            {
              priceScale: o,
              minMove: a,
              fractional: r,
              minMove2: s,
              variableMinTick: n,
              ignoreMinMove: i,
              noExponentialForm: l,
            }
          );
        })(e, t, i);
        if (null != e) {
          const r = e.format;
          if ("default" === t && "volume" === r)
            return new s.VolumeFormatter({ precision: 2 });
          if ("percent" === r)
            return new n.PercentageFormatter({
              priceScale: l,
              minMove: o,
              fractional: a,
              minMove2: u,
              variableMinTick: c,
              ignoreMinMove: i,
            });
        }
        return new r.PriceFormatter({
          priceScale: l,
          minMove: o,
          fractional: a,
          minMove2: u,
          variableMinTick: c,
          ignoreMinMove: i,
          noExponentialForm: d,
        });
      }
    },
    569531(e, t, i) {
      "use strict";
      i.d(t, { getTimeFormatForInterval: () => s });
      var r = i(525912);
      function s(e, t) {
        if (e.isRange())
          return (function (e) {
            return e === r.TimeHoursFormat.TwelveHours
              ? r.twelveHourMinuteNonZeroSecondFormat
              : r.hourMinuteNonZeroSecondFormat;
          })(t);
        if (e.isTicks()) return r.hourMinuteSecondMillisecFormat;
        return e.isSeconds() || e.isTicks()
          ? (function (e) {
              return e === r.TimeHoursFormat.TwelveHours
                ? r.twelveHourMinuteSecondFormat
                : r.hourMinuteSecondFormat;
            })(t)
          : (function (e) {
              return e === r.TimeHoursFormat.TwelveHours
                ? r.twelveHourMinuteFormat
                : r.hourMinuteFormat;
            })(t);
      }
    },
    342288(e, t, i) {
      "use strict";
      i.d(t, { Interval: () => u, ResolutionKind: () => n });
      const r = /^(\d*)([TSHDWMR])$/,
        s = /^(\d+)$/;
      var n = (function (e) {
        return (
          (e.Ticks = "ticks"),
          (e.Seconds = "seconds"),
          (e.Minutes = "minutes"),
          (e.Days = "days"),
          (e.Weeks = "weeks"),
          (e.Months = "months"),
          (e.Range = "range"),
          (e.Invalid = "invalid"),
          e
        );
      })({});
      const l = { ticks: 1e3, seconds: 1e3 };
      (l.minutes = 60 * l.seconds),
        (l.days = 1440 * l.minutes),
        (l.weeks = 7 * l.days);
      const o = {
          T: "ticks",
          S: "seconds",
          D: "days",
          W: "weeks",
          M: "months",
          R: "range",
        },
        a = new Set(["ticks", "seconds", "minutes"]);
      class u {
        kind() {
          return this._kind;
        }
        guiKind() {
          return this.isMinuteHours() ? "hours" : this._kind;
        }
        multiplier() {
          return this._multiplier;
        }
        isValid() {
          return "invalid" !== this.kind() && this.multiplier() > 0;
        }
        isDWM() {
          return (
            this.isValid() &&
            !this.isRange() &&
            !this.isIntraday() &&
            !this.isTicks()
          );
        }
        isIntraday() {
          const e = a.has(this.kind());
          return this.isValid() && e;
        }
        isSeconds() {
          return "seconds" === this.kind();
        }
        isMinutes() {
          return "minutes" === this.kind();
        }
        isMinuteHours() {
          return (
            "minutes" === this.kind() &&
            (e = this.multiplier()) >= 60 &&
            !(e % 60)
          );
          var e;
        }
        isDays() {
          return "days" === this.kind();
        }
        isWeeks() {
          return "weeks" === this.kind();
        }
        isMonths() {
          return "months" === this.kind();
        }
        isRange() {
          return "range" === this.kind();
        }
        isTicks() {
          return "ticks" === this.kind();
        }
        is1Tick() {
          return this.isTicks() && 1 === this.multiplier();
        }
        isTimeBased() {
          return !this.isRange();
        }
        letter() {
          return this.isValid() && "minutes" !== this.kind()
            ? this.kind()[0].toUpperCase()
            : "";
        }
        value() {
          return this.isValid()
            ? "minutes" === this.kind()
              ? this.multiplier() + ""
              : this.multiplier() + this.letter()
            : "";
        }
        isEqualTo(e) {
          if (!(e instanceof u)) throw new Error("Argument is not an Interval");
          return (
            !(!this.isValid() || !e.isValid()) &&
            this.kind() === e.kind() &&
            this.multiplier() === e.multiplier()
          );
        }
        inMilliseconds(e = Date.now()) {
          if (!this.isValid() || this.isRange()) return NaN;
          if (this.isMonths()) {
            const t = new Date(e);
            t.setUTCMonth(t.getUTCMonth() + (this.multiplier() || 1));
            return +t - e;
          }
          const t = this.multiplier();
          return l[this.kind()] * t;
        }
        static isEqual(e, t) {
          return e === t || u.parse(e).isEqualTo(u.parse(t));
        }
        static parseExt(e) {
          e = (e + "").toUpperCase().split(",")[0];
          let t = r.exec(e);
          return null !== t
            ? "H" === t[2]
              ? {
                  interval: new u("minutes", 60 * c(t[1])),
                  guiResolutionKind: "hours",
                }
              : {
                  interval: new u(o[t[2]], c(t[1])),
                  guiResolutionKind: o[t[2]],
                }
            : ((t = s.exec(e)),
              null !== t
                ? {
                    interval: new u("minutes", c(t[1])),
                    guiResolutionKind: "minutes",
                  }
                : {
                    interval: new u("invalid", 0),
                    guiResolutionKind: "invalid",
                  });
        }
        static parse(e) {
          return u.parseExt(e).interval;
        }
        static kind(e) {
          return u.parse(e).kind();
        }
        static isValid(e) {
          return u.parse(e).isValid();
        }
        static isDWM(e) {
          return u.parse(e).isDWM();
        }
        static isIntraday(e) {
          return u.parse(e).isIntraday();
        }
        static isSeconds(e) {
          return u.parse(e).isSeconds();
        }
        static isMinutes(e) {
          return u.parse(e).isMinutes();
        }
        static isMinuteHours(e) {
          return u.parse(e).isMinuteHours();
        }
        static isDays(e) {
          return u.parse(e).isDays();
        }
        static isWeeks(e) {
          return u.parse(e).isWeeks();
        }
        static isMonths(e) {
          return u.parse(e).isMonths();
        }
        static isRange(e) {
          return u.parse(e).isRange();
        }
        static isTicks(e) {
          return u.parse(e).isTicks();
        }
        static isTimeBased(e) {
          return u.parse(e).isTimeBased();
        }
        static normalize(e) {
          const t = u.parse(e);
          return t.isValid() ? t.value() : null;
        }
        constructor(e, t) {
          (this._kind = "invalid"),
            (this._multiplier = 0),
            "invalid" !== e &&
              t > 0 &&
              ((this._kind = e), (this._multiplier = t));
        }
      }
      function c(e) {
        return 0 === e.length ? 1 : parseInt(e, 10);
      }
    },
    182002(e, t, i) {
      "use strict";
      i.d(t, { getTimeFrames: () => l });
      var r = i(383636),
        s = i(80365),
        n = i(164732);
      function l(e) {
        return {
          "1d": {
            text: r.t(null, void 0, i(938100)),
            value: { value: "1D", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["1D"] ?? (0, n.stringAsResolution)("1"),
            description: (0, n.daysStringLiteral)(1),
          },
          "5d": {
            text: r.t(null, void 0, i(82855)),
            value: { value: "5D", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["5D"] ?? (0, n.stringAsResolution)("5"),
            description: (0, n.daysStringLiteral)(5),
          },
          "1w": {
            text: r.t(null, void 0, i(492135)),
            value: { value: "7D", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["5W"] ?? (0, n.stringAsResolution)("15"),
            description: (0, n.weeksStringLiteral)(1),
          },
          "1m": {
            text: r.t(null, void 0, i(832733)),
            value: { value: "1M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["1M"] ?? (0, n.stringAsResolution)("30"),
            description: (0, n.monthsStringLiteral)(1),
          },
          "3m": {
            text: r.t(null, void 0, i(819078)),
            value: { value: "3M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["3M"] ?? (0, n.stringAsResolution)("60"),
            description: (0, n.monthsStringLiteral)(3),
          },
          "6m": {
            text: r.t(null, void 0, i(68076)),
            value: { value: "6M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["6M"] ?? (0, n.stringAsResolution)("120"),
            description: (0, n.monthsStringLiteral)(6),
          },
          "12m": {
            text: r.t(null, void 0, i(770303)),
            value: { value: "12M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["12M"] ?? (0, n.stringAsResolution)("1D"),
            description: (0, n.yearsStringLiteral)(1),
          },
          "24m": {
            text: r.t(null, void 0, i(934777)),
            value: { value: "24M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["24M"] ?? (0, n.stringAsResolution)("1W"),
            description: (0, n.yearsStringLiteral)(2),
          },
          "36m": {
            text: r.t(null, void 0, i(272098)),
            value: { value: "36M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["36M"] ?? (0, n.stringAsResolution)("1W"),
            description: (0, n.yearsStringLiteral)(3),
          },
          "60m": {
            text: r.t(null, void 0, i(446560)),
            value: { value: "60M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["60M"] ?? (0, n.stringAsResolution)("1W"),
            description: (0, n.yearsStringLiteral)(5),
          },
          "120m": {
            text: r.t(null, void 0, i(995066)),
            value: { value: "120M", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.["120M"] ?? (0, n.stringAsResolution)("1M"),
            description: (0, n.yearsStringLiteral)(10),
          },
          ytd: {
            text: r.t(null, void 0, i(422369)),
            value: { value: "YTD", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.YTD ?? (0, n.stringAsResolution)("1D"),
            description: r.t(null, void 0, i(485420)),
          },
          all: {
            text: r.t(null, void 0, i(233690)),
            value: { value: "ALL", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.ALL ?? (0, n.stringAsResolution)("1M"),
          },
          lastsession: {
            text: r.t(null, void 0, i(938100)),
            value: { value: "LASTSESSION", type: s.TimeFrameType.PeriodBack },
            targetResolution: e?.LASTSESSION ?? (0, n.stringAsResolution)("1"),
            description: (0, n.daysStringLiteral)(1),
          },
        };
      }
    },
    164732(e, t, i) {
      "use strict";
      i.d(t, {
        daysStringLiteral: () => s,
        monthsStringLiteral: () => l,
        stringAsResolution: () => a,
        weeksStringLiteral: () => n,
        yearsStringLiteral: () => o,
      });
      var r = i(383636);
      const s = (e) =>
          r.t(
            null,
            { plural: "{str} days", count: e, replace: { str: `${e}` } },
            i(103030)
          ),
        n = (e) =>
          r.t(
            null,
            { plural: "{str} weeks", count: e, replace: { str: `${e}` } },
            i(644625)
          ),
        l = (e) =>
          r.t(
            null,
            { plural: "{str} months", count: e, replace: { str: `${e}` } },
            i(694617)
          ),
        o = (e) =>
          r.t(
            null,
            { plural: "{str} years", count: e, replace: { str: `${e}` } },
            i(216402)
          ),
        a = (e) => e;
    },
    166447(e, t, i) {
      "use strict";
      i.d(t, { getActualTimeFrame: () => s });
      var r = i(182002);
      function s(e) {
        const t = new Set(
          Object.values((0, r.getTimeFrames)()).map((e) => e.value.value)
        );
        if (t.has(e)) return e;
        const i = e.toUpperCase();
        return t.has(i) ? i : "12M";
      }
    },
    951536(e, t, i) {
      "use strict";
      i.d(t, { getCircleLogoAnyHtml: () => n });
      var r = i(987056),
        s = i(710776);
      function n(e) {
        const { logoUrls: t, ...i } = e;
        return 1 === t.length
          ? (0, r.getCircleLogoHtml)({ logoUrl: t[0], ...i })
          : 2 === t.length
          ? (0, s.getCircleLogoPairHtml)({
              primaryLogoUrl: t[0],
              secondaryLogoUrl: t[1],
              ...i,
            })
          : (0, r.getCircleLogoHtml)({ logoUrl: void 0, ...i });
      }
    },
    710776(e, t, i) {
      "use strict";
      i.d(t, { getCircleLogoPairHtml: () => n });
      var r = i(805733),
        s = i(16934);
      function n(e) {
        const {
          primaryLogoUrl: t,
          secondaryLogoUrl: i,
          size: r,
          className: n,
        } = e;
        return `<span class="${(0, s.getBlockStyleClasses)(r, n)}">\n\t\t\t${l({
          logoUrl: i,
          size: r,
        })}\n\t\t\t${l({ logoUrl: t, size: r })}\n\t\t</span>`;
      }
      function l(e) {
        const { logoUrl: t, size: i } = e,
          n = (0, s.getLogoStyleClasses)(
            i,
            r.CircleLogoLifeCycle.Complete,
            Boolean(t)
          );
        return void 0 === t
          ? `<span class="${n}"></span>`
          : `<img class="${n}" crossorigin src="${t}" alt="" />`;
      }
    },
    16934(e, t, i) {
      "use strict";
      i.d(t, { getBlockStyleClasses: () => u, getLogoStyleClasses: () => c });
      var r = i(914487),
        s = i.n(r),
        n = i(805733),
        l = i(405114),
        o = i(585752),
        a = i.n(o);
      function u(e, t) {
        return s()(a().pair, a()[e], t);
      }
      function c(e, t = n.CircleLogoLifeCycle.Complete, i = !0) {
        return s()(
          a().logo,
          a()[e],
          a().skeleton,
          l.skeletonTheme.wrapper,
          !i && a().empty,
          t === n.CircleLogoLifeCycle.Loading && s()(l.skeletonTheme.animated)
        );
      }
    },
    987056(e, t, i) {
      "use strict";
      i.d(t, { getCircleLogoHtml: () => n });
      var r = i(805733),
        s = i(618641);
      i(294088);
      function n(e) {
        const t = (0, s.getStyleClasses)(
          e.size,
          r.CircleLogoLifeCycle.Complete,
          e.className
        );
        return (0, s.isCircleLogoWithUrlProps)(e)
          ? `<img class="${t}" crossorigin src="${e.logoUrl}" alt="">`
          : `<span class="${t}">${e.placeholderLetter || ""}</span>`;
      }
    },
    805733(e, t, i) {
      "use strict";
      i.d(t, { CircleLogoLifeCycle: () => s, CircleLogoSize: () => r });
      var r = (function (e) {
          return (
            (e.XXCeptionallySmallDoNotUse_BRV1023 =
              "xxceptionallysmalldonotusebrv1023"),
            (e.XXXXSmall = "xxxxsmall"),
            (e.XXXSmall = "xxxsmall"),
            (e.XXSmall = "xxsmall"),
            (e.XSmall = "xsmall"),
            (e.Small = "small"),
            (e.Medium = "medium"),
            (e.Large = "large"),
            (e.XLarge = "xlarge"),
            (e.XXLarge = "xxlarge"),
            (e.XXXLarge = "xxxlarge"),
            e
          );
        })({}),
        s = (function (e) {
          return (
            (e[(e.Pre = 0)] = "Pre"),
            (e[(e.Loading = 1)] = "Loading"),
            (e[(e.Complete = 2)] = "Complete"),
            (e[(e.Error = 3)] = "Error"),
            e
          );
        })({});
    },
    618641(e, t, i) {
      "use strict";
      i.d(t, { getStyleClasses: () => u, isCircleLogoWithUrlProps: () => c });
      var r = i(914487),
        s = i.n(r),
        n = i(805733),
        l = i(405114),
        o = i(294088),
        a = i.n(o);
      function u(e, t = n.CircleLogoLifeCycle.Complete, i) {
        return s()(
          a().logo,
          a()[e],
          i,
          t === n.CircleLogoLifeCycle.Pre || t === n.CircleLogoLifeCycle.Loading
            ? s()(l.skeletonTheme.wrapper, a().skeleton)
            : a().letter,
          t === n.CircleLogoLifeCycle.Loading && l.skeletonTheme.animated
        );
      }
      function c(e) {
        return (
          "logoUrl" in e &&
          null !== e.logoUrl &&
          void 0 !== e.logoUrl &&
          0 !== e.logoUrl.length
        );
      }
    },
    405114(e, t, i) {
      "use strict";
      i.d(t, { skeletonTheme: () => s });
      var r = i(987712);
      const s = i.n(r)();
    },
    213610(e, t, i) {
      "use strict";
      i.d(t, { SeriesData: () => d, SeriesPlotIndex: () => l });
      var r = i(146961),
        s = i(382044),
        n = i(125047),
        l = (function (e) {
          return (
            (e[(e.Time = 0)] = "Time"),
            (e[(e.Open = 1)] = "Open"),
            (e[(e.High = 2)] = "High"),
            (e[(e.Low = 3)] = "Low"),
            (e[(e.Close = 4)] = "Close"),
            (e[(e.Volume = 5)] = "Volume"),
            (e[(e.Adt = 6)] = "Adt"),
            e
          );
        })({});
      const o = ["open", "high", "low", "close", "hl2", "hlc3", "ohlc4"];
      const a = {
        open: (e) => e[1],
        high: (e) => e[2],
        low: (e) => e[3],
        close: (e) => e[4],
        hl2: (e) => (e[2] + e[3]) / 2,
        hlc3: (e) => (e[2] + e[3] + e[4]) / 3,
        ohlc4: (e) => (e[1] + e[2] + e[3] + e[4]) / 4,
      };
      function u() {
        const e = new Map();
        return (
          o.forEach((t, i) => {
            e.set(
              t,
              (function (e, t, i) {
                const r = a[t ?? e],
                  s = a[e],
                  n = a[i ?? e];
                return (e, t) => {
                  switch (t) {
                    case 0:
                      return r(e);
                    case 2:
                      return n(e);
                    default:
                      return s(e);
                  }
                };
              })(t)
            );
          }),
          e
        );
      }
      function c(e, t) {
        return null == e[t];
      }
      class d {
        bars() {
          return this.m_bars;
        }
        nsBars() {
          return this.m_nsBars;
        }
        conflatedChunks(e, t) {
          return this._conflatedChunksBuilder.conflatedChunks(e, t);
        }
        mergeRegularBars(e) {
          return this._conflatedChunksBuilder.mergeData(e);
        }
        size() {
          return this.m_bars.size() + this.m_nsBars.size();
        }
        each(e) {
          this.m_bars.each(e), this.m_nsBars.each(e);
        }
        clear() {
          this.m_nsBars.clear(),
            (this.lastProjectionPrice = void 0),
            this._conflatedChunksBuilder.clearData();
        }
        clone() {
          const e = new d();
          return (
            (e.lastProjectionPrice = this.lastProjectionPrice),
            (e.boxSize = this.boxSize),
            (e.reversalAmount = this.reversalAmount),
            (e.m_bars = this.m_bars.clone()),
            (e.m_nsBars = this.m_bars.clone()),
            e
          );
        }
        isEmpty() {
          return this.m_bars.isEmpty() && this.m_nsBars.isEmpty();
        }
        first() {
          return this.m_bars.isEmpty()
            ? this.m_nsBars.first()
            : this.m_bars.first();
        }
        last() {
          return this.m_nsBars.isEmpty()
            ? this.m_bars.last()
            : this.m_nsBars.last();
        }
        search(e, t, i) {
          return this.nsBars().isEmpty()
            ? this.bars().search(e, t, i)
            : this.bars().isEmpty() ||
              (0, r.ensureNotNull)(this.nsBars().firstIndex()) <= e
            ? this.nsBars().search(e, t, i)
            : this.bars().search(e, t, i);
        }
        valueAt(e) {
          const t = this.search(e);
          return null !== t ? t.value : null;
        }
        plotValueToTimePointIndex(e, t, i) {
          if (1 === i) {
            const i = (i, r) => {
                const s = r[t];
                return null != s && e >= s;
              },
              r = this.m_bars.findLast(i);
            if (null !== r) return r.index;
            const s = this.m_nsBars.findLast(i);
            return null !== s ? s.index : this.m_bars.firstIndex();
          }
          if (-1 === i) {
            const i = (i, r) => {
                const s = r[t];
                return null != s && e <= s;
              },
              r = this.m_bars.findFirst(i);
            if (null !== r) return r.index;
            const s = this.m_nsBars.findFirst(i);
            return null !== s ? s.index : this.m_bars.lastIndex();
          }
          throw new Error("plotValueToTimePointIndex: unsupported search mode");
        }
        moveData(e) {
          this._conflatedChunksBuilder.moveData(e), this.m_nsBars.move(e);
        }
        constructor() {
          (this.m_bars = new s.PlotList(u(), c)),
            (this.m_nsBars = new s.PlotList(u(), c)),
            (this._conflatedChunksBuilder = new n.ConflatedChunksBuilder(
              this.m_bars,
              (e) => a[e]
            ));
        }
      }
    },
  },
]);
