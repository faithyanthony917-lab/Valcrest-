(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [85589, 86914],
  {
    228424(e) {
      e.exports = {
        "tv-spinner__container-rotate": "tv-spinner__container-rotate-j4JlrYVH",
        "tv-spinner__container-rotate-rtl":
          "tv-spinner__container-rotate-rtl-j4JlrYVH",
      };
    },
    969301(e, t, s) {
      "use strict";
      s.d(t, { AsyncResourceWrapper: () => r });
      class r {
        destroy() {
          this._resource.resource && this._destroyFn?.(this._resource.resource),
            (this._resource = {
              pendingResource: Promise.reject("Resource is destroyed").catch(
                () => {}
              ),
            }),
            (this._callbacks = []),
            (this._destroyed = !0);
        }
        callFunction(e) {
          this._destroyed ||
            (this._resource.resource
              ? e(this._resource.resource)
              : this._callbacks.push(e));
        }
        get() {
          return this._destroyed || !this._resource.resource
            ? null
            : this._resource.resource;
        }
        promise() {
          return this._resource.pendingResource;
        }
        constructor(e, t) {
          (this._destroyed = !1),
            (this._callbacks = []),
            (this._resource = { pendingResource: e }),
            (this._destroyFn = t),
            e
              .then((e) => {
                if (this._destroyed) this._destroyFn?.(e);
                else {
                  this._resource.resource = e;
                  for (const t of this._callbacks) t(e);
                }
              })
              .finally(() => {
                this._callbacks = [];
              });
        }
      }
    },
    635774(e, t, s) {
      "use strict";
      s.d(t, { WatchedObject: () => o });
      var r = s(881014),
        i = s(140136);
      function a(e, t) {
        return (0, r.deepEquals)(e, t)[0];
      }
      class o extends i.WatchedValue {
        setValue(e, t) {
          (!t && this._comparator(this.value(), e)) || super.setValue(e, t);
        }
        constructor(e, t = a) {
          super(e), (this._comparator = t);
        }
      }
    },
    178845(e, t, s) {
      "use strict";
      s.d(t, { DateFormatter: () => a });
      var r = s(253808);
      class i {
        format(e) {
          return this._dateFormatFunc(e, !1);
        }
        formatLocal(e) {
          return this._dateFormatFunc(e, !0);
        }
        parse(e) {
          return "" === e ? { res: !1 } : { res: !0, value: e };
        }
        constructor(e = "yyyy-MM-dd", t = !1, s = "UTC") {
          this._dateFormatFunc = t
            ? (0, r.getDateFormatWithWeekday)(e, s)
            : r.dateFormatFunctions[e];
        }
      }
      class a {
        format(e) {
          return a._customFormatter
            ? a._customFormatter.format(e)
            : this._dateFormatterInstance.format(e);
        }
        formatLocal(e) {
          return a._customFormatter
            ? a._customFormatter.formatLocal(e)
            : this._dateFormatterInstance.formatLocal(e);
        }
        parse(e) {
          return a._customFormatter
            ? a._customFormatter.parse(e)
            : this._dateFormatterInstance.parse(e);
        }
        static setCustomFormatter(e) {
          a._customFormatter = e;
        }
        constructor(e, t, s) {
          this._dateFormatterInstance = new i(e, t, s);
        }
      }
      a._customFormatter = null;
    },
    384229(e, t, s) {
      "use strict";
      s.d(t, { DateTimeFormatter: () => n });
      var r = s(525912),
        i = s(178845),
        a = s(54480);
      const o = {
        dateFormat: "yyyy-MM-dd",
        withWeekday: !1,
        timeFormat: r.hourMinuteSecondFormat,
        dateTimeSeparator: " ",
      };
      class n {
        format(e, t) {
          const s = t?.dateTimeSeparator ?? this._separator;
          return `${this._dateFormatter.format(
            e
          )}${s}${this._timeFormatter.format(e)}`;
        }
        formatLocal(e, t) {
          const s = t?.dateTimeSeparator ?? this._separator;
          return `${this._dateFormatter.formatLocal(
            e
          )}${s}${this._timeFormatter.formatLocal(e)}`;
        }
        constructor(e = {}) {
          const t = Object.assign({}, o, e);
          (this._dateFormatter = new i.DateFormatter(
            t.dateFormat,
            t.withWeekday,
            t.timezone
          )),
            (this._timeFormatter = new a.TimeFormatter(t.timeFormat)),
            (this._separator = t.dateTimeSeparator);
        }
      }
    },
    525912(e, t, s) {
      "use strict";
      s.d(t, {
        TimeHoursFormat: () => h,
        hourMinuteFormat: () => o,
        hourMinuteNonZeroSecondFormat: () => i,
        hourMinuteSecondFormat: () => r,
        hourMinuteSecondMillisecFormat: () => a,
        twelveHourMinuteFormat: () => d,
        twelveHourMinuteNonZeroSecondFormat: () => l,
        twelveHourMinuteSecondFormat: () => n,
      });
      const r = "%h:%m:%s",
        i = "%h:%m:%s+",
        a = "%h:%m:%s.%ss+",
        o = "%h:%m",
        n = "%h:%m:%s %ampm",
        l = "%h:%m:%s+ %ampm",
        d = "%h:%m %ampm";
      var h = (function (e) {
        return (
          (e.TwentyFourHours = "24-hours"), (e.TwelveHours = "12-hours"), e
        );
      })({});
    },
    54480(e, t, s) {
      "use strict";
      s.d(t, { TimeFormatter: () => o });
      var r = s(525912),
        i = s(948102);
      class a {
        format(e) {
          return this._formatTime(e);
        }
        formatLocal(e) {
          return this._formatTime(e, !0);
        }
        _formatTime(e, t = !1) {
          let s = t ? e.getHours() : e.getUTCHours();
          const r = t ? e.getMinutes() : e.getUTCMinutes(),
            a = t ? e.getSeconds() : e.getUTCSeconds(),
            o = t ? e.getMilliseconds() : e.getUTCMilliseconds();
          let n = "";
          this._isTwelveHoursFormat &&
            ((n = s >= 12 ? "PM" : "AM"), (s %= 12), (s = s || 12));
          let l = "",
            d = !1;
          for (let e = this._valuesAndDelimiters.length - 1; e >= 0; e--) {
            const t = this._valuesAndDelimiters[e];
            let h;
            switch (t) {
              case "%h":
                h = (0, i.numberToStringWithLeadingZero)(s, 2);
                break;
              case "%m":
                h = (0, i.numberToStringWithLeadingZero)(r, 2);
                break;
              case "%s+":
                0 !== a
                  ? (h = (0, i.numberToStringWithLeadingZero)(a, 2))
                  : ((h = ""), (d = !0));
                break;
              case "%s":
                h = (0, i.numberToStringWithLeadingZero)(a, 2);
                break;
              case "%ss":
                h = (0, i.numberToStringWithLeadingZero)(o, 3);
                break;
              case "%ss+":
                0 !== o
                  ? (h = (0, i.numberToStringWithLeadingZero)(o, 3))
                  : ((h = ""), (d = !0));
                break;
              case "%ampm":
                h = n;
                break;
              default:
                if (d) {
                  d = !1;
                  continue;
                }
                h = t;
            }
            l = h + l;
          }
          return l;
        }
        constructor(e) {
          (this._isTwelveHoursFormat = !1), (this._valuesAndDelimiters = []);
          const t = e || r.hourMinuteSecondFormat,
            s = new RegExp("%h|%m|%s\\+|%ss\\+|%ss|%ampm|%s", "g");
          let i = s.exec(t),
            a = 0;
          for (; null !== i; ) {
            const e = i[0];
            "%ampm" === e && (this._isTwelveHoursFormat = !0);
            const r = t.substring(a, i.index);
            "" !== r && this._valuesAndDelimiters.push(r),
              this._valuesAndDelimiters.push(e),
              (a = i.index + e.length),
              (i = s.exec(t));
          }
        }
      }
      class o {
        format(e) {
          return o._customFormatter
            ? o._customFormatter.format(e)
            : this._timeFormatterInstance.format(e);
        }
        formatLocal(e) {
          return o._customFormatter
            ? o._customFormatter.formatLocal(e)
            : this._timeFormatterInstance.formatLocal(e);
        }
        static setCustomFormatter(e) {
          o._customFormatter = e;
        }
        constructor(e) {
          this._timeFormatterInstance = new a(e);
        }
      }
      o._customFormatter = null;
    },
    358237(e, t, s) {
      "use strict";
      s.d(t, { tryParseNamedRgba: () => i });
      const r = new Map([
        ["aliceblue", "#f0f8ff"],
        ["antiquewhite", "#faebd7"],
        ["aqua", "#00ffff"],
        ["aquamarine", "#7fffd4"],
        ["azure", "#f0ffff"],
        ["beige", "#f5f5dc"],
        ["bisque", "#ffe4c4"],
        ["black", "#000000"],
        ["blanchedalmond", "#ffebcd"],
        ["blue", "#0000ff"],
        ["blueviolet", "#8a2be2"],
        ["brown", "#a52a2a"],
        ["burlywood", "#deb887"],
        ["cadetblue", "#5f9ea0"],
        ["chartreuse", "#7fff00"],
        ["chocolate", "#d2691e"],
        ["coral", "#ff7f50"],
        ["cornflowerblue", "#6495ed"],
        ["cornsilk", "#fff8dc"],
        ["crimson", "#dc143c"],
        ["cyan", "#00ffff"],
        ["darkblue", "#00008b"],
        ["darkcyan", "#008b8b"],
        ["darkgoldenrod", "#b8860b"],
        ["darkgray", "#a9a9a9"],
        ["darkgreen", "#006400"],
        ["darkkhaki", "#bdb76b"],
        ["darkmagenta", "#8b008b"],
        ["darkolivegreen", "#556b2f"],
        ["darkorange", "#ff8c00"],
        ["darkorchid", "#9932cc"],
        ["darkred", "#8b0000"],
        ["darksalmon", "#e9967a"],
        ["darkseagreen", "#8fbc8f"],
        ["darkslateblue", "#483d8b"],
        ["darkslategray", "#2f4f4f"],
        ["darkturquoise", "#00ced1"],
        ["darkviolet", "#9400d3"],
        ["deeppink", "#ff1493"],
        ["deepskyblue", "#00bfff"],
        ["dimgray", "#696969"],
        ["dodgerblue", "#1e90ff"],
        ["feldspar", "#d19275"],
        ["firebrick", "#b22222"],
        ["floralwhite", "#fffaf0"],
        ["forestgreen", "#228b22"],
        ["fuchsia", "#ff00ff"],
        ["gainsboro", "#dcdcdc"],
        ["ghostwhite", "#f8f8ff"],
        ["gold", "#ffd700"],
        ["goldenrod", "#daa520"],
        ["gray", "#808080"],
        ["green", "#008000"],
        ["greenyellow", "#adff2f"],
        ["honeydew", "#f0fff0"],
        ["hotpink", "#ff69b4"],
        ["indianred", "#cd5c5c"],
        ["indigo", "#4b0082"],
        ["ivory", "#fffff0"],
        ["khaki", "#f0e68c"],
        ["lavender", "#e6e6fa"],
        ["lavenderblush", "#fff0f5"],
        ["lawngreen", "#7cfc00"],
        ["lemonchiffon", "#fffacd"],
        ["lightblue", "#add8e6"],
        ["lightcoral", "#f08080"],
        ["lightcyan", "#e0ffff"],
        ["lightgoldenrodyellow", "#fafad2"],
        ["lightgreen", "#90ee90"],
        ["lightgrey", "#d3d3d3"],
        ["lightpink", "#ffb6c1"],
        ["lightsalmon", "#ffa07a"],
        ["lightseagreen", "#20b2aa"],
        ["lightskyblue", "#87cefa"],
        ["lightslateblue", "#8470ff"],
        ["lightslategray", "#778899"],
        ["lightsteelblue", "#b0c4de"],
        ["lightyellow", "#ffffe0"],
        ["lime", "#00ff00"],
        ["limegreen", "#32cd32"],
        ["linen", "#faf0e6"],
        ["magenta", "#ff00ff"],
        ["maroon", "#800000"],
        ["mediumaquamarine", "#66cdaa"],
        ["mediumblue", "#0000cd"],
        ["mediumorchid", "#ba55d3"],
        ["mediumpurple", "#9370d8"],
        ["mediumseagreen", "#3cb371"],
        ["mediumslateblue", "#7b68ee"],
        ["mediumspringgreen", "#00fa9a"],
        ["mediumturquoise", "#48d1cc"],
        ["mediumvioletred", "#c71585"],
        ["midnightblue", "#191970"],
        ["mintcream", "#f5fffa"],
        ["mistyrose", "#ffe4e1"],
        ["moccasin", "#ffe4b5"],
        ["navajowhite", "#ffdead"],
        ["navy", "#000080"],
        ["oldlace", "#fdf5e6"],
        ["olive", "#808000"],
        ["olivedrab", "#6b8e23"],
        ["orange", "#ffa500"],
        ["orangered", "#ff4500"],
        ["orchid", "#da70d6"],
        ["palegoldenrod", "#eee8aa"],
        ["palegreen", "#98fb98"],
        ["paleturquoise", "#afeeee"],
        ["palevioletred", "#d87093"],
        ["papayawhip", "#ffefd5"],
        ["peachpuff", "#ffdab9"],
        ["peru", "#cd853f"],
        ["pink", "#ffc0cb"],
        ["plum", "#dda0dd"],
        ["powderblue", "#b0e0e6"],
        ["purple", "#800080"],
        ["red", "#ff0000"],
        ["rosybrown", "#bc8f8f"],
        ["royalblue", "#4169e1"],
        ["saddlebrown", "#8b4513"],
        ["salmon", "#fa8072"],
        ["sandybrown", "#f4a460"],
        ["seagreen", "#2e8b57"],
        ["seashell", "#fff5ee"],
        ["sienna", "#a0522d"],
        ["silver", "#c0c0c0"],
        ["skyblue", "#87ceeb"],
        ["slateblue", "#6a5acd"],
        ["slategray", "#708090"],
        ["snow", "#fffafa"],
        ["springgreen", "#00ff7f"],
        ["steelblue", "#4682b4"],
        ["tan", "#d2b48c"],
        ["teal", "#008080"],
        ["thistle", "#d8bfd8"],
        ["tomato", "#ff6347"],
        ["turquoise", "#40e0d0"],
        ["violet", "#ee82ee"],
        ["violetred", "#d02090"],
        ["wheat", "#f5deb3"],
        ["white", "#ffffff"],
        ["whitesmoke", "#f5f5f5"],
        ["yellow", "#ffff00"],
        ["yellowgreen", "#9acd32"],
      ]);
      function i(e) {
        const t = r.get(e);
        if (void 0 === t) return null;
        return [
          parseInt(t.slice(1, 3), 16),
          parseInt(t.slice(3, 5), 16),
          parseInt(t.slice(5, 7), 16),
          1,
        ];
      }
    },
    825280(e, t, s) {
      "use strict";
      s.d(t, { Spinner: () => a });
      s(228424);
      var r = s(304635),
        i = s(833669);
      class a {
        spin(e) {
          return (
            this._el.classList.add("tv-spinner--shown"),
            void 0 === this._container &&
              ((this._container = e), void 0 !== e && e.appendChild(this._el)),
            (this._shown = !0),
            this
          );
        }
        stop(e) {
          return (
            e &&
              void 0 !== this._container &&
              this._container.removeChild(this._el),
            this._el && this._el.classList.remove("tv-spinner--shown"),
            (this._shown = !1),
            this
          );
        }
        setStyle(e) {
          return (
            Object.keys(e).forEach((t) => {
              const s = e[t];
              void 0 !== s && this._el.style.setProperty(t, s);
            }),
            this
          );
        }
        style() {
          return this._el.style;
        }
        setSize(e) {
          const t = void 0 !== e ? `tv-spinner--size_${e}` : "";
          return (
            (this._el.className = `tv-spinner ${t} ${
              this._shown ? "tv-spinner--shown" : ""
            }`),
            this
          );
        }
        getEl() {
          return this._el;
        }
        destroy() {
          this.stop(), delete this._el, delete this._container;
        }
        constructor(e) {
          (this._shown = !1),
            (this._el = (0, r.parseHtmlElement)(
              (function (e = "") {
                return `<div class="tv-spinner ${e}" role="progressbar"></div>`;
              })()
            )),
            this.setSize(i.spinnerSizeMap[e || i.DEFAULT_SIZE]);
        }
      }
    },
    833669(e, t, s) {
      "use strict";
      s.d(t, { DEFAULT_SIZE: () => r, spinnerSizeMap: () => i });
      const r = "large",
        i = {
          mini: "xsmall",
          xxsmall: "xxsmall",
          xsmall: "xsmall",
          small: "small",
          medium: "medium",
          large: "large",
        };
    },
    136035(e, t, s) {
      "use strict";
      s.d(t, { ChartSession: () => a });
      var r = s(570071),
        i = s(583938);
      class a extends i.Session {
        destroy() {
          this._criticalError.destroy(),
            (this._handler = null),
            this._symbolResolveMap.clear(),
            super.destroy();
        }
        switchTimezone(e) {
          return this._getChartApi().switchTimezone(this.sessionId(), e);
        }
        defaultResolutions() {
          return this._getChartApi().defaultResolutions();
        }
        availableCurrencies() {
          return this._getChartApi().availableCurrencies();
        }
        availableUnits() {
          return this._getChartApi().availableUnits();
        }
        availableMetrics() {
          return this._getChartApi().availableMetrics();
        }
        availablePriceSources(e) {
          return this._getChartApi().availablePriceSources(e);
        }
        resolveSymbol(e, t, s) {
          if (this._symbolResolveMap.has(t)) {
            const [e, r] = this._symbolResolveMap.get(t);
            return Array.isArray(r) ? r.push(s) : r.then(s), e;
          }
          {
            const r = [s];
            return (
              this._getChartApi().resolveSymbol(this.sessionId(), e, t, (s) => {
                if ("symbol_error" === s.method)
                  this._symbolResolveMap.delete(t);
                else {
                  this._symbolResolveMap.set(t, [e, Promise.resolve(s)]);
                  const [, r] = s.params,
                    i = { pro_name: r.pro_name, ticker: r.ticker };
                  this._lastSymbolResolveInfoMap.set(t, i),
                    i.pro_name &&
                      this._lastSymbolResolveInfoMap.set(i.pro_name, i),
                    r.full_name &&
                      this._lastSymbolResolveInfoMap.set(r.full_name, i),
                    i.ticker && this._lastSymbolResolveInfoMap.set(i.ticker, i);
                }
                r.forEach((e) => e(s));
              }),
              this._symbolResolveMap.set(t, [e, r]),
              e
            );
          }
        }
        requestFirstBarTime(e, t, s) {
          return this._getChartApi().requestFirstBarTime(
            this.sessionId(),
            e,
            t,
            s
          );
        }
        lastSymbolResolveInfo(e) {
          return this._lastSymbolResolveInfoMap.get(e) ?? null;
        }
        createSeries(e, t, s, r, i, a, o) {
          return this._getChartApi().createSeries(
            this.sessionId(),
            e,
            t,
            s,
            r,
            i,
            a,
            o
          );
        }
        modifySeries(e, t, s, r, i, a, o) {
          return this._getChartApi().modifySeries(
            this.sessionId(),
            e,
            t,
            s,
            r,
            i,
            a,
            o
          );
        }
        removeSeries(e) {
          return (
            !!this.isConnected().value() &&
            this._getChartApi().removeSeries(this.sessionId(), e)
          );
        }
        requestMoreData(e, t, s) {
          return "number" == typeof e
            ? this._getChartApi().requestMoreData(this.sessionId(), e)
            : this._getChartApi().requestMoreData(this.sessionId(), e, t, s);
        }
        requestMoreTickmarks(e, t, s) {
          return this._getChartApi().requestMoreTickmarks(
            this.sessionId(),
            e,
            t,
            s
          );
        }
        setFutureTickmarksMode(e) {
          return this._getChartApi().setFutureTickmarksMode(
            this.sessionId(),
            e
          );
        }
        canCreateStudy(e, t) {
          return this._getChartApi().canCreateStudy(this.sessionId(), e, t);
        }
        getStudyCounter() {
          return this._getChartApi().getStudyCounter(this.sessionId());
        }
        getFundamentalCounter() {
          return this._getChartApi().getFundamentalCounter(this.sessionId());
        }
        getChildStudyCounter() {
          return this._getChartApi().getChildStudyCounter(this.sessionId());
        }
        createStudy(e, t, s, r, i, a, o) {
          return this._getChartApi().createStudy(
            this.sessionId(),
            e,
            t,
            s,
            r,
            i,
            a,
            o
          );
        }
        modifyStudy(e, t, s, r, i) {
          return this._getChartApi().modifyStudy(
            this.sessionId(),
            e,
            t,
            s,
            r,
            i
          );
        }
        notifyStudy(e, t, s) {
          return this._getChartApi().notifyStudy(this.sessionId(), e, t, s);
        }
        removeStudy(e) {
          return this._getChartApi().removeStudy(this.sessionId(), e);
        }
        createPointset(e, t, s, r, i, a) {
          return this._getChartApi().createPointset(
            this.sessionId(),
            e,
            t,
            s,
            r,
            i,
            a
          );
        }
        modifyPointset(e, t, s, r) {
          return this._getChartApi().modifyPointset(
            this.sessionId(),
            e,
            t,
            s,
            r
          );
        }
        removePointset(e) {
          return this._getChartApi().removePointset(this.sessionId(), e);
        }
        setVisibleTimeRange(e, t, s, r, i, a, o) {
          this._getChartApi().setVisibleTimeRange(
            this.sessionId(),
            e,
            t,
            s,
            r,
            !0,
            i,
            a,
            void 0,
            o
          );
        }
        criticalError() {
          return this._criticalError;
        }
        connect(e = null) {
          null !== e && (this._handler = e),
            this._symbolResolveMap.clear(),
            super.connect();
        }
        setHandler(e) {
          this._handler = e;
        }
        connected() {
          return this.isConnected().value() && !this._sessionDisabled;
        }
        disable() {
          this._sessionDisabled = !0;
        }
        chartApi() {
          return this._getChartApi();
        }
        _sendCreateSession() {
          Object.keys(this).forEach((e) => {
            /^(s|st|symbol_)\d+$/.test(e) && delete this[e];
          }),
            this._getChartApi().chartCreateSession(
              this.sessionId(),
              this._disableStatistics
            );
        }
        _sendRemoveSession() {
          this._getChartApi().chartDeleteSession(this.sessionId());
        }
        _onMessage(e) {
          this._handler && this._handler(e);
        }
        _onCriticalError(e, t) {
          this._criticalError.fire(e, t), super._onCriticalError(e, t);
        }
        constructor(e, t = !1) {
          super(e, "cs", !1),
            (this._sessionDisabled = !1),
            (this._handler = null),
            (this._criticalError = new r.Delegate()),
            (this._symbolResolveMap = new Map()),
            (this._lastSymbolResolveInfoMap = new Map()),
            (this._disableStatistics = t);
        }
      }
    },
    125047(e, t, s) {
      "use strict";
      s.d(t, { ConflatedChunksBuilder: () => o });
      var r = s(146961),
        i = s(834758);
      const a = [
        { barsToMerge: 10, forBarspacingLargerThen: 0.03 },
        { barsToMerge: 30, forBarspacingLargerThen: 0.01 },
        { barsToMerge: 100, forBarspacingLargerThen: 0.003 },
        { barsToMerge: 500, forBarspacingLargerThen: 0 },
      ];
      class o {
        conflatedChunks(e, t) {
          if (t !== this._state.priceSource) {
            this._state.priceSource = t;
            const e = this._plots.first();
            e &&
              (this._setEmptyConflatedChunks(),
              this._rebuildConflatedChunks(e));
          }
          const s = (0, r.ensureDefined)(
            a.find((t) => t.forBarspacingLargerThen <= e)
          );
          return (0, r.ensureDefined)(this._state.chunks.get(s.barsToMerge));
        }
        mergeData(e) {
          const t = this._plots.size(),
            s = this._plots.merge(e);
          return (
            s &&
              null !== this._state.priceSource &&
              (t === this._plots.size() && s.index === this._plots.lastIndex()
                ? this._updateLatestChunks()
                : this._rebuildConflatedChunks(s)),
            s
          );
        }
        moveData(e) {
          this._plots.move(e), this._plots.size() > 0 && this._clearState();
        }
        clearData() {
          this._plots.clear(), this._clearState();
        }
        _rebuildConflatedChunks(e) {
          const t = this._state.priceSource;
          if (null === t) return;
          const s = e.index,
            o = this._state.priceSourcesProvider(t),
            n = (e, t, s) => {
              let r = null;
              for (const i of e) {
                const e = o(i.value);
                r &&
                  i.index - r.startTime >= s.barsToMerge &&
                  (t.push(r), (r = null)),
                  r
                    ? ((r.endTime = i.index),
                      (r.high = Math.max(r.high, e)),
                      (r.low = Math.min(r.low, e)),
                      (r.close = e))
                    : (r = {
                        startTime: i.index,
                        endTime: i.index,
                        open: e,
                        high: e,
                        low: e,
                        close: e,
                      });
              }
              r && t.push(r);
            };
          a.forEach((e) => {
            const t = (0, r.ensureDefined)(
                this._state.chunks.get(e.barsToMerge)
              ),
              a = (0, i.lowerbound)(t, s, (e, t) => e.endTime < t);
            if (0 === a && t.length > 0) {
              const s = t[0].startTime - 1,
                i = (0, r.ensureNotNull)(this._plots.firstIndex()),
                a = this._plots.rangeIterator(i, s),
                o = [];
              n(a, o, e);
              const l = o.concat(t);
              this._state.chunks.set(e.barsToMerge, l);
            } else {
              const s = (0, r.ensureNotNull)(this._plots.lastIndex());
              t.splice(a);
              let i = (0, r.ensureNotNull)(this._plots.firstIndex());
              t.length && (i = t[t.length - 1].endTime + 1);
              const o = this._plots.rangeIterator(i, s);
              n(o, t, e);
            }
          });
        }
        _updateLatestChunks() {
          const e = (0, r.ensureNotNull)(this._plots.last()),
            t = this._state.priceSourcesProvider("close");
          a.forEach((s) => {
            const i = (0, r.ensureDefined)(
                this._state.chunks.get(s.barsToMerge)
              ),
              a = t(e.value),
              o = i[i.length - 1];
            (o.high = Math.max(o.high, a)),
              (o.low = Math.min(o.low, a)),
              (o.close = a),
              (o.endTime = e.index);
          });
        }
        _setEmptyConflatedChunks() {
          a.forEach((e) => this._state.chunks.set(e.barsToMerge, []));
        }
        _clearState() {
          this._state.chunks.clear(), (this._state.priceSource = null);
        }
        constructor(e, t) {
          (this._plots = e),
            (this._state = {
              chunks: new Map(),
              priceSource: null,
              priceSourcesProvider: t,
            }),
            this._setEmptyConflatedChunks();
        }
      }
    },
    700713(e, t, s) {
      "use strict";
      function r(e, t, s, r, i) {
        const {
          payAttentionToTickerNotSymbol: a,
          useTickerOnSymbolInfoUpdate: o,
          chartingLibrarySingleSymbolRequest: n,
          uppercaseInstrumentNames: l,
        } = e;
        let d = t && ((r && t.pro_name) || t.full_name || t.name);
        return (
          n && s
            ? (d = s)
            : (o || (!i && a)) && t && t.ticker && (d = t.ticker),
          l && d && (d = d.toUpperCase()),
          d
        );
      }
      s.d(t, { extractSymbolNameFromSymbolInfo: () => r });
    },
    208345(e, t, s) {
      "use strict";
      s.d(t, { PlotRowSearchMode: () => r });
      var r = (function (e) {
        return (
          (e[(e.NearestLeft = -1)] = "NearestLeft"),
          (e[(e.Exact = 0)] = "Exact"),
          (e[(e.NearestRight = 1)] = "NearestRight"),
          e
        );
      })({});
    },
    426514(e, t, s) {
      "use strict";
      s.d(t, {
        SymbolErrorPermissionDeniedReason: () => r,
        invalidSymbol: () => a,
        permissionDenied: () => i,
      });
      var r = (function (e) {
        return (
          (e.Symbol = "symbol"),
          (e.GroupPermission = "group"),
          (e.BondMetrics = "bond_metrics"),
          e
        );
      })({});
      const i = "permission denied",
        a = "invalid symbol";
    },
    899312(e, t, s) {
      "use strict";
      s.d(t, { parseNonSeriesEnvelope: () => a });
      var r = s(881014),
        i = s(319764);
      function a(e) {
        if ("" === e) return null;
        const t = JSON.parse(e);
        if (!(0, r.isObject)(t) || "function" == typeof t)
          throw new Error("Non-object content in the non-series envelope");
        if ((0, r.hasProperty)(t, "indexes_replace"))
          return { nsData: { indexes_replace: !0 }, parsedData: t };
        const s = {
          indexes_replace: !1,
        };
        if (
          ((0, r.hasProperty)(t, "offsets") && (s.offsets = t.offsets),
          (0, r.hasProperty)(t, "isUpdate"))
        ) {
          if ("boolean" != typeof t.isUpdate)
            throw new Error('Invalid type of "isUpdate" field');
          s.isUpdate = t.isUpdate;
        }
        return (
          (0, r.hasProperty)(t, "data") && (s.data = t.data),
          (0, r.hasProperty)(t, "graphicsCmds") &&
            (s.graphicsCmds = (0, i.validateGraphicsCommands)(t.graphicsCmds)),
          { nsData: s, parsedData: t }
        );
      }
    },
    38747(e, t, s) {
      "use strict";
      s.d(t, { unpackNonSeriesData: () => i });
      var r = s(899312);
      async function i(e) {
        return (0, r.parseNonSeriesEnvelope)(e)?.nsData ?? null;
      }
    },
    464541(e, t, s) {
      "use strict";
      s.d(t, {
        DEFAULT_NUMBARS: () => i,
        initialRequestOptionsToNumBars: () => a,
      });
      var r = s(146961);
      const i = 300;
      function a(e) {
        return e.startDate
          ? e.endDate || e.count
            ? e.endDate
              ? ["from_to", e.startDate, e.endDate]
              : ["bar_count", e.startDate, (0, r.ensure)(e.count)]
            : ["from_to", e.startDate]
          : e.count || i;
      }
    },
    26698(e, t, s) {
      "use strict";
      async function r(e, t) {
        if (void 0 === e) return { projectionPlots: [], boxSize: null };
        if ("" === e.d || "nochange" === e.indexes) return null;
        const s = await t(e.d);
        if (null === s || s.indexes_replace) return null;
        const r = e.indexes,
          { bars: i = [], price: a, boxSize: o, reversalAmount: n } = s.data;
        return {
          lastPrice: a,
          projectionPlots: i.map((e) => {
            let t;
            return (
              "factor" in e
                ? (t = e.factor)
                : "additionalPrice" in e && (t = e.additionalPrice),
              {
                index: r[e.time],
                value: [0, e.open, e.high, e.low, e.close, e.volume, t],
              }
            );
          }),
          reversalAmount: n,
          boxSize: o,
        };
      }
      s.d(t, { parseJapaneseProjectionBars: () => r });
    },
    548903(e, t, s) {
      "use strict";
      s.d(t, { SeriesDataSource: () => C });
      var r = s(146961),
        i = s(881014),
        a = s(819511),
        o = s(342288),
        n = s(213610),
        l = s(426514),
        d = s(38747),
        h = s(464541),
        c = s(419082),
        u = s(570071);
      class m {
        destroy() {
          this._created.destroy(),
            this._modified.destroy(),
            this._loading.destroy(),
            this._completed.destroy(),
            this._error.destroy(),
            this._symbolError.destroy(),
            this._symbolResolved.destroy(),
            this._seriesError.destroy(),
            this._symbolInvalid.destroy(),
            this._symbolNotPermitted.destroy(),
            this._symbolGroupNotPermitted.destroy(),
            this._symbolBondMetricsNotPermitted.destroy(),
            this._chartTypeNotPermitted.destroy(),
            this._intradaySpreadNotPermitted.destroy(),
            this._intradayExchangeNotPermitted.destroy(),
            this._customIntervalNotPermitted.destroy(),
            this._secondsIntervalNotPermitted.destroy(),
            this._ticksIntervalNotPermitted.destroy(),
            this._barReceived.destroy(),
            this._seriesTimeFrame.destroy(),
            this._dataUpdated.destroy(),
            this._unsupportedResolutionRequested.destroy();
        }
        created() {
          return this._created;
        }
        modified() {
          return this._modified;
        }
        cleared() {
          return this._cleared;
        }
        loading() {
          return this._loading;
        }
        completed() {
          return this._completed;
        }
        error() {
          return this._error;
        }
        symbolError() {
          return this._symbolError;
        }
        symbolResolved() {
          return this._symbolResolved;
        }
        seriesError() {
          return this._seriesError;
        }
        symbolInvalid() {
          return this._symbolInvalid;
        }
        symbolNotPermitted() {
          return this._symbolNotPermitted;
        }
        symbolGroupNotPermitted() {
          return this._symbolGroupNotPermitted;
        }
        symbolBondMetricsNotPermitted() {
          return this._symbolBondMetricsNotPermitted;
        }
        chartTypeNotPermitted() {
          return this._chartTypeNotPermitted;
        }
        intradaySpreadNotPermitted() {
          return this._intradaySpreadNotPermitted;
        }
        intradayExchangeNotPermitted() {
          return this._intradayExchangeNotPermitted;
        }
        customIntervalNotPermitted() {
          return this._customIntervalNotPermitted;
        }
        secondsIntervalNotPermitted() {
          return this._secondsIntervalNotPermitted;
        }
        ticksIntervalNotPermitted() {
          return this._ticksIntervalNotPermitted;
        }
        barReceived() {
          return this._barReceived;
        }
        seriesTimeFrame() {
          return this._seriesTimeFrame;
        }
        dataUpdated() {
          return this._dataUpdated;
        }
        unsupportedResolutionRequested() {
          return this._unsupportedResolutionRequested;
        }
        fireCompleted(e) {
          this._completed.fire(e);
        }
        fireCreated(e) {
          this._created.fire(e);
        }
        fireModified() {
          this._modified.fire();
        }
        fireCleared() {
          this._cleared.fire();
        }
        fireLoading(e) {
          this._loading.fire(e);
        }
        fireError() {
          this._error.fire();
        }
        fireSymbolError(e) {
          this._symbolError.fire(e), this.fireError();
        }
        fireSymbolResolved(e) {
          this._symbolResolved.fire(e);
        }
        fireSeriesError(e) {
          this._seriesError.fire(e), this.fireError();
        }
        fireSymbolInvalid() {
          this._symbolInvalid.fire();
        }
        fireSymbolNotPermitted(e) {
          this._symbolNotPermitted.fire(e);
        }
        fireSymbolGroupNotPermitted(e) {
          this._symbolGroupNotPermitted.fire(e);
        }
        fireSymbolBondMetricsNotPermitted(e) {
          this._symbolBondMetricsNotPermitted.fire(e);
        }
        fireChartTypeNotPermitted(e) {
          this._chartTypeNotPermitted.fire(e), this.fireError();
        }
        fireIntradaySpreadNotPermitted() {
          this._intradaySpreadNotPermitted.fire(), this.fireError();
        }
        fireIntradayExchangeNotPermitted() {
          this._intradayExchangeNotPermitted.fire(), this.fireError();
        }
        fireCustomIntervalNotPermitted(e) {
          this._customIntervalNotPermitted.fire(e), this.fireError();
        }
        fireSecondsIntervalNotPermitted() {
          this._secondsIntervalNotPermitted.fire(), this.fireError();
        }
        fireTicksIntervalNotPermitted() {
          this._ticksIntervalNotPermitted.fire(), this.fireError();
        }
        fireBarReceived(e) {
          this._barReceived.fire(e);
        }
        fireSeriesTimeFrame(e, t, s, r, i) {
          this._seriesTimeFrame.fire(e, t, s, r, i);
        }
        fireDataUpdated(e, t, s, r, i) {
          this._dataUpdated.fire(e, t, s, r, i);
        }
        fireUnsupportedResolutionRequested() {
          this._unsupportedResolutionRequested.fire();
        }
        constructor() {
          (this._created = new u.Delegate()),
            (this._modified = new u.Delegate()),
            (this._cleared = new u.Delegate()),
            (this._loading = new u.Delegate()),
            (this._completed = new u.Delegate()),
            (this._error = new u.Delegate()),
            (this._symbolError = new u.Delegate()),
            (this._symbolResolved = new u.Delegate()),
            (this._seriesError = new u.Delegate()),
            (this._symbolNotPermitted = new u.Delegate()),
            (this._symbolInvalid = new u.Delegate()),
            (this._symbolGroupNotPermitted = new u.Delegate()),
            (this._symbolBondMetricsNotPermitted = new u.Delegate()),
            (this._chartTypeNotPermitted = new u.Delegate()),
            (this._intradaySpreadNotPermitted = new u.Delegate()),
            (this._intradayExchangeNotPermitted = new u.Delegate()),
            (this._customIntervalNotPermitted = new u.Delegate()),
            (this._secondsIntervalNotPermitted = new u.Delegate()),
            (this._ticksIntervalNotPermitted = new u.Delegate()),
            (this._barReceived = new u.Delegate()),
            (this._seriesTimeFrame = new u.Delegate()),
            (this._dataUpdated = new u.Delegate()),
            (this._unsupportedResolutionRequested = new u.Delegate());
        }
      }
      var _ = s(26698),
        f = s(700713),
        p = s(818957);
      const b = /{(\w+)}/g;
      const y = (0, a.getLogger)("Chart.SeriesDataSource");
      var g = (function (e) {
        return (
          (e[(e.Idle = 0)] = "Idle"),
          (e[(e.AwaitingConnection = 1)] = "AwaitingConnection"),
          (e[(e.AwaitingFirstDataUpdate = 2)] = "AwaitingFirstDataUpdate"),
          (e[(e.Active = 3)] = "Active"),
          e
        );
      })(g || {});
      let S = 1;
      let v = 1;
      function I(e) {
        return (0, c.extractExtendedSymbol)(e).symbol;
      }
      class C {
        destroy() {
          this.stop(),
            this._gateway
              .isConnected()
              .unsubscribe(this._boundOnGatewayIsConnectedChanged),
            this._dataEvents.destroy();
        }
        canModifySeries(e, t) {
          const s = !(0, i.deepEquals)(this._extSymbol, e)[0],
            r =
              null === this._resolution ||
              !o.Interval.isEqual(this._resolution, t);
          return s || r;
        }
        modifySeries(e, t, s = null, a = !1, n = null) {
          a &&
            (y.logNormal(
              "Due to force flag clearing symbol & resolution to force re-requesting data."
            ),
            (this._extSymbol = null),
            (this._resolution = null));
          const l = I(e),
            d = !this.symbolSameAsResolved(l);
          if ((d && (this._lastResolvedSymbol = ""), this._extSymbol && !d)) {
            const t = I(this._extSymbol);
            (0, c.replaceExtendedSymbol)(e, t);
          }
          const h = this._extSymbol,
            u = this._resolution;
          if (
            ((this._extSymbol = e),
            (this._resolution = t),
            null === this._instanceId)
          )
            return void (this._timeFrame = s);
          const m = !(0, i.deepEquals)(h, e)[0];
          m && (0, c.replaceExtendedSymbol)(this._extSymbol, l);
          const _ = null === u || !o.Interval.isEqual(u, t);
          (m || _ || null !== s) &&
            ((this._timeFrame = null),
            (m || _) && this._turnaroundCounter++,
            m && this._resolveSymbol(),
            this._gateway.modifySeries(
              this._instanceId,
              this.turnaround(),
              (0, r.ensureNotNull)(this._symbolInstanceId),
              this._resolution,
              n,
              s,
              this._boundOnMessage
            ),
            this._dataEvents.fireModified());
        }
        requestMoreData(e) {
          null !== this._instanceId &&
            this._gateway.requestMoreData(
              this._instanceId,
              e,
              this._boundOnMessage
            );
        }
        requestMoreTickmarks(e) {
          null !== this._instanceId &&
            this._gateway.requestMoreTickmarks(
              this._instanceId,
              e,
              this._boundOnMessage
            );
        }
        setFutureTickmarksMode(e) {
          null !== this._instanceId && this._gateway.setFutureTickmarksMode(e);
        }
        isStarted() {
          return 0 !== this._status;
        }
        isActive() {
          return 3 === this._status;
        }
        resolution() {
          return this._resolution;
        }
        start() {
          this.isStarted()
            ? y.logNormal(
                "start: data source is already started, nothing to do"
              )
            : ((0, r.assert)(
                null !== this._extSymbol,
                "symbol must be set before start"
              ),
              (0, r.assert)(
                null !== this._resolution,
                "resolution must be set before start"
              ),
              this._gateway.isConnected().value()
                ? this._createSeries()
                : this._changeStatusTo(1));
        }
        stop() {
          this.isStarted()
            ? (null !== this._instanceId &&
                (this._gateway.removeSeries(this._instanceId),
                (this._instanceId = null)),
              (this._symbolInstanceId = null),
              this._changeStatusTo(0))
            : y.logNormal(
                "stop: data source is already stopped, nothing to do"
              );
        }
        instanceId() {
          return this._instanceId;
        }
        data() {
          return this._data;
        }
        setData(e) {
          this._data = e;
        }
        setTimeframe(e) {
          this._timeFrame = e;
        }
        clearData() {
          this.isStarted()
            ? this._enqueueUpdate(() => this._clearDataImpl())
            : this._clearDataImpl();
        }
        dataEvents() {
          return this._dataEvents;
        }
        turnaround() {
          return `${this._turnaroundPrefix}${this._turnaroundCounter}`;
        }
        symbolInstanceId() {
          return this._symbolInstanceId;
        }
        symbol() {
          return this._extSymbol;
        }
        updateExtSymbol(e) {
          this._extSymbol = e;
        }
        moveData(e) {
          return this._enqueueUpdate(() => this._data.moveData(e));
        }
        setInitialRequestOptions(e) {
          this._createSeriesOverriddenParams = (0,
          h.initialRequestOptionsToNumBars)(e);
        }
        symbolSameAsResolved(e) {
          return (
            null !== this._extSymbol &&
            (0, p.symbolSameAsResolved)(
              e,
              I(this._extSymbol),
              this._lastResolvedSymbol
            )
          );
        }
        resolvedSymbol() {
          return null === this._extSymbol ? null : I(this._extSymbol);
        }
        static setNonSeriesDataUnpacker(e) {
          C._nonSeriesDataUnpacker = e;
        }
        static setSymbolEncoder(e) {
          C._encodeSymbol = e;
        }
        static setExtractSymbolFeaturesets(e) {
          C._extractSymbolNameFeaturesets = e;
        }
        _resolveSymbol() {
          null !== this._extSymbol &&
            (this._symbolInstanceId = this._gateway.resolveSymbol(
              "sds_sym_" + S++,
              C._encodeSymbol(this._extSymbol),
              this._boundOnMessage
            ));
        }
        _clearDataImpl() {
          this._data.clear(), this._dataEvents.fireCleared();
        }
        _changeStatusTo(e) {
          (0, r.assert)(
            this._status !== e,
            "Source and destination status should be distinct"
          ),
            y.logNormal(`Status changed from ${g[this._status]} to ${g[e]}`),
            (this._status = e);
        }
        _createSeries() {
          (0, r.assert)(
            3 !== this._status,
            'Status should not be "Active" when creating a study'
          ),
            (this._instanceId = "sds_" + v++),
            this._resolveSymbol();
          const e =
            this._createSeriesOverriddenParams || this._createSeriesParams;
          this._createSeriesOverriddenParams &&
            (this._createSeriesOverriddenParams = 0),
            this._gateway.createSeries(
              this._instanceId,
              this.turnaround(),
              (0, r.ensureNotNull)(this._symbolInstanceId),
              (0, r.ensureNotNull)(this._resolution),
              e,
              this._timeFrame,
              this._boundOnMessage
            ),
            (this._timeFrame = null),
            this._changeStatusTo(2),
            this._dataEvents.fireCreated(this._instanceId);
        }
        _onGatewayIsConnectedChanged(e) {
          e ? this._onGatewayConnected() : this._onGatewayDisconnected();
        }
        _onGatewayConnected() {
          1 === this._status && this._createSeries();
        }
        _onGatewayDisconnected() {
          0 !== this._status &&
            1 !== this._status &&
            ((this._instanceId = null), this._changeStatusTo(1)),
            (this._turnaroundCounter = 1);
        }
        _onMessage(e) {
          this._enqueueUpdate(() => this._onMessageImpl(e));
        }
        async _onMessageImpl(e) {
          switch (e.method) {
            case "symbol_resolved": {
              const [t, s] = e.params;
              if (t !== this._symbolInstanceId) {
                null !== this._symbolInstanceId &&
                  y.logNormal(
                    `Resolve for old symbol, expected: ${this._symbolInstanceId}, actual ${e.params[0]}`
                  );
                break;
              }
              this._onSymbolResolved(s);
              break;
            }
            case "symbol_error":
              if (e.params[0] !== this._symbolInstanceId) {
                null !== this._symbolInstanceId &&
                  y.logNormal(
                    `Symbol error for old symbol, expected: ${this._symbolInstanceId}, actual ${e.params[0]}`
                  );
                break;
              }
              this._onSymbolError(e);
              break;
            case "series_timeframe": {
              const [t, s, r, i, a, o, n] = e.params;
              if (!this._checkTurnaround(t, s)) {
                y.logNormal(
                  `Time frame for old data, expected: ${
                    this._symbolInstanceId
                  } (${this.turnaround()}), actual ${t} (${s})`
                );
                break;
              }
              this._onSeriesTimeFrame(r, i, a, o, n);
              break;
            }
            case "series_error": {
              const [t, s] = e.params;
              if (!this._checkTurnaround(t, s)) {
                y.logNormal(
                  `Series error for old data, expected: ${
                    this._symbolInstanceId
                  } (${this.turnaround()}), actual ${t} (${s})`
                );
                break;
              }
              this._onSeriesError(e.params[2]);
              break;
            }
            case "series_loading": {
              const [t, s] = e.params;
              if (!this._checkTurnaround(t, s)) break;
              this._onSeriesLoading(e.time);
              break;
            }
            case "series_completed": {
              const [t, s, r, i] = e.params;
              if (!this._checkTurnaround(t, r)) {
                y.logNormal(
                  `Series completed for old data, expected: ${
                    this._symbolInstanceId
                  } (${this.turnaround()}), actual ${t} (${r})`
                );
                break;
              }
              this._onSeriesCompleted(s, e.time, i);
              break;
            }
            case "data_update":
              if (
                !this._checkTurnaround(e.params.customId, e.params.turnaround)
              ) {
                y.logNormal(
                  `Data update for old data, expected: ${
                    this._symbolInstanceId
                  } (${this.turnaround()}), actual ${e.params.customId} (${
                    e.params.turnaround
                  })`
                );
                break;
              }
              await this._onDataUpdate(
                e.params.plots,
                e.params.nonseries,
                e.params.lastBar
              );
              break;
            case "clear_data": {
              if (e.params.turnaround !== this.turnaround()) {
                y.logNormal(
                  `Clear data for old data, expected: ${this.turnaround()}, actual ${
                    e.params.turnaround
                  }`
                );
                break;
              }
              const t = this._data.first();
              this._clearDataImpl(),
                this._dataEvents.fireDataUpdated(void 0, !1, null, !1, t);
              break;
            }
          }
        }
        _onSeriesError(e) {
          let t, s;
          if ("string" == typeof e) (s = { error: e }), (t = e);
          else if (((s = e), e.ctx)) {
            const s = {};
            Object.entries(e.ctx).forEach(([e, t]) => {
              s[e] = t.toString();
            }),
              (i = e.error),
              (a = s),
              (t = i.replace(b, (e, t) => (void 0 !== a[t] ? a[t] : e)));
          } else t = e.error;
          var i, a;
          if (t.startsWith("study_not_auth:")) {
            const e = t.split(":", 2)[1].split("@", 2)[0];
            if (
              [
                "BarSetRenko",
                "BarSetPriceBreak",
                "BarSetKagi",
                "BarSetPnF",
              ].includes(e)
            )
              this._dataEvents.fireChartTypeNotPermitted(e);
            else {
              if ("BarSetSpread" === e)
                return void this._dataEvents.fireIntradaySpreadNotPermitted();
              if ("BarSetRange" === e) {
                const e = `${
                  (0, r.ensureNotNull)(this._extSymbol).inputs.range
                }R`;
                this._dataEvents.fireCustomIntervalNotPermitted(e);
              }
            }
          } else {
            if (t.startsWith("unsupported"))
              return void this._dataEvents.fireUnsupportedResolutionRequested();
            "resolution_not_entitled" === t
              ? this._dataEvents.fireIntradayExchangeNotPermitted()
              : "custom_resolution" === t
              ? this._dataEvents.fireCustomIntervalNotPermitted(
                  (0, r.ensureNotNull)(this._resolution)
                )
              : "seconds_not_entitled" === t
              ? this._dataEvents.fireSecondsIntervalNotPermitted()
              : "ticks_not_entitled" === t &&
                this._dataEvents.fireTicksIntervalNotPermitted();
          }
          this._dataEvents.fireSeriesError(s);
        }
        _onSeriesTimeFrame(e, t, s, r, i) {
          this._dataEvents.fireSeriesTimeFrame(e, t, s, r ?? !0, i);
        }
        _onSymbolError(e) {
          if (e.params[1] === l.permissionDenied)
            switch (e.params[2]) {
              case l.SymbolErrorPermissionDeniedReason.Symbol:
                this._dataEvents.fireSymbolNotPermitted(e.params[3]);
                break;
              case l.SymbolErrorPermissionDeniedReason.GroupPermission:
                this._dataEvents.fireSymbolGroupNotPermitted(e.params[3]);
                break;
              case l.SymbolErrorPermissionDeniedReason.BondMetrics:
                this._dataEvents.fireSymbolBondMetricsNotPermitted(e.params[3]);
                break;
              default:
                this._dataEvents.fireSymbolNotPermitted(e.params[2]);
            }
          else
            e.params[1] === l.invalidSymbol &&
              this._dataEvents.fireSymbolInvalid();
          this._dataEvents.fireSymbolError(e.params[1]);
        }
        _onSymbolResolved(e) {
          (this._lastResolvedSymbol = (0, r.ensureNotNull)(
            (0, f.extractSymbolNameFromSymbolInfo)(
              C._extractSymbolNameFeaturesets,
              e,
              ""
            )
          )),
            this._dataEvents.fireSymbolResolved(e);
        }
        async _onDataUpdate(e, t, s) {
          this._onDataUnpacked(
            e,
            s,
            await (0, _.parseJapaneseProjectionBars)(
              t,
              C._nonSeriesDataUnpacker
            )
          );
        }
        _enqueueUpdate(e) {
          return (
            (this._ongoingDataUpdate = this._ongoingDataUpdate.then(e, e)),
            this._ongoingDataUpdate
          );
        }
        _onDataUnpacked(e, t, s) {
          if (0 === this._status) return;
          2 === this._status &&
            (this._changeStatusTo(3), this._clearDataImpl());
          const r = this._data.bars().size(),
            i = this._data.first(),
            a = this._data.bars().firstIndex(),
            o = this._data.mergeRegularBars(e);
          null !== s &&
            (this._data.nsBars().clear(),
            this._data.nsBars().merge(s.projectionPlots),
            (this._data.lastProjectionPrice = s.lastPrice),
            null !== s.boxSize && (this._data.boxSize = s.boxSize),
            (this._data.reversalAmount = s.reversalAmount));
          const n = null === a,
            l = n || (null !== o && o.index < a);
          this._dataEvents.fireDataUpdated(t, l, o, n, i),
            r !== this._data.bars().size() &&
              null !== o &&
              this._dataEvents.fireBarReceived(o);
        }
        _onSeriesLoading(e) {
          this._dataEvents.fireLoading(e);
        }
        _onSeriesCompleted(e, t, s) {
          this._dataEvents.fireCompleted({ updateMode: e, time: t, flags: s });
        }
        _checkTurnaround(e, t) {
          return (
            this._instanceId === e && (void 0 === t || t === this.turnaround())
          );
        }
        constructor(e, t, s, r) {
          (this._extSymbol = null),
            (this._lastResolvedSymbol = ""),
            (this._createSeriesOverriddenParams = 0),
            (this._instanceId = null),
            (this._symbolInstanceId = null),
            (this._resolution = null),
            (this._timeFrame = null),
            (this._data = new n.SeriesData()),
            (this._dataEvents = new m()),
            (this._status = 0),
            (this._turnaroundCounter = 1),
            (this._boundOnGatewayIsConnectedChanged =
              this._onGatewayIsConnectedChanged.bind(this)),
            (this._boundOnMessage = this._onMessage.bind(this)),
            (this._ongoingDataUpdate = Promise.resolve()),
            (this._gateway = e),
            (this._turnaroundPrefix = t),
            (this._createSeriesParams = (0, h.initialRequestOptionsToNumBars)(
              s ?? { count: h.DEFAULT_NUMBARS }
            )),
            (this._timeFrame = r || null),
            this._gateway
              .isConnected()
              .subscribe(this._boundOnGatewayIsConnectedChanged);
        }
      }
      (C._nonSeriesDataUnpacker = d.unpackNonSeriesData),
        (C._encodeSymbol = c.encodeExtendedSymbol),
        (C._extractSymbolNameFeaturesets = {
          payAttentionToTickerNotSymbol: !1,
          chartingLibrarySingleSymbolRequest: !1,
          useTickerOnSymbolInfoUpdate: !1,
          uppercaseInstrumentNames: !1,
        });
    },
    652258(e, t, s) {
      "use strict";
      s.d(t, { getServerInterval: () => i });
      var r = s(342288);
      function i(e) {
        return r.Interval.isRange(e) ? "1" : e;
      }
    },
    583938(e, t, s) {
      "use strict";
      s.d(t, { Session: () => d });
      var r = s(146961),
        i = s(140136),
        a = s(570071),
        o = s(819511),
        n = s(966193);
      const l = (0, o.getLogger)("ChartApi.AbstractSession");
      class d {
        destroy() {
          this._logNormal("Destroying session"),
            this._isConnected.unsubscribe(),
            this.disconnect(),
            this._sessionIdChanged.destroy(),
            delete this._chartApi,
            this._logNormal("Session has been destroyed");
        }
        isConnected() {
          return this._isConnected;
        }
        sessionId() {
          return this._sessionId;
        }
        onSessionIdChanged() {
          return this._sessionIdChanged;
        }
        connect() {
          0 === this._state &&
            ((0, r.assert)(
              !this._isConnectForbidden,
              "Cannot call connect because it is forbidden at this moment"
            ),
            this._setSessionId(`${this._sessionPrefix}_${(0, n.randomHash)()}`),
            this._logNormal(
              "Connecting session - wait until transport stay connected"
            ),
            (this._state = 1),
            this._chartApi.createSession(this._sessionId, this));
        }
        disconnect() {
          0 !== this._state &&
            ((0, r.assert)(
              "" !== this._sessionId,
              "sessionId must not be invalid"
            ),
            this._logNormal("Disconnecting session..."),
            this._forbidConnectWhile(() => {
              this._chartApi.connected() && this._sendRemoveSession(),
                this._processDestroyingOnServer();
            }));
        }
        onMessage(e) {
          switch (e.method) {
            case "connected":
              return void this._onChartApiConnected();
            case "disconnected":
              return void this._onChartApiDisconnected();
            case "critical_error":
              const t = String(e.params[0]),
                s = String(e.params[1]);
              return void this._onCriticalError(t, s);
          }
          this._onMessage(e);
        }
        serverTime() {
          return this._chartApi.serverTime();
        }
        _getChartApi() {
          return this._chartApi;
        }
        _generateLogMessage(e) {
          return `[${this._sessionId}] ${e}`;
        }
        _onCriticalError(e, t) {
          this._logError(`Critical error. Reason=${e}, info=${t}.`),
            this._forbidConnectWhile(() => {
              this._processDestroyingOnServer();
            }),
            this._shouldReconnectAfterCriticalError
              ? (this._logNormal("Reconnecting after critical error..."),
                this.connect())
              : this._logNormal("Reconnecting after critical error skipped");
        }
        _onChartApiConnected() {
          (0, r.assert)(1 === this._state, "Session is not registered"),
            this._logNormal(
              "Transport is connected. Creating session on the server"
            ),
            this._sendCreateSession(),
            (this._state = 2),
            this._isConnected.setValue(!0);
        }
        _onChartApiDisconnected() {
          this._logNormal("Transport is disconnected. Reconnecting..."),
            this._forbidConnectWhile(() => {
              this._processDestroyingOnServer();
            }),
            this.connect();
        }
        _setSessionId(e) {
          const t = this._sessionId;
          this._logNormal(`Changing sessionId: old=${t}, new=${e}`),
            (this._sessionId = e),
            this._sessionIdChanged.fire(e, t);
        }
        _logNormal(e) {
          l.logNormal(this._generateLogMessage(e));
        }
        _logError(e) {
          l.logError(this._generateLogMessage(e));
        }
        _processDestroyingOnServer() {
          (this._state = 0),
            this._isConnected.setValue(!1),
            this._chartApi.removeSession(this._sessionId),
            this._setSessionId("");
        }
        _forbidConnectWhile(e) {
          (this._isConnectForbidden = !0), e(), (this._isConnectForbidden = !1);
        }
        constructor(e, t, s) {
          (this._isConnected = new i.WatchedValue(!1)),
            (this._state = 0),
            (this._isConnectForbidden = !1),
            (this._sessionId = ""),
            (this._sessionIdChanged = new a.Delegate()),
            (this._chartApi = e),
            (this._sessionPrefix = t),
            (this._shouldReconnectAfterCriticalError = s);
        }
      }
    },
    319764(e, t, s) {
      "use strict";
      s.d(t, { validateGraphicsCommands: () => a });
      var r = s(881014),
        i = s(146961);
      function a(e) {
        if (!(0, r.isObject)(e))
          throw new Error("Graphics commands should be wrapped in an object");
        if (((0, r.hasProperty)(e, "create"), (0, r.hasProperty)(e, "erase"))) {
          const t = e.erase;
          (0, i.assert)(
            Array.isArray(t),
            "Collection of erase commands should be array"
          );
          for (const e of t) {
            if (!(0, r.isObject)(e) || !(0, r.hasProperty)(e, "action"))
              throw new Error(
                "Command should be an object with 'action' property"
              );
            (0, i.assert)(
              "all" === e.action || "one" === e.action,
              "Erase command action should be 'all' or 'one'"
            );
          }
        }
        return e;
      }
    },
    818957(e, t, s) {
      "use strict";
      function r(e, t, s) {
        return e === t || e === s;
      }
      s.d(t, { symbolSameAsResolved: () => r });
    },
    301510(e, t, s) {
      "use strict";
      s.d(t, {
        INVALID_TIME_POINT_INDEX: () => r,
        UNPLOTTABLE_TIME_POINT_INDEX: () => i,
      });
      const r = -2e6,
        i = -1e6;
    },
  },
]);
