"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [79726],
  {
    984139(t, e, r) {
      r.d(e, { default: () => n });
      const n = function (t, e) {
        for (
          var r = -1, n = null == t ? 0 : t.length;
          ++r < n && !1 !== e(t[r], r, t);

        );
        return t;
      };
    },
    168533(t, e, r) {
      r.d(e, { default: () => o });
      var n = r(254738),
        a = r(910778),
        u = Object.prototype.hasOwnProperty;
      const o = function (t, e, r) {
        var o = t[e];
        (u.call(t, e) && (0, a.default)(o, r) && (void 0 !== r || e in t)) ||
          (0, n.default)(t, e, r);
      };
    },
    254738(t, e, r) {
      r.d(e, { default: () => a });
      var n = r(36049);
      const a = function (t, e, r) {
        "__proto__" == e && n.default
          ? (0, n.default)(t, e, {
              configurable: !0,
              enumerable: !0,
              value: r,
              writable: !0,
            })
          : (t[e] = r);
      };
    },
    493018(t, e, r) {
      r.d(e, { default: () => H });
      var n = r(886514),
        a = r(984139),
        u = r(168533),
        o = r(61857),
        c = r(309080);
      const f = function (t, e) {
        return t && (0, o.default)(e, (0, c.default)(e), t);
      };
      var d = r(217457);
      const l = function (t, e) {
        return t && (0, o.default)(e, (0, d.default)(e), t);
      };
      var i = r(487060),
        s = r(705749),
        b = r(230951);
      const v = function (t, e) {
        return (0, o.default)(t, (0, b.default)(t), e);
      };
      var j = r(116641);
      const y = function (t, e) {
        return (0, o.default)(t, (0, j.default)(t), e);
      };
      var p = r(806240),
        w = r(991599),
        A = r(969785),
        g = Object.prototype.hasOwnProperty;
      const h = function (t) {
        var e = t.length,
          r = new t.constructor(e);
        return (
          e &&
            "string" == typeof t[0] &&
            g.call(t, "index") &&
            ((r.index = t.index), (r.input = t.input)),
          r
        );
      };
      var O = r(377251);
      const m = function (t, e) {
        var r = e ? (0, O.default)(t.buffer) : t.buffer;
        return new t.constructor(r, t.byteOffset, t.byteLength);
      };
      var x = /\w*$/;
      const S = function (t) {
        var e = new t.constructor(t.source, x.exec(t));
        return (e.lastIndex = t.lastIndex), e;
      };
      var U = r(872999),
        I = U.default ? U.default.prototype : void 0,
        B = I ? I.valueOf : void 0;
      const F = function (t) {
        return B ? Object(B.call(t)) : {};
      };
      var P = r(13907);
      const k = function (t, e, r) {
        var n = t.constructor;
        switch (e) {
          case "[object ArrayBuffer]":
            return (0, O.default)(t);
          case "[object Boolean]":
          case "[object Date]":
            return new n(+t);
          case "[object DataView]":
            return m(t, r);
          case "[object Float32Array]":
          case "[object Float64Array]":
          case "[object Int8Array]":
          case "[object Int16Array]":
          case "[object Int32Array]":
          case "[object Uint8Array]":
          case "[object Uint8ClampedArray]":
          case "[object Uint16Array]":
          case "[object Uint32Array]":
            return (0, P.default)(t, r);
          case "[object Map]":
          case "[object Set]":
            return new n();
          case "[object Number]":
          case "[object String]":
            return new n(t);
          case "[object RegExp]":
            return S(t);
          case "[object Symbol]":
            return F(t);
        }
      };
      var E = r(807575),
        M = r(295635),
        C = r(659018),
        D = r(672511),
        _ = r(880115),
        N = r(360620);
      const L = function (t) {
        return (0, N.default)(t) && "[object Set]" == (0, A.default)(t);
      };
      var R = r(899339),
        T = r(369899),
        V = T.default && T.default.isSet;
      const G = V ? (0, R.default)(V) : L;
      var W = "[object Arguments]",
        $ = "[object Function]",
        q = "[object Object]",
        z = {};
      (z[W] =
        z["[object Array]"] =
        z["[object ArrayBuffer]"] =
        z["[object DataView]"] =
        z["[object Boolean]"] =
        z["[object Date]"] =
        z["[object Float32Array]"] =
        z["[object Float64Array]"] =
        z["[object Int8Array]"] =
        z["[object Int16Array]"] =
        z["[object Int32Array]"] =
        z["[object Map]"] =
        z["[object Number]"] =
        z[q] =
        z["[object RegExp]"] =
        z["[object Set]"] =
        z["[object String]"] =
        z["[object Symbol]"] =
        z["[object Uint8Array]"] =
        z["[object Uint8ClampedArray]"] =
        z["[object Uint16Array]"] =
        z["[object Uint32Array]"] =
          !0),
        (z["[object Error]"] = z[$] = z["[object WeakMap]"] = !1);
      const H = function t(e, r, o, b, j, g) {
        var O,
          m = 1 & r,
          x = 2 & r,
          S = 4 & r;
        if ((o && (O = j ? o(e, b, j, g) : o(e)), void 0 !== O)) return O;
        if (!(0, _.default)(e)) return e;
        var U = (0, M.default)(e);
        if (U) {
          if (((O = h(e)), !m)) return (0, s.default)(e, O);
        } else {
          var I = (0, A.default)(e),
            B = I == $ || "[object GeneratorFunction]" == I;
          if ((0, C.default)(e)) return (0, i.default)(e, m);
          if (I == q || I == W || (B && !j)) {
            if (((O = x || B ? {} : (0, E.default)(e)), !m))
              return x ? y(e, l(O, e)) : v(e, f(O, e));
          } else {
            if (!z[I]) return j ? e : {};
            O = k(e, I, m);
          }
        }
        g || (g = new n.default());
        var F = g.get(e);
        if (F) return F;
        g.set(e, O),
          G(e)
            ? e.forEach(function (n) {
                O.add(t(n, r, o, n, e, g));
              })
            : (0, D.default)(e) &&
              e.forEach(function (n, a) {
                O.set(a, t(n, r, o, a, e, g));
              });
        var P = S ? (x ? w.default : p.default) : x ? d.default : c.default,
          N = U ? void 0 : P(e);
        return (
          (0, a.default)(N || e, function (n, a) {
            N && (n = e[(a = n)]), (0, u.default)(O, a, t(n, r, o, a, e, g));
          }),
          O
        );
      };
    },
    851082(t, e, r) {
      r.d(e, { default: () => u });
      var n = r(880115),
        a = Object.create;
      const u = (function () {
        function t() {}
        return function (e) {
          if (!(0, n.default)(e)) return {};
          if (a) return a(e);
          t.prototype = e;
          var r = new t();
          return (t.prototype = void 0), r;
        };
      })();
    },
    377251(t, e, r) {
      r.d(e, { default: () => a });
      var n = r(865330);
      const a = function (t) {
        var e = new t.constructor(t.byteLength);
        return new n.default(e).set(new n.default(t)), e;
      };
    },
    487060(t, e, r) {
      r.d(e, { default: () => f });
      var n = r(981523),
        a =
          "object" == typeof exports && exports && !exports.nodeType && exports,
        u =
          a &&
          "object" == typeof module &&
          module &&
          !module.nodeType &&
          module,
        o = u && u.exports === a ? n.default.Buffer : void 0,
        c = o ? o.allocUnsafe : void 0;
      const f = function (t, e) {
        if (e) return t.slice();
        var r = t.length,
          n = c ? c(r) : new t.constructor(r);
        return t.copy(n), n;
      };
    },
    13907(t, e, r) {
      r.d(e, { default: () => a });
      var n = r(377251);
      const a = function (t, e) {
        var r = e ? (0, n.default)(t.buffer) : t.buffer;
        return new t.constructor(r, t.byteOffset, t.length);
      };
    },
    705749(t, e, r) {
      r.d(e, { default: () => n });
      const n = function (t, e) {
        var r = -1,
          n = t.length;
        for (e || (e = Array(n)); ++r < n; ) e[r] = t[r];
        return e;
      };
    },
    61857(t, e, r) {
      r.d(e, { default: () => u });
      var n = r(168533),
        a = r(254738);
      const u = function (t, e, r, u) {
        var o = !r;
        r || (r = {});
        for (var c = -1, f = e.length; ++c < f; ) {
          var d = e[c],
            l = u ? u(r[d], t[d], d, r, t) : void 0;
          void 0 === l && (l = t[d]),
            o ? (0, a.default)(r, d, l) : (0, n.default)(r, d, l);
        }
        return r;
      };
    },
    36049(t, e, r) {
      r.d(e, { default: () => a });
      var n = r(162316);
      const a = (function () {
        try {
          var t = (0, n.default)(Object, "defineProperty");
          return t({}, "", {}), t;
        } catch (t) {}
      })();
    },
    991599(t, e, r) {
      r.d(e, { default: () => o });
      var n = r(916085),
        a = r(116641),
        u = r(217457);
      const o = function (t) {
        return (0, n.default)(t, u.default, a.default);
      };
    },
    392545(t, e, r) {
      r.d(e, { default: () => n });
      const n = (0, r(139849).default)(Object.getPrototypeOf, Object);
    },
    116641(t, e, r) {
      r.d(e, { default: () => c });
      var n = r(448626),
        a = r(392545),
        u = r(230951),
        o = r(177655);
      const c = Object.getOwnPropertySymbols
        ? function (t) {
            for (var e = []; t; )
              (0, n.default)(e, (0, u.default)(t)), (t = (0, a.default)(t));
            return e;
          }
        : o.default;
    },
    807575(t, e, r) {
      r.d(e, { default: () => o });
      var n = r(851082),
        a = r(392545),
        u = r(693941);
      const o = function (t) {
        return "function" != typeof t.constructor || (0, u.default)(t)
          ? {}
          : (0, n.default)((0, a.default)(t));
      };
    },
    203681(t, e, r) {
      r.d(e, { default: () => a });
      var n = r(493018);
      const a = function (t) {
        return (0, n.default)(t, 5);
      };
    },
    817350(t, e, r) {
      r.d(e, { default: () => u });
      var n = r(178497),
        a = r(360620);
      const u = function (t) {
        return (
          !0 === t ||
          !1 === t ||
          ((0, a.default)(t) && "[object Boolean]" == (0, n.default)(t))
        );
      };
    },
    672511(t, e, r) {
      r.d(e, { default: () => d });
      var n = r(969785),
        a = r(360620);
      const u = function (t) {
        return (0, a.default)(t) && "[object Map]" == (0, n.default)(t);
      };
      var o = r(899339),
        c = r(369899),
        f = c.default && c.default.isMap;
      const d = f ? (0, o.default)(f) : u;
    },
    206673(t, e, r) {
      r.d(e, { default: () => u });
      var n = r(178497),
        a = r(360620);
      const u = function (t) {
        return (
          "number" == typeof t ||
          ((0, a.default)(t) && "[object Number]" == (0, n.default)(t))
        );
      };
    },
    304221(t, e, r) {
      r.d(e, { default: () => o });
      var n = r(178497),
        a = r(295635),
        u = r(360620);
      const o = function (t) {
        return (
          "string" == typeof t ||
          (!(0, a.default)(t) &&
            (0, u.default)(t) &&
            "[object String]" == (0, n.default)(t))
        );
      };
    },
    217457(t, e, r) {
      r.d(e, { default: () => l });
      var n = r(820975),
        a = r(880115),
        u = r(693941);
      const o = function (t) {
        var e = [];
        if (null != t) for (var r in Object(t)) e.push(r);
        return e;
      };
      var c = Object.prototype.hasOwnProperty;
      const f = function (t) {
        if (!(0, a.default)(t)) return o(t);
        var e = (0, u.default)(t),
          r = [];
        for (var n in t)
          ("constructor" != n || (!e && c.call(t, n))) && r.push(n);
        return r;
      };
      var d = r(392908);
      const l = function (t) {
        return (0, d.default)(t) ? (0, n.default)(t, !0) : f(t);
      };
    },
  },
]);
