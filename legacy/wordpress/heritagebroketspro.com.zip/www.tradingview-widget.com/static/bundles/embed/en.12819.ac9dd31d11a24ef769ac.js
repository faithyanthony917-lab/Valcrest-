(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [12819, 17859, 24929, 40240, 48764, 57184, 74358, 77807, 94388],
  {
    558412(e) {
      e.exports = ["% of GDP"];
    },
    468460(e) {
      e.exports = ["% of par"];
    },
    44505(e) {
      e.exports = ["Disc. yield, %"];
    },
    859994(e) {
      e.exports = ["C"];
    },
    892363(e) {
      e.exports = ["D"];
    },
    394501(e) {
      e.exports = ["D"];
    },
    570939(e) {
      e.exports = ["E"];
    },
    394921(e) {
      e.exports = ["F"];
    },
    86644(e) {
      e.exports = ["R"];
    },
    756457(e) {
      e.exports = ["R"];
    },
    257326(e) {
      e.exports = ["S"];
    },
    229994(e) {
      e.exports = ["C"];
    },
    954614(e) {
      e.exports = ["H"];
    },
    839463(e) {
      e.exports = ["L"];
    },
    960513(e) {
      e.exports = ["O"];
    },
    565321(e) {
      e.exports = ["Vol"];
    },
    55215(e) {
      e.exports = ["Delisted"];
    },
    685104(e) {
      e.exports = ["Holiday"];
    },
    638405(e) {
      e.exports = ["Invalid symbol"];
    },
    49248(e) {
      e.exports = ["Overnight"];
    },
    274415(e) {
      e.exports = ["Loading"];
    },
    702788(e) {
      e.exports = ["Market open"];
    },
    914572(e) {
      e.exports = ["Market closed"];
    },
    867455(e) {
      e.exports = ["Post-market"];
    },
    918842(e) {
      e.exports = ["Pre-market"];
    },
    829273(e) {
      e.exports = ["Intraday spread data is not available"];
    },
    299153(e) {
      e.exports = ["No data"];
    },
    285893(e) {
      e.exports = ["No data for this resolution"];
    },
    734750(e) {
      e.exports = ["May"];
    },
    384597(e) {
      e.exports = ["CFD"];
    },
    655235(e) {
      e.exports = ["Crypto"];
    },
    350146(e) {
      e.exports = ["All"];
    },
    765440(e) {
      e.exports = ["Bonds"];
    },
    548322(e) {
      e.exports = ["Economy"];
    },
    97997(e) {
      e.exports = ["Forex"];
    },
    505079(e) {
      e.exports = ["Futures"];
    },
    564917(e) {
      e.exports = ["Funds"];
    },
    927411(e) {
      e.exports = ["Indices"];
    },
    79600(e) {
      e.exports = ["Options"];
    },
    555510(e) {
      e.exports = ["Stocks"];
    },
    57062(e) {
      e.exports = ["N/A"];
    },
    819078(e) {
      e.exports = ["3M"];
    },
    272098(e) {
      e.exports = ["3Y"];
    },
    670568(e) {
      e.exports = ["10 years"];
    },
    995066(e) {
      e.exports = ["10Y"];
    },
    832733(e) {
      e.exports = ["1M"];
    },
    938100(e) {
      e.exports = ["1D"];
    },
    492135(e) {
      e.exports = ["1W"];
    },
    770303(e) {
      e.exports = ["1Y"];
    },
    934777(e) {
      e.exports = ["2Y"];
    },
    82855(e) {
      e.exports = ["5D"];
    },
    446560(e) {
      e.exports = ["5Y"];
    },
    68076(e) {
      e.exports = ["6M"];
    },
    194194(e) {
      e.exports = ["Connecting"];
    },
    233690(e) {
      e.exports = ["All"];
    },
    290787(e) {
      e.exports = ["All time"];
    },
    526785(e) {
      e.exports = ["Apr"];
    },
    93762(e) {
      e.exports = ["Aug"];
    },
    769036(e) {
      e.exports = ["Dec"];
    },
    229525(e) {
      e.exports = ["Delayed"];
    },
    601764(e) {
      e.exports = ["End of Day"];
    },
    87238(e) {
      e.exports = ["Error"];
    },
    617341(e) {
      e.exports = ["Feb"];
    },
    968815(e) {
      e.exports = ["Fraction part is invalid."];
    },
    751278(e) {
      e.exports = ["Intraday spread data is not available"];
    },
    732776(e) {
      e.exports = ["Invalid symbol"];
    },
    328313(e) {
      e.exports = ["Instrument is not allowed"];
    },
    657374(e) {
      e.exports = ["Jan"];
    },
    183959(e) {
      e.exports = ["Jul"];
    },
    87745(e) {
      e.exports = ["Jun"];
    },
    728337(e) {
      e.exports = ["Oct"];
    },
    103305(e) {
      e.exports = ["Mar"];
    },
    5197(e) {
      e.exports = ["No data here"];
    },
    146807(e) {
      e.exports = ["No data here yet"];
    },
    646545(e) {
      e.exports = ["Nov"];
    },
    562395(e) {
      e.exports = ["Snapshot"];
    },
    850298(e) {
      e.exports = ["Second fraction part is invalid."];
    },
    178469(e) {
      e.exports = ["Sep"];
    },
    673523(e) {
      e.exports = ["Past year"];
    },
    878708(e) {
      e.exports = ["Past five years"];
    },
    430333(e) {
      e.exports = ["Past month"];
    },
    44656(e) {
      e.exports = ["Past quarter"];
    },
    61618(e) {
      e.exports = ["Price format is invalid."];
    },
    89767(e) {
      e.exports = ["Q1"];
    },
    948923(e) {
      e.exports = ["Q2"];
    },
    367935(e) {
      e.exports = ["Q3"];
    },
    175507(e) {
      e.exports = ["Q4"];
    },
    81461(e) {
      e.exports = ["Quotes are delayed by {number} min"];
    },
    790524(e) {
      e.exports = [
        "Quotes are delayed by {number} min and updated every 30 seconds",
      ];
    },
    883928(e) {
      e.exports = ["Real-time"];
    },
    97727(e) {
      e.exports = ["Replay Mode"];
    },
    614450(e) {
      e.exports = ["Today"];
    },
    114338(e) {
      e.exports = [
        "This symbol is only available on {linkStart}TradingView{linkEnd}",
      ];
    },
    517859(e) {
      e.exports = [
        "Visit TradingView — financial charting platform and trading community",
      ];
    },
    422369(e) {
      e.exports = ["YTD"];
    },
    485420(e) {
      e.exports = ["Year to date"];
    },
    103030(e) {
      e.exports = ["{str} day", "{str} days"];
    },
    210574(e) {
      e.exports = ["{str} hour", "{str} hours"];
    },
    694617(e) {
      e.exports = ["{str} month", "{str} months"];
    },
    4390(e) {
      e.exports = ["{str} minute", "{str} minutes"];
    },
    644625(e) {
      e.exports = ["{str} week", "{str} weeks"];
    },
    216402(e) {
      e.exports = ["{str} year", "{str} years"];
    },
  },
]);
