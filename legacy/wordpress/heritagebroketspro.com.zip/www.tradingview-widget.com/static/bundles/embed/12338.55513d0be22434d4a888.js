"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [12338],
  {
    666746(e, t, r) {
      r.d(t, { getChartApi: () => a, setChartApi: () => s });
      var n = r(819511),
        i = r(284656);
      const _ = (0, n.getLogger)("ChartApi");
      let o = null;
      function s(e, t) {
        null !== o &&
          o.kind !== e &&
          _.logWarn(
            `Chart API is already installed as "${o.kind}", replacing with "${e}"`
          ),
          (o = { kind: e, instance: t });
      }
      function a() {
        if (null === o)
          throw new Error(
            "Chart API is not installed on this page. Use getChartApiOrNull() if the backend is optional here."
          );
        return o.instance;
      }
      function l(e) {
        return null !== o && o.kind === e ? o.instance : null;
      }
      function E(e) {
        const t = l(e);
        if (null === t)
          throw new Error(
            `Chart API "${e}" is not installed on this page` +
              (null === o ? "." : `; installed backend is "${o.kind}".`)
          );
        return t;
      }
      const S = {
        get: function () {
          return null === o ? null : o.instance;
        },
        getSite: function () {
          return E("site");
        },
        getLocal: function () {
          return l("local");
        },
      };
      i.qaGlobals.provide("chartApi", S);
    },
    549282(e, t, r) {
      r.d(t, { isTicksEnabled: () => i });
      var n = r(503617);
      r(478561);
      function i() {
        return !(0, n.onWidget)();
      }
    },
    478561(e, t, r) {
      r.d(t, { isFeaturesetEnabled: () => n.enabled });
      var n = r(516825);
      "object" == typeof __initialDisabledFeaturesets &&
        Array.isArray(__initialDisabledFeaturesets) &&
        __initialDisabledFeaturesets.forEach(n.disable),
        "object" == typeof __initialEnabledFeaturesets &&
          Array.isArray(__initialEnabledFeaturesets) &&
          __initialEnabledFeaturesets.forEach(n.enable);
    },
    712859(e, t, r) {
      r.d(t, { isOnMobileAppPage: () => i });
      var n = r(489489);
      function i(e, t = !1) {
        const { searchParams: r } = new URL(String(location));
        let i = "true" === r.get("mobileapp_new"),
          _ = "true" === r.get("mobileapp");
        if (!t) {
          const e = n.get("tv_app") || "";
          (i ||= ["android", "android_nps"].includes(e)), (_ ||= "ios" === e);
        }
        return !(("new" !== e && "any" !== e) || !i) || !("new" === e || !_);
      }
    },
    861378(e, t, r) {
      r.d(t, { getQuoteSessionInstance: () => a });
      var n = r(933390),
        i = r(958633),
        _ = r(966193),
        o = r(666746);
      const s = {};
      function a(e = "full") {
        return (
          s[e] ||
            (function (e = "full", t) {
              s[e] = t;
            })(
              e,
              new n.QuoteSessionMultiplexer({
                name: e,
                api: (0, o.getChartApi)(),
                fields: l[e],
                extensions: {
                  formatter: (e) => new E(e).formatter,
                  snapshot: (e) => new S(e).snapshot,
                },
              })
            ),
          s[e]
        );
      }
      const l = {
        simple: [
          "base-currency-logoid",
          "logo",
          "ch",
          "chp",
          "currency-logoid",
          "currency_code",
          "currency_id",
          "base_currency_id",
          "current_session",
          "description",
          "exchange",
          "format",
          "fractional",
          "is_tradable",
          "language",
          "local_description",
          "listed_exchange",
          "logoid",
          "lp",
          "lp_time",
          "minmov",
          "minmove2",
          "original_name",
          "pricescale",
          "pro_name",
          "short_name",
          "type",
          "typespecs",
          "update_mode",
          "volume",
          "variable_tick_size",
          "value_unit_id",
          "unit_id",
          "measure",
        ],
      };
      (l.simpleDetailed = [
        ...l.simple,
        "ask",
        "bid",
        "fundamentals",
        "high_price",
        "is_tradable",
        "low_price",
        "open_price",
        "prev_close_price",
        "rch",
        "rchp",
        "rtc",
        "rtc_time",
        "status",
        "basic_eps_net_income",
        "beta_1_year",
        "earnings_per_share_basic_ttm",
        "industry",
        "market_cap_basic",
        "price_earnings_ttm",
        "sector",
        "volume",
        "dividends_yield",
        "timezone",
      ]),
        (l.full = []),
        (l.watchlist = [
          ...l.simple,
          "rchp",
          "nchp",
          "rtc",
          "country_code",
          "provider_id",
          "dividends_availability",
          "financials_availability",
          "earnings_availability",
        ]),
        (l.portfolio = [
          "pro_name",
          "short_name",
          "exchange",
          "listed_exchange",
          "description",
          "local_description",
          "language",
          "sector",
          "type",
          "typespecs",
          "industry",
          "currency_code",
          "currency_id",
          "ch",
          "chp",
          "logo",
          "logoid",
          "currency-logoid",
          "base-currency-logoid",
          "earnings_per_share_forecast_next_fq",
          "earnings_release_next_date",
          "earnings_release_date",
          "earnings_per_share_fq",
          "lp",
          "fractional",
          "minmov",
          "minmove2",
          "pricescale",
          "volume",
          "average_volume",
          "market_cap_calc",
          "market_cap_basic",
          "total_revenue",
          "earnings_per_share_basic_ttm",
          "price_earnings_ttm",
          "beta_1_year",
          "dps_common_stock_prim_issue_fy",
          "dividends_yield",
          "fundamental_currency_code",
          "rates_mc",
          "rates_fy",
          "rates_ttm",
          "format",
          "value_unit_id",
          "unit_id",
          "measure",
        ]),
        (l.notes = [
          "short_name",
          "pro_name",
          "logoid",
          "currency-logoid",
          "base-currency-logoid",
          "logo",
          "symbol-primaryname",
          "type",
          "typespecs",
        ]),
        (l.estimates = [
          "fundamental_data",
          "type",
          "typespecs",
          "earnings_per_share_forecast_next_symbol_currency_fq",
          "earnings_release_next_aligned_date",
          "earnings_release_next_calendar_date",
          "earnings_release_next_date",
        ]),
        (l.economic = [
          "reference-last-period",
          "lp",
          "currency_code",
          "value_unit_id",
          "unit_id",
          "measure",
        ]),
        (l.options = ["ask", "bid", "lp", "volume", "oi", "ch", "chp"]);
      class E {
        constructor(e) {
          (this._formatterValuesCache = {}),
            (this._waitingForFormatters = {}),
            (this.formatter = (e, t) => {
              if (this._waitingForFormatters[e])
                return this._waitingForFormatters[e];
              function r(e) {
                const r = t && !e.fractional ? 1 : e.minmov;
                return new i.PriceFormatter({
                  priceScale: e.pricescale,
                  minMove: r,
                  fractional: e.fractional,
                  minMove2: e.minmove2,
                });
              }
              const n = new Promise((t, n) => {
                if (this._formatterValuesCache[e])
                  t(r(this._formatterValuesCache[e]));
                else {
                  const i = (0, _.guid)();
                  this._multiplexer.subscribe(i, [e], (_) => {
                    "error" === _.status &&
                      ((this._waitingForFormatters[e] = null),
                      n("Quotes snapshot is not received")),
                      (function (e) {
                        return e && null != e.pricescale && null != e.minmov;
                      })(_.values) &&
                        ((this._waitingForFormatters[e] = null),
                        (this._formatterValuesCache[e] = _.values),
                        t(r(_.values)),
                        this._multiplexer.unsubscribe(i, e));
                  });
                }
              });
              return (this._waitingForFormatters[e] = n), n;
            }),
            (this._multiplexer = e);
        }
      }
      class S {
        constructor(e) {
          (this._snapshotValuesCache = {}),
            (this._waitingForSnapshot = {}),
            (this.snapshot = (e) => {
              if (this._waitingForSnapshot[e])
                return this._waitingForSnapshot[e];
              const t = new Promise((t, r) => {
                if (this._snapshotValuesCache[e])
                  t(this._snapshotValuesCache[e]);
                else {
                  const n = (0, _.guid)();
                  this._multiplexer.subscribe(n, [e], (i) => {
                    "error" === i.status &&
                      ((this._waitingForSnapshot[e] = null),
                      r("Quotes snapshot is not received"));
                    const _ = i.values;
                    _ &&
                      _.minmov &&
                      _.pricescale &&
                      _.description &&
                      ((this._waitingForSnapshot[e] = null),
                      (this._snapshotValuesCache[e] = _),
                      t(_),
                      this._multiplexer.unsubscribe(n, e));
                  });
                }
              });
              return (this._waitingForSnapshot[e] = t), t;
            }),
            (this._multiplexer = e);
        }
      }
      "undefined" != typeof window && (window.getQuoteSessionInstance = a);
    },
    955089(e, t, r) {
      r.d(t, { ExpertPlans: () => i, ProPlans: () => n });
      var n = (function (e) {
          return (
            (e.Free = "free"),
            (e.Pro = "pro"),
            (e.ProTrial = "pro_trial"),
            (e.ProRealtime = "pro_realtime"),
            (e.ProRealtimeTrial = "pro_realtime_trial"),
            (e.ProPremium = "pro_premium"),
            (e.ProPremiumTrial = "pro_premium_trial"),
            e
          );
        })({}),
        i = (function (e) {
          return (
            (e.ProExpert = "pro_expert"),
            (e.PremiumExpert = "pro_premium_expert"),
            (e.ProExpertTrial = "pro_expert_trial"),
            (e.PremiumExpertTrial = "pro_premium_expert_trial"),
            e
          );
        })({});
    },
    498728(e, t, r) {
      async function n() {
        const { getUnboundTrackerInstance: e } = await Promise.all([
          r.e(5220),
          r.e(66399),
        ]).then(r.bind(r, 654147));
        return e();
      }
      r.d(t, { getUnboundTracker: () => n });
    },
    197052(e, t, r) {
      r.d(t, { telemetry: () => S });
      var n = r(570071),
        i = r(819511),
        _ = r(384017),
        o = r(503617),
        s = r(712859);
      r(284656);
      const a = (0, i.getLogger)("Common.Telemetry"),
        l = { default: 15e3, site: 3e5 },
        E = [
          "before_websocket_connection_time_frame",
          "websocket_connection_time_frame",
          "first_series_full_time_frame",
          "page_full_load_time_frame",
          "page_load_time_frame",
        ];
      const S = new (class {
        setSessionInfo(e) {
          const t = this._parseCluster(e);
          null !== t && (this._commonAdditionalData.cluster = t);
        }
        sendReport(e, t, r) {
          if (!this._isAbleToSendReport(t)) return;
          const n = this._getSubserviceType(e),
            i = this._getHost(e, n);
          if (null !== i) {
            if (
              ((r = void 0 === r ? { count: 1 } : r),
              this._addReportToStash(r, t, i),
              !this._timeoutIds[e])
            ) {
              const t = l[e] ?? l.default;
              this._timeoutIds[e] = setTimeout(
                this._sendTelemetryToService.bind(this, e, i),
                t
              );
            }
          } else
            a.logError(
              `Unable to get host for counter: ${t}, metric type: ${e}, serivce type: ${n}`
            );
        }
        flush(e = !1) {
          for (const e of Object.keys(this._timeoutIds)) {
            const t = this._timeoutIds[e];
            null !== t && (clearTimeout(t), (this._timeoutIds[e] = null));
          }
          for (const t of Object.keys(this._reportStash))
            this._sendStashToHost(t, e);
        }
        sendChartReport(e, t, r = !0) {
          this._sendServiceSpecifiedReport("charts", e, t, r);
        }
        sendLineToolsStorageReport(e, t, r = !0) {
          this._sendServiceSpecifiedReport("line_tools_storage", e, t, r);
        }
        _sendServiceSpecifiedReport(e, t, r, n = !0) {
          this._updateUserInfo(),
            (r = void 0 === r ? { count: 1 } : r),
            n &&
              (r = this._appendCommonAdditionalInfo(r, ["cluster", "userId"])),
            this.sendReport(e, t, r);
        }
        _updateUserInfo() {
          const e =
            "user" in window && "id" in window.user ? window.user.id : "0";
          this._commonAdditionalData.userId = String(e);
        }
        _isAbleToSendReport(e) {
          const t = window.TELEMETRY_HOSTS,
            r = E.includes(e),
            n = Boolean(window.TradingView?.onChartPage || (0, o.onWidget)());
          return t && (!r || n);
        }
        _sendTelemetryToService(e, t) {
          this._sendStashToHost(t, !1), (this._timeoutIds[e] = null);
        }
        _sendStashToHost(e, t) {
          if (!this._reportStash.hasOwnProperty(e)) return;
          const r = this._cropParams(this._reportStash[e]),
            n = this._renameAllParams(r),
            i = { event: "report_stash", params: this._cleanAllParams(n) };
          a.logDebug(
            `Report to host: ${e}; stash: ${JSON.stringify(
              this._reportStash[e]
            )}`
          ),
            this.reportSent.fire(this._reportStash[e]),
            delete this._reportStash[e];
          const o = JSON.stringify(i);
          (0, _.fetch)(`${e}/report`, {
            method: "POST",
            body: o,
            keepalive: t && new TextEncoder().encode(o).length <= 32768,
          });
        }
        _getHost(e, t) {
          const r = window.TELEMETRY_HOSTS,
            n = r[e] && r[e][t];
          return Boolean(n) ? n : null;
        }
        _getSubserviceType(e) {
          if (!["charts", "site"].includes(e)) return "all";
          let t = "free";
          const r = window.user.is_pro;
          return (
            "charts" === e && (0, s.isOnMobileAppPage)("old")
              ? (t = r ? "ios_pro" : "ios_free")
              : "charts" === e && (0, s.isOnMobileAppPage)("new")
              ? (t = r ? "android_pro" : "android_free")
              : (0, o.onWidget)()
              ? (t = "widget")
              : r && (t = "pro"),
            t
          );
        }
        _parseCluster(e) {
          let t;
          try {
            t = JSON.parse(e).session_id;
          } catch (e) {
            return a.logError("Could not parse cluster id (session id)"), null;
          }
          const r = /(.*@)(.*)/gi.exec(t);
          return null !== r && r.length >= 3 ? r[2] : null;
        }
        _appendCommonAdditionalInfo(e, t) {
          return (
            t.forEach((t) => {
              t in this._commonAdditionalData &&
                ((e.additional = e.additional || {}),
                (e.additional[t] = this._commonAdditionalData[t]));
            }),
            e
          );
        }
        _cropParams(e) {
          for (const t in e)
            e.hasOwnProperty(t) &&
              e[t].length > 1e3 &&
              ((e.too_much_metrics_frame = e.too_much_metrics_frame ?? []),
              e.too_much_metrics_frame.push({
                value: e[t].length,
                additional: { event: t },
              }),
              delete e[t]);
          return e;
        }
        _renameAllParams(e) {
          const t = {};
          for (const r in e)
            e.hasOwnProperty(r) &&
              ((t[r] = []),
              e[r].forEach((e) => {
                t[r].push(this._renameEntryParams(e));
              }));
          return t;
        }
        _renameEntryParams(e) {
          const t = { count: "c", value: "v", text: "t", additional: "a" };
          return Object.keys(e).reduce((r, n) => ((r[t[n]] = e[n]), r), {});
        }
        _cleanAllParams(e) {
          const t = {};
          for (const r in e)
            if (e.hasOwnProperty(r)) {
              t[r] = [];
              const n = { c: 0 };
              e[r].forEach((e) => {
                const i = this._cleanEntryParams(e),
                  _ = Object.keys(i).length;
                1 === _ && void 0 !== i.c
                  ? (n.c += i.c)
                  : _ > 0 && t[r].push(i);
              }),
                n.c > 0 && t[r].push(n),
                0 === t[r].length && delete t[r];
            }
          return t;
        }
        _cleanEntryParams(e) {
          const t = Object.keys(e).reduce(
            (t, r) =>
              ("c" !== r && "t" !== r) || e[r] ? ((t[r] = e[r]), t) : t,
            {}
          );
          return "c" in t || "v" in t || "t" in t ? t : {};
        }
        _addReportToStash(e, t, r) {
          r in this._reportStash || (this._reportStash[r] = {}),
            t in this._reportStash[r] || (this._reportStash[r][t] = []),
            Object.keys(e).length > 0 && this._reportStash[r][t].push(e);
        }
        constructor() {
          (this.reportSent = new n.Delegate()),
            (this.timeCounters = {
              series: { marks: [] },
              study: {},
              pine: {},
            }),
            (this._timeoutIds = {}),
            (this._commonAdditionalData = { cluster: null, userId: "0" }),
            (this._reportStash = {});
        }
      })();
      window.addEventListener("pagehide", () => S.flush(!0)),
        document.addEventListener("visibilitychange", () => {
          "hidden" === document.visibilityState && S.flush(!0);
        });
    },
    495340(e, t, r) {
      r.d(t, { ProductFeatures: () => n });
      var n = (function (e) {
        return (
          (e.DISABLE_ON_TRIAL = "disable_on_trial"),
          (e.DISABLE_ON_LITE_PLAN = "disable_on_lite_plan"),
          (e.CUSTOM_INTERVALS = "CUSTOM_INTERVALS"),
          (e.CHART_STORAGE = "CHART_STORAGE"),
          (e.MULTIPLE_CHARTS = "MULTIPLE_CHARTS"),
          (e.MULTIPLE_WATCHLISTS = "MULTIPLE_WATCHLISTS"),
          (e.IMPORT_WATCHLISTS = "IMPORT_WATCHLISTS"),
          (e.EXPORT_WATCHLISTS = "EXPORT_WATCHLISTS"),
          (e.WATCHLIST_SYMBOLS = "WATCHLIST_SYMBOLS"),
          (e.INDICATORS_ON_CHART = "INDICATORS_ON_CHART"),
          (e.STUDY_ON_STUDY = "STUDY_ON_STUDY"),
          (e.TICK_BY_TICK_PUSH_DATA = "TICK_BY_TICK_PUSH_DATA"),
          (e.SERVER_SIDE_ALERTS = "SERVER_SIDE_ALERTS"),
          (e.SERVER_SIDE_ALERTS_TECHNICAL = "SERVER_SIDE_ALERTS_TECHNICAL"),
          (e.SERVER_SIDE_ALERTS_WATCHLIST = "SERVER_SIDE_ALERTS_WATCHLIST"),
          (e.ALERTS_MULTICONDITIONS = "ALERTS_MULTICONDITIONS"),
          (e.ALERTS_ON_EARNINGS = "ALERTS_ON_EARNINGS"),
          (e.ALERTS_ON_FUNDAMENTAL_METRICS = "ALERTS_ON_FUNDAMENTAL_METRICS"),
          (e.PUBLISH_INVITE_ONLY_SCRIPTS = "PUBLISH_INVITE_ONLY_SCRIPTS"),
          (e.PUBLISH_PROTECTED_SCRIPTS = "PUBLISH_PROTECTED_SCRIPTS"),
          (e.IO_SCRIPTS = "IO_SCRIPTS"),
          (e.PRIVATE_IO_SCRIPTS = "PRIVATE_IO_SCRIPTS"),
          (e.SCREENER_AUTO_REFRESH = "SCREENER_AUTO_REFRESH"),
          (e.SCREENER_NEW_AUTO_REFRESH = "SCREENER_NEW_AUTO_REFRESH"),
          (e.SCREENER_INTERVALS = "SCREENER_INTERVALS"),
          (e.SCREENER_NEW_EXPORT_CSV_DATA = "SCREENER_NEW_EXPORT_CSV_DATA"),
          (e.SCREENER_NEW_SHOW_RESTRICTED_DATA =
            "SCREENER_NEW_SHOW_RESTRICTED_DATA"),
          (e.SCREENER_CHART_INDICATORS = "SCREENER_CHART_INDICATORS"),
          (e.SCREENER_AI_FILTER = "SCREENER_AI_FILTER"),
          (e.SCREENER_ADD_NEW_COLUMN = "SCREENER_ADD_NEW_COLUMN"),
          (e.SCREENER_SCREEN_OWNER_EMPTY_STATE =
            "SCREENER_SCREEN_OWNER_EMPTY_STATE"),
          (e.SCREENER_SHARED_SCREEN = "SCREENER_SHARED_SCREEN"),
          (e.PINE_SCREENER = "PINE_SCREENER"),
          (e.SAVED_PINE_SCRIPTS = "SAVED_PINE_SCRIPTS"),
          (e.SIMULTANEOUS_CONNECTIONS = "SIMULTANEOUS_CONNECTIONS"),
          (e.BACKEND_CONNECTIONS = "BACKEND_CONNECTIONS"),
          (e.STUDY_TEMPLATES = "STUDY_TEMPLATES"),
          (e.CAN_EDIT_PUBLIC_CHATS = "CAN_EDIT_PUBLIC_CHATS"),
          (e.NO_SPONSORED_ADS = "NO_SPONSORED_ADS"),
          (e.IDC_AVAILABLE_DELAY = "IDC_AVAILABLE_DELAY"),
          (e.STATUS = "STATUS"),
          (e.ALERTS_NO_EXPIRATION = "ALERTS_NO_EXPIRATION"),
          (e.MULTIFLAGGED_SYMBOLS_LISTS = "MULTIFLAGGED_SYMBOLS_LISTS"),
          (e.BAR_REPLAY_INTRADAY = "BAR_REPLAY_INTRADAY"),
          (e.BAR_REPLAY_1S = "BAR_REPLAY_1S"),
          (e.BAR_REPLAY_1T = "BAR_REPLAY_1T"),
          (e.TV_VOLUMEBYPRICE = "TV_VOLUMEBYPRICE"),
          (e.ALERTS_WEBHOOK = "ALERTS_WEBHOOK"),
          (e.MARKET_DATA_LIMITS = "MARKET_DATA_LIMITS"),
          (e.DEEP_FUNDAMENTALS_HISTORY = "DEEP_FUNDAMENTALS_HISTORY"),
          (e.FINANCIALS_DOCUMENTS_SUMMARY = "FINANCIALS_DOCUMENTS_SUMMARY"),
          (e.EXPORT_CHART_DATA = "EXPORT_CHART_DATA"),
          (e.EXPORT_FINANCIALS_DATA = "EXPORT_FINANCIALS_DATA"),
          (e.ALERTS_ON_SECONDS = "ALERTS_ON_SECONDS"),
          (e.PERMANENT_STREAM_RECORDS = "PERMANENT_STREAM_RECORDS"),
          (e.IDEA_SOCIAL_LINKS = "IDEA_SOCIAL_LINKS"),
          (e.EXTENDED_SOCIAL_LINKS = "EXTENDED_SOCIAL_LINKS"),
          (e.DEEP_HISTORY_BACKTEST = "DEEP_HISTORY_BACKTEST"),
          (e.BACKTESTING_EXPORT_XLSX = "BACKTESTING_EXPORT_XLSX"),
          (e.BACKTESTING_EXPORT_CSV = "BACKTESTING_EXPORT_CSV"),
          (e.FUNDAMENTALS_FORECAST = "FUNDAMENTALS_FORECAST"),
          (e.BACKTESTING_EXTENDED_METRICS = "BACKTESTING_EXTENDED_METRICS"),
          (e.BAR_DETALIZATION = "BAR_DETALIZATION"),
          (e.SCRIPT_EXECUTION_ON_HISTORY_BARS =
            "SCRIPT_EXECUTION_ON_HISTORY_BARS"),
          (e.BACKTESTING_CHART_EXPAND = "BACKTESTING_CHART_EXPAND"),
          (e.HISTORICAL_BARS = "HISTORICAL_BARS"),
          (e.KAGI_RENKO = "KAGI_RENKO"),
          (e.INTRADAY_SPREAD = "INTRADAY_SPREAD"),
          (e.SECONDS_INTERVALS = "SECONDS_INTERVALS"),
          (e.MULTICOLOR_FLAGGED_SYMBOLS = "MULTICOLOR_FLAGGED_SYMBOLS"),
          (e.INTRADAY_EXCHANGE = "INTRADAY_EXCHANGE"),
          (e.CUSTOM_CHATS = "CUSTOM_CHATS"),
          (e.VOLUME_PROFILE = "VOLUME_PROFILE"),
          (e.VOLUME_CANDLES = "VOLUME_CANDLES"),
          (e.TPO_PERIODIC = "TPO_PERIODIC"),
          (e.TPO_CHART_STYLE = "TPO_CHART_STYLE"),
          (e.PRIMITIVE_ALERTS = "PRIMITIVE_ALERTS"),
          (e.COMPLEX_ALERTS = "COMPLEX_ALERTS"),
          (e.TV_PROSTUDIES = "TV_PROSTUDIES"),
          (e.CHART_PATTERNS = "CHART_PATTERNS"),
          (e.SMS_2FA_VERIFICATION = "SMS_2FA_VERIFICATION"),
          (e.SOCIAL_ACTIVITY = "SOCIAL_ACTIVITY"),
          (e.TICK_INTERVALS = "TICK_INTERVALS"),
          (e.CUSTOM_FORMULAS = "CUSTOM_FORMULAS"),
          (e.CUSTOM_RANGE_BARS = "CUSTOM_RANGE_BARS"),
          (e.BUY_PRO_DATA = "BUY_PRO_DATA"),
          (e.FASTEST_DATA_FLOW = "FASTEST_DATA_FLOW"),
          (e.FIRST_PRIORITY_SUPPORT = "FIRST_PRIORITY_SUPPORT"),
          (e.FUNDAMENTALS_ON_CHART = "FUNDAMENTALS_ON_CHART"),
          (e.FUNDAMENTAL_GRAPHS_LARGE_TIME_RANGE =
            "FUNDAMENTAL_GRAPHS_LARGE_TIME_RANGE"),
          (e.VIDEO_IDEAS_LENGTH = "VIDEO_IDEAS_LENGTH"),
          (e.VOLUME_FOOTPRINT = "VOLUME_FOOTPRINT"),
          (e.SESSION_VOLUME_PROFILE = "SESSION_VOLUME_PROFILE"),
          (e.CHAT_ASSISTANT = "CHAT_ASSISTANT"),
          (e.PERSONAL_SUPPORT = "PERSONAL_SUPPORT"),
          (e.SHOW_BONDS_RESTRICTED_DATA = "SHOW_BONDS_RESTRICTED_DATA"),
          (e.SHOW_ETF_HOLDINGS_DATA = "SHOW_ETF_HOLDINGS_DATA"),
          (e.CREATE_MORE_PORTFOLIOS = "CREATE_MORE_PORTFOLIOS"),
          (e.PORTFOLIO_TRANSACTIONS = "PORTFOLIO_TRANSACTIONS"),
          (e.PORTFOLIO_HOLDINGS = "PORTFOLIO_HOLDINGS"),
          (e.PORTFOLIO_DATA_LIMIT = "PORTFOLIO_DATA_LIMIT"),
          (e.SOCIAL_TRUSTED_USER = "SOCIAL_TRUSTED_USER"),
          (e.ACCESS_ACROSS_DEVICES = "ACCESS_ACROSS_DEVICES"),
          (e.FOLLOWERS_ONLY_MINDS = "FOLLOWERS_ONLY_MINDS"),
          (e.FORECAST_ESTIMATE_DATA = "FORECAST_ESTIMATE_DATA"),
          (e.DRAWINGS = "DRAWINGS"),
          (e.MACRO_MAPS = "MACRO_MAPS"),
          e
        );
      })({});
    },
    389086(e, t, r) {
      r.d(t, { TRIAL_SUFFIX: () => n });
      const n = "_trial";
    },
    982738(e, t, r) {
      r.d(t, { enabled: () => E, getConfig: () => c });
      var n = r(955089),
        i = r(495340),
        _ = r(202580),
        o = (r(956293), r(83019), r(467242)),
        s = r(127711),
        a = r(502587),
        l = r(910327);
      function E(e, t, r) {
        const n = r ?? window.user,
          _ = c(e, t, r);
        if (!_) return !1;
        if (_[i.ProductFeatures.DISABLE_ON_TRIAL] && (!n || n.is_trial))
          return !1;
        const s = _[i.ProductFeatures.DISABLE_ON_LITE_PLAN];
        if (s && n?.is_lite_plan) {
          if ("all" === s) return !1;
          if ("exclude_mobile" === s && !o.isAnyMobile) return !1;
        }
        return !0;
      }
      n.ProPlans.Free,
        n.ProPlans.Free,
        n.ProPlans.Pro,
        n.ProPlans.Pro,
        n.ProPlans.ProTrial,
        n.ProPlans.ProTrial,
        n.ProPlans.ProRealtime,
        n.ProPlans.ProRealtime,
        n.ProPlans.ProRealtimeTrial,
        n.ProPlans.ProRealtimeTrial,
        n.ProPlans.ProPremium,
        n.ProPlans.ProPremium,
        n.ProPlans.ProPremiumTrial,
        n.ProPlans.ProPremiumTrial;
      n.ExpertPlans.ProExpert,
        n.ExpertPlans.ProExpert,
        n.ExpertPlans.PremiumExpert,
        n.ExpertPlans.PremiumExpert,
        n.ExpertPlans.ProExpertTrial,
        n.ExpertPlans.ProExpertTrial,
        n.ExpertPlans.PremiumExpertTrial,
        n.ExpertPlans.PremiumExpertTrial;
      function S(e) {
        const t = a[e];
        return t ? (t.extends ? Object.assign({}, S(t.extends), t) : t) : null;
      }
      function c(e, t, r) {
        let i = S(
          t ||
            ((function (e) {
              const t = e ?? window.user;
              let r = t?.pro_plan || n.ProPlans.Free;
              return (
                (r !== n.ProPlans.Free && !(0, l.isTrialProduct)(r)) ||
                  (r = (0, l.getProductForTrial)(r)),
                r
              );
            })(r) ??
              "")
        );
        if (!i) return null;
        const o = (0, _.embedWidgetCustomer)();
        return (
          o && s[o] && (i = Object.assign({}, i, s[o])), (i && i[e]) || null
        );
      }
    },
    505519(e, t, r) {
      r.d(t, { getMinTickData: () => a, makeVariableMinTickData: () => E });
      var n = r(712745),
        i = r(881014),
        _ = r(66721),
        o = r(715471);
      function s(e) {
        return e ? (0, n.Big)(e.minMove).div(e.priceScale).toNumber() : NaN;
      }
      function a(e) {
        const {
            minTick: t,
            price: r,
            variableMinTickData: n,
            shouldCheckForEquality: _,
          } = e,
          o = (0, i.isNumber)(t) ? l(t) : t;
        return void 0 === n
          ? o
          : (function (e, t, r = !1) {
              for (let n = 0; n < t.length; n++) {
                if (e < t[n].price) return t[n].minTick;
                if (r && e === t[n].price) return t[n].minTick;
              }
              return t[t.length - 1].minTick;
            })(r, n, _);
      }
      function l(e) {
        const t = (0, _.numOfDecimalPlaces)(e),
          r = Math.pow(10, t);
        return { priceScale: r, minMove: (0, n.Big)(e).mul(r).toNumber() };
      }
      function E(e, t) {
        const r = [
          {
            minTick: (0, i.isNumber)(e) ? l(e) : e,
            price: 1 / 0,
            maxIndex: 1 / 0,
          },
        ];
        try {
          const e = t.split(" ").map((e, t) =>
            (0, o.isEven)(t)
              ? (function (e) {
                  const t = Number(e);
                  if (Number.isFinite(t)) return l(t);
                  {
                    const t = e.split("/");
                    if (t.length < 2 || t.length > 3)
                      throw new Error(`Unexpected mintick: ${e}`);
                    const r = Number(t[1]),
                      n = Number(t[0]);
                    if (!Number.isFinite(r) || !Number.isFinite(n))
                      throw new Error(`Unexpected mintick: ${e}`);
                    const i = 3 === t.length ? Number(t[2]) : void 0;
                    if (void 0 !== i && !Number.isFinite(i))
                      throw new Error(`Unexpected mintick: ${e}`);
                    const _ = { priceScale: r, minMove: n };
                    return void 0 !== i && (_.minMove2 = i), _;
                  }
                })(e)
              : (function (e) {
                  const t = Number(e);
                  if (Number.isNaN(t))
                    throw new Error(`Unexpected price limit: ${e}`);
                  return t;
                })(e)
          );
          if ((0, o.isEven)(e.length))
            throw new Error("Theme must not be event number of elements");
          const r = [];
          for (let t = 0; t < e.length; t += 2) {
            const i = e[t + 1] ?? 1 / 0,
              _ = r[r.length - 1]?.price ?? 0,
              o = r[r.length - 1]?.maxIndex ?? 0,
              a =
                i === 1 / 0
                  ? 1 / 0
                  : new n.Big(i).minus(_).div(s(e[t])).plus(o).toNumber();
            r.push({ minTick: e[t], price: i, maxIndex: a });
          }
          return r;
        } catch {
          return r;
        }
      }
    },
    516825(e, t, r) {
      r.d(t, { disable: () => E, enable: () => l, enabled: () => s });
      var n = r(558948);
      const i = new Map(),
        _ = new Map(),
        o = new Set();
      function s(e) {
        const t = i.get(e);
        if (void 0 !== t) return t;
        const r = _.get(e);
        return !!r && r.some(s);
      }
      function a(e, t) {
        i.set(String(e), Boolean(t));
      }
      function l(e) {
        a(e, !0);
      }
      function E(e) {
        a(e, !1);
      }
      !(function () {
        for (const [e, t] of Object.entries(n))
          if ((o.add(e), "subsets" in t))
            for (const r of t.subsets) {
              o.add(r);
              let t = _.get(r);
              void 0 === t && ((t = []), _.set(r, t)), t.push(e);
            }
      })();
    },
    948102(e, t, r) {
      r.d(t, { numberToStringWithLeadingZero: () => i });
      var n = r(881014);
      function i(e, t) {
        if (!(0, n.isNumber)(e)) return "n/a";
        if (!(0, n.isInteger)(t)) throw new TypeError("invalid length");
        if (t < 0 || t > 24) throw new TypeError("invalid length");
        if (0 === t) return e.toString();
        return ("00000000000000000000" + e.toString()).slice(-t);
      }
    },
    819511(e, t, r) {
      r.d(t, {
        getLogHistory: () => u,
        getLogger: () => R,
        getRawLogHistory: () => c,
        isHighRateEnabled: () => S,
      });
      let n = 0;
      const i = [];
      let _ = null,
        o = null,
        s = null,
        a = null,
        l = 2,
        E = !1;
      function S() {
        return E;
      }
      function c(e, t) {
        let r = i.reduce((e, t) => e.concat(t), []);
        return (
          r.sort((e, t) => e.id - t.id),
          void 0 !== t && (r = r.filter((e) => e.subSystemId === t)),
          "number" == typeof e && (r = r.slice(-e)),
          r
        );
      }
      function T(e) {
        return (
          new Date(e.timestamp).toISOString() +
          ":" +
          e.subSystemId +
          ":" +
          e.message.replace(/"/g, "'")
        );
      }
      const u = (e, t) =>
        (function (e, t) {
          let r,
            n = 0,
            i = 0;
          for (
            r = e.length - 1;
            r >= 1 &&
            ((n += 8 * (1 + encodeURIComponent(e[r]).length)),
            !(
              r - 1 > 0 &&
              ((i = 8 * (1 + encodeURIComponent(e[r - 1]).length)), n + i > t)
            ));
            r--
          );
          return e.slice(r);
        })(c(e, t).map(T), 75497472);
      function A(e, t, r, i, E) {
        if (t === o && i.id === s) return;
        const c = new Date();
        if (
          (e <= 4 &&
            (function (e, t, r, i, _, o) {
              "function" == typeof structuredClone && (t = structuredClone(t)),
                (t = t.slice(0, o ?? 1e3));
              const s = {
                id: n,
                message: t,
                subSystemId: i,
                timestamp: Number(e),
              };
              (n += 1),
                r.push(s),
                void 0 !== _ && r.length > _ && r.splice(0, 1);
            })(c, t, r, i.id, i.maxCount, E),
          e <= l && (!i.highRate || S()) && (!_ || i.id.match(_)))
        ) {
          const r = c.toISOString() + ":" + i.id + ":" + t;
          switch (e) {
            case 5:
              console.debug(r);
              break;
            case 3:
            case 4:
              i.color
                ? console.log("%c" + r, "color: " + i.color)
                : console.log(r);
              break;
            case 2:
              console.warn(r);
              break;
            case 1:
              console.error(r);
          }
          (o = t),
            (s = i.id),
            null !== a && clearTimeout(a),
            (a = setTimeout(() => {
              (o = null), (s = null), (a = null);
            }, 1e3));
        }
      }
      function R(e, t = {}) {
        const r = [];
        i.push(r);
        const n = Object.assign(t, { id: e });
        function _(e) {
          return (t, i) => A(e, String(t), r, n, i);
        }
        return {
          logDebug: _(5),
          logError: _(1),
          logInfo: _(3),
          logNormal: _(4),
          logWarn: _(2),
        };
      }
    },
    220455(e, t, r) {
      function n(e) {
        const t = (function (e) {
          if (void 0 === e) return null;
          const t = e.match(/(delayed_streaming)_(\d+)/);
          return null === t ? null : { mode: t[1], interval: parseInt(t[2]) };
        })(e.update_mode);
        return (
          null === t ||
            ((e.update_mode = t.mode), (e.update_mode_seconds = t.interval)),
          e
        );
      }
      r.d(t, { normalizeUpdateMode: () => n });
    },
  },
]);
