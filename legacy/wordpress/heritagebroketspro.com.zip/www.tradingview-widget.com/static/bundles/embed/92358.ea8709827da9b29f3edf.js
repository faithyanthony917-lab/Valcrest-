(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [71319, 92358],
  {
    878384(e) {
      e.exports = {};
    },
    940485(e, t, n) {
      n(32183).setClasses(), n(730072), n(937321);
      var r = n(771405).whenDocumentReady,
        i = n(770627).handleTVLinksClick;
      r(() => {
        i();
      });
    },
    384017(e, t, n) {
      "use strict";
      n.d(t, { fetch: () => s });
      var r = n(819511);
      n(284656);
      const i = (0, r.getLogger)("Fetch");
      function s(e, t, n = {}) {
        {
          const { logOnErrorStatus: r = !0, logBodyOnError: s = !1 } = n;
          (t = t || {}),
            (function (e) {
              return new URL(e, document.baseURI).origin === location.origin;
            })(e) &&
              (t.headers
                ? t.headers instanceof Headers ||
                  (t.headers = new Headers(t.headers))
                : (t.headers = new Headers()),
              window.locale && t.headers.set("X-Language", window.locale),
              t.headers.set("X-Requested-With", "XMLHttpRequest")),
            void 0 === t.credentials && (t.credentials = "same-origin");
          const o = window.fetch(e, t);
          return (
            o.then(
              (n) => {
                if (!n.ok && r) {
                  let r = "";
                  t.method && (r += `${t.method.toUpperCase()} `),
                    (r += e),
                    (r += `. Status ${n.status}`),
                    n.statusText && (r += `. ${n.statusText}`),
                    n.headers.via && (r += `. Via: ${n.headers.via}`),
                    s &&
                      "string" == typeof t.body &&
                      (r += `. Body: ${t.body.slice(0, 1024)}`),
                    i.logError(r);
                }
                return n;
              },
              (n) => {
                if (n && "AbortError" === n.name) return;
                let r = "";
                t.method && (r += `${t.method.toUpperCase()} `),
                  (r += e),
                  navigator.onLine
                    ? (r += `. ${String(n)}`)
                    : (r += ". User is offline."),
                  i.logError(r);
              }
            ),
            o
          );
        }
      }
    },
    932365(e, t, n) {
      "use strict";
      n.d(t, { TVLocalStorage: () => s });
      const r = (0, n(819511).getLogger)("TVLocalStorage");
      var i = function () {
        try {
          (this.isAvailable = !0),
            (this.localStorage = window.localStorage),
            this.localStorage.setItem("tvlocalstorage.available", "true");
        } catch (e) {
          delete this.isAvailable, delete this.localStorage;
        }
        this._updateLength();
        try {
          this._report();
        } catch (e) {}
      };
      (i.prototype._report = function () {
        if (this.isAvailable) {
          const e = 10,
            t = [];
          for (let e = 0; e < this.localStorage.length; e++) {
            const n = this.key(e);
            t.push({ key: n, length: String(this.getItem(n)).length });
          }
          t.sort((e, t) => t.length - e.length);
          const n = t.slice(0, e);
          t.sort((e, t) => t.key.length - e.key.length);
          const i = t.slice(0, e);
          r.logNormal(`Total amount of keys in Local Storage: ${this.length}`),
            r.logNormal(
              `Top ${e} keys with longest values: ${JSON.stringify(n)}`
            ),
            r.logNormal(`Top ${e} longest key names: ${JSON.stringify(i)}`);
          try {
            navigator.storage.estimate().then((e) => {
              r.logNormal(`Storage estimate: ${JSON.stringify(e)}`);
            });
          } catch (e) {}
        }
      }),
        (i.prototype.length = 0),
        (i.prototype.isAvailable = !1),
        (i.prototype.localStorage = { "tvlocalstorage.available": "false" }),
        (i.prototype._updateLength = function () {
          if (this.isAvailable) this.length = this.localStorage.length;
          else {
            var e,
              t = 0;
            for (e in this.localStorage)
              this.localStorage.hasOwnProperty(e) && t++;
            this.length = t;
          }
        }),
        (i.prototype.key = function (e) {
          return this.isAvailable
            ? this.localStorage.key(e)
            : Object.keys(this.localStorage)[e];
        }),
        (i.prototype.getItem = function (e) {
          return this.isAvailable
            ? this.localStorage.getItem(e)
            : void 0 === this.localStorage[e]
            ? null
            : this.localStorage[e];
        }),
        (i.prototype.setItem = function (e, t) {
          this.isAvailable
            ? this.localStorage.setItem(e, t)
            : (this.localStorage[e] = t),
            this._updateLength();
        }),
        (i.prototype.removeItem = function (e) {
          this.isAvailable
            ? this.localStorage.removeItem(e)
            : delete this.localStorage[e],
            this._updateLength();
        }),
        (i.prototype.clear = function () {
          this.isAvailable
            ? this.localStorage.clear()
            : (this.localStorage = {}),
            this._updateLength();
        });
      const s = new i();
      window.TVLocalStorage = s;
    },
    383636(e, t, n) {
      "use strict";
      n.d(t, { t: () => r });
      const r = n.i18next;
    },
    892449(e, t, n) {
      "use strict";
      n.d(t, { getEnvValue: () => i });
      const r = globalThis;
      function i(e) {
        return r[e];
      }
    },
    39032(e, t, n) {
      "use strict";
      n.d(t, { isFeatureEnabled: () => u });
      var r = n(570071),
        i = n(503617),
        s = n(739722),
        o = n(932365);
      const a = new r.Delegate(),
        l = "forcefeaturetoggle.";
      const c = new (class {
        enableFeature(e) {
          o.TVLocalStorage.setItem(l + e, "true"), a.fire(e);
        }
        disableFeature(e) {
          o.TVLocalStorage.setItem(l + e, "false"), a.fire(e);
        }
        resetFeature(e) {
          o.TVLocalStorage.removeItem(l + e), a.fire(e);
        }
        onFeaturesStateChanged() {
          return a;
        }
      })();
      function d(e, t) {
        return (
          (!e[t] || -1 !== e[t]) &&
          (!!(
            "true" === o.TVLocalStorage.getItem(l + t) ||
            (window.is_authenticated &&
              "true" === window.user?.settings?.[l + t])
          ) ||
            (!(
              "false" === o.TVLocalStorage.getItem(l + t) ||
              (window.is_authenticated &&
                "false" === window.user?.settings?.[l + t])
            ) &&
              !!e[t] &&
              (1 === e[t] || (0, s.shouldAffectUser)(t, e[t]))))
        );
      }
      (window.TradingView = window.TradingView || {}),
        (window.TradingView.FeatureToggle = c);
      const u =
        ((g = window.featureToggleState || {}),
        (0, i.onWidget)() ||
          Promise.all([n.e(50488), n.e(13993)])
            .then(n.bind(n, 250488))
            .then((e) => {
              e.pushStreamMultiplexer.on("featuretoggle", (e) => {
                const t = d(g, e.name);
                (g[e.name] = e.state), t !== d(g, e.name) && a.fire(e.name);
              });
            }),
        d.bind(null, g));
      var g;
      window.TradingView.isFeatureEnabled = u;
    },
    514154(e, t, n) {
      "use strict";
      n.d(t, { getInitDataField: () => a });
      var r = n(146961);
      const i = (0, n(819511).getLogger)("Common.InitData"),
        s = "undefined" == typeof window ? {} : window.initData || {};
      function o() {
        !(function () {
          const e = window;
          e.initData &&
            e.initData !== s &&
            (Object.assign(s, e.initData), (e.initData = s));
        })();
        const e = document.querySelectorAll(
          'script[type="application/prs.init-data+json"]'
        );
        for (let t = 0; t < e.length; t++) {
          const n = e[t];
          try {
            const e = JSON.parse((0, r.ensureNotNull)(n.textContent));
            Object.assign(s, e);
          } catch (e) {
            i.logWarn(`Failed to parse initData element. ${e}`);
          } finally {
            (0, r.ensureNotNull)(n.parentNode).removeChild(n);
          }
        }
        const t = s.content;
        t &&
          s.study_meta_info_map &&
          (t.studyMetaInfoMap = {
            ...t.studyMetaInfoMap,
            ...s.study_meta_info_map,
          });
      }
      function a(e) {
        return o(), s[e];
      }
    },
    503617(e, t, n) {
      "use strict";
      n.d(t, { onWidget: () => i });
      const r = new Map();
      function i() {
        const e = window.location.pathname,
          t = window.location.host,
          n = `${t}${e}`;
        return (
          r.has(n) ||
            r.set(
              n,
              (function (e, t) {
                const n = ["^widget-docs"];
                for (const e of n) if (new RegExp(e).test(t)) return !0;
                const r = [
                    "^widgetembed/?$",
                    "^cmewidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/widgetembed/?$",
                    "^([0-9a-zA-Z-]+)/widgetstatic/?$",
                    "^([0-9a-zA-Z-]+)?/?mediumwidgetembed/?$",
                    "^twitter-chart/?$",
                    "^telegram/chart/?$",
                    "^embed/([0-9a-zA-Z]{8})/?$",
                    "^widgetpopup/?$",
                    "^extension/?$",
                    "^idea-popup/?$",
                    "^hotlistswidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/hotlistswidgetembed/?$",
                    "^marketoverviewwidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/marketoverviewwidgetembed/?$",
                    "^eventswidgetembed/?$",
                    "^tickerswidgetembed/?$",
                    "^forexcrossrateswidgetembed/?$",
                    "^forexheatmapwidgetembed/?$",
                    "^marketquoteswidgetembed/?$",
                    "^screenerwidget/?$",
                    "^cryptomktscreenerwidget/?$",
                    "^([0-9a-zA-Z-]+)/cryptomktscreenerwidget/?$",
                    "^([0-9a-zA-Z-]+)/marketquoteswidgetembed/?$",
                    "^technical-analysis-widget-embed/$",
                    "^singlequotewidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/singlequotewidgetembed/?$",
                    "^embed-widget/([0-9a-zA-Z-]+)/(([0-9a-zA-Z-]+)/)?$",
                    "^widget-docs/([0-9a-zA-Z-]+)/([0-9a-zA-Z-/]+)?$",
                  ],
                  i = e.replace(/^\//, "");
                let s;
                for (let e = r.length - 1; e >= 0; e--)
                  if (((s = new RegExp(r[e])), s.test(i))) return !0;
                return !1;
              })(e, t)
            ),
          r.get(n) ?? !1
        );
      }
    },
    739722(e, t, n) {
      "use strict";
      n.d(t, { shouldAffectUser: () => l });
      var r = n(100595),
        i = n.n(r),
        s = n(932365);
      const o = "featuretoggle_seed";
      function a(e) {
        try {
          const t = i()(
              e +
                (function () {
                  if (window.user && window.user.id) return window.user.id;
                  const e = s.TVLocalStorage.getItem(o);
                  if (null !== e) return e;
                  const t = Math.floor(1e6 * Math.random());
                  return s.TVLocalStorage.setItem(o, `${t}`), t;
                })()
            ),
            n = new DataView(t);
          return n.getUint32(0, !0) / 4294967296;
        } catch (e) {
          return 0.5;
        }
      }
      function l(e, t) {
        return a(e) <= t;
      }
    },
    863644(e, t, n) {
      "use strict";
      function r(e) {
        const t = new URL(e, document.baseURI);
        return s(t) && i(t);
      }
      n.d(t, { isInternalHost: () => o, isSafeUrl: () => r });
      const i = (e) => !e.username,
        s = (e) => "http:" === e.protocol || "https:" === e.protocol;
      function o(e, t = window.location.hostname) {
        const n = "." === t.slice(-1) ? 3 : 2,
          r = t.toLowerCase().split(".").slice(-n),
          i = e.toLowerCase().split(".").slice(-r.length);
        return r.join(".") === i.join(".");
      }
    },
    556554(e, t, n) {
      "use strict";
      n.d(t, { createCopyrightLabel: () => a });
      var r = n(914487),
        i = n.n(r),
        s = n(869996),
        o = n(943667);
      function a({ sheriffOptions: e, ...t }) {
        const [n, r] = (0, s.copyrightLabel)(t),
          a = e && e.includes(o.KnownAction.Expand),
          l = e && e.includes(o.KnownAction.LargeTradeLogo);
        return (
          (n.className = i()(
            n.className,
            (a || l) && r.expandedWithTransition
          )),
          n
        );
      }
    },
    285187(e, t, n) {
      "use strict";
      function r(e, t) {
        return e && e.utm_campaign && (e.utm_campaign += `-${t}`), e;
      }
      async function i(e, t, r, i) {
        if ("lentaru" === e) {
          const { getLentaCopyrightData: e } = await Promise.all([
            n.e(92991),
            n.e(85038),
          ]).then(n.bind(n, 487707));
          return e();
        }
        if ("cmoneycomtw" === e) {
          const { getCmoneycomtwCopyrightData: e } = await Promise.all([
            n.e(84351),
            n.e(17007),
            n.e(71394),
          ]).then(n.bind(n, 747803));
          return e(t, r);
        }
        if ("new" === i) {
          const { getTradingViewCopyrightData: e } = await Promise.all([
            n.e(82727),
            n.e(76040),
          ]).then(n.bind(n, 802175));
          return e(t, r);
        }
        if ("with_border" === i) {
          const { getTradingViewCopyrightData: e } = await Promise.all([
            n.e(70715),
            n.e(16813),
          ]).then(n.bind(n, 845831));
          return e(t, r);
        }
        if ("large_trade" === i) {
          const { getTradingViewCopyrightData: e } = await Promise.all([
            n.e(38213),
            n.e(79041),
          ]).then(n.bind(n, 460973));
          return e(t, r);
        }
        {
          const { getTradingViewCopyrightData: e } = await Promise.all([
            n.e(84351),
            n.e(97509),
          ]).then(n.bind(n, 80595));
          return e(t, r);
        }
      }
      n.d(t, {
        addUtmCampaignSource: () => r,
        getCustomerCopyrightData: () => i,
      });
    },
    356656(e, t, n) {
      "use strict";
      n.d(t, { filterUtmInfo: () => s });
      var r = n(246759);
      const i = ["utm_source", "utm_medium", "utm_campaign"];
      function s(e) {
        const t = {};
        return (
          i.forEach((n) => {
            const i = e[n];
            "string" == typeof i && "" !== i && (t[n] = (0, r.htmlEscape)(i));
          }),
          t
        );
      }
    },
    943667(e, t, n) {
      "use strict";
      n.d(t, { KnownAction: () => r });
      var r = (function (e) {
        return (
          (e.Expand = "expand-logo"), (e.LargeTradeLogo = "large-trade-logo"), e
        );
      })({});
    },
    343747(e, t, n) {
      "use strict";
      n.d(t, { getWidgetSheriffActions: () => d });
      var r = n(819511),
        i = n(384017),
        s = n(943667);
      const o = new Set([s.KnownAction.Expand, s.KnownAction.LargeTradeLogo]),
        a =
          window.WIDGET_SHERIFF_HOST ||
          "https://widget-sheriff.xstaging-widget.tv",
        l = (0, r.getLogger)("WidgetSheriff.Widget");
      let c = null;
      async function d() {
        return (
          null === c &&
            (c = await (async function () {
              const e = (function () {
                if (
                  document.location.ancestorOrigins &&
                  document.location.ancestorOrigins.length
                )
                  return document.location.ancestorOrigins[
                    document.location.ancestorOrigins.length - 1
                  ];
                try {
                  return new URL(document.referrer).origin;
                } catch (e) {
                  return document.location.origin || null;
                }
              })();
              if (null === e)
                return (
                  l.logWarn("ancestorOrigin is undefined"), Promise.resolve([])
                );
              const t = new URL("/sheriff/api/v1/rules/search", a);
              t.searchParams.append("origin", e);
              return (
                await (0, i.fetch)(t.toJSON())
                  .then((e) => {
                    if (!e.ok) throw new Error("Guard request error occured");
                    return 204 === e.status
                      ? Promise.resolve({ actions: [] })
                      : e.json();
                  })
                  .catch(
                    (e) => (
                      l.logWarn(e.message), Promise.resolve({ actions: [] })
                    )
                  )
              ).actions.filter((e) => o.has(e));
            })()),
          Promise.resolve(c)
        );
      }
    },
    905436(e, t, n) {
      "use strict";
      n.d(t, { addUtmToUrl: () => i });
      var r = n(201109);
      function i(e, t) {
        if (!/([a-zA-Z0-9.-]*tradingview.com)|localhost/.test(e)) return e;
        const n = (0, r.utmQueryString)(t);
        if ("" === n) return e;
        const i = e.indexOf("?"),
          s = e.indexOf("#"),
          o = -1 !== s;
        if (-1 !== i && (!o || i < s)) {
          return `${e.slice(0, i)}?${
            o ? e.slice(i + 1, s) : e.slice(i + 1)
          }&${n}${o ? e.slice(s) : ""}`;
        }
        if (o) {
          return `${e.slice(0, s)}?${n}${e.slice(s)}`;
        }
        return `${e}?${n}`;
      }
    },
    201109(e, t, n) {
      "use strict";
      n.d(t, { utmQueryString: () => i });
      var r = n(533618);
      function i(e, t = !1) {
        const n = (0, r.createUrlParams)(e);
        return n && t ? `?${n}` : n;
      }
    },
    444873(e, t, n) {
      "use strict";
      n.d(t, { makeTemplateSymbolUrl: () => s });
      var r = n(980136),
        i = n(863644);
      function s(e, t) {
        let n = e;
        if (!/{tvsymbol}|{tvexchange}|{tvprosymbol}/.test(e)) {
          let r = "tvprosymbol";
          void 0 === t.proName && (r = "tvsymbol"),
            (n = `${e}?tvwidgetsymbol={${r}}`);
        }
        const s = (0, r.renderTemplate)(
          n,
          (0, r.makeSymbolInfoWithSymbolInfoPriority)(
            (0, r.normalizeSpreadSymbol)(t)
          )
        );
        if (!(0, i.isSafeUrl)(s))
          throw new Error(`The symbol URL ${s} is not allowed.`);
        return s;
      }
    },
    285478(e, t, n) {
      "use strict";
      n.d(t, { createEmbedWidgetWrapper: () => d });
      var r = n(146961),
        i = n(343747),
        s = n(556554),
        o = n(285187),
        a = n(563946),
        l = n(943667);
      async function c(e, t, n, c, d = {}) {
        const u = d.isSheriffDisabled
            ? []
            : await (0, i.getWidgetSheriffActions)(),
          g = u.includes(l.KnownAction.LargeTradeLogo),
          h = (function (e) {
            return [
              a.WidgetId.CryptoCoinsHeatmap,
              a.WidgetId.ForexCrossRates,
              a.WidgetId.MarketOverview,
              a.WidgetId.SymbolOverview,
              a.WidgetId.MarketQuotes,
              a.WidgetId.StockHeatmap,
              a.WidgetId.Screener,
              a.WidgetId.ForexHeatMap,
              a.WidgetId.CryptoMktScreener,
              a.WidgetId.EconomicCalendar,
              a.WidgetId.Hotlists,
            ].includes(e);
          })(t),
          p = g && h ? "large_trade" : void 0,
          m = await (0, o.getCustomerCopyrightData)(
            d.customer,
            d.locale,
            (0, o.addUtmCampaignSource)({ ...c }, "logo"),
            p
          ),
          w = p ?? d.copyrightOptions?.mode ?? "small_old";
        (0, r.ensureNotNull)(e).appendChild(
          (0, s.createCopyrightLabel)({
            sheriffOptions: u,
            snapToEdge: n,
            ...d.copyrightOptions,
            ...m,
            mode: w,
          })
        );
      }
      function d(e, t, n, i = {}) {
        if (null === e.parentElement)
          return (
            console.warn(
              "Can not wrap 'elWidgetContainer' because it has no parentElement"
            ),
            e
          );
        let s = null,
          o = document.querySelector(".js-embed-widget-body");
        const a = null !== o;
        if (a) {
          (o = (0, r.ensureNotNull)(o)),
            (s = (0, r.ensureNotNull)(o.parentElement));
          let e = document.querySelector(".js-embed-widget-head");
          null === e &&
            ((e = document.createElement("div")),
            e.classList.add("tv-embed-widget-wrapper__header"),
            e.classList.add("js-embed-widget-head"),
            s.insertBefore(e, o));
        } else
          (s = document.createElement("div")),
            s.classList.add("tv-embed-widget-wrapper"),
            (s.innerHTML =
              '<div class="tv-embed-widget-wrapper__header js-embed-widget-head"></div><div class="tv-embed-widget-wrapper__body js-embed-widget-body"></div>'),
            (o = s.querySelector(".js-embed-widget-body"));
        if (
          (i.overflowAuto &&
            o.classList.add("tv-embed-widget-wrapper__body--overflow_auto"),
          i.showBorderOnTransparent &&
            o.classList.add(
              "tv-embed-widget-wrapper__body--border-on-transparent"
            ),
          !i.isWhiteLabel)
        ) {
          c(
            o,
            t,
            !document.documentElement.classList.contains("is-transparent") ||
              Boolean(i.showBorderOnTransparent),
            n,
            i
          );
        }
        return a || (e.parentElement.insertBefore(s, e), o.appendChild(e)), e;
      }
    },
    952643(e, t, n) {
      "use strict";
      n.d(t, { createEmbedWidgetWrapper: () => r.createEmbedWidgetWrapper });
      n(878384);
      var r = n(285478);
    },
    570071(e, t, n) {
      "use strict";
      n.d(t, { Delegate: () => s });
      const r = (0, n(819511).getLogger)("Common.Delegate");
      function i(e) {
        return !e.singleShot;
      }
      class s {
        subscribe(e, t, n) {
          this._listeners.push({
            object: e,
            member: t,
            singleShot: !!n,
            skip: !1,
          });
        }
        unsubscribe(e, t) {
          for (let n = 0; n < this._listeners.length; ++n) {
            const r = this._listeners[n];
            if (r.object === e && r.member === t) {
              (r.skip = !0), this._listeners.splice(n, 1);
              break;
            }
          }
        }
        unsubscribeAll(e) {
          for (let t = this._listeners.length - 1; t >= 0; --t) {
            const n = this._listeners[t];
            n.object === e && ((n.skip = !0), this._listeners.splice(t, 1));
          }
        }
        destroy() {
          this._listeners = [];
        }
        _fireImpl(...e) {
          const t = this._listeners;
          this._listeners = this._listeners.filter(i);
          const n = t.length;
          for (let i = 0; i < n; ++i) {
            const n = t[i];
            if (!n.skip)
              try {
                n.member.apply(n.object || null, e);
              } catch (e) {
                r.logError(`${e && (e.stack || e.message)}`);
              }
          }
        }
        constructor() {
          (this.fire = this._fireImpl.bind(this)), (this._listeners = []);
        }
      }
    },
    533618(e, t, n) {
      "use strict";
      function r(e) {
        const t = [];
        for (const n in e)
          if (e.hasOwnProperty(n) && null != e[n]) {
            const r = e[n],
              i = "object" == typeof r ? JSON.stringify(r) : String(r);
            t.push({
              key: n,
              pair: encodeURIComponent(n) + "=" + encodeURIComponent(i),
            });
          }
        return t
          .sort((e, t) => (e.key > t.key ? 1 : e.key < t.key ? -1 : 0))
          .map((e) => e.pair)
          .join("&");
      }
      n.d(t, {
        createUrlParams: () => r,
      });
    },
    140136(e, t, n) {
      "use strict";
      n.d(t, { WatchedValue: () => a });
      var r = n(819511),
        i = n(863150);
      const s = (0, r.getLogger)("Common.WatchedValue");
      function o(e) {
        s.logError(`${e && (e.stack || e.message)}`);
      }
      class a {
        destroy() {
          this.unsubscribe();
        }
        value() {
          return this._owner ? this._owner._value : this._value;
        }
        setValue(e, t) {
          const n = this._owner ? this._owner : this;
          if (n.writeLock) return;
          const r =
            n._value === e || (Number.isNaN(n._value) && Number.isNaN(e));
          if (!t && r && n.hasOwnProperty("_value")) return;
          n._value = e;
          const i = n._listeners.slice();
          let s = 0;
          for (let t = 0; t < i.length; t++) {
            i[t].once && (n._listeners.splice(t - s, 1), s++);
            try {
              i[t].cb(e);
            } catch (e) {
              o(e);
            }
          }
        }
        deleteValue() {
          this.setValue(void 0);
        }
        subscribe(e, t) {
          if ("function" != typeof e)
            throw new TypeError("callback must be a function");
          const n = !!t && !!t.once,
            r = !!t && !!t.callWithLast,
            i = this._owner ? this._owner : this;
          if (r && i.hasOwnProperty("_value")) {
            try {
              e(i._value);
            } catch (e) {
              o(e);
            }
            if (n) return;
          }
          i._listeners.push({ cb: e, owner: this, once: !!t && !!t.once });
        }
        unsubscribe(e) {
          const t = this._owner ? this._owner : this;
          void 0 === e && (e = null);
          const n = t._listeners;
          for (let r = n.length; r--; )
            (n[r].owner !== this && t !== this) ||
              (n[r].cb !== e && null !== e) ||
              n.splice(r, 1);
        }
        readonly() {
          if (this._readonlyInstance) return this._readonlyInstance;
          const e = {
            subscribe: this.subscribe.bind(this),
            unsubscribe: this.unsubscribe.bind(this),
            value: this.value.bind(this),
            when: this.when.bind(this),
            ownership: this.ownership.bind(this),
            spawnOwnership: this.spawnOwnership.bind(this),
            weakReference: this.weakReference.bind(this),
            spawn: (e) => this.spawn(e).readonly(),
            destroy: this.destroy.bind(this),
          };
          return (this._readonlyInstance = e), e;
        }
        spawn(e) {
          return this._spawn(e);
        }
        when(e) {
          (0, i.callWhen)(
            this,
            (e) => Boolean(e),
            () => {
              try {
                e(this.value());
              } catch (e) {
                o(e);
              }
            }
          );
        }
        assertNoSubscriptions() {
          0;
        }
        ownership() {
          return this;
        }
        release() {
          this.destroy();
        }
        spawnOwnership() {
          return this._spawn();
        }
        weakReference() {
          return this._spawn(void 0, !0);
        }
        _spawn(e, t) {
          return new l(this._owner || this, e, t);
        }
        constructor(...e) {
          (this._listeners = []),
            e.length > 0 ? (this._value = e[0]) : delete this._value;
        }
      }
      class l extends a {
        destroy() {
          try {
            this._onDestroy?.();
          } catch (e) {
            o(e);
          }
          super.destroy();
        }
        readonly() {
          return (
            this._readonlySpawnInstance ||
              (this._readonlySpawnInstance = {
                ...super.readonly(),
                destroy: () => this.destroy(),
                readonly() {
                  return this;
                },
              }),
            this._readonlySpawnInstance
          );
        }
        release() {
          this._weakReference || super.release();
        }
        constructor(e, t, n) {
          super(),
            delete this._listeners,
            (this._owner = e),
            (this._onDestroy = t),
            (this._weakReference = !!n);
        }
      }
    },
    837483(e, t, n) {
      "use strict";
      n.d(t, { formatNumber: () => o, parseNumber: () => l });
      var r = n(712745),
        i = n(663046),
        s = n(334120);
      function o(e, t, n, i, s) {
        if (!Number.isFinite(e)) return `${e}`;
        const o = -1 === Math.sign(e) ? "-" : "";
        e = Math.abs(e);
        let a = void 0 === n ? e.toString() : e.toFixed(n);
        if (a.includes("e")) {
          if (!i) return `${o}${a.replace(".", t.decimalSign)}`;
          {
            const n = new r.Big(e);
            if (((a = n.lt(1) ? n.toFixed() : n.toString()), a.includes("e")))
              return `${o}${a.replace(".", t.decimalSign)}`;
          }
        }
        const l = a.split("."),
          c = l[0];
        let d = l[1];
        const u = (function (e, t) {
          let n = e.length;
          const r = [];
          for (; n > 0; ) r.unshift(e.slice(Math.max(n - 3, 0), n)), (n -= 3);
          return r.join(t);
        })(c, t.groupingSeparator);
        return (
          void 0 !== n && (d = 0 === n ? void 0 : e.toFixed(n).slice(-n)),
          void 0 !== s &&
            void 0 !== d &&
            (d = (function (e, t) {
              let n = e.length - 1;
              for (let r = n; r >= t && "0" === e[r]; r -= 1) n -= 1;
              return e.slice(0, n + 1);
            })(d, s)),
          d ? `${o}${u}${t.decimalSign}${d}` : `${o}${u}`
        );
      }
      const a = (0, i.default)((e) => {
        const t = e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
        return new RegExp(t, "gm");
      });
      function l(e, t) {
        if (/^(NaN|[+|-]?Infinity)$/.test(e)) return parseFloat(e);
        e = (0, s.stripLTRMarks)(e);
        const n = a(t.groupingSeparator);
        return (
          n && (e = e.replace(n, "")),
          (e = e.replace(t.decimalSign, ".")),
          /^(\+|-)?\d+(\.\d+|\.)?(e(\+|-)?\d+)?$/.test(e) ? parseFloat(e) : NaN
        );
      }
    },
    925639(e, t, n) {
      "use strict";
      n.d(t, { getNumberFormat: () => u });
      var r = n(135277),
        i = n(714942);
      function s(e, t) {
        return { groupingSeparator: e, decimalSign: t };
      }
      const o = s(",", "."),
        a = s(".", ","),
        l = s(" ", ","),
        c = s("", "."),
        d = new Map([
          ["en", o],
          ["th", o],
          ["ja", o],
          ["ko", o],
          ["zh", o],
          ["zh_TW", o],
          ["ar", o],
          ["he_IL", o],
          ["ms_MY", o],
          ["vi", o],
          ["de", a],
          ["es", a],
          ["it", a],
          ["tr", a],
          ["pt", a],
          ["id_ID", a],
          ["fr", l],
          ["pl", l],
          ["ru", l],
        ]);
      function u(e) {
        return e
          ? c
          : (0, i.applyFormatModifier)(d.get((0, r.getLanguage)()) || c);
      }
    },
    714942(e, t, n) {
      "use strict";
      n.d(t, { applyFormatModifier: () => i });
      let r = null;
      function i(e) {
        return r ? r(e) : e;
      }
    },
    920621(e, t, n) {
      "use strict";
      n.d(t, { SEPARATOR_PREFIX: () => r });
      const r = "###";
    },
    683325(e, t, n) {
      "use strict";
      function r(e, t, n = {}) {
        return Object.assign(
          {},
          e,
          (function (e, t, n = {}) {
            const r = Object.assign({}, t);
            for (const i of Object.keys(t)) {
              const s = n[i] || i;
              s in e && (r[i] = [e[s], t[i]].join(" "));
            }
            return r;
          })(e, t, n)
        );
      }
      n.d(t, { mergeThemes: () => r });
    },
    398871(e, t, n) {
      "use strict";
      n.d(t, { hasCryptoTypespec: () => r });
      function r(e) {
        return void 0 !== e && e.includes("crypto");
      }
    },
    371774(e, t, n) {
      "use strict";
      function r(e, t) {
        const n = t || window.locale || "en";
        let r = e[n] ? e[n] : e.en;
        return (
          (r = "tradingview.com" === r ? "www.tradingview.com" : r),
          r ? document.location.protocol + "//" + r : ""
        );
      }
      n.d(t, { determineBaseUrl: () => r });
    },
    648143(e, t, n) {
      "use strict";
      n.d(t, { SymbolSubpath: () => r });
      var r = (function (e) {
        return (
          (e.Empty = ""),
          (e.TechnicalsPath = "technicals/"),
          (e.FinancialsOverviewPath = "financials-overview/"),
          (e.TimelinePath = "history-timeline/"),
          (e.NewsPath = "news/"),
          (e.OptionsPath = "options/"),
          (e.ProfilePath = "profile/"),
          (e.HoldingsPath = "holdings/"),
          e
        );
      })({});
    },
    730072(e, t, n) {
      "use strict";
      n.r(t);
      var r = n(135277),
        i = n(933142);
      (0, r.registerLanguageGetter)(() => window.language || ""),
        (0, r.registerLanguageCodeMapper)(i.getIsoLanguageCodeFromLanguage);
    },
  },
]);
