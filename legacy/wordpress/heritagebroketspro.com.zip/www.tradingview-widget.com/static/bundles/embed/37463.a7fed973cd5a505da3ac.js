(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [37463],
  {
    756514(t) {
      t.exports = {};
    },
    478051(t) {
      t.exports = {};
    },
    490506(t, e, s) {
      "use strict";
      s.d(e, { QuoteTicker: () => S });
      var i = s(565199),
        o = s(819511),
        n = s(881014),
        a = s(174673),
        l = s(349356),
        r = s(958633),
        h = s(377979),
        c = s(871847),
        d = s(851234),
        _ = s(808807),
        u = s(769215),
        m = s(861378),
        p = s(748351);
      function g(t, e, s) {
        const i = (function (t) {
          if (null != t && "boolean" != typeof t && !isNaN(Number(t)))
            return Number(t);
        })(t);
        if (("economic" === e?.type && 0 === i) || void 0 === i) return;
        const o =
            s?.customPriceFormatter ||
            ("volume" === e.format &&
              new h.VolumeFormatter({ precision: 2 })) ||
            new r.PriceFormatter({
              priceScale: e.pricescale || 100,
              minMove: e.minmov || 1,
              fractional: e.fractional,
              minMove2: e.minmove2,
            }),
          n =
            void 0 !== s?.signPositiveChange
              ? s.signPositiveChange
              : s?.signPositive;
        return ((t, e = !0) => (e ? `(${t})` : t))(
          o.format(i, { signPositive: n, signNegative: s?.signNegative }),
          s?.changeInBrackets
        );
      }
      var f = s(383636);
      function y(t) {
        switch (t) {
          case "DEGC":
            return "℃";
          case "PCTDY":
            return f.t(null, { context: "_max_len_9" }, s(44505));
          case "PCTPAR":
            return f.t(null, { context: "_max_len_9" }, s(468460));
          default:
            return t;
        }
      }
      var v = (function (t) {
        return (t.McxFlag = "mcx_free"), t;
      })({});
      function b(t) {
        return t === v.McxFlag;
      }
      var x = s(511649);
      const C = (0, o.getLogger)("QuoteTicker"),
        N = {
          addDescriptionTitle: !0,
          changeDirectionDownClass: "down",
          changeDirectionUpClass: "up",
          changeDirectionNeutralClass: "neutral",
          changeInBrackets: !1,
          changePercentInBrackets: !1,
          lastPriceTimeInBrackets: !0,
          lastReleaseDateTimeInBrackets: !0,
          rtcTimeInBrackets: !0,
          clientName: "quote-ticker",
          dontDyePrice: !1,
          fallingBg: null,
          growingBg: null,
          lastFallingClass: "falling",
          lastGrowingClass: "growing",
          quoteSession: null,
          signNegative: !0,
          signPositive: !1,
          customPriceFormatter: null,
          customTimeFormatter: null,
          sessionStatusClassSuffix: "--for-ticker",
          dataModeClassSuffix: "--for-ticker",
          showInvalidSymbolStatus: !1,
          indicatorsTooltipType: "custom",
          lastPriceLastCharSup: !1,
          lastPriceHighlightDiffOnly: !1,
          initedHook: void 0,
          setStateHook: void 0,
          permissionDeniedHook: void 0,
          noSuchSymbolHook: void 0,
        },
        T = /[KMBT]/;
      function S(t, e, s = {}) {
        (this.enabled = !0),
          (this._symbol = t),
          (this._symbolOriginal = null),
          (this._options = (0, i.deepExtend)({}, N, s)),
          !1 !== this._options.signNegative &&
            !0 !== this._options.signNegative &&
            delete this._options.signNegative,
          s.customPriceFormatter &&
            (this._customPriceFormatter = s.customPriceFormatter),
          s.customTimeFormatter &&
            (void 0 !== s.customTimeFormatter.lastPrice ||
            void 0 !== s.customTimeFormatter.rtc
              ? (this._timeFormatter = s.customTimeFormatter)
              : (this._timeFormatter = {
                  lastPrice: s.customPriceFormatter,
                  rtc: s.customPriceFormatter,
                })),
          (this._percentFormatter = new a.PercentageFormatter()),
          (this._defaultPriceFormatter = new r.PriceFormatter({
            priceScale: 100,
          })),
          (this._priceFormatter =
            this._customPriceFormatter || this._defaultPriceFormatter),
          (this._volumeFormatter = new h.VolumeFormatter({ precision: 2 })),
          (this._cache = {}),
          (this._lastPrice = null),
          (this._lastPriceFormatted = ""),
          (this._lastMinMove = 0),
          (this._elements = {}),
          (this._textNodes = {}),
          (this._changeVolumeLetter = this._getChangeVolumeLetterCallback()),
          this._setElements(e),
          (this._highlighters = {}),
          this._initHighlighters(),
          this._options.setStateHook &&
            this.setStateHook(this._options.setStateHook),
          (this.quoteSession =
            this._options.quoteSession ||
            (0, m.getQuoteSessionInstance)("simple")),
          (this._quoteSessionEventHandler = this.onData.bind(this)),
          (this._connectTimeoutId = setTimeout(this.connect.bind(this), 0));
      }
      function k(t) {
        const e = t.search(T),
          s = e >= 0 ? t.slice(e) : "";
        return [e > 0 ? t.substring(e, 0) : 0 === e ? "" : t, s];
      }
      function w(t, e, s, i, o) {
        var n,
          a = null;
        function l() {
          if ((n && (clearTimeout(n), (n = void 0)), s || e))
            for (var a = 0; a < t.length; a++) t[a].style.background = "";
          if (!s || !e)
            for (a = 0; a < t.length; a++)
              i && t[a].classList.remove(i), o && t[a].classList.remove(o);
        }
        return {
          show: function (r) {
            var h = 0;
            if (r !== a) {
              if (
                (null !== a && null !== r && (h = r - a),
                l(),
                (n = setTimeout(l, 750)),
                0 < h)
              ) {
                if (e)
                  for (var c = 0; c < t.length; c++) t[c].style.background = e;
                else if (i)
                  for (c = 0; c < t.length; c++) t[c].classList.add(i);
              } else if (h < 0)
                if (s) for (c = 0; c < t.length; c++) t[c].style.background = s;
                else if (o)
                  for (c = 0; c < t.length; c++) t[c].classList.add(o);
              null !== r && (a = r);
            }
          },
          hide: l,
        };
      }
      (S.prototype._setElements = function (t) {
        (this._container = t),
          (this._elements.change = this._findElements(t, [
            "js-symbol-change",
            "symbol-change",
          ])),
          (this._elements.changeDirection = this._findElements(t, [
            "js-symbol-change-direction",
            "symbol-change-direction",
          ])),
          (this._elements.extHrsChangeDirection = this._findElements(t, [
            "js-symbol-ext-hrs-change-direction",
          ])),
          (this._elements.changePercent = this._findElements(t, [
            "js-symbol-change-pt",
            "symbol-change-pt",
          ])),
          (this._elements.description = this._findElements(t, [
            "js-symbol-description-name",
            "symbol-description-name",
          ])),
          (this._elements.extHrsChange = this._findElements(
            t,
            "js-symbol-ext-hrs-change"
          )),
          (this._elements.extHrsChangePercent = this._findElements(
            t,
            "js-symbol-ext-hrs-change-pt"
          )),
          (this._elements.extHrsClose = this._findElements(
            t,
            "js-symbol-ext-hrs-close"
          )),
          (this._elements.nightChangeDirection = this._findElements(t, [
            "js-symbol-night-change-direction",
          ])),
          (this._elements.nightChange = this._findElements(
            t,
            "js-symbol-night-change"
          )),
          (this._elements.nightChangePercent = this._findElements(
            t,
            "js-symbol-night-change-pt"
          )),
          (this._elements.nightClose = this._findElements(
            t,
            "js-symbol-night-close"
          )),
          (this._elements.industry = this._findElements(t, [
            "js-symbol-industry",
            "symbol-industry",
          ])),
          (this._elements.last = this._findElements(t, [
            "js-symbol-last",
            "symbol-last",
          ])),
          (this._elements.sector = this._findElements(t, [
            "js-symbol-sector",
            "symbol-sector",
          ])),
          (this._elements.sessionStatus = this._findElements(
            t,
            "js-symbol-session-status"
          )),
          (this._elements.shortName = this._findElements(t, [
            "js-symbol-short-name",
            "symbol-short-name",
          ])),
          (this._elements.updateMode = this._findElements(t, "js-data-mode")),
          (this._elements.lastPeriod = this._findElements(
            t,
            "js-symbol-last-period"
          )),
          this._elements.updateMode.forEach((t) => t.classList.add("i-hidden")),
          (this._textNodes.change = this._getOrCreateTextNodes(
            this._elements.change
          )),
          (this._textNodes.changePercent = this._getOrCreateTextNodes(
            this._elements.changePercent
          )),
          (this._textNodes.extHrsChange = this._getOrCreateTextNodes(
            this._elements.extHrsChange
          )),
          (this._textNodes.extHrsChangePercent = this._getOrCreateTextNodes(
            this._elements.extHrsChangePercent
          )),
          (this._textNodes.extHrsClose = this._getOrCreateTextNodes(
            this._elements.extHrsClose
          )),
          (this._textNodes.nightChange = this._getOrCreateTextNodes(
            this._elements.nightChange
          )),
          (this._textNodes.nightChangePercent = this._getOrCreateTextNodes(
            this._elements.nightChangePercent
          )),
          (this._textNodes.nightClose = this._getOrCreateTextNodes(
            this._elements.nightClose
          )),
          (this._textNodes.last = this._getOrCreateTextNodes(
            this._elements.last
          )),
          (this._textNodes.open = this._findTextNodes(t, "js-symbol-open")),
          (this._textNodes.eps = this._findTextNodes(t, "js-symbol-eps")),
          (this._textNodes.marketCap = this._findTextNodes(
            t,
            "js-symbol-market-cap"
          )),
          (this._textNodes.prevClose = this._findTextNodes(
            t,
            "js-symbol-prev-close"
          )),
          (this._textNodes.dividends = this._findTextNodes(
            t,
            "js-symbol-dividends"
          )),
          (this._textNodes.priceEarnings = this._findTextNodes(
            t,
            "js-symbol-pe"
          )),
          (this._textNodes.volume = this._findTextNodes(t, "js-symbol-volume")),
          (this._textNodes.high = this._findTextNodes(t, "js-symbol-high")),
          (this._textNodes.low = this._findTextNodes(t, "js-symbol-low")),
          (this._textNodes.currency = this._findTextNodes(
            t,
            "js-symbol-currency"
          )),
          (this._textNodes.ipoOfferPrice = this._findTextNodes(
            t,
            "js-symbol-ipo-offer-price"
          )),
          (this._textNodes.ipoPriceRange = this._findTextNodes(
            t,
            "js-symbol-ipo-price-range"
          )),
          (this._textNodes.lastPriceTime = this._findTextNodes(
            t,
            "js-symbol-lp-time"
          )),
          (this._textNodes.lastReleaseDate = this._findTextNodes(
            t,
            "js-symbol-last-release-date"
          )),
          (this._textNodes.rtcTime = this._findTextNodes(
            t,
            "js-symbol-rtc-time"
          )),
          (this._textNodes.ntcTime = this._findTextNodes(
            t,
            "js-symbol-ntc-time"
          )),
          (this._elements.lastHighlight = this._options
            .lastPriceHighlightDiffOnly
            ? this._elements.last.map((t) =>
                this._appendAndGetNewElement(t, "span")
              )
            : this._elements.last),
          (this._textNodes.lastHighlight = this._getOrCreateTextNodes(
            this._elements.lastHighlight
          )),
          (this._elements.lastSup = this._options.lastPriceLastCharSup
            ? this._elements.lastHighlight.map((t) =>
                this._appendAndGetNewElement(t, "sup")
              )
            : []),
          (this._textNodes.lastSup = this._getOrCreateTextNodes(
            this._elements.lastSup
          ));
      }),
        (S.prototype._findElements = function (t, e) {
          var s = (0, n.isArray)(e) ? e : [e];
          return Array.prototype.concat.apply(
            [],
            s.map((e) =>
              Array.prototype.slice.call(t.getElementsByClassName(e))
            )
          );
        }),
        (S.prototype._findTextNodes = function (t, e) {
          return this._getOrCreateTextNodes(this._findElements(t, e));
        }),
        (S.prototype._getOrCreateTextNodes = function (t) {
          return t.map((t) => {
            var e = this._getFirstTextNode(t);
            return (
              e || ((e = t.ownerDocument.createTextNode("")), t.appendChild(e)),
              e
            );
          });
        }),
        (S.prototype._appendAndGetNewElement = function (t, e) {
          const s = document.createElement(e);
          return t.appendChild(s), s;
        }),
        (S.prototype._getFirstTextNode = function (t) {
          for (var e = t.childNodes, s = e.length - 1; s >= 0; s--)
            if (3 === e.item(s).nodeType) return e.item(s);
          return null;
        }),
        (S.prototype.connect = function (t) {
          this._subscribed ||
            ((this._subscribedSymbol = t || this._symbol),
            this.quoteSession.subscribe(
              this._options.clientName,
              this._subscribedSymbol,
              this._quoteSessionEventHandler
            ),
            (this._subscribed = !0));
        }),
        (S.prototype.disconnect = function () {
          clearTimeout(this._connectTimeoutId),
            this._subscribed &&
              (this.quoteSession.unsubscribe(
                this._options.clientName,
                this._subscribedSymbol,
                this._quoteSessionEventHandler
              ),
              (this._subscribed = !1));
        }),
        (S.prototype.onData = function (t, e) {
          this.enabled &&
            ("ok" === t.status
              ? this.successData(t, e)
              : "permission_denied" === t.status
              ? this.onPermissionDenied(t)
              : "error" === t.status && this.errorData(t));
        }),
        (S.prototype.successData = function (t, e) {
          t.values && this.setState(t.values, t, e);
        }),
        (S.prototype.onPermissionDenied = function (t) {
          (0, x.isSfQuoteData)(t) ||
          (function (t) {
            return (
              !!t &&
              (b(t.symbolname) ||
                ("permission_denied" === t.status && b(t.values?.alternative)))
            );
          })(t)
            ? this._options.permissionDeniedHook
              ? this._options.permissionDeniedHook(
                  t,
                  this._symbolOriginal || this._symbol
                )
              : this.errorData(t)
            : this.downgradeData(t);
        }),
        (S.prototype.errorData = function (t) {
          this._options.showInvalidSymbolStatus &&
            (this.setShortName(this._symbol),
            this._elements.sessionStatus.map(
              (t) =>
                new c.MarketStatusIndicator({
                  classSuffix: this._options.sessionStatusClassSuffix,
                  el: t,
                  data: { values: { current_session: "invalid" } },
                  tooltipType: this._options.indicatorsTooltipType,
                })
            )),
            this._options.noSuchSymbolHook
              ? (this._symbolOriginal &&
                  this.setShortName(this._symbolOriginal),
                this._options.noSuchSymbolHook.call(
                  this,
                  t,
                  this._symbolOriginal || this._symbol
                ))
              : C.logWarn("No data for: " + this._symbol);
        }),
        (S.prototype.downgradeData = function (t) {
          {
            const e = t && t.values && t.values.alternative,
              s = this._symbol === e;
            if (!(e && -1 !== e.indexOf(":")) || s)
              return void this.errorData(t);
            (this._symbolOriginal = this._symbol),
              (this._symbol = e),
              (this._subscribed = !1),
              this.connect();
          }
        }),
        (S.prototype.setState = function (t, e, i) {
          const o = i.values;
          (this._isVolumeFormat = "volume" === t.format),
            (null == o.pricescale &&
              null == o.minmov &&
              null == o.fractional &&
              null == o.minmove2) ||
              (this._priceFormatter =
                this._customPriceFormatter ||
                (this._isVolumeFormat && this._volumeFormatter) ||
                new r.PriceFormatter({
                  priceScale: t.pricescale || 100,
                  minMove: t.minmov || 1,
                  fractional: t.fractional,
                  minMove2: t.minmove2,
                }));
          const n = this._options,
            a = this._percentFormatter,
            l = this._priceFormatter,
            m = this._defaultPriceFormatter,
            f = this._volumeFormatter,
            v = (t, e = !0) => (e ? `(${t})` : t),
            b =
              void 0 !== n.signPositiveChange
                ? n.signPositiveChange
                : n.signPositive,
            x = (t) => g(t, o, n),
            N = (t) => {
              const e = a.format(t, {
                signPositive: b,
                signNegative: n.signNegative,
              });
              return v(e, n.changePercentInBrackets);
            },
            T = l.format.bind(l),
            S = m.format.bind(m),
            k = f.format.bind(f),
            w = (t) => (null == t ? h.PLACE_HOLDER : S(t));
          n.disableChange ||
            (this._setNodesValue(this._textNodes.change, o.change, x),
            this._setNodesValue(
              this._textNodes.changePercent,
              o.change_percent,
              N
            ),
            null != o.change &&
              (n.dontDyePrice ||
                this._setChangeFontColor(
                  [].concat(
                    this._elements.change,
                    this._elements.changePercent
                  ),
                  o.change,
                  n.changeUpFontColor,
                  n.changeDownFontColor,
                  n.changeNeutralFontColor
                ),
              this._setChangeDirection(
                this._elements.changeDirection,
                o.change
              )),
            this._setNodesValue(this._textNodes.extHrsChange, o.rch, x),
            this._setNodesValue(this._textNodes.extHrsChangePercent, o.rchp, N),
            null != o.rch &&
              (n.dontDyePrice ||
                this._setChangeFontColor(
                  [].concat(
                    this._elements.extHrsChange,
                    this._elements.extHrsChangePercent
                  ),
                  o.rch,
                  n.changeUpFontColor,
                  n.changeDownFontColor,
                  n.changeNeutralFontColor
                ),
              this._setChangeDirection(
                this._elements.extHrsChangeDirection,
                o.rch
              )),
            this._setNodesValue(this._textNodes.nightChange, o.nch, x),
            this._setNodesValue(this._textNodes.nightChangePercent, o.nchp, N),
            null != o.nch &&
              (n.dontDyePrice ||
                this._setChangeFontColor(
                  [].concat(
                    this._elements.nightChange,
                    this._elements.nightChangePercent
                  ),
                  o.nch,
                  n.changeUpFontColor,
                  n.changeDownFontColor,
                  n.changeNeutralFontColor
                ),
              this._setChangeDirection(
                this._elements.nightChangeDirection,
                o.nch
              ))),
            this._setNodesValue(
              this._textNodes.prevClose,
              o.prev_close_price,
              T
            ),
            this._setNodesValue(
              this._textNodes.dividends,
              t.dividends_yield,
              (t) =>
                null == t
                  ? h.PLACE_HOLDER
                  : a.format(t, {
                      signPositive: n.signPositive,
                      signNegative: n.signNegative,
                    }),
              !0
            );
          let P = (0, _.getTranslatedSymbolDescription)(o);
          if (
            P &&
            ((P = this._prepareSymbolDescription(P)),
            this._setTextsContent(this._elements.description, P),
            this._options.addDescriptionTitle)
          )
            for (var D = 0; D < this._elements.description.length; D++)
              this._elements.description[D].setAttribute("title", P);
          if ((null != o.short_name || null != o.exchange) && t.short_name) {
            var E = t.short_name;
            "QUANDL" === t.exchange &&
              void 0 !== t.short_name.split("/")[1] &&
              (E =
                t.short_name.split("/")[1] + ", " + t.short_name.split("/")[0]),
              this.setShortName(E);
          }
          t["reference-last-period"] &&
            this._elements.lastPeriod.length &&
            Promise.all([s.e(23567), s.e(7397)])
              .then(s.bind(s, 695673))
              .then((e) => {
                this._setTextsContent(
                  this._elements.lastPeriod,
                  e.periodFormatter(t["reference-last-period"])
                );
              }),
            this._elements.lastPeriod.length &&
              void 0 === t["reference-last-period"] &&
              this._setTextsContent(this._elements.lastPeriod, "—"),
            this._setLastValue(o.last_price, o.minmove2, T);
          const L = (0, p.getIpoValueWithCurrency)(
            t.ipo_offer_price,
            t.ipo_offer_price_usd,
            t.currency_code
          );
          L &&
            this._setNodesValue(
              this._textNodes.ipoOfferPrice,
              L.value,
              L.isUsdFallback ? S : T
            );
          const M = (0, p.getIpoValueWithCurrency)(
            t.ipo_price_range || void 0,
            t.ipo_price_range_usd || void 0,
            t.currency_code
          );
          M &&
            this._setNodesValue(this._textNodes.ipoPriceRange, M.value, (t) =>
              t.replace("-", "–")
            ),
            this._setNodesValue(this._textNodes.extHrsClose, o.rtc, T),
            o.rtc && this._highlighters.extHrsClose.show(o.rtc),
            this._setNodesValue(this._textNodes.nightClose, o.ntc, T),
            o.ntc && this._highlighters.nightClose.show(o.ntc),
            o.industry &&
              this._setTextsContent(
                this._elements.industry,
                t.industry,
                (t) => t
              ),
            o.sector && this._setTextsContent(this._elements.sector, t.sector),
            this._elements.sessionStatus &&
              o.current_session &&
              (this._sessionStatusInstances
                ? this._sessionStatusInstances.forEach((t) =>
                    t.setStatus(o.current_session)
                  )
                : (this._sessionStatusInstances =
                    this._elements.sessionStatus.map(
                      (e) =>
                        new c.MarketStatusIndicator({
                          classSuffix: this._options.sessionStatusClassSuffix,
                          el: e,
                          short: !0,
                          data: { values: o },
                          quoteSession: this.quoteSession,
                          symbol: t.original_name,
                          manualUpdate: !0,
                          tooltipType: this._options.indicatorsTooltipType,
                          sessionStatusIcon: this._options.sessionStatusIcon,
                        })
                    ))),
            this._setNodesValue(this._textNodes.open, o.open_price, T),
            this._setNodesValue(this._textNodes.high, o.high_price, T),
            this._setNodesValue(this._textNodes.low, o.low_price, T),
            this._setNodesValue(
              this._textNodes.eps,
              t.earnings_per_share_basic_ttm,
              w,
              !0
            ),
            this._setNodesValue(
              this._textNodes.priceEarnings,
              t.price_earnings_ttm,
              w,
              !0
            ),
            this._setNodesValue(
              this._textNodes.marketCap,
              t.market_cap_basic,
              k,
              !0
            ),
            this._setNodesValue(this._textNodes.volume, t.volume, k, !0);
          const F = (0, u.prepareCurrencyValue)(o);
          if (
            (F && this._setNodesValue(this._textNodes.currency, F, y, !0),
            (o.lp_time || t.lp_time) &&
              this._textNodes.lastPriceTime.length &&
              (this._timeFormatter && this._timeFormatter.lastPrice
                ? this._setNodesValue(
                    this._textNodes.lastPriceTime,
                    v(
                      this._timeFormatter.lastPrice(
                        t.lp_time,
                        t.current_session
                      ),
                      this._options.lastPriceTimeInBrackets
                    )
                  )
                : C.logError(
                    "last price time field requested with no formatter provided"
                  )),
            (o.last_release_date || t.last_release_date) &&
              this._textNodes.lastReleaseDate.length &&
              (this._timeFormatter && this._timeFormatter.lastReleaseDate
                ? this._setNodesValue(
                    this._textNodes.lastReleaseDate,
                    v(
                      this._timeFormatter.lastReleaseDate(
                        t.last_release_date,
                        t.current_session
                      ),
                      this._options.lastReleaseDateTimeInBrackets
                    )
                  )
                : C.logError(
                    "lastReleaseDate time field requested with no formatter provided"
                  )),
            (o.rtc_time || t.rtc_time) &&
              this._textNodes.rtcTime.length &&
              (this._timeFormatter && this._timeFormatter.rtc
                ? this._setNodesValue(
                    this._textNodes.rtcTime,
                    v(
                      this._timeFormatter.rtc(t.rtc_time, t.current_session),
                      this._options.rtcTimeInBrackets
                    )
                  )
                : C.logError(
                    "rtc time field requested with no formatter provided"
                  )),
            (o.ntc_time || t.ntc_time) &&
              this._textNodes.ntcTime.length &&
              (this._timeFormatter && this._timeFormatter.rtc
                ? this._setNodesValue(
                    this._textNodes.ntcTime,
                    v(
                      this._timeFormatter.rtc(t.ntc_time, t.current_session),
                      this._options.rtcTimeInBrackets
                    )
                  )
                : C.logError(
                    "ntc time field requested with no formatter provided"
                  )),
            null != o.last_price)
          )
            for (D = 0; D < this._elements.updateMode.length; D++)
              this._elements.updateMode[D].classList.remove("i-hidden");
          this._elements.updateMode &&
            (o.update_mode || o.update_mode_seconds) &&
            (this._updateModeInstances
              ? this._updateModeInstances.forEach((e) =>
                  e.update({ values: t })
                )
              : (this._updateModeInstances = this._elements.updateMode.map(
                  (e) =>
                    new d.DataModeIndicator({
                      classSuffix: this._options.dataModeClassSuffix,
                      el: e,
                      data: { values: t },
                      modeInterval: t.update_mode_seconds,
                      short: !0,
                      tooltipType: this._options.indicatorsTooltipType,
                    })
                ))),
            this._setStateHook &&
              this._setStateHook(
                e.values,
                i.values,
                e.complete,
                this.getOptions()
              ),
            this._lastPrice
              ? this._highlighters.last.show(t.last_price)
              : null === this._lastPrice &&
                (this._container.classList.add("quote-ticker-inited"),
                "function" == typeof this._options.initedHook &&
                  this._options.initedHook("last_price" in t)),
            (this._lastPrice = t.last_price);
        }),
        (S.prototype._setNodesValue = function (t, e, s, i) {
          if (null != e || i)
            for (
              var o = "function" == typeof s ? s(e) : e, n = 0;
              n < t.length;
              n++
            )
              t[n].nodeValue = o;
        }),
        (S.prototype._setTextsContent = function (t, e, s) {
          if (t && t.length && e)
            for (
              var i = "function" == typeof s ? s(e) : e, o = 0;
              o < t.length;
              o++
            )
              t[o].textContent = i;
        }),
        (S.prototype._setLastValue = function (t, e, s) {
          if (null == t) return;
          const i = "function" == typeof s ? s(t) : String(t);
          if (i === this._lastPriceFormatted) return;
          const [o, n, a] = this._options.lastPriceHighlightDiffOnly
              ? this._getLastValueStringDiff(this._lastPriceFormatted, i)
              : ["", i, ""],
            l = o,
            r = this._calculatePipetteDigits(e),
            [h, c] =
              this._options.lastPriceLastCharSup && r
                ? [n.slice(0, -r), n.slice(-r)]
                : [n, ""];
          this._options.lastPriceHighlightDiffOnly &&
            (this._isVolumeFormat && this._changeVolumeLetter.call(this, a),
            this._setNodesValue(this._textNodes.last, l)),
            this._setNodesValue(this._textNodes.lastHighlight, h),
            this._setNodesValue(this._textNodes.lastSup, c),
            (this._lastPriceFormatted = i);
        }),
        (S.prototype._getChangeVolumeLetterCallback = function () {
          let t;
          return function (e) {
            e !== t &&
              ((t = e),
              this._elements.last.forEach((e) => {
                3 !== e.childNodes.length
                  ? e.appendChild(document.createTextNode(t))
                  : (e.childNodes[2].nodeValue = t);
              }));
          };
        }),
        (S.prototype._getLastValueStringDiff = function (t, e) {
          if (t === e) {
            const [t, s] = k(e);
            return [t, "", s];
          }
          let s = 0;
          for (; t[s] === e[s]; ) s++;
          const [i, o] = k(e.slice(s));
          return [e.slice(0, s), i, o];
        }),
        (S.prototype._calculatePipetteDigits = function (t) {
          return (
            t && t !== this._lastMinMove && (this._lastMinMove = t),
            this._lastMinMove ? ("" + this._lastMinMove).length - 1 : 0
          );
        }),
        (S.prototype._setChangeFontColor = function (t, e, s, i, o) {
          for (
            var n = l.PriceColorer.formatSign(e, {
                up: s,
                down: i,
                neutral: o,
              }),
              a = 0;
            a < t.length;
            a++
          )
            t[a].style.color = n;
        }),
        (S.prototype._setChangeDirection = function (t, e) {
          for (var s = 0; s < t.length; s++) {
            var i = t[s].classList;
            i.toggle(this._options.changeDirectionUpClass, e > 0),
              i.toggle(this._options.changeDirectionDownClass, e < 0),
              i.toggle(this._options.changeDirectionNeutralClass, 0 === e);
          }
        }),
        (S.prototype.setShortName = function (t = "") {
          this._setTextsContent(this._elements.shortName, t);
        }),
        (S.prototype._prepareSymbolDescription = function (t) {
          var e = this._getCache("symbol-description:" + t);
          return (
            e || ((e = t), this._setCache("symbol-description:" + t, e), e)
          );
        }),
        (S.prototype._initHighlighters = function () {
          (this._highlighters.last = new w(
            this._elements.lastHighlight,
            this._options.growingBg,
            this._options.fallingBg,
            this._options.lastGrowingClass,
            this._options.lastFallingClass
          )),
            (this._highlighters.extHrsClose = new w(
              this._elements.extHrsClose,
              this._options.growingBg,
              this._options.fallingBg,
              this._options.lastGrowingClass,
              this._options.lastFallingClass
            )),
            (this._highlighters.nightClose = new w(
              this._elements.nightClose,
              this._options.growingBg,
              this._options.fallingBg,
              this._options.lastGrowingClass,
              this._options.lastFallingClass
            ));
        }),
        (S.prototype.disable = function () {
          (this.enabled = !1), this.disconnect();
        }),
        (S.prototype.enable = function () {
          (this.enabled = !0), this.connect();
        }),
        (S.prototype.setStateHook = function (t) {
          null === t && this._setStateHook
            ? delete this._setStateHook
            : "function" == typeof t && (this._setStateHook = t);
        }),
        (S.prototype._setCache = function (t, e) {
          null == e ? delete this._cache[t] : (this._cache[t] = e);
        }),
        (S.prototype._getCache = function (t) {
          return this._cache && this._cache[t];
        }),
        (S.prototype.getOptions = function () {
          return this._options;
        });
    },
    808807(t, e, s) {
      "use strict";
      s.d(e, { getTranslatedSymbolDescription: () => n });
      var i = s(892449),
        o = s(737462);
      function n(t) {
        return (0, o.getTranslatedSymbolDescription)(t, {
          localizedDescriptionAllowed: !0,
          uiLanguage: (0, i.getEnvValue)("language"),
        });
      }
    },
    748351(t, e, s) {
      "use strict";
      function i(t, e, s) {
        return null != t && s
          ? {
              value: t,
              currency: s,
              isUsdFallback: !1,
            }
          : null != e
          ? { value: e, currency: "USD", isUsdFallback: !0 }
          : null;
      }
      s.d(e, { getIpoValueWithCurrency: () => i });
    },
    511649(t, e, s) {
      "use strict";
      function i(t) {
        return t.endsWith("_dly");
      }
      function o(t) {
        return (
          !!t &&
          (!(void 0 === t.symbolname || !i(t.symbolname)) ||
            Boolean(
              "permission_denied" === t.status &&
                t.values &&
                void 0 !== t.values.alternative &&
                i(t.values.alternative)
            ))
        );
      }
      s.d(e, { isSfQuoteData: () => o });
    },
    527048(t, e, s) {
      "use strict";
      s.d(e, {
        getDataFromTarget: () => u,
        getTooltip: () => m,
        hideTooltip: () => f,
        setStyle: () => p,
        showTooltip: () => g,
      });
      var i = s(146961),
        o = s(304635),
        n = s(334120),
        a = s(403334),
        l = s(715471),
        r = s(467242),
        h = s(250280),
        c = s(556694),
        d = s(505513),
        _ = s(296297);
      function u(t) {
        const e = (function (t) {
            const e = t.hasAttribute("data-tooltip")
              ? t.getAttribute("data-tooltip")
              : t.getAttribute("title");
            return (
              e &&
                ((0, c.setTooltipData)(t, "text", e),
                t.removeAttribute("title")),
              (0, c.getTooltipData)(t, "text") || ""
            );
          })(t),
          s = t.getBoundingClientRect(),
          i = { h: s.height, w: s.width, x: s.left, y: s.top },
          o = t.getAttribute("data-color-theme") || "",
          n = t.classList.contains("common-tooltip-html"),
          a = parseInt(t.getAttribute("data-tooltip-delay") || ""),
          l = parseInt(t.getAttribute("data-tooltip-debounce") || "");
        let r = { type: "none" };
        return (
          e && (r = { type: n ? "html" : "text", data: e }),
          {
            above: t.classList.contains("common-tooltip-above"),
            below: t.classList.contains("common-tooltip-below"),
            otl: t.classList.contains("common-tooltip-otl"),
            otr: t.classList.contains("common-tooltip-otr"),
            vertical: t.classList.contains("common-tooltip-vertical"),
            hotkey: t.getAttribute("data-tooltip-hotkey"),
            narrow: t.classList.contains("common-tooltip-narrow"),
            wide: t.classList.contains("common-tooltip-wide"),
            colorTheme: o,
            tooltipDelay: a,
            tooltipDebounce: l,
            rect: i,
            content: r,
            target: t,
          }
        );
      }
      function m(t) {
        const e = (0, i.ensureNotNull)(C).cloneNode(!0),
          s = S(e),
          { content: o } = t;
        switch (o.type) {
          case "element":
            (s.innerHTML = ""), s.appendChild(o.data);
            break;
          case "html":
            s.innerHTML = o.data;
            break;
          case "text":
            if (t.hotkey) {
              const t = (0, i.ensureNotNull)(T).cloneNode(!0);
              (t.innerText = o.data), s.appendChild(t);
            } else s.innerText = o.data;
        }
        if (t.hotkey) {
          const e = "none" !== o.type,
            n = (0, i.ensureNotNull)(N).cloneNode(!0),
            a = (0, d.hotKeyDeserialize)(t.hotkey),
            l = a.keys.map(
              (t) =>
                `<span class="${_["common-tooltip__hotkey-button"]}">${t}</span>`
            );
          (n.innerHTML = (function (t, e) {
            const s = /{\d}|{hotkey_\d}/gi;
            return t.replace(s, (t) => {
              const s = Number(t.match(/\d/));
              return e[s];
            });
          })(a.text, l).replace(
            /\s\+\s/g,
            `<span class="${_["common-tooltip__plus-sign"]}">+</span>`
          )),
            s.classList.add(_["common-tooltip__body--with-hotkey"]),
            e && n.classList.add(_["common-tooltip__hotkey-block--divider"]),
            s.appendChild(n);
        }
        return e.addEventListener("contextmenu", a.preventDefault), e;
      }
      function p(t, e) {
        const s = e.rect;
        if (!s) return;
        (0, h.setTooltipColorTheme)(t, e.colorTheme || "default");
        const i = S(t),
          o = t.querySelector(`.${_["common-tooltip__button-container"]}`);
        e.addClass && t.classList.add(e.addClass),
          e.addBodyClass && i.classList.add(e.addBodyClass),
          i.classList.toggle(
            _["common-tooltip__body--width_wide"],
            Boolean(e.wide)
          ),
          i.classList.toggle(
            _["common-tooltip__body--no-padding"],
            Boolean(e.noPadding)
          ),
          i.classList.toggle(
            _["common-tooltip__body--width_narrow"],
            Boolean(e.narrow)
          ),
          i.classList.toggle(_["common-tooltip__body--no-buttons"], !0),
          (i.style.left = y(0)),
          (i.style.width = y(i.clientWidth + (Boolean(e.noPadding) ? 0 : 2)));
        const a = document.body.clientWidth,
          c = r.mobiletouch || r.touch || r.isAnyMobile,
          d =
            r.isIOS || r.isAndroid || (c && r.isMac)
              ? window.innerHeight
              : document.body.clientHeight,
          u = e.vertical,
          m = e.extendMargin || (u && s.w < 20) || (!u && s.h < 20);
        t.classList.toggle(_["common-tooltip--farther"], m),
          t.classList.toggle(_["common-tooltip--vertical"], u),
          t.classList.toggle(_["common-tooltip--horizontal"], !u);
        const p = (function (t) {
            return t.querySelector(`.${_["common-tooltip__ear-holder"]}`);
          })(t),
          g = t.offsetHeight;
        if (u) {
          const r = 10,
            h = d - 10,
            c = 12,
            u = r + c,
            m = h - c,
            f = (0, l.clamp)(s.y + s.h / 2, u, m) - g / 2,
            v = f + g;
          (t.style.left = y(s.x + s.w)),
            (t.style.top = y(f)),
            f < r
              ? (i.style.top = o.style.top = y(r - f))
              : v > h && (i.style.top = o.style.top = y(h - v));
          const { right: b } = (
              t.querySelector(":last-child") || i
            ).getBoundingClientRect(),
            x = b + 10 > a;
          t.classList.toggle(_["common-tooltip--direction_reversed"], x),
            t.classList.toggle(_["common-tooltip--direction_normal"], !x);
          let C = x ? "after" : "before";
          (0, n.isRtl)()
            ? ((C = e.otr ? "after" : C), (C = e.otl ? "before" : C))
            : ((C = e.otr ? "before" : C), (C = e.otl ? "after" : C)),
            p.classList.toggle(
              _["common-tooltip__ear-holder--before"],
              "before" === C
            ),
            p.classList.toggle(
              _["common-tooltip__ear-holder--after"],
              "after" === C
            ),
            "after" === C &&
              ((t.style.left = "auto"), (t.style.right = y(a - s.x)));
        } else {
          const n = s.x - (i.offsetWidth - s.w) / 2,
            l = a - t.offsetWidth - 20 <= 0 ? (a - t.offsetWidth) / 2 : 10,
            r = a - l - t.offsetWidth,
            h = Math.max(l, Math.min(n, r));
          t.style.left = y(h);
          const c = r < n;
          t.classList.toggle(_["common-tooltip--direction_reversed"], c),
            t.classList.toggle(_["common-tooltip--direction_normal"], !c);
          const u = (function (t, e, s, i) {
            if (t.above) return k(e, i) ? "above" : "below";
            if (t.below)
              return (function (t, e, s) {
                return s.y + s.h + e + 10 < t;
              })(e, s, i)
                ? "below"
                : "above";
            return k(s, i) ? "above" : "below";
          })(e, d, g, s);
          "above" === u
            ? (t.style.bottom = y(d - s.y))
            : (t.style.top = y(s.y + s.h)),
            p.classList.add(
              "above" === u
                ? _["common-tooltip__ear-holder--above"]
                : _["common-tooltip__ear-holder--below"]
            );
          const { left: m } = i.getBoundingClientRect();
          let f = Math.trunc(s.x + s.w / 2 - (m + i.clientWidth / 2));
          (t.style.left = y(h + f)),
            (t.style.width = y(i.clientWidth + o.clientWidth)),
            (f = c ? Math.max(0, f) : Math.min(0, f)),
            (o.style.left = y(-f)),
            (i.style.left = y(-f));
        }
      }
      function g(t) {
        t.classList.toggle(_["common-tooltip--hidden"], !1);
      }
      function f(t) {
        t.classList.toggle(_["common-tooltip--hidden"], !0);
      }
      function y(t) {
        return `${Math.floor(t)}px`;
      }
      const v = `\n\t<div id="common-tooltip-wrapper" class="${_["common-tooltip"]}">\n\t\t<div class="${_["common-tooltip__ear-holder"]}" >\n\t\t\t<div class="${_["common-tooltip__body"]} js-tooltip-body"></div>\n\t\t</div>\n\t\t<div class="${_["common-tooltip__button-container"]}"></div>\n\t</div>\n`,
        b = `\n\t<div class="${_["common-tooltip__hotkey-block"]}"></div>\n`,
        x = `\n\t<div class="${_["common-tooltip__hotkey-text"]}"></div>\n`,
        C = (0, o.parseHtmlElement)(v),
        N = (0, o.parseHtmlElement)(b),
        T = (0, o.parseHtmlElement)(x);
      function S(t) {
        return t.querySelector(`.${_["common-tooltip__body"]}`);
      }
      function k(t, e) {
        return 10 + t < e.y;
      }
    },
    738239(t, e, s) {
      "use strict";
      s.d(e, { formatByKey: () => o });
      const i = /{(\w+)}/g;
      function o(t, e) {
        return t.replace(i, (t, s) => (void 0 !== e[s] ? e[s] : t));
      }
    },
    855085(t, e, s) {
      "use strict";
      s.d(e, { DataMode: () => i });
      var i = (function (t) {
        return (
          (t.Delayed = "delayed"),
          (t.DelayedStreaming = "delayed_streaming"),
          (t.EndOfDay = "endofday"),
          (t.Snapshot = "snapshot"),
          (t.Realtime = "realtime"),
          (t.Connecting = "connecting"),
          (t.Loading = "loading"),
          (t.Invalid = "invalid"),
          (t.Forbidden = "forbidden"),
          (t.Streaming = "streaming"),
          t
        );
      })({});
    },
    4282(t, e, s) {
      "use strict";
      s.d(e, { AbstractIndicator: () => a });
      var i = s(819511),
        o = s(966193);
      s(517615);
      const n = (0, i.getLogger)("GUI.Blocks.AbstractIndicator");
      class a {
        getValue() {
          return this._value;
        }
        getTooltipText() {
          return this._labelMap[this._value] || "";
        }
        getLabel() {
          return this._labelMap[this._value] || "";
        }
        getElement() {
          return this._el;
        }
        update(t, e) {
          this._updateValue(t, e), this._render();
        }
        setTooltipEnabled(t = !1) {
          this._showTooltip !== t &&
            ((this._showTooltip = t), this._renderTooltip());
        }
        enableShortMode() {
          !0 !== this._shortMode && ((this._shortMode = !0), this._render());
        }
        disableShortMode() {
          !1 !== this._shortMode && ((this._shortMode = !1), this._render());
        }
        isShortModeEnabled() {
          return this._shortMode;
        }
        start() {
          !this._subscribed &&
            this._symbolName &&
            (this._quoteSession
              ? (this._quoteSession.subscribe(
                  this._getQuoteSessionId(),
                  this._symbolName,
                  this._handleQuoteData.bind(this)
                ),
                (this._subscribed = !0))
              : n.logError(
                  "quoteSession option is required to start a quote subscription"
                ));
        }
        stop() {
          this._subscribed &&
            this._quoteSession &&
            this._symbolName &&
            (this._quoteSession.unsubscribe(
              this._getQuoteSessionId(),
              this._symbolName
            ),
            (this._subscribed = !1));
        }
        setSessionStatusIcon(t) {
          this._sessionStatusIcon !== t &&
            ((this._sessionStatusIcon = t), this._render());
        }
        _init(t) {
          (this._el = t.el ? t.el : document.createElement("span")),
            (this._el.innerHTML = ""),
            (this._classMap = t.classMap),
            (this._iconClassMap = t.iconClassMap),
            (this._labelMap = t.labelMap),
            (this._showTooltip = t.showTooltip),
            (this._classSuffix = t.classSuffix),
            (this._symbolName = t.symbol),
            (this._sessionStatusIcon = t.sessionStatusIcon),
            (this._onValueChange = t.onValueChange),
            t.tooltipType && (this._tooltipType = t.tooltipType),
            (this._quoteSessionGUID = (0, o.guid)()),
            !0 === t.short && this.enableShortMode(),
            t.data && this._updateValue(t.data);
        }
        _clearClasses() {
          Object.values(this._classMap).map((t) => {
            this._el.classList.remove(`${t}`),
              this._el.classList.remove(`${t}${this._classSuffix}`);
          });
        }
        _render() {
          this._renderClasses(), this._renderTooltip(), this._renderLabel();
        }
        _renderLabel() {
          this._el.textContent = this.getLabel();
        }
        _updateValue(t, e) {
          const s = this._getValueFromData(t);
          (e || s !== this._value) &&
            ((this._value = s), this._onValueChange?.(this._value));
        }
        _renderClasses() {
          const t = this._el.classList;
          t.add(this._componentClass, this._componentClass + this._classSuffix);
          const e = this._classMap[this._value];
          for (const s in this._classMap) {
            const i = this._classMap[s];
            i &&
              (i === e
                ? (t.add(i, i + this._classSuffix),
                  this._sessionStatusIcon && t.add(i + "__withIcon"))
                : (t.remove(i, i + this._classSuffix),
                  this._sessionStatusIcon && t.remove(i + "__withIcon")));
          }
          !e &&
            this._value &&
            n.logWarn(`no className for status ${this._value}`);
        }
        _renderTooltip() {
          const t = this._showTooltip ? this.getTooltipText() : "";
          t !== this._lastTooltipText &&
            ((this._lastTooltipText = t),
            this._el.setAttribute("title", t),
            "custom" === this._tooltipType &&
              this._el.classList.toggle(
                "apply-common-tooltip",
                this._showTooltip
              ));
        }
        _getQuoteSessionId() {
          return `${this._quoteSessionPrefix}.${this._quoteSessionGUID}`;
        }
        _handleQuoteData(t) {
          this.update(t);
        }
        constructor(t) {
          (this._classSuffix = ""),
            (this._quoteSessionPrefix = "abstract-indicator"),
            (this._shortMode = !1),
            (this._showTooltip = !0),
            (this._subscribed = !1),
            (this._tooltipType = "custom"),
            (this._lastTooltipText = ""),
            (this._quoteSession = t.quoteSession);
        }
      }
    },
    851234(t, e, s) {
      "use strict";
      s.d(e, { DataModeIndicator: () => c });
      var i = s(383636),
        o = s(738239),
        n = (s(756514), s(855085)),
        a = s(4282);
      const l = {
        connecting: "tv-data-mode--connecting",
        delayed: "tv-data-mode--delayed",
        delayed_streaming: "tv-data-mode--delayed",
        endofday: "tv-data-mode--endofday",
        forbidden: "tv-data-mode--forbidden",
        realtime: "tv-data-mode--realtime",
        snapshot: "tv-data-mode--snapshot",
        loading: "tv-data-mode--loading",
        replay: "tv-data-mode--replay",
      };
      function r() {
        return {
          connecting: i.t(
            null,
            { context: "data_mode_connecting_letter" },
            s(859994)
          ),
          delayed: i.t(
            null,
            { context: "data_mode_delayed_letter" },
            s(892363)
          ),
          delayed_streaming: i.t(
            null,
            { context: "data_mode_delayed_streaming_letter" },
            s(394501)
          ),
          endofday: i.t(
            null,
            { context: "data_mode_end_of_day_letter" },
            s(570939)
          ),
          forbidden: i.t(
            null,
            { context: "data_mode_forbidden_letter" },
            s(394921)
          ),
          realtime: i.t(
            null,
            { context: "data_mode_realtime_letter" },
            s(86644)
          ),
          snapshot: i.t(
            null,
            { context: "data_mode_snapshot_letter" },
            s(257326)
          ),
          loading: "",
          replay: i.t(null, { context: "data_mode_replay_letter" }, s(756457)),
        };
      }
      const h = { streaming: n.DataMode.Realtime };
      class c extends a.AbstractIndicator {
        getLabel() {
          return !0 === this._shortMode
            ? this._shortLabelMap[this._value] || ""
            : super.getLabel();
        }
        setMode(t, e) {
          this.update({ values: { update_mode: t, update_mode_seconds: e } });
        }
        hide() {
          this._el.classList.add("i-hidden");
        }
        show() {
          this._el.classList.remove("i-hidden");
        }
        getTooltipText() {
          let t = "";
          const e = this.getValue();
          if ("" === e) return t;
          switch (e) {
            case "delayed":
              t = i.t(null, void 0, s(790524));
              break;
            case "delayed_streaming":
              t = i.t(null, void 0, s(81461));
              break;
            default:
              t = this._labelMap[e] || t;
          }
          return (
            ["delayed", "delayed_streaming"].includes(e) &&
              (t = (0, o.formatByKey)(t, {
                number: String(Math.round(this._modeInterval / 60)),
              })),
            t
          );
        }
        _init(t = {}) {
          const e = Object.assign(
            {},
            {
              classMap: l,
              classSuffix: "",
              data: { values: { update_mode: "connecting" } },
              labelMap: {
                connecting: i.t(null, void 0, s(194194)),
                delayed: i.t(null, void 0, s(229525)),
                delayed_streaming: i.t(null, void 0, s(229525)),
                endofday: i.t(null, void 0, s(601764)),
                forbidden: i.t(null, void 0, s(328313)),
                realtime: i.t(null, void 0, s(883928)),
                snapshot: i.t(null, void 0, s(562395)),
                loading: "",
                replay: i.t(null, void 0, s(97727)),
              },
              modeInterval: 600,
              short: !1,
              shortLabelMap: r(),
              showTooltip: !0,
              tooltipType: "custom",
            },
            t
          );
          (this._modeInterval = e.modeInterval || 600),
            (this._shortLabelMap = e.shortLabelMap || r()),
            super._init(e),
            this._render();
        }
        _getValueFromData(t) {
          let e;
          return (
            (e =
              void 0 !== t.values && void 0 !== t.values.update_mode
                ? t.values.update_mode
                : this.getValue()),
            h[e] || e
          );
        }
        _updateValue(t, e) {
          void 0 !== t.values &&
            void 0 !== t.values.update_mode_seconds &&
            (this._modeInterval = t.values.update_mode_seconds),
            super._updateValue(t, e);
        }
        constructor(t) {
          super(t),
            (this._quoteSessionPrefix = "data-mode-indicator"),
            (this._componentClass = "tv-data-mode"),
            this._init(t);
        }
      }
    },
    871847(t, e, s) {
      "use strict";
      s.d(e, { MarketStatusIndicator: () => l });
      var i = s(383636),
        o = (s(478051), s(4282));
      const n = {
          invalid: "tv-market-status--invalid",
          market: "tv-market-status--market",
          out_of_session: "tv-market-status--out-of-session",
          post_market: "tv-market-status--post-market",
          pre_market: "tv-market-status--pre-market",
          night: "tv-market-status--night",
          loading: "tv-market-status--loading",
          holiday: "tv-market-status--holiday",
          replay: "tv-market-status--replay",
          delisted: "tv-market-status--delisted",
        },
        a = {
          invalid: "tv-market-status__icon--invalid",
          market: "tv-market-status__icon--market",
          out_of_session: "tv-market-status__icon--out-of-session",
          post_market: "tv-market-status__icon--post-market",
          night: "tv-market-status__icon--night",
          pre_market: "tv-market-status__icon--pre-market",
          loading: "tv-market-status__icon--loading",
          holiday: "tv-market-status__icon--holiday",
          replay: "tv-market-status__icon--replay",
          delisted: "tv-market-status__icon--delisted",
        };
      class l extends o.AbstractIndicator {
        setStatus(t, e) {
          const s = {
            values: {
              current_session: "delisted" === this.getValue() ? "delisted" : t,
            },
          };
          this.update(s, e);
        }
        getTooltipText() {
          let t = super.getTooltipText();
          return (
            "" === t ||
              ("" !== this._extraTitle && (t = `${t}, ${this._extraTitle}`)),
            t
          );
        }
        setExtraTitle(t) {
          this._extraTitle = t;
        }
        reset() {
          this._clearClasses(),
            (this._labelEl.textContent = ""),
            (this._extraTitle = ""),
            this._el.setAttribute("title", ""),
            (this._value = "");
        }
        enableShortMode(t = !0) {
          void 0 !== this._labelEl && this._labelEl.classList.add("i-hidden"),
            super.enableShortMode();
        }
        disableShortMode() {
          void 0 !== this._labelEl &&
            this._labelEl.classList.remove("i-hidden"),
            super.disableShortMode();
        }
        _renderLabel() {
          this._labelEl.textContent = this.getLabel();
        }
        _getValueFromData(t) {
          return t.values?.typespecs?.includes("discontinued")
            ? "delisted"
            : void 0 !== t.values?.current_session
            ? t.values.current_session
            : this.getValue();
        }
        _render() {
          this._renderLabelElement(),
            this._sessionStatusIcon
              ? this._renderIconElement()
              : this._renderDotElement(),
            super._render();
        }
        _init(t) {
          const e = Object.assign(
            {},
            (function () {
              const t = {
                invalid: i.t(null, { context: "market-status" }, s(638405)),
                market: i.t(null, { context: "market-status" }, s(702788)),
                out_of_session: i.t(
                  null,
                  { context: "market-status" },
                  s(914572)
                ),
                post_market: i.t(null, { context: "market-status" }, s(867455)),
                pre_market: i.t(null, { context: "market-status" }, s(918842)),
                loading: i.t(null, { context: "market-status" }, s(274415)),
                holiday: i.t(null, { context: "market-status" }, s(685104)),
                delisted: i.t(null, { context: "market-status" }, s(55215)),
                night: i.t(null, { context: "market-status" }, s(49248)),
                replay: "",
              };
              return {
                classMap: n,
                iconClassMap: a,
                classSuffix: "",
                data: {},
                extraTitle: "",
                labelMap: t,
                short: !1,
                showTooltip: !0,
                tooltipType: "custom",
              };
            })(),
            t
          );
          super._init(e), this.setExtraTitle(e.extraTitle), this._render();
        }
        _renderLabelElement() {
          void 0 === this._labelEl &&
            ((this._labelEl = document.createElement("span")),
            this._labelEl.classList.add(`${this._componentClass}__label`),
            this._labelEl.classList.add(
              `${this._componentClass}__label${this._classSuffix}`
            ),
            this._el.appendChild(this._labelEl));
        }
        _renderDotElement() {
          this._el.contains(this._iconEl) && this._el.removeChild(this._iconEl),
            void 0 === this._dotEl &&
              ((this._dotEl = document.createElement("span")),
              this._dotEl.classList.add(`${this._componentClass}__dot`),
              this._dotEl.classList.add(
                `${this._componentClass}__dot${this._classSuffix}`
              ),
              this._el.appendChild(this._dotEl));
        }
        _renderIconElement() {
          this._el.contains(this._dotEl) && this._el.removeChild(this._dotEl),
            void 0 === this._iconEl &&
              this._value &&
              ((this._iconEl = document.createElement("span")),
              this._iconEl.classList.add(`${this._componentClass}__icon`),
              this._iconEl.classList.add(
                `${this._componentClass}__icon${this._classSuffix}`
              ),
              this._el.appendChild(this._iconEl));
        }
        constructor(t) {
          super(t),
            (this._quoteSessionPrefix = "market-status-indicator"),
            (this._componentClass = "tv-market-status"),
            (this._extraTitle = ""),
            this._init(t);
        }
      }
    },
    737462(t, e, s) {
      "use strict";
      s.d(e, { getTranslatedSymbolDescription: () => n });
      var i = s(383636);
      function o(t) {
        const e = `#${t}-symbol-description`,
          o = i.t(e, void 0, s(258667));
        return o === e ? null : o;
      }
      function n(t, e) {
        if (e.localizedDescriptionAllowed) {
          if (void 0 !== t.pro_name) {
            const e = o(t.pro_name);
            if (null !== e) return e;
            if (void 0 !== t.short_name) {
              const e = o(t.short_name);
              if (null !== e) return e;
            }
          }
          if (void 0 !== t.local_description && t.language === e.uiLanguage)
            return t.local_description;
        }
        return t.description || "";
      }
    },
    349356(t, e, s) {
      "use strict";
      s.d(e, { PriceColorer: () => i });
      var i,
        o = s(493616),
        n = s(778738);
      !(function (t) {
        function e(t, e) {
          return 0 === t
            ? e && void 0 !== e.neutral
              ? e.neutral
              : o.color.black70
            : t > 0
            ? e && void 0 !== e.up
              ? e.up
              : n.colorsPalette["color-success"]
            : e && void 0 !== e.down
            ? e.down
            : n.colorsPalette["color-danger"];
        }
        (t.formatSign = e),
          (t.formatDiff = function (t, s) {
            return e(s - t);
          }),
          (t.domDifference = function (t, e, s = 0, i = "", o = "") {
            function n(t) {
              const e = document.createElement("span");
              return (e.innerHTML = t), e;
            }
            const a = document.createElement("div");
            if (!s) return a.appendChild(n(t)), a;
            const l = t + "",
              r = e + "";
            let h = null;
            if (l.length === r.length) {
              for (let t = 0; t < l.length; t++)
                if (l.charAt(t) !== r.charAt(t)) {
                  h = t;
                  break;
                }
            } else h = Number("0");
            if (null === h) return a.appendChild(n(l)), a;
            const c = n(l.substring(0, h)),
              d = document.createElement("span");
            return (
              (d.className = s < 0 ? i : o),
              d.appendChild(n(l.substring(h))),
              a.appendChild(c),
              a.appendChild(d),
              a
            );
          });
      })(i || (i = {}));
    },
  },
]);
