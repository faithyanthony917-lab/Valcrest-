(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [1068, 78312],
  {
    914487(t, i) {
      var s;
      !(function () {
        "use strict";
        var e = {}.hasOwnProperty;
        function h() {
          for (var t = [], i = 0; i < arguments.length; i++) {
            var s = arguments[i];
            if (s) {
              var n = typeof s;
              if ("string" === n || "number" === n) t.push(s);
              else if (Array.isArray(s) && s.length) {
                var r = h.apply(null, s);
                r && t.push(r);
              } else if ("object" === n)
                for (var o in s) e.call(s, o) && s[o] && t.push(o);
            }
          }
          return t.join(" ");
        }
        t.exports
          ? ((h.default = h), (t.exports = h))
          : void 0 ===
              (s = function () {
                return h;
              }.apply(i, [])) || (t.exports = s);
      })();
    },
    320403(t, i) {
      "use strict";
      var s,
        e = !(
          "undefined" == typeof window ||
          !window.document ||
          !window.document.createElement
        );
      function h() {
        if (s) return s;
        if (!e || !window.document.body) return "indeterminate";
        var t = window.document.createElement("div");
        return (
          t.appendChild(document.createTextNode("ABCD")),
          (t.dir = "rtl"),
          (t.style.fontSize = "14px"),
          (t.style.width = "4px"),
          (t.style.height = "1px"),
          (t.style.position = "absolute"),
          (t.style.top = "-1000px"),
          (t.style.overflow = "scroll"),
          document.body.appendChild(t),
          (s = "reverse"),
          t.scrollLeft > 0
            ? (s = "default")
            : ((t.scrollLeft = 1), 0 === t.scrollLeft && (s = "negative")),
          document.body.removeChild(t),
          s
        );
      }
    },
    32183(t, i, s) {
      "use strict";
      s.d(i, { setClasses: () => h });
      var e = s(467242);
      e.mobiletouch, e.touch;
      function h() {
        document.documentElement.classList.add(
          e.touch ? "feature-touch" : "feature-no-touch",
          e.mobiletouch ? "feature-mobiletouch" : "feature-no-mobiletouch"
        );
      }
    },
    527323(t, i, s) {
      var e;
      !(function (i) {
        "use strict";
        function h() {}
        var n = h.prototype,
          r = i.EventEmitter;
        function o(t, i) {
          for (var s = t.length; s--; ) if (t[s].listener === i) return s;
          return -1;
        }
        function l(t) {
          return function () {
            return this[t].apply(this, arguments);
          };
        }
        function a(t) {
          return (
            "function" == typeof t ||
            t instanceof RegExp ||
            (!(!t || "object" != typeof t) && a(t.listener))
          );
        }
        (n.getListeners = function (t) {
          var i,
            s,
            e = this._getEvents();
          if (t instanceof RegExp)
            for (s in ((i = {}), e))
              e.hasOwnProperty(s) && t.test(s) && (i[s] = e[s]);
          else i = e[t] || (e[t] = []);
          return i;
        }),
          (n.flattenListeners = function (t) {
            var i,
              s = [];
            for (i = 0; i < t.length; i += 1) s.push(t[i].listener);
            return s;
          }),
          (n.getListenersAsObject = function (t) {
            var i,
              s = this.getListeners(t);
            return s instanceof Array && ((i = {})[t] = s), i || s;
          }),
          (n.addListener = function (t, i) {
            if (!a(i)) throw new TypeError("listener must be a function");
            var s,
              e = this.getListenersAsObject(t),
              h = "object" == typeof i;
            for (s in e)
              e.hasOwnProperty(s) &&
                -1 === o(e[s], i) &&
                e[s].push(h ? i : { listener: i, once: !1 });
            return this;
          }),
          (n.on = l("addListener")),
          (n.addOnceListener = function (t, i) {
            return this.addListener(t, { listener: i, once: !0 });
          }),
          (n.once = l("addOnceListener")),
          (n.defineEvent = function (t) {
            return this.getListeners(t), this;
          }),
          (n.defineEvents = function (t) {
            for (var i = 0; i < t.length; i += 1) this.defineEvent(t[i]);
            return this;
          }),
          (n.removeListener = function (t, i) {
            var s,
              e,
              h = this.getListenersAsObject(t);
            for (e in h)
              h.hasOwnProperty(e) &&
                -1 !== (s = o(h[e], i)) &&
                h[e].splice(s, 1);
            return this;
          }),
          (n.off = l("removeListener")),
          (n.addListeners = function (t, i) {
            return this.manipulateListeners(!1, t, i);
          }),
          (n.removeListeners = function (t, i) {
            return this.manipulateListeners(!0, t, i);
          }),
          (n.manipulateListeners = function (t, i, s) {
            var e,
              h,
              n = t ? this.removeListener : this.addListener,
              r = t ? this.removeListeners : this.addListeners;
            if ("object" != typeof i || i instanceof RegExp)
              for (e = s.length; e--; ) n.call(this, i, s[e]);
            else
              for (e in i)
                i.hasOwnProperty(e) &&
                  (h = i[e]) &&
                  ("function" == typeof h
                    ? n.call(this, e, h)
                    : r.call(this, e, h));
            return this;
          }),
          (n.removeEvent = function (t) {
            var i,
              s = typeof t,
              e = this._getEvents();
            if ("string" === s) delete e[t];
            else if (t instanceof RegExp)
              for (i in e) e.hasOwnProperty(i) && t.test(i) && delete e[i];
            else delete this._events;
            return this;
          }),
          (n.removeAllListeners = l("removeEvent")),
          (n.emitEvent = function (t, i) {
            var s,
              e,
              h,
              n,
              r = this.getListenersAsObject(t);
            for (n in r)
              if (r.hasOwnProperty(n))
                for (s = r[n].slice(0), h = 0; h < s.length; h++)
                  !0 === (e = s[h]).once && this.removeListener(t, e.listener),
                    e.listener.apply(this, i || []) ===
                      this._getOnceReturnValue() &&
                      this.removeListener(t, e.listener);
            return this;
          }),
          (n.trigger = l("emitEvent")),
          (n.emit = function (t) {
            var i = Array.prototype.slice.call(arguments, 1);
            return this.emitEvent(t, i);
          }),
          (n.setOnceReturnValue = function (t) {
            return (this._onceReturnValue = t), this;
          }),
          (n._getOnceReturnValue = function () {
            return (
              !this.hasOwnProperty("_onceReturnValue") || this._onceReturnValue
            );
          }),
          (n._getEvents = function () {
            return this._events || (this._events = {});
          }),
          (h.noConflict = function () {
            return (i.EventEmitter = r), h;
          }),
          void 0 ===
            (e = function () {
              return h;
            }.call(i, s, i, t)) || (t.exports = e);
      })(this || {});
    },
    918779(t, i, s) {
      "use strict";
      s.d(i, {
        bindCanvasElementBitmapSizeTo: () => r,
        equalSizes: () => e.equalSizes,
        size: () => e.size,
        tryCreateCanvasRenderingTarget2D: () => a,
      });
      var e = s(74279),
        h = s(743451),
        n = (function () {
          function t(t, i, s) {
            var h;
            (this._canvasElement = null),
              (this._bitmapSizeChangedListeners = []),
              (this._suggestedBitmapSize = null),
              (this._suggestedBitmapSizeChangedListeners = []),
              (this._devicePixelRatioObservable = null),
              (this._canvasElementResizeObserver = null),
              (this._canvasElement = t),
              (this._canvasElementClientSize = (0, e.size)({
                width: this._canvasElement.clientWidth,
                height: this._canvasElement.clientHeight,
              })),
              (this._transformBitmapSize =
                null != i
                  ? i
                  : function (t) {
                      return t;
                    }),
              (this._allowResizeObserver =
                null === (h = null == s ? void 0 : s.allowResizeObserver) ||
                void 0 === h ||
                h),
              this._chooseAndInitObserver();
          }
          return (
            (t.prototype.dispose = function () {
              var t, i;
              if (null === this._canvasElement)
                throw new Error("Object is disposed");
              null === (t = this._canvasElementResizeObserver) ||
                void 0 === t ||
                t.disconnect(),
                (this._canvasElementResizeObserver = null),
                null === (i = this._devicePixelRatioObservable) ||
                  void 0 === i ||
                  i.dispose(),
                (this._devicePixelRatioObservable = null),
                (this._suggestedBitmapSizeChangedListeners.length = 0),
                (this._bitmapSizeChangedListeners.length = 0),
                (this._canvasElement = null);
            }),
            Object.defineProperty(t.prototype, "canvasElement", {
              get: function () {
                if (null === this._canvasElement)
                  throw new Error("Object is disposed");
                return this._canvasElement;
              },
              enumerable: !1,
              configurable: !0,
            }),
            Object.defineProperty(t.prototype, "canvasElementClientSize", {
              get: function () {
                return this._canvasElementClientSize;
              },
              enumerable: !1,
              configurable: !0,
            }),
            Object.defineProperty(t.prototype, "bitmapSize", {
              get: function () {
                return (0, e.size)({
                  width: this.canvasElement.width,
                  height: this.canvasElement.height,
                });
              },
              enumerable: !1,
              configurable: !0,
            }),
            (t.prototype.resizeCanvasElement = function (t) {
              (this._canvasElementClientSize = (0, e.size)(t)),
                (this.canvasElement.style.width = "".concat(
                  this._canvasElementClientSize.width,
                  "px"
                )),
                (this.canvasElement.style.height = "".concat(
                  this._canvasElementClientSize.height,
                  "px"
                )),
                this._invalidateBitmapSize();
            }),
            (t.prototype.subscribeBitmapSizeChanged = function (t) {
              this._bitmapSizeChangedListeners.push(t);
            }),
            (t.prototype.unsubscribeBitmapSizeChanged = function (t) {
              this._bitmapSizeChangedListeners =
                this._bitmapSizeChangedListeners.filter(function (i) {
                  return i !== t;
                });
            }),
            Object.defineProperty(t.prototype, "suggestedBitmapSize", {
              get: function () {
                return this._suggestedBitmapSize;
              },
              enumerable: !1,
              configurable: !0,
            }),
            (t.prototype.subscribeSuggestedBitmapSizeChanged = function (t) {
              this._suggestedBitmapSizeChangedListeners.push(t);
            }),
            (t.prototype.unsubscribeSuggestedBitmapSizeChanged = function (t) {
              this._suggestedBitmapSizeChangedListeners =
                this._suggestedBitmapSizeChangedListeners.filter(function (i) {
                  return i !== t;
                });
            }),
            (t.prototype.applySuggestedBitmapSize = function () {
              if (null !== this._suggestedBitmapSize) {
                var t = this._suggestedBitmapSize;
                (this._suggestedBitmapSize = null),
                  this._resizeBitmap(t),
                  this._emitSuggestedBitmapSizeChanged(
                    t,
                    this._suggestedBitmapSize
                  );
              }
            }),
            (t.prototype._resizeBitmap = function (t) {
              var i = this.bitmapSize;
              (0, e.equalSizes)(i, t) ||
                ((this.canvasElement.width = t.width),
                (this.canvasElement.height = t.height),
                this._emitBitmapSizeChanged(i, t));
            }),
            (t.prototype._emitBitmapSizeChanged = function (t, i) {
              var s = this;
              this._bitmapSizeChangedListeners.forEach(function (e) {
                return e.call(s, t, i);
              });
            }),
            (t.prototype._suggestNewBitmapSize = function (t) {
              var i = this._suggestedBitmapSize,
                s = (0, e.size)(
                  this._transformBitmapSize(t, this._canvasElementClientSize)
                ),
                h = (0, e.equalSizes)(this.bitmapSize, s) ? null : s;
              (null === i && null === h) ||
                (null !== i && null !== h && (0, e.equalSizes)(i, h)) ||
                ((this._suggestedBitmapSize = h),
                this._emitSuggestedBitmapSizeChanged(i, h));
            }),
            (t.prototype._emitSuggestedBitmapSizeChanged = function (t, i) {
              var s = this;
              this._suggestedBitmapSizeChangedListeners.forEach(function (e) {
                return e.call(s, t, i);
              });
            }),
            (t.prototype._chooseAndInitObserver = function () {
              var t = this;
              this._allowResizeObserver
                ? new Promise(function (t) {
                    var i = new ResizeObserver(function (s) {
                      t(
                        s.every(function (t) {
                          return "devicePixelContentBoxSize" in t;
                        })
                      ),
                        i.disconnect();
                    });
                    i.observe(document.body, {
                      box: "device-pixel-content-box",
                    });
                  })
                    .catch(function () {
                      return !1;
                    })
                    .then(function (i) {
                      return i
                        ? t._initResizeObserver()
                        : t._initDevicePixelRatioObservable();
                    })
                : this._initDevicePixelRatioObservable();
            }),
            (t.prototype._initDevicePixelRatioObservable = function () {
              var t = this;
              if (null !== this._canvasElement) {
                var i = o(this._canvasElement);
                if (null === i)
                  throw new Error("No window is associated with the canvas");
                (this._devicePixelRatioObservable = (0, h.createObservable)(i)),
                  this._devicePixelRatioObservable.subscribe(function () {
                    return t._invalidateBitmapSize();
                  }),
                  this._invalidateBitmapSize();
              }
            }),
            (t.prototype._invalidateBitmapSize = function () {
              var t, i;
              if (null !== this._canvasElement) {
                var s = o(this._canvasElement);
                if (null !== s) {
                  var h =
                      null !==
                        (i =
                          null === (t = this._devicePixelRatioObservable) ||
                          void 0 === t
                            ? void 0
                            : t.value) && void 0 !== i
                        ? i
                        : s.devicePixelRatio,
                    n = this._canvasElement.getClientRects(),
                    r =
                      void 0 !== n[0]
                        ? (function (t, i) {
                            return (0, e.size)({
                              width:
                                Math.round(t.left * i + t.width * i) -
                                Math.round(t.left * i),
                              height:
                                Math.round(t.top * i + t.height * i) -
                                Math.round(t.top * i),
                            });
                          })(n[0], h)
                        : (0, e.size)({
                            width: this._canvasElementClientSize.width * h,
                            height: this._canvasElementClientSize.height * h,
                          });
                  this._suggestNewBitmapSize(r);
                }
              }
            }),
            (t.prototype._initResizeObserver = function () {
              var t = this;
              null !== this._canvasElement &&
                ((this._canvasElementResizeObserver = new ResizeObserver(
                  function (i) {
                    var s = i.find(function (i) {
                      return i.target === t._canvasElement;
                    });
                    if (
                      s &&
                      s.devicePixelContentBoxSize &&
                      s.devicePixelContentBoxSize[0]
                    ) {
                      var h = s.devicePixelContentBoxSize[0],
                        n = (0, e.size)({
                          width: h.inlineSize,
                          height: h.blockSize,
                        });
                      t._suggestNewBitmapSize(n);
                    }
                  }
                )),
                this._canvasElementResizeObserver.observe(this._canvasElement, {
                  box: "device-pixel-content-box",
                }));
            }),
            t
          );
        })();
      function r(t, i) {
        if ("device-pixel-content-box" === i.type)
          return new n(t, i.transform, i.options);
        throw new Error("Unsupported binding target");
      }
      function o(t) {
        return t.ownerDocument.defaultView;
      }
      var l = (function () {
        function t(t, i, s) {
          if (0 === i.width || 0 === i.height)
            throw new TypeError(
              "Rendering target could only be created on a media with positive width and height"
            );
          if (((this._mediaSize = i), 0 === s.width || 0 === s.height))
            throw new TypeError(
              "Rendering target could only be created using a bitmap with positive integer width and height"
            );
          (this._bitmapSize = s), (this._context = t);
        }
        return (
          (t.prototype.useMediaCoordinateSpace = function (t) {
            try {
              return (
                this._context.save(),
                this._context.setTransform(1, 0, 0, 1, 0, 0),
                this._context.scale(
                  this._horizontalPixelRatio,
                  this._verticalPixelRatio
                ),
                t({ context: this._context, mediaSize: this._mediaSize })
              );
            } finally {
              this._context.restore();
            }
          }),
          (t.prototype.useBitmapCoordinateSpace = function (t) {
            try {
              return (
                this._context.save(),
                this._context.setTransform(1, 0, 0, 1, 0, 0),
                t({
                  context: this._context,
                  mediaSize: this._mediaSize,
                  bitmapSize: this._bitmapSize,
                  horizontalPixelRatio: this._horizontalPixelRatio,
                  verticalPixelRatio: this._verticalPixelRatio,
                })
              );
            } finally {
              this._context.restore();
            }
          }),
          Object.defineProperty(t.prototype, "_horizontalPixelRatio", {
            get: function () {
              return this._bitmapSize.width / this._mediaSize.width;
            },
            enumerable: !1,
            configurable: !0,
          }),
          Object.defineProperty(t.prototype, "_verticalPixelRatio", {
            get: function () {
              return this._bitmapSize.height / this._mediaSize.height;
            },
            enumerable: !1,
            configurable: !0,
          }),
          t
        );
      })();
      function a(t, i) {
        var s = t.canvasElementClientSize;
        if (0 === s.width || 0 === s.height) return null;
        var e = t.bitmapSize;
        if (0 === e.width || 0 === e.height) return null;
        var h = t.canvasElement.getContext("2d", i);
        return null === h ? null : new l(h, s, e);
      }
    },
    678312(t, i, s) {
      "use strict";
      s.d(i, {
        AreaSeries: () => Eh,
        BarSeries: () => Th,
        BaselineSeries: () => xh,
        CandlestickSeries: () => Ph,
        ColorType: () => Ki,
        HistogramSeries: () => Oh,
        LineSeries: () => vh,
        MismatchDirection: () => Tt,
        PriceScaleMode: () => wi,
        TickMarkType: () => Vi,
        createChartEx: () => th,
        createTextWatermark: () => Hh,
        customSeriesDefaultOptions: () => Gh,
        defaultHorzScaleBehavior: () => ih,
      });
      var e = s(918779);
      const h = {
        title: "",
        visible: !0,
        hitTestTolerance: 3,
        lastValueVisible: !0,
        priceLineVisible: !0,
        priceLineSource: 0,
        priceLineWidth: 1,
        priceLineColor: "",
        priceLineStyle: 2,
        baseLineVisible: !0,
        baseLineWidth: 1,
        baseLineColor: "#B2B5BE",
        baseLineStyle: 0,
        priceFormat: { type: "price", precision: 2, minMove: 0.01 },
      };
      var n, r, o;
      function l(t, i) {
        const s = (function (t, i) {
          switch (t) {
            case 0:
            default:
              return [];
            case 1:
              return [i, i];
            case 2:
              return [2 * i, 2 * i];
            case 3:
              return [6 * i, 6 * i];
            case 4:
              return [i, 4 * i];
          }
        })(i, t.lineWidth);
        return t.setLineDash(s), s;
      }
      function a(t, i, s, e) {
        t.beginPath();
        const h = t.lineWidth % 2 ? 0.5 : 0;
        t.moveTo(s, i + h), t.lineTo(e, i + h), t.stroke();
      }
      function u(t, i) {
        if (!t) throw new Error("Assertion failed" + (i ? ": " + i : ""));
      }
      function c(t) {
        if (void 0 === t) throw new Error("Value is undefined");
        return t;
      }
      function d(t) {
        if (null === t) throw new Error("Value is null");
        return t;
      }
      function f(t) {
        return d(c(t));
      }
      ((o = n || (n = {}))[(o.Simple = 0)] = "Simple"),
        (o[(o.WithSteps = 1)] = "WithSteps"),
        (o[(o.Curved = 2)] = "Curved"),
        (function (t) {
          (t[(t.Solid = 0)] = "Solid"),
            (t[(t.Dotted = 1)] = "Dotted"),
            (t[(t.Dashed = 2)] = "Dashed"),
            (t[(t.LargeDashed = 3)] = "LargeDashed"),
            (t[(t.SparseDotted = 4)] = "SparseDotted");
        })(r || (r = {}));
      class m {
        constructor() {
          this.t = [];
        }
        i(t, i, s) {
          const e = { h: t, l: i, o: !0 === s };
          this.t.push(e);
        }
        _(t) {
          const i = this.t.findIndex((i) => t === i.h);
          i > -1 && this.t.splice(i, 1);
        }
        u(t) {
          this.t = this.t.filter((i) => i.l !== t);
        }
        p(t, i, s) {
          const e = [...this.t];
          (this.t = this.t.filter((t) => !t.o)), e.forEach((e) => e.h(t, i, s));
        }
        v() {
          return this.t.length > 0;
        }
        m() {
          this.t = [];
        }
      }
      function p(t, ...i) {
        for (const s of i)
          for (const i in s)
            void 0 !== s[i] &&
              Object.prototype.hasOwnProperty.call(s, i) &&
              !["__proto__", "constructor", "prototype"].includes(i) &&
              ("object" != typeof s[i] || void 0 === t[i] || Array.isArray(s[i])
                ? (t[i] = s[i])
                : p(t[i], s[i]));
        return t;
      }
      function v(t) {
        return "number" == typeof t && isFinite(t);
      }
      function g(t) {
        return "number" == typeof t && t % 1 == 0;
      }
      function b(t) {
        return "string" == typeof t;
      }
      function w(t) {
        return "boolean" == typeof t;
      }
      function M(t) {
        const i = t;
        if (!i || "object" != typeof i) return i;
        let s, e, h;
        for (e in ((s = Array.isArray(i) ? [] : {}), i))
          i.hasOwnProperty(e) &&
            ((h = i[e]), (s[e] = h && "object" == typeof h ? M(h) : h));
        return s;
      }
      function y(t) {
        return null !== t;
      }
      function S(t) {
        return null === t ? void 0 : t;
      }
      const x =
        "-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif";
      function _(t, i, s) {
        return (
          void 0 === i && (i = x),
          `${(s = void 0 !== s ? `${s} ` : "")}${t}px ${i}`
        );
      }
      class C {
        constructor(t) {
          (this.M = {
            S: 1,
            C: 5,
            k: NaN,
            P: "",
            T: "",
            R: "",
            D: "",
            I: 0,
            V: 0,
            B: 0,
            A: 0,
            L: 0,
          }),
            (this.O = t);
        }
        N() {
          const t = this.M,
            i = this.F(),
            s = this.W();
          return (
            (t.k === i && t.T === s) ||
              ((t.k = i),
              (t.T = s),
              (t.P = _(i, s)),
              (t.A = (2.5 / 12) * i),
              (t.I = t.A),
              (t.V = (i / 12) * t.C),
              (t.B = (i / 12) * t.C),
              (t.L = 0)),
            (t.R = this.H()),
            (t.D = this.U()),
            this.M
          );
        }
        H() {
          return this.O.N().layout.textColor;
        }
        U() {
          return this.O.$();
        }
        F() {
          return this.O.N().layout.fontSize;
        }
        W() {
          return this.O.N().layout.fontFamily;
        }
      }
      function E(t) {
        return t < 0 ? 0 : t > 255 ? 255 : Math.round(t) || 0;
      }
      function z(t) {
        return 0.199 * t[0] + 0.687 * t[1] + 0.114 * t[2];
      }
      class k {
        constructor(t, i) {
          (this.j = new Map()), (this.q = t), i && (this.j = i);
        }
        Y(t, i) {
          if ("transparent" === t) return t;
          const s = this.K(t),
            e = s[3];
          return `rgba(${s[0]}, ${s[1]}, ${s[2]}, ${i * e})`;
        }
        Z(t) {
          const i = this.K(t);
          return {
            G: `rgb(${i[0]}, ${i[1]}, ${i[2]})`,
            X: z(i) > 160 ? "black" : "white",
          };
        }
        J(t) {
          return z(this.K(t));
        }
        tt(t, i, s) {
          const [e, h, n, r] = this.K(t),
            [o, l, a, u] = this.K(i),
            c = [
              E(e + s * (o - e)),
              E(h + s * (l - h)),
              E(n + s * (a - n)),
              ((d = r + s * (u - r)),
              d <= 0 || d > 1
                ? Math.min(Math.max(d, 0), 1)
                : Math.round(1e4 * d) / 1e4),
            ];
          var d;
          return `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${c[3]})`;
        }
        K(t) {
          const i = this.j.get(t);
          if (i) return i;
          const s = (function (t) {
              const i = document.createElement("div");
              (i.style.display = "none"),
                document.body.appendChild(i),
                (i.style.color = t);
              const s = window.getComputedStyle(i).color;
              return document.body.removeChild(i), s;
            })(t),
            e = s.match(
              /^rgba?\s*\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d*\.?\d+))?\)$/
            );
          if (!e) {
            if (this.q.length)
              for (const i of this.q) {
                const s = i(t);
                if (s) return this.j.set(t, s), s;
              }
            throw new Error(`Failed to parse color: ${t}`);
          }
          const h = [
            parseInt(e[1], 10),
            parseInt(e[2], 10),
            parseInt(e[3], 10),
            e[4] ? parseFloat(e[4]) : 1,
          ];
          return this.j.set(t, h), h;
        }
      }
      class N {
        constructor() {
          this.it = [];
        }
        nt(t) {
          this.it = t;
        }
        st(t, i, s) {
          this.it.forEach((e) => {
            e.st(t, i, s);
          });
        }
      }
      class T {
        st(t, i, s) {
          t.useBitmapCoordinateSpace((t) => this.et(t, i, s));
        }
      }
      class R extends T {
        constructor() {
          super(...arguments), (this.rt = null);
        }
        ht(t) {
          this.rt = t;
        }
        et({ context: t, horizontalPixelRatio: i, verticalPixelRatio: s }) {
          if (null === this.rt || null === this.rt.lt) return;
          const e = this.rt.lt,
            h = this.rt,
            n = (Math.max(1, Math.floor(i)) % 2) / 2,
            r = (r) => {
              t.beginPath();
              for (let o = e.to - 1; o >= e.from; --o) {
                const e = h.ot[o],
                  l = Math.round(e._t * i) + n,
                  a = e.ut * s,
                  u = r * s + n;
                t.moveTo(l, a), t.arc(l, a, u, 0, 2 * Math.PI);
              }
              t.fill();
            };
          h.ct > 0 && ((t.fillStyle = h.dt), r(h.ft + h.ct)),
            (t.fillStyle = h.vt),
            r(h.ft);
        }
      }
      function L() {
        return {
          ot: [{ _t: 0, ut: 0, wt: 0, Mt: 0 }],
          vt: "",
          dt: "",
          ft: 0,
          ct: 0,
          lt: null,
        };
      }
      const P = { from: 0, to: 1 };
      class I {
        constructor(t, i, s) {
          (this.gt = new N()),
            (this.bt = []),
            (this.St = []),
            (this.xt = !0),
            (this.O = t),
            (this.Ct = i),
            (this.yt = s),
            this.gt.nt(this.bt);
        }
        kt(t) {
          this.Pt(), (this.xt = !0);
        }
        Tt() {
          return this.xt && (this.Rt(), (this.xt = !1)), this.gt;
        }
        Pt() {
          const t = this.yt.Dt();
          t.length !== this.bt.length &&
            ((this.St = t.map(L)),
            (this.bt = this.St.map((t) => {
              const i = new R();
              return i.ht(t), i;
            })),
            this.gt.nt(this.bt));
        }
        Rt() {
          const t = 2 === this.Ct.N().mode || !this.Ct.It(),
            i = this.yt.Vt(),
            s = this.Ct.Bt(),
            e = this.O.Et();
          this.Pt(),
            i.forEach((i, h) => {
              const n = this.St[h],
                r = i.At(s),
                o = i.Lt();
              !t && null !== r && i.It() && null !== o
                ? ((n.vt = r.zt),
                  (n.ft = r.ft),
                  (n.ct = r.Ot),
                  (n.ot[0].Mt = r.Mt),
                  (n.ot[0].ut = i.Ft().Nt(r.Mt, o.Wt)),
                  (n.dt = r.Ht ?? this.O.Ut(n.ot[0].ut / i.Ft().$t())),
                  (n.ot[0].wt = s),
                  (n.ot[0]._t = e.jt(s)),
                  (n.lt = P))
                : (n.lt = null);
            });
        }
      }
      class q extends T {
        constructor(t) {
          super(), (this.qt = t);
        }
        et({
          context: t,
          bitmapSize: i,
          horizontalPixelRatio: s,
          verticalPixelRatio: e,
        }) {
          if (null === this.qt) return;
          const h = this.qt.Yt.It,
            n = this.qt.Kt.It;
          if (!h && !n) return;
          const r = Math.round(this.qt._t * s),
            o = Math.round(this.qt.ut * e);
          (t.lineCap = "butt"),
            h &&
              r >= 0 &&
              ((t.lineWidth = Math.floor(this.qt.Yt.ct * s)),
              (t.strokeStyle = this.qt.Yt.R),
              (t.fillStyle = this.qt.Yt.R),
              l(t, this.qt.Yt.Zt),
              (function (t, i, s, e) {
                t.beginPath();
                const h = t.lineWidth % 2 ? 0.5 : 0;
                t.moveTo(i + h, 0), t.lineTo(i + h, e), t.stroke();
              })(t, r, 0, i.height)),
            n &&
              o >= 0 &&
              ((t.lineWidth = Math.floor(this.qt.Kt.ct * e)),
              (t.strokeStyle = this.qt.Kt.R),
              (t.fillStyle = this.qt.Kt.R),
              l(t, this.qt.Kt.Zt),
              a(t, o, 0, i.width));
        }
      }
      class O {
        constructor(t, i) {
          (this.xt = !0),
            (this.Gt = {
              Yt: { ct: 1, Zt: 0, R: "", It: !1 },
              Kt: { ct: 1, Zt: 0, R: "", It: !1 },
              _t: 0,
              ut: 0,
            }),
            (this.Xt = new q(this.Gt)),
            (this.Jt = t),
            (this.yt = i);
        }
        kt() {
          this.xt = !0;
        }
        Tt(t) {
          return this.xt && (this.Rt(), (this.xt = !1)), this.Xt;
        }
        Rt() {
          const t = this.Jt.It(),
            i = this.yt.Qt().N().crosshair,
            s = this.Gt;
          if (2 === i.mode) return (s.Kt.It = !1), void (s.Yt.It = !1);
          (s.Kt.It = t && this.Jt.ti(this.yt)),
            (s.Yt.It = t && this.Jt.ii()),
            (s.Kt.ct = i.horzLine.width),
            (s.Kt.Zt = i.horzLine.style),
            (s.Kt.R = i.horzLine.color),
            (s.Yt.ct = i.vertLine.width),
            (s.Yt.Zt = i.vertLine.style),
            (s.Yt.R = i.vertLine.color),
            (s._t = this.Jt.ni()),
            (s.ut = this.Jt.si());
        }
      }
      function F(t, i, s, e, h, n) {
        t.fillRect(i + n, s, e - 2 * n, n),
          t.fillRect(i + n, s + h - n, e - 2 * n, n),
          t.fillRect(i, s, n, h),
          t.fillRect(i + e - n, s, n, h);
      }
      function W(t, i, s, e, h, n) {
        t.save(),
          (t.globalCompositeOperation = "copy"),
          (t.fillStyle = n),
          t.fillRect(i, s, e, h),
          t.restore();
      }
      function B(t, i, s, e, h, n) {
        t.beginPath(),
          t.roundRect
            ? t.roundRect(i, s, e, h, n)
            : (t.lineTo(i + e - n[1], s),
              0 !== n[1] && t.arcTo(i + e, s, i + e, s + n[1], n[1]),
              t.lineTo(i + e, s + h - n[2]),
              0 !== n[2] && t.arcTo(i + e, s + h, i + e - n[2], s + h, n[2]),
              t.lineTo(i + n[3], s + h),
              0 !== n[3] && t.arcTo(i, s + h, i, s + h - n[3], n[3]),
              t.lineTo(i, s + n[0]),
              0 !== n[0] && t.arcTo(i, s, i + n[0], s, n[0]));
      }
      function Q(t, i, s, e, h, n, r = 0, o = [0, 0, 0, 0], l = "") {
        if ((t.save(), !r || !l || l === n))
          return (
            B(t, i, s, e, h, o), (t.fillStyle = n), t.fill(), void t.restore()
          );
        const a = r / 2;
        var u;
        B(
          t,
          i + a,
          s + a,
          e - r,
          h - r,
          ((u = -a), o.map((t) => (0 === t ? t : t + u)))
        ),
          "transparent" !== n && ((t.fillStyle = n), t.fill()),
          "transparent" !== l &&
            ((t.lineWidth = r), (t.strokeStyle = l), t.closePath(), t.stroke()),
          t.restore();
      }
      function D(t, i, s, e, h, n, r) {
        t.save(), (t.globalCompositeOperation = "copy");
        const o = t.createLinearGradient(0, 0, 0, h);
        o.addColorStop(0, n),
          o.addColorStop(1, r),
          (t.fillStyle = o),
          t.fillRect(i, s, e, h),
          t.restore();
      }
      class K {
        constructor(t, i) {
          this.ht(t, i);
        }
        ht(t, i) {
          (this.qt = t), (this.ei = i);
        }
        $t(t, i) {
          return this.qt.It ? t.k + t.A + t.I : 0;
        }
        st(t, i, s, e) {
          if (!this.qt.It || 0 === this.qt.ri.length) return;
          const h = this.qt.R,
            n = this.ei.G,
            r = t.useBitmapCoordinateSpace((t) => {
              const r = t.context;
              r.font = i.P;
              const o = this.hi(t, i, s, e),
                l = o.ai;
              return (
                o.li
                  ? Q(r, l.oi, l._i, l.ui, l.ci, n, l.di, [l.ft, 0, 0, l.ft], n)
                  : Q(
                      r,
                      l.fi,
                      l._i,
                      l.ui,
                      l.ci,
                      n,
                      l.di,
                      [0, l.ft, l.ft, 0],
                      n
                    ),
                this.qt.pi &&
                  ((r.fillStyle = h),
                  r.fillRect(l.fi, l.mi, l.wi - l.fi, l.Mi)),
                this.qt.gi &&
                  ((r.fillStyle = i.D),
                  r.fillRect(o.li ? l.bi - l.di : 0, l._i, l.di, l.Si - l._i)),
                o
              );
            });
          t.useMediaCoordinateSpace(({ context: t }) => {
            const s = r.xi;
            (t.font = i.P),
              (t.textAlign = r.li ? "right" : "left"),
              (t.textBaseline = "middle"),
              (t.fillStyle = h),
              t.fillText(this.qt.ri, s.Ci, (s._i + s.Si) / 2 + s.yi);
          });
        }
        hi(t, i, s, e) {
          const {
              context: h,
              bitmapSize: n,
              mediaSize: r,
              horizontalPixelRatio: o,
              verticalPixelRatio: l,
            } = t,
            a = this.qt.pi || !this.qt.ki ? i.C : 0,
            u = this.qt.Pi ? i.S : 0,
            c = i.A + this.ei.Ti,
            d = i.I + this.ei.Ri,
            f = i.V,
            m = i.B,
            p = this.qt.ri,
            v = i.k,
            g = s.Di(h, p),
            b = Math.ceil(s.Ii(h, p)),
            w = v + c + d,
            M = i.S + f + m + b + a,
            y = Math.max(1, Math.floor(l));
          let S = Math.round(w * l);
          S % 2 != y % 2 && (S += 1);
          const x = u > 0 ? Math.max(1, Math.floor(u * o)) : 0,
            _ = Math.round(M * o),
            C = Math.round(a * o),
            E = this.ei.Vi ?? this.ei.Bi ?? this.ei.Ei,
            z = Math.round(E * l) - Math.floor(0.5 * l),
            k = Math.floor(z + y / 2 - S / 2),
            N = k + S,
            T = "right" === e,
            R = T ? r.width - u : u,
            L = T ? n.width - x : x;
          let P, I, q;
          return (
            T
              ? ((P = L - _), (I = L - C), (q = R - a - f - u))
              : ((P = L + _), (I = L + C), (q = R + a + f)),
            {
              li: T,
              ai: {
                _i: k,
                mi: z,
                Si: N,
                ui: _,
                ci: S,
                ft: 2 * o,
                di: x,
                oi: P,
                fi: L,
                wi: I,
                Mi: y,
                bi: n.width,
              },
              xi: { _i: k / l, Si: N / l, Ci: q, yi: g },
            }
          );
        }
      }
      class V {
        constructor(t) {
          (this.Ai = { Ei: 0, G: "#000", Ri: 0, Ti: 0 }),
            (this.Li = {
              ri: "",
              It: !1,
              pi: !0,
              ki: !1,
              Ht: "",
              R: "#FFF",
              gi: !1,
              Pi: !1,
            }),
            (this.zi = {
              ri: "",
              It: !1,
              pi: !1,
              ki: !0,
              Ht: "",
              R: "#FFF",
              gi: !0,
              Pi: !0,
            }),
            (this.xt = !0),
            (this.Oi = new (t || K)(this.Li, this.Ai)),
            (this.Ni = new (t || K)(this.zi, this.Ai));
        }
        ri() {
          return this.Fi(), this.Li.ri;
        }
        Ei() {
          return this.Fi(), this.Ai.Ei;
        }
        kt() {
          this.xt = !0;
        }
        $t(t, i = !1) {
          return Math.max(this.Oi.$t(t, i), this.Ni.$t(t, i));
        }
        Wi() {
          return this.Ai.Vi ?? null;
        }
        Hi() {
          return this.Ai.Vi ?? this.Ai.Bi ?? this.Ei();
        }
        Ui(t) {
          this.Ai.Bi = t ?? void 0;
        }
        $i() {
          return this.Fi(), this.Li.It || this.zi.It;
        }
        ji() {
          return this.Fi(), this.Li.It;
        }
        Tt(t) {
          return (
            this.Fi(),
            (this.Li.pi = this.Li.pi && t.N().ticksVisible),
            (this.zi.pi = this.zi.pi && t.N().ticksVisible),
            this.Oi.ht(this.Li, this.Ai),
            this.Ni.ht(this.zi, this.Ai),
            this.Oi
          );
        }
        qi() {
          return (
            this.Fi(),
            this.Oi.ht(this.Li, this.Ai),
            this.Ni.ht(this.zi, this.Ai),
            this.Ni
          );
        }
        Fi() {
          this.xt &&
            ((this.Li.pi = !0),
            (this.zi.pi = !1),
            this.Yi(this.Li, this.zi, this.Ai));
        }
      }
      class $ extends V {
        constructor(t, i, s) {
          super(), (this.Jt = t), (this.Ki = i), (this.Zi = s);
        }
        Yi(t, i, s) {
          if (((t.It = !1), 2 === this.Jt.N().mode)) return;
          const e = this.Jt.N().horzLine;
          if (!e.labelVisible) return;
          const h = this.Ki.Lt();
          if (!this.Jt.It() || this.Ki.Gi() || null === h) return;
          const n = this.Ki.Xi().Z(e.labelBackgroundColor);
          (s.G = n.G), (t.R = n.X);
          const r = (2 / 12) * this.Ki.k();
          (s.Ti = r), (s.Ri = r);
          const o = this.Zi(this.Ki);
          (s.Ei = o.Ei), (t.ri = this.Ki.Ji(o.Mt, h)), (t.It = !0);
        }
      }
      const A = /[1-9]/g;
      class Z {
        constructor() {
          this.qt = null;
        }
        ht(t) {
          this.qt = t;
        }
        st(t, i) {
          if (null === this.qt || !1 === this.qt.It || 0 === this.qt.ri.length)
            return;
          const s = t.useMediaCoordinateSpace(
            ({ context: t }) => (
              (t.font = i.P), Math.round(i.Qi.Ii(t, d(this.qt).ri, A))
            )
          );
          if (s <= 0) return;
          const e = i.tn,
            h = s + 2 * e,
            n = h / 2,
            r = this.qt.nn;
          let o = this.qt.Ei,
            l = Math.floor(o - n) + 0.5;
          l < 0
            ? ((o += Math.abs(0 - l)), (l = Math.floor(o - n) + 0.5))
            : l + h > r &&
              ((o -= Math.abs(r - (l + h))), (l = Math.floor(o - n) + 0.5));
          const a = l + h,
            u = Math.ceil(0 + i.S + i.C + i.A + i.k + i.I);
          t.useBitmapCoordinateSpace(
            ({
              context: t,
              horizontalPixelRatio: s,
              verticalPixelRatio: e,
            }) => {
              const h = d(this.qt);
              t.fillStyle = h.G;
              const n = Math.round(l * s),
                r = Math.round(0 * e),
                o = Math.round(a * s),
                c = Math.round(u * e),
                f = Math.round(2 * s);
              if (
                (t.beginPath(),
                t.moveTo(n, r),
                t.lineTo(n, c - f),
                t.arcTo(n, c, n + f, c, f),
                t.lineTo(o - f, c),
                t.arcTo(o, c, o, c - f, f),
                t.lineTo(o, r),
                t.fill(),
                h.pi)
              ) {
                const n = Math.round(h.Ei * s),
                  o = r,
                  l = Math.round((o + i.C) * e);
                t.fillStyle = h.R;
                const a = Math.max(1, Math.floor(s)),
                  u = Math.floor(0.5 * s);
                t.fillRect(n - u, o, a, l - o);
              }
            }
          ),
            t.useMediaCoordinateSpace(({ context: t }) => {
              const s = d(this.qt),
                h = 0 + i.S + i.C + i.A + i.k / 2;
              (t.font = i.P),
                (t.textAlign = "left"),
                (t.textBaseline = "middle"),
                (t.fillStyle = s.R);
              const n = i.Qi.Di(t, "Apr0");
              t.translate(l + e, h + n), t.fillText(s.ri, 0, 0);
            });
        }
      }
      class H {
        constructor(t, i, s) {
          (this.xt = !0),
            (this.Xt = new Z()),
            (this.Gt = {
              It: !1,
              G: "#4c525e",
              R: "white",
              ri: "",
              nn: 0,
              Ei: NaN,
              pi: !0,
            }),
            (this.Ct = t),
            (this.sn = i),
            (this.Zi = s);
        }
        kt() {
          this.xt = !0;
        }
        Tt() {
          return (
            this.xt && (this.Rt(), (this.xt = !1)), this.Xt.ht(this.Gt), this.Xt
          );
        }
        Rt() {
          const t = this.Gt;
          if (((t.It = !1), 2 === this.Ct.N().mode)) return;
          const i = this.Ct.N().vertLine;
          if (!i.labelVisible) return;
          const s = this.sn.Et();
          if (s.Gi()) return;
          t.nn = s.nn();
          const e = this.Zi();
          if (null === e) return;
          t.Ei = e.Ei;
          const h = s.en(this.Ct.Bt());
          (t.ri = s.rn(d(h))), (t.It = !0);
          const n = this.sn.Xi().Z(i.labelBackgroundColor);
          (t.G = n.G), (t.R = n.X), (t.pi = s.N().ticksVisible);
        }
      }
      class G {
        constructor() {
          (this.hn = null), (this.an = 0);
        }
        ln() {
          return this.an;
        }
        _n(t) {
          this.an = t;
        }
        Ft() {
          return this.hn;
        }
        un(t) {
          this.hn = t;
        }
        cn(t) {
          return [];
        }
        dn() {
          return [];
        }
        It() {
          return !0;
        }
      }
      var Y;
      !(function (t) {
        (t[(t.Normal = 0)] = "Normal"),
          (t[(t.Magnet = 1)] = "Magnet"),
          (t[(t.Hidden = 2)] = "Hidden"),
          (t[(t.MagnetOHLC = 3)] = "MagnetOHLC");
      })(Y || (Y = {}));
      class U extends G {
        constructor(t, i) {
          super(),
            (this.yt = null),
            (this.fn = NaN),
            (this.pn = 0),
            (this.vn = !1),
            (this.mn = new Map()),
            (this.wn = !1),
            (this.Mn = new WeakMap()),
            (this.gn = new WeakMap()),
            (this.bn = NaN),
            (this.Sn = NaN),
            (this.xn = NaN),
            (this.Cn = NaN),
            (this.sn = t),
            (this.yn = i),
            (this.kn = ((t, i) => (s) => {
              const e = i(),
                h = t();
              if (s === d(this.yt).Pn()) return { Mt: h, Ei: e };
              {
                const t = d(s.Lt());
                return { Mt: s.Tn(e, t), Ei: e };
              }
            })(
              () => this.fn,
              () => this.Sn
            ));
          const s = ((t, i) => () => {
            const s = this.sn.Et().Rn(t()),
              e = i();
            return s && Number.isFinite(e) ? { wt: s, Ei: e } : null;
          })(
            () => this.pn,
            () => this.ni()
          );
          this.Dn = new H(this, t, s);
        }
        N() {
          return this.yn;
        }
        In(t, i) {
          (this.xn = t), (this.Cn = i);
        }
        Vn() {
          (this.xn = NaN), (this.Cn = NaN);
        }
        Bn() {
          return this.xn;
        }
        En() {
          return this.Cn;
        }
        An(t, i, s) {
          this.wn || (this.wn = !0), (this.vn = !0), this.Ln(t, i, s);
        }
        Bt() {
          return this.pn;
        }
        ni() {
          return this.bn;
        }
        si() {
          return this.Sn;
        }
        It() {
          return this.vn;
        }
        zn() {
          (this.vn = !1),
            this.On(),
            (this.fn = NaN),
            (this.bn = NaN),
            (this.Sn = NaN),
            (this.yt = null),
            this.Vn(),
            this.Nn();
        }
        Fn(t) {
          if (!this.yn.doNotSnapToHiddenSeriesIndices) return t;
          const i = this.sn,
            s = i.Et();
          let e = null,
            h = null;
          for (const s of i.Wn()) {
            const i = s.Un().Hn(t, -1);
            if (i) {
              if (i.$n === t) return t;
              (null === e || i.$n > e) && (e = i.$n);
            }
            const n = s.Un().Hn(t, 1);
            if (n) {
              if (n.$n === t) return t;
              (null === h || n.$n < h) && (h = n.$n);
            }
          }
          const n = [e, h].filter(y);
          if (0 === n.length) return t;
          const r = s.jt(t),
            o = n.map((t) => Math.abs(r - s.jt(t)));
          return n[o.indexOf(Math.min(...o))];
        }
        jn(t) {
          let i = this.Mn.get(t);
          i || ((i = new O(this, t)), this.Mn.set(t, i));
          let s = this.gn.get(t);
          return (
            s || ((s = new I(this.sn, this, t)), this.gn.set(t, s)), [i, s]
          );
        }
        ti(t) {
          return t === this.yt && this.yn.horzLine.visible;
        }
        ii() {
          return this.yn.vertLine.visible;
        }
        qn(t, i) {
          (this.vn && this.yt === t) || this.mn.clear();
          const s = [];
          return this.yt === t && s.push(this.Yn(this.mn, i, this.kn)), s;
        }
        dn() {
          return this.vn ? [this.Dn] : [];
        }
        Kn() {
          return this.yt;
        }
        Nn() {
          this.sn.Zn().forEach((t) => {
            this.Mn.get(t)?.kt(), this.gn.get(t)?.kt();
          }),
            this.mn.forEach((t) => t.kt()),
            this.Dn.kt();
        }
        Gn(t) {
          return t && !t.Pn().Gi() ? t.Pn() : null;
        }
        Ln(t, i, s) {
          this.Xn(t, i, s) && this.Nn();
        }
        Xn(t, i, s) {
          const e = this.bn,
            h = this.Sn,
            n = this.fn,
            r = this.pn,
            o = this.yt,
            l = this.Gn(s);
          (this.pn = t),
            (this.bn = isNaN(t) ? NaN : this.sn.Et().jt(t)),
            (this.yt = s);
          const a = null !== l ? l.Lt() : null;
          return (
            null !== l && null !== a
              ? ((this.fn = i), (this.Sn = l.Nt(i, a)))
              : ((this.fn = NaN), (this.Sn = NaN)),
            e !== this.bn ||
              h !== this.Sn ||
              r !== this.pn ||
              n !== this.fn ||
              o !== this.yt
          );
        }
        On() {
          const t = this.sn
              .Jn()
              .map((t) => t.Un().Qn())
              .filter(y),
            i = 0 === t.length ? null : Math.max(...t);
          this.pn = null !== i ? i : NaN;
        }
        Yn(t, i, s) {
          let e = t.get(i);
          return void 0 === e && ((e = new $(this, i, s)), t.set(i, e)), e;
        }
      }
      function j(t) {
        return "left" === t || "right" === t;
      }
      class X {
        constructor(t) {
          (this.ts = new Map()), (this.ns = []), (this.ss = t);
        }
        es(t, i) {
          const s = (function (t, i) {
            return void 0 === t
              ? i
              : { rs: Math.max(t.rs, i.rs), hs: t.hs || i.hs };
          })(this.ts.get(t), i);
          this.ts.set(t, s);
        }
        ls() {
          return this.ss;
        }
        _s(t) {
          const i = this.ts.get(t);
          return void 0 === i
            ? { rs: this.ss }
            : { rs: Math.max(this.ss, i.rs), hs: i.hs };
        }
        us() {
          this.cs(), (this.ns = [{ ds: 0 }]);
        }
        fs(t) {
          this.cs(), (this.ns = [{ ds: 1, Wt: t }]);
        }
        ps(t) {
          this.vs(), this.ns.push({ ds: 5, Wt: t });
        }
        cs() {
          this.vs(), this.ns.push({ ds: 6 });
        }
        ws() {
          this.cs(), (this.ns = [{ ds: 4 }]);
        }
        Ms(t) {
          this.cs(), this.ns.push({ ds: 2, Wt: t });
        }
        gs(t) {
          this.cs(), this.ns.push({ ds: 3, Wt: t });
        }
        bs() {
          return this.ns;
        }
        Ss(t) {
          for (const i of t.ns) this.xs(i);
          (this.ss = Math.max(this.ss, t.ss)),
            t.ts.forEach((t, i) => {
              this.es(i, t);
            });
        }
        static Cs() {
          return new X(2);
        }
        static ys() {
          return new X(3);
        }
        xs(t) {
          switch (t.ds) {
            case 0:
              this.us();
              break;
            case 1:
              this.fs(t.Wt);
              break;
            case 2:
              this.Ms(t.Wt);
              break;
            case 3:
              this.gs(t.Wt);
              break;
            case 4:
              this.ws();
              break;
            case 5:
              this.ps(t.Wt);
              break;
            case 6:
              this.vs();
          }
        }
        vs() {
          const t = this.ns.findIndex((t) => 5 === t.ds);
          -1 !== t && this.ns.splice(t, 1);
        }
      }
      class J {
        formatTickmarks(t) {
          return t.map((t) => this.format(t));
        }
      }
      function tt(t, i) {
        if (!v(t)) return "n/a";
        if (!g(i)) throw new TypeError("invalid length");
        if (i < 0 || i > 16) throw new TypeError("invalid length");
        return 0 === i
          ? t.toString()
          : ("0000000000000000" + t.toString()).slice(-i);
      }
      class it extends J {
        constructor(t, i) {
          if ((super(), i || (i = 1), (v(t) && g(t)) || (t = 100), t < 0))
            throw new TypeError("invalid base");
          (this.Ki = t), (this.ks = i), this.Ps();
        }
        format(t) {
          const i = t < 0 ? "−" : "";
          return (t = Math.abs(t)), i + this.Ts(t);
        }
        Ps() {
          if (((this.Rs = 0), this.Ki > 0 && this.ks > 0)) {
            let t = this.Ki;
            for (; t > 1; ) (t /= 10), this.Rs++;
          }
        }
        Ts(t) {
          const i = this.Ki / this.ks;
          let s = Math.floor(t),
            e = "";
          const h = void 0 !== this.Rs ? this.Rs : NaN;
          if (i > 1) {
            let n = +(Math.round(t * i) - s * i).toFixed(this.Rs);
            n >= i && ((n -= i), (s += 1)),
              (e = "." + tt(+n.toFixed(this.Rs) * this.ks, h));
          } else (s = Math.round(s * i) / i), h > 0 && (e = "." + tt(0, h));
          return s.toFixed(0) + e;
        }
      }
      class st extends it {
        constructor(t = 100) {
          super(t);
        }
        format(t) {
          return `${super.format(t)}%`;
        }
      }
      class et extends J {
        constructor(t) {
          super(), (this.Ds = t);
        }
        format(t) {
          let i = "";
          return (
            t < 0 && ((i = "-"), (t = -t)),
            t < 995
              ? i + this.Is(t)
              : t < 999995
              ? i + this.Is(t / 1e3) + "K"
              : t < 999999995
              ? ((t = 1e3 * Math.round(t / 1e3)), i + this.Is(t / 1e6) + "M")
              : ((t = 1e6 * Math.round(t / 1e6)), i + this.Is(t / 1e9) + "B")
          );
        }
        Is(t) {
          let i;
          const s = Math.pow(10, this.Ds);
          return (
            (i =
              (t = Math.round(t * s) / s) >= 1e-15 && t < 1
                ? t.toFixed(this.Ds).replace(/\.?0+$/, "")
                : String(t)),
            i.replace(/(\.[1-9]*)0+$/, (t, i) => i)
          );
        }
      }
      const ht = /[2-9]/g;
      class nt {
        constructor(t = 50) {
          (this.Vs = 0),
            (this.Bs = 1),
            (this.Es = 1),
            (this.As = {}),
            (this.Ls = new Map()),
            (this.zs = t);
        }
        Os() {
          (this.Vs = 0),
            this.Ls.clear(),
            (this.Bs = 1),
            (this.Es = 1),
            (this.As = {});
        }
        Ii(t, i, s) {
          return this.Ns(t, i, s).width;
        }
        Di(t, i, s) {
          const e = this.Ns(t, i, s);
          return (
            ((e.actualBoundingBoxAscent || 0) -
              (e.actualBoundingBoxDescent || 0)) /
            2
          );
        }
        Ns(t, i, s) {
          const e = s || ht,
            h = String(i).replace(e, "0");
          if (this.Ls.has(h)) return c(this.Ls.get(h)).Fs;
          if (this.Vs === this.zs) {
            const t = this.As[this.Es];
            delete this.As[this.Es], this.Ls.delete(t), this.Es++, this.Vs--;
          }
          t.save(), (t.textBaseline = "middle");
          const n = t.measureText(h);
          return (
            t.restore(),
            (0 === n.width && i.length) ||
              (this.Ls.set(h, { Fs: n, Ws: this.Bs }),
              (this.As[this.Bs] = h),
              this.Vs++,
              this.Bs++),
            n
          );
        }
      }
      class rt {
        constructor(t) {
          (this.Hs = null), (this.M = null), (this.Us = "right"), (this.$s = t);
        }
        js(t, i, s) {
          (this.Hs = t), (this.M = i), (this.Us = s);
        }
        st(t) {
          null !== this.M &&
            null !== this.Hs &&
            this.Hs.st(t, this.M, this.$s, this.Us);
        }
      }
      class ot {
        constructor(t, i, s) {
          (this.qs = t),
            (this.$s = new nt(50)),
            (this.Ys = i),
            (this.O = s),
            (this.F = -1),
            (this.Xt = new rt(this.$s));
        }
        Tt() {
          const t = this.O.Ks(this.Ys);
          if (null === t) return null;
          const i = t.Zs(this.Ys) ? t.Gs() : this.Ys.Ft();
          if (null === i) return null;
          const s = t.Xs(i);
          if ("overlay" === s) return null;
          const e = this.O.Js();
          return (
            e.k !== this.F && ((this.F = e.k), this.$s.Os()),
            this.Xt.js(this.qs.qi(), e, s),
            this.Xt
          );
        }
      }
      class lt extends T {
        constructor() {
          super(...arguments), (this.qt = null);
        }
        ht(t) {
          this.qt = t;
        }
        Qs(t, i) {
          if (!this.qt?.It) return null;
          const { ut: s, ct: e, te: h } = this.qt;
          return i >= s - e - 7 && i <= s + e + 7
            ? {
                ie: this.qt,
                ne: Math.abs(i - s),
                se: 2,
                ee: "price-line",
                te: h,
              }
            : null;
        }
        et({
          context: t,
          bitmapSize: i,
          horizontalPixelRatio: s,
          verticalPixelRatio: e,
        }) {
          if (null === this.qt) return;
          if (!1 === this.qt.It) return;
          const h = Math.round(this.qt.ut * e);
          h < 0 ||
            h > i.height ||
            ((t.lineCap = "butt"),
            (t.strokeStyle = this.qt.R),
            (t.lineWidth = Math.floor(this.qt.ct * s)),
            l(t, this.qt.Zt),
            a(t, h, 0, i.width));
        }
      }
      class at {
        constructor(t) {
          (this.re = { ut: 0, R: "rgba(0, 0, 0, 0)", ct: 1, Zt: 0, It: !1 }),
            (this.he = new lt()),
            (this.xt = !0),
            (this.ae = t),
            (this.le = t.Qt()),
            this.he.ht(this.re);
        }
        kt() {
          this.xt = !0;
        }
        Tt() {
          return this.ae.It()
            ? (this.xt && (this.oe(), (this.xt = !1)), this.he)
            : null;
        }
      }
      class ut extends at {
        constructor(t) {
          super(t);
        }
        oe() {
          this.re.It = !1;
          const t = this.ae.Ft(),
            i = t._e()._e;
          if (2 !== i && 3 !== i) return;
          const s = this.ae.N();
          if (!s.baseLineVisible || !this.ae.It()) return;
          const e = this.ae.Lt();
          null !== e &&
            ((this.re.It = !0),
            (this.re.ut = t.Nt(e.Wt, e.Wt)),
            (this.re.R = s.baseLineColor),
            (this.re.ct = s.baseLineWidth),
            (this.re.Zt = s.baseLineStyle));
        }
      }
      class ct extends T {
        constructor() {
          super(...arguments), (this.qt = null);
        }
        ht(t) {
          this.qt = t;
        }
        ue() {
          return this.qt;
        }
        et({ context: t, horizontalPixelRatio: i, verticalPixelRatio: s }) {
          const e = this.qt;
          if (null === e) return;
          const h = Math.max(1, Math.floor(i)),
            n = (h % 2) / 2,
            r = Math.round(e.ce.x * i) + n,
            o = e.ce.y * s;
          (t.fillStyle = e.de), t.beginPath();
          const l = Math.max(2, 1.5 * e.fe) * i;
          t.arc(r, o, l, 0, 2 * Math.PI, !1),
            t.fill(),
            (t.fillStyle = e.pe),
            t.beginPath(),
            t.arc(r, o, e.ft * i, 0, 2 * Math.PI, !1),
            t.fill(),
            (t.lineWidth = h),
            (t.strokeStyle = e.ve),
            t.beginPath(),
            t.arc(r, o, e.ft * i + h / 2, 0, 2 * Math.PI, !1),
            t.stroke();
        }
      }
      const dt = [
        { me: 0, we: 0.25, Me: 4, ge: 10, be: 0.25, Se: 0, xe: 0.4, Ce: 0.8 },
        { me: 0.25, we: 0.525, Me: 10, ge: 14, be: 0, Se: 0, xe: 0.8, Ce: 0 },
        { me: 0.525, we: 1, Me: 14, ge: 14, be: 0, Se: 0, xe: 0, Ce: 0 },
      ];
      class ft {
        constructor(t) {
          (this.Xt = new ct()),
            (this.xt = !0),
            (this.ye = !0),
            (this.ke = performance.now()),
            (this.Pe = this.ke - 1),
            (this.Te = t);
        }
        Re() {
          (this.Pe = this.ke - 1), this.kt();
        }
        De() {
          if ((this.kt(), 2 === this.Te.N().lastPriceAnimation)) {
            const t = performance.now(),
              i = this.Pe - t;
            if (i > 0) return void (i < 650 && (this.Pe += 2600));
            (this.ke = t), (this.Pe = t + 2600);
          }
        }
        kt() {
          this.xt = !0;
        }
        Ie() {
          this.ye = !0;
        }
        It() {
          return 0 !== this.Te.N().lastPriceAnimation;
        }
        Ve() {
          switch (this.Te.N().lastPriceAnimation) {
            case 0:
              return !1;
            case 1:
              return !0;
            case 2:
              return performance.now() <= this.Pe;
          }
        }
        Tt() {
          return (
            this.xt
              ? (this.Rt(), (this.xt = !1), (this.ye = !1))
              : this.ye && (this.Be(), (this.ye = !1)),
            this.Xt
          );
        }
        Rt() {
          this.Xt.ht(null);
          const t = this.Te.Qt().Et(),
            i = t.Ee(),
            s = this.Te.Lt();
          if (null === i || null === s) return;
          const e = this.Te.Ae(!0);
          if (e.Le || !i.ze(e.$n)) return;
          const h = { x: t.jt(e.$n), y: this.Te.Ft().Nt(e.Mt, s.Wt) },
            n = e.R,
            r = this.Te.N().lineWidth,
            o = this.Oe(this.Ne(), n);
          this.Xt.ht({ de: n, fe: r, pe: o.pe, ve: o.ve, ft: o.ft, ce: h });
        }
        Be() {
          const t = this.Xt.ue();
          if (null !== t) {
            const i = this.Oe(this.Ne(), t.de);
            (t.pe = i.pe), (t.ve = i.ve), (t.ft = i.ft);
          }
        }
        Ne() {
          return this.Ve() ? performance.now() - this.ke : 2599;
        }
        Fe(t, i, s, e) {
          const h = s + (e - s) * i;
          return this.Te.Qt().Xi().Y(t, h);
        }
        Oe(t, i) {
          const s = (t % 2600) / 2600;
          let e;
          for (const t of dt)
            if (s >= t.me && s <= t.we) {
              e = t;
              break;
            }
          u(void 0 !== e, "Last price animation internal logic error");
          const h = (s - e.me) / (e.we - e.me);
          return {
            pe: this.Fe(i, h, e.be, e.Se),
            ve: this.Fe(i, h, e.xe, e.Ce),
            ft: ((n = h), (r = e.Me), (o = e.ge), r + (o - r) * n),
          };
          var n, r, o;
        }
      }
      class mt extends at {
        constructor(t) {
          super(t);
        }
        oe() {
          const t = this.re;
          t.It = !1;
          const i = this.ae.N();
          if (!i.priceLineVisible || !this.ae.It()) return;
          const s = this.ae.Ae(0 === i.priceLineSource);
          s.Le ||
            ((t.It = !0),
            (t.ut = s.Ei),
            (t.R = this.ae.We(s.R)),
            (t.ct = i.priceLineWidth),
            (t.Zt = i.priceLineStyle));
        }
      }
      class pt extends V {
        constructor(t) {
          super(), (this.Jt = t);
        }
        Yi(t, i, s) {
          (t.It = !1), (i.It = !1);
          const e = this.Jt;
          if (!e.It()) return;
          const h = e.N(),
            n = h.lastValueVisible,
            r = "" !== e.He(),
            o = 0 === h.seriesLastValueMode,
            l = e.Ae(!1);
          if (l.Le) return;
          n && ((t.ri = this.Ue(l, n, o)), (t.It = 0 !== t.ri.length)),
            (r || o) &&
              ((i.ri = this.$e(l, n, r, o)), (i.It = i.ri.length > 0));
          const a = e.We(l.R),
            u = this.Jt.Qt().Xi().Z(a);
          (s.G = u.G),
            (s.Ei = l.Ei),
            (i.Ht = e.Qt().Ut(l.Ei / e.Ft().$t())),
            (t.Ht = a),
            (t.R = u.X),
            (i.R = u.X);
        }
        $e(t, i, s, e) {
          let h = "";
          const n = this.Jt.He();
          return (
            s && 0 !== n.length && (h += `${n} `),
            i && e && (h += this.Jt.Ft().je() ? t.qe : t.Ye),
            h.trim()
          );
        }
        Ue(t, i, s) {
          return i ? (s ? (this.Jt.Ft().je() ? t.Ye : t.qe) : t.ri) : "";
        }
      }
      function vt(t, i, s, e) {
        const h = Number.isFinite(i),
          n = Number.isFinite(s);
        return h && n ? t(i, s) : h || n ? (h ? i : s) : e;
      }
      class gt {
        constructor(t, i) {
          (this.Ke = t), (this.Ze = i);
        }
        Ge(t) {
          return null !== t && this.Ke === t.Ke && this.Ze === t.Ze;
        }
        Xe() {
          return new gt(this.Ke, this.Ze);
        }
        Je() {
          return this.Ke;
        }
        Qe() {
          return this.Ze;
        }
        tr() {
          return this.Ze - this.Ke;
        }
        Gi() {
          return (
            this.Ze === this.Ke ||
            Number.isNaN(this.Ze) ||
            Number.isNaN(this.Ke)
          );
        }
        Ss(t) {
          return null === t
            ? this
            : new gt(
                vt(Math.min, this.Je(), t.Je(), -1 / 0),
                vt(Math.max, this.Qe(), t.Qe(), 1 / 0)
              );
        }
        ir(t) {
          if (!v(t)) return;
          if (0 == this.Ze - this.Ke) return;
          const i = 0.5 * (this.Ze + this.Ke);
          let s = this.Ze - i,
            e = this.Ke - i;
          (s *= t), (e *= t), (this.Ze = i + s), (this.Ke = i + e);
        }
        nr(t) {
          v(t) && ((this.Ze += t), (this.Ke += t));
        }
        sr() {
          return { minValue: this.Ke, maxValue: this.Ze };
        }
        static er(t) {
          return null === t ? null : new gt(t.minValue, t.maxValue);
        }
      }
      class bt {
        constructor(t, i) {
          (this.rr = t), (this.hr = i || null);
        }
        ar() {
          return this.rr;
        }
        lr() {
          return this.hr;
        }
        sr() {
          return {
            priceRange: null === this.rr ? null : this.rr.sr(),
            margins: this.hr || void 0,
          };
        }
        static er(t) {
          return null === t ? null : new bt(gt.er(t.priceRange), t.margins);
        }
      }
      const wt = [2, 4, 8, 16, 32, 64, 128, 256, 512];
      class Mt extends at {
        constructor(t, i) {
          super(t), (this._r = i);
        }
        oe() {
          const t = this.re;
          t.It = !1;
          const i = this._r.N();
          if (!this.ae.It() || !i.lineVisible) return;
          const s = this._r.ur();
          null !== s &&
            ((t.It = !0),
            (t.ut = s),
            (t.R = i.color),
            (t.ct = i.lineWidth),
            (t.Zt = i.lineStyle),
            (t.te = this._r.N().id));
        }
      }
      class yt extends V {
        constructor(t, i) {
          super(), (this.Te = t), (this._r = i);
        }
        Yi(t, i, s) {
          (t.It = !1), (i.It = !1);
          const e = this._r.N(),
            h = e.axisLabelVisible,
            n = "" !== e.title,
            r = this.Te;
          if (!h || !r.It()) return;
          const o = this._r.ur();
          if (null === o) return;
          n && ((i.ri = e.title), (i.It = !0)),
            (i.Ht = r.Qt().Ut(o / r.Ft().$t())),
            (t.ri = this.cr(e.price)),
            (t.It = !0);
          const l = this.Te.Qt()
            .Xi()
            .Z(e.axisLabelColor || e.color);
          s.G = l.G;
          const a = e.axisLabelTextColor || l.X;
          (t.R = a), (i.R = a), (s.Ei = o);
        }
        cr(t) {
          const i = this.Te.Lt();
          return null === i ? "" : this.Te.Ft().Ji(t, i.Wt);
        }
      }
      class St {
        constructor(t, i) {
          (this.Te = t),
            (this.yn = i),
            (this.dr = new Mt(t, this)),
            (this.qs = new yt(t, this)),
            (this.pr = new ot(this.qs, t, t.Qt()));
        }
        vr(t) {
          p(this.yn, t), this.kt(), this.Te.Qt().mr();
        }
        N() {
          return this.yn;
        }
        wr() {
          return this.dr;
        }
        Mr() {
          return this.pr;
        }
        gr() {
          return this.qs;
        }
        kt() {
          this.dr.kt(), this.qs.kt();
        }
        ur() {
          const t = this.Te,
            i = t.Ft();
          if (t.Qt().Et().Gi() || i.Gi()) return null;
          const s = t.Lt();
          return null === s ? null : i.Nt(this.yn.price, s.Wt);
        }
      }
      class xt {
        constructor() {
          this.br = new WeakMap();
        }
        Sr(t, i, s) {
          const e = (1 / i) * s;
          if (t >= e) return 1;
          const h = e / t,
            n = Math.pow(2, Math.floor(Math.log2(h)));
          return Math.min(n, 512);
        }
        Cr(t, i, s, e = !1, h) {
          if (0 === t.length || i <= 1) return t;
          const n = this.yr(i);
          if (n <= 1) return t;
          const r = this.kr(t);
          let o = r.Pr.get(n);
          return (
            void 0 !== o ||
              ((o = this.Tr(t, n, s, e, h, r.Pr)), r.Pr.set(n, o)),
            o
          );
        }
        Rr(t, i, s, e, h = !1, n) {
          if (s < 1 || 0 === t.length) return t;
          const r = this.kr(t),
            o = r.Pr.get(s);
          if (!o) return this.Cr(t, s, e, h, n);
          const l = this.Dr(t, i, s, o, h, e, n);
          return r.Pr.set(s, l), l;
        }
        yr(t) {
          if (t <= 2) return 2;
          for (const i of wt) if (t <= i) return i;
          return 512;
        }
        Ir(t) {
          if (0 === t.length) return 0;
          const i = t[0],
            s = t[t.length - 1];
          return 31 * t.length + 17 * i.$n + 13 * s.$n;
        }
        Tr(t, i, s, e = !1, h, n = new Map()) {
          if (2 === i) return this.Vr(t, 2, s, e, h);
          const r = i / 2;
          let o = n.get(r);
          return (
            o || ((o = this.Tr(t, r, s, e, h, n)), n.set(r, o)),
            this.Br(o, s, e, h)
          );
        }
        Vr(t, i, s, e = !1, h) {
          const n = this.Er(t, i, s, e, h);
          return this.Ar(n, e);
        }
        Br(t, i, s = !1, e) {
          const h = this.Er(t, 2, i, s, e);
          return this.Ar(h, s);
        }
        Er(t, i, s, e = !1, h) {
          const n = [];
          for (let r = 0; r < t.length; r += i)
            if (t.length - r >= i) {
              const i = this.Lr(t[r], t[r + 1], s, e, h);
              (i.zr = !1), n.push(i);
            } else if (0 === n.length) n.push(this.Or(t[r], !0));
            else {
              const i = n[n.length - 1];
              n[n.length - 1] = this.Nr(i, t[r], s, e, h);
            }
          return n;
        }
        Fr(t, i) {
          return (t ?? 1) + (i ?? 1);
        }
        Lr(t, i, s, e = !1, h) {
          if (!e || !s || !h) {
            const s = t.Wt[1] > i.Wt[1] ? t.Wt[1] : i.Wt[1],
              e = t.Wt[2] < i.Wt[2] ? t.Wt[2] : i.Wt[2];
            return {
              Wr: t.$n,
              Hr: i.$n,
              Ur: t.wt,
              $r: i.wt,
              jr: t.Wt[0],
              qr: s,
              Yr: e,
              Kr: i.Wt[3],
              Zr: this.Fr(t.Zr, i.Zr),
              Gr: void 0,
              zr: !1,
            };
          }
          const n = s(this.Xr(t, h), this.Xr(i, h)),
            r = h(n),
            o = r.length ? r[r.length - 1] : 0;
          return {
            Wr: t.$n,
            Hr: i.$n,
            Ur: t.wt,
            $r: i.wt,
            jr: t.Wt[0],
            qr: Math.max(t.Wt[1], o),
            Yr: Math.min(t.Wt[2], o),
            Kr: o,
            Zr: this.Fr(t.Zr, i.Zr),
            Gr: n,
            zr: !1,
          };
        }
        Nr(t, i, s, e = !1, h) {
          if (!e || !s || !h)
            return {
              Wr: t.Wr,
              Hr: i.$n,
              Ur: t.Ur,
              $r: i.wt,
              jr: t.jr,
              qr: t.qr > i.Wt[1] ? t.qr : i.Wt[1],
              Yr: t.Yr < i.Wt[2] ? t.Yr : i.Wt[2],
              Kr: i.Wt[3],
              Zr: t.Zr + (i.Zr ?? 1),
              Gr: t.Gr,
              zr: !1,
            };
          const n = t.Gr,
            r = this.Xr(i, h),
            o = n
              ? {
                  data: n,
                  index: t.Wr,
                  originalTime: t.Ur,
                  time: t.Ur,
                  priceValues: h(n),
                }
              : null,
            l = o ? s(o, r) : r.data,
            a = o ? h(l) : r.priceValues,
            u = a.length ? a[a.length - 1] : 0;
          return {
            Wr: t.Wr,
            Hr: i.$n,
            Ur: t.Ur,
            $r: i.wt,
            jr: t.jr,
            qr: Math.max(t.qr, u),
            Yr: Math.min(t.Yr, u),
            Kr: u,
            Zr: t.Zr + (i.Zr ?? 1),
            Gr: l,
            zr: !1,
          };
        }
        Jr(t, i, s, e, h, n, r = !1, o) {
          const l = i === e ? h : t[i];
          if (s - i == 1) return this.Or(l, !0);
          const a = i + 1 === e ? h : t[i + 1];
          let u = this.Lr(l, a, n, r, o);
          for (let l = i + 2; l < s; l++) {
            const i = l === e ? h : t[l];
            u = this.Nr(u, i, n, r, o);
          }
          return u;
        }
        Xr(t, i) {
          const s = t.ue ?? {};
          return {
            data: t.ue,
            index: t.$n,
            originalTime: t.Qr,
            time: t.wt,
            priceValues: i(s),
          };
        }
        th(t, i = !1) {
          const s = !0 === i,
            e = !!t.Gr;
          return {
            $n: t.Wr,
            wt: t.Ur,
            Qr: t.Ur,
            Wt: [s ? t.Kr : t.jr, t.qr, t.Yr, t.Kr],
            Zr: t.Zr,
            ue: s ? (e ? t.Gr : { wt: t.Ur }) : void 0,
          };
        }
        Ar(t, i = !1) {
          return t.map((t) => this.th(t, i));
        }
        Dr(t, i, s, e, h = !1, n, r) {
          if (0 === e.length) return e;
          const o = t.length - 1,
            l = Math.floor(o / s) * s;
          if (Math.min(l + s, t.length) - l < s && t.length > s) {
            const e = t.slice();
            return (e[e.length - 1] = i), this.Cr(e, s, n, h, r);
          }
          if (Math.floor((o - 1) / s) === Math.floor(o / s) || 1 === e.length) {
            const a = Math.min(l + s, t.length),
              u = a - l;
            if (u <= 0) return e;
            const c =
              1 === u
                ? this.Or(l === o ? i : t[l], !0)
                : this.Jr(t, l, a, o, i, n, h, r);
            return (e[e.length - 1] = this.th(c, h)), e;
          }
          {
            const e = t.slice();
            return (e[e.length - 1] = i), this.Cr(e, s, n, h, r);
          }
        }
        Or(t, i = !1) {
          return {
            Wr: t.$n,
            Hr: t.$n,
            Ur: t.wt,
            $r: t.wt,
            jr: t.Wt[0],
            qr: t.Wt[1],
            Yr: t.Wt[2],
            Kr: t.Wt[3],
            Zr: t.Zr ?? 1,
            Gr: t.ue,
            zr: i,
          };
        }
        kr(t) {
          const i = this.ih(t),
            s = this.Ir(t);
          return i.nh !== s && (i.Pr.clear(), (i.nh = s)), i;
        }
        ih(t) {
          let i = this.br.get(t);
          return (
            void 0 === i &&
              ((i = { nh: this.Ir(t), Pr: new Map() }), this.br.set(t, i)),
            i
          );
        }
      }
      class _t extends G {
        constructor(t) {
          super(), (this.sn = t);
        }
        Qt() {
          return this.sn;
        }
      }
      const Ct = {
        Bar: (t, i, s, e) => {
          const h = i.upColor,
            n = i.downColor,
            r = d(t(s, e)),
            o = f(r.Wt[0]) <= f(r.Wt[3]);
          return { sh: r.R ?? (o ? h : n) };
        },
        Candlestick: (t, i, s, e) => {
          const h = i.upColor,
            n = i.downColor,
            r = i.borderUpColor,
            o = i.borderDownColor,
            l = i.wickUpColor,
            a = i.wickDownColor,
            u = d(t(s, e)),
            c = f(u.Wt[0]) <= f(u.Wt[3]);
          return {
            sh: u.R ?? (c ? h : n),
            eh: u.Ht ?? (c ? r : o),
            rh: u.hh ?? (c ? l : a),
          };
        },
        Custom: (t, i, s, e) => ({ sh: d(t(s, e)).R ?? i.color }),
        Area: (t, i, s, e) => {
          const h = d(t(s, e));
          return {
            sh: h.vt ?? i.lineColor,
            vt: h.vt ?? i.lineColor,
            ah: h.ah ?? i.topColor,
            oh: h.oh ?? i.bottomColor,
          };
        },
        Baseline: (t, i, s, e) => {
          const h = d(t(s, e));
          return {
            sh:
              h.Wt[3] >= i.baseValue.price ? i.topLineColor : i.bottomLineColor,
            _h: h._h ?? i.topLineColor,
            uh: h.uh ?? i.bottomLineColor,
            dh: h.dh ?? i.topFillColor1,
            fh: h.fh ?? i.topFillColor2,
            ph: h.ph ?? i.bottomFillColor1,
            mh: h.mh ?? i.bottomFillColor2,
          };
        },
        Line: (t, i, s, e) => {
          const h = d(t(s, e));
          return { sh: h.R ?? i.color, vt: h.R ?? i.color };
        },
        Histogram: (t, i, s, e) => ({ sh: d(t(s, e)).R ?? i.color }),
      };
      class Et {
        constructor(t) {
          (this.wh = (t, i) => (void 0 !== i ? i.Wt : this.Te.Un().Mh(t))),
            (this.Te = t),
            (this.gh = Ct[t.bh()]);
        }
        Sh(t, i) {
          return this.gh(this.wh, this.Te.N(), t, i);
        }
      }
      function zt(t, i, s, e, h = 0, n = i.length) {
        let r = n - h;
        for (; 0 < r; ) {
          const n = r >> 1,
            o = h + n;
          e(i[o], s) === t ? ((h = o + 1), (r -= n + 1)) : (r = n);
        }
        return h;
      }
      const kt = zt.bind(null, !0),
        Nt = zt.bind(null, !1);
      var Tt;
      !(function (t) {
        (t[(t.NearestLeft = -1)] = "NearestLeft"),
          (t[(t.None = 0)] = "None"),
          (t[(t.NearestRight = 1)] = "NearestRight");
      })(Tt || (Tt = {}));
      const Rt = 30;
      class Lt {
        constructor() {
          (this.xh = []),
            (this.Ch = new Map()),
            (this.yh = new Map()),
            (this.kh = []);
        }
        Ph() {
          return this.Th() > 0 ? this.xh[this.xh.length - 1] : null;
        }
        Rh() {
          return this.Th() > 0 ? this.Dh(0) : null;
        }
        Qn() {
          return this.Th() > 0 ? this.Dh(this.xh.length - 1) : null;
        }
        Th() {
          return this.xh.length;
        }
        Gi() {
          return 0 === this.Th();
        }
        ze(t) {
          return null !== this.Ih(t, 0);
        }
        Mh(t) {
          return this.Hn(t);
        }
        Hn(t, i = 0) {
          const s = this.Ih(t, i);
          return null === s ? null : { ...this.Vh(s), $n: this.Dh(s) };
        }
        Bh() {
          return this.xh;
        }
        Eh(t, i, s) {
          if (this.Gi()) return null;
          let e = null;
          for (const h of s) e = Pt(e, this.Ah(t, i, h));
          return e;
        }
        ht(t) {
          this.yh.clear(),
            this.Ch.clear(),
            (this.xh = t),
            (this.kh = t.map((t) => t.$n));
        }
        Lh() {
          return this.kh;
        }
        Dh(t) {
          return this.xh[t].$n;
        }
        Vh(t) {
          return this.xh[t];
        }
        Ih(t, i) {
          const s = this.zh(t);
          if (null === s && 0 !== i)
            switch (i) {
              case -1:
                return this.Oh(t);
              case 1:
                return this.Nh(t);
              default:
                throw new TypeError("Unknown search mode");
            }
          return s;
        }
        Oh(t) {
          let i = this.Fh(t);
          return (
            i > 0 && (i -= 1), i !== this.xh.length && this.Dh(i) < t ? i : null
          );
        }
        Nh(t) {
          const i = this.Wh(t);
          return i !== this.xh.length && t < this.Dh(i) ? i : null;
        }
        zh(t) {
          const i = this.Fh(t);
          return i === this.xh.length || t < this.xh[i].$n ? null : i;
        }
        Fh(t) {
          return kt(this.xh, t, (t, i) => t.$n < i);
        }
        Wh(t) {
          return Nt(this.xh, t, (t, i) => t.$n > i);
        }
        Hh(t, i, s) {
          let e = null;
          for (let h = t; h < i; h++) {
            const t = this.xh[h].Wt[s];
            Number.isNaN(t) ||
              (null === e
                ? (e = { Uh: t, $h: t })
                : (t < e.Uh && (e.Uh = t), t > e.$h && (e.$h = t)));
          }
          return e;
        }
        Ah(t, i, s) {
          if (this.Gi()) return null;
          let e = null;
          const h = d(this.Rh()),
            n = d(this.Qn()),
            r = Math.max(t, h),
            o = Math.min(i, n),
            l = Math.ceil(r / Rt) * Rt,
            a = Math.max(l, Math.floor(o / Rt) * Rt);
          {
            const t = this.Fh(r),
              h = this.Wh(Math.min(o, l, i));
            e = Pt(e, this.Hh(t, h, s));
          }
          let u = this.Ch.get(s);
          void 0 === u && ((u = new Map()), this.Ch.set(s, u));
          for (let t = Math.max(l + 1, r); t < a; t += Rt) {
            const i = Math.floor(t / Rt);
            let h = u.get(i);
            if (void 0 === h) {
              const t = this.Fh(i * Rt),
                e = this.Wh((i + 1) * Rt - 1);
              (h = this.Hh(t, e, s)), u.set(i, h);
            }
            e = Pt(e, h);
          }
          {
            const t = this.Fh(a),
              i = this.Wh(o);
            e = Pt(e, this.Hh(t, i, s));
          }
          return e;
        }
      }
      function Pt(t, i) {
        return null === t
          ? i
          : null === i
          ? t
          : { Uh: Math.min(t.Uh, i.Uh), $h: Math.max(t.$h, i.$h) };
      }
      function It() {
        return new Lt();
      }
      const qt = { setLineStyle: l };
      class Ot {
        constructor(t) {
          this.jh = t;
        }
        st(t, i, s) {
          this.jh.draw(t, qt);
        }
        qh(t, i, s) {
          this.jh.drawBackground?.(t, qt);
        }
      }
      class Ft {
        constructor(t) {
          (this.Ls = null), (this.Yh = t);
        }
        Tt() {
          const t = this.Yh.renderer();
          if (null === t) return null;
          if (this.Ls?.Kh === t) return this.Ls.Zh;
          const i = new Ot(t);
          return (this.Ls = { Kh: t, Zh: i }), i;
        }
        Gh() {
          return this.Yh.zOrder?.() ?? "normal";
        }
      }
      class Wt {
        constructor(t) {
          (this.Xh = null), (this.Jh = t);
        }
        Qh() {
          return this.Jh;
        }
        Nn() {
          this.Jh.updateAllViews?.();
        }
        jn() {
          const t = this.Jh.paneViews?.() ?? [];
          if (this.Xh?.Kh === t) return this.Xh.Zh;
          const i = t.map((t) => new Ft(t));
          return (this.Xh = { Kh: t, Zh: i }), i;
        }
        Qs(t, i) {
          return this.Jh.hitTest?.(t, i) ?? null;
        }
      }
      let Bt = class extends Wt {
        cn() {
          return [];
        }
      };
      class Qt {
        constructor(t) {
          this.jh = t;
        }
        st(t, i, s) {
          this.jh.draw(t, qt);
        }
        qh(t, i, s) {
          this.jh.drawBackground?.(t, qt);
        }
      }
      class Dt {
        constructor(t) {
          (this.Ls = null), (this.Yh = t);
        }
        Tt() {
          const t = this.Yh.renderer();
          if (null === t) return null;
          if (this.Ls?.Kh === t) return this.Ls.Zh;
          const i = new Qt(t);
          return (this.Ls = { Kh: t, Zh: i }), i;
        }
        Gh() {
          return this.Yh.zOrder?.() ?? "normal";
        }
      }
      function Kt(t) {
        return {
          ri: t.text(),
          Ei: t.coordinate(),
          Vi: t.fixedCoordinate?.(),
          R: t.textColor(),
          G: t.backColor(),
          It: t.visible?.() ?? !0,
          pi: t.tickVisible?.() ?? !0,
        };
      }
      class Vt {
        constructor(t, i) {
          (this.Xt = new Z()), (this.ta = t), (this.ia = i);
        }
        Tt() {
          return this.Xt.ht({ nn: this.ia.nn(), ...Kt(this.ta) }), this.Xt;
        }
      }
      class $t extends V {
        constructor(t, i) {
          super(), (this.ta = t), (this.Ki = i);
        }
        Yi(t, i, s) {
          const e = Kt(this.ta);
          (s.G = e.G), (t.R = e.R);
          const h = (2 / 12) * this.Ki.k();
          (s.Ti = h),
            (s.Ri = h),
            (s.Ei = e.Ei),
            (s.Vi = e.Vi),
            (t.ri = e.ri),
            (t.It = e.It),
            (t.pi = e.pi);
        }
      }
      class At extends Wt {
        constructor(t, i) {
          super(t),
            (this.na = null),
            (this.sa = null),
            (this.ea = null),
            (this.ra = null),
            (this.Te = i);
        }
        dn() {
          const t = this.Jh.timeAxisViews?.() ?? [];
          if (this.na?.Kh === t) return this.na.Zh;
          const i = this.Te.Qt().Et(),
            s = t.map((t) => new Vt(t, i));
          return (this.na = { Kh: t, Zh: s }), s;
        }
        qn() {
          const t = this.Jh.priceAxisViews?.() ?? [];
          if (this.sa?.Kh === t) return this.sa.Zh;
          const i = this.Te.Ft(),
            s = t.map((t) => new $t(t, i));
          return (this.sa = { Kh: t, Zh: s }), s;
        }
        ha() {
          const t = this.Jh.priceAxisPaneViews?.() ?? [];
          if (this.ea?.Kh === t) return this.ea.Zh;
          const i = t.map((t) => new Dt(t));
          return (this.ea = { Kh: t, Zh: i }), i;
        }
        aa() {
          const t = this.Jh.timeAxisPaneViews?.() ?? [];
          if (this.ra?.Kh === t) return this.ra.Zh;
          const i = t.map((t) => new Dt(t));
          return (this.ra = { Kh: t, Zh: i }), i;
        }
        la(t, i) {
          return this.Jh.autoscaleInfo?.(t, i) ?? null;
        }
      }
      function Zt(t, i, s, e) {
        t.forEach((t) => {
          i(t).forEach((t) => {
            t.Gh() === s && e.push(t);
          });
        });
      }
      function Ht(t) {
        return t.jn();
      }
      function Gt(t) {
        return t.ha();
      }
      function Yt(t) {
        return t.aa();
      }
      const Ut = ["Area", "Line", "Baseline"];
      class jt extends _t {
        constructor(t, i, s, e, h) {
          super(t),
            (this.qt = It()),
            (this.dr = new mt(this)),
            (this.oa = []),
            (this._a = new ut(this)),
            (this.ua = null),
            (this.ca = null),
            (this.da = null),
            (this.fa = []),
            (this.pa = new xt()),
            (this.va = new Map()),
            (this.ma = null),
            (this.yn = s),
            (this.wa = i);
          const n = new pt(this);
          if (
            ((this.mn = [n]),
            (this.pr = new ot(n, this, t)),
            Ut.includes(this.wa) && (this.ua = new ft(this)),
            this.Ma(),
            (this.Yh = e(this, this.Qt(), h)),
            "Custom" === this.wa)
          ) {
            const t = this.Yh;
            t.ga && this.ba(t.ga);
          }
        }
        m() {
          null !== this.da && clearTimeout(this.da);
        }
        We(t) {
          return this.yn.priceLineColor || t;
        }
        Ae(t) {
          const i = { Le: !0 },
            s = this.Ft();
          if (this.Qt().Et().Gi() || s.Gi() || this.qt.Gi()) return i;
          const e = this.Qt().Et().Ee(),
            h = this.Lt();
          if (null === e || null === h) return i;
          let n, r;
          if (t) {
            const t = this.qt.Ph();
            if (null === t) return i;
            (n = t), (r = t.$n);
          } else {
            const t = this.qt.Hn(e.bi(), -1);
            if (null === t) return i;
            if (((n = this.qt.Mh(t.$n)), null === n)) return i;
            r = t.$n;
          }
          const o = n.Wt[3],
            l = this.Sa().Sh(r, { Wt: n }),
            a = s.Nt(o, h.Wt);
          return {
            Le: !1,
            Mt: o,
            ri: s.Ji(o, h.Wt),
            qe: s.xa(o),
            Ye: s.Ca(o, h.Wt),
            R: l.sh,
            Ei: a,
            $n: r,
          };
        }
        Sa() {
          return null !== this.ca || (this.ca = new Et(this)), this.ca;
        }
        N() {
          return this.yn;
        }
        vr(t) {
          const i = this.Qt(),
            { priceScaleId: s, visible: e, priceFormat: h } = t;
          void 0 !== s && s !== this.yn.priceScaleId && i.ya(this, s),
            void 0 !== e && e !== this.yn.visible && i.ka();
          const n = void 0 !== t.conflationThresholdFactor;
          p(this.yn, t),
            n && (this.va.clear(), this.Qt().mr()),
            void 0 !== h && (this.Ma(), i.Pa()),
            i.Ta(this),
            i.Ra(),
            this.Yh.kt("options");
        }
        ht(t, i) {
          this.qt.ht(t), this.va.clear();
          const s = this.Qt().Et().N();
          s.enableConflation &&
            s.precomputeConflationOnInit &&
            this.Da(s.precomputeConflationPriority),
            this.Yh.kt("data"),
            null !== this.ua &&
              (i && i.Ia ? this.ua.De() : 0 === t.length && this.ua.Re());
          const e = this.Qt().Ks(this);
          this.Qt().Va(e), this.Qt().Ta(this), this.Qt().Ra(), this.Qt().mr();
        }
        Ba(t) {
          const i = new St(this, t);
          return this.oa.push(i), this.Qt().Ta(this), i;
        }
        Ea(t) {
          const i = this.oa.indexOf(t);
          -1 !== i && this.oa.splice(i, 1), this.Qt().Ta(this);
        }
        Aa() {
          return this.oa;
        }
        bh() {
          return this.wa;
        }
        Lt() {
          const t = this.La();
          return null === t ? null : { Wt: t.Wt[3], za: t.wt };
        }
        La() {
          const t = this.Qt().Et().Ee();
          if (null === t) return null;
          const i = t.Oa();
          return this.qt.Hn(i, 1);
        }
        Un() {
          return this.qt;
        }
        ba(t) {
          (this.ma = t), this.va.clear();
        }
        Na() {
          return !!this.Qt().Et().N().enableConflation && this.Fa() > 1;
        }
        Rr(t) {
          if (!this.Na()) return;
          const i = this.Fa();
          if (!this.va.has(i)) return;
          const s = "Custom" === this.wa,
            e = (s && this.ma) || void 0,
            h =
              s && this.Yh.Wa
                ? (t) => {
                    const i = t,
                      s = this.Yh.Wa(i);
                    return Array.isArray(s)
                      ? s
                      : ["number" == typeof s ? s : 0];
                  }
                : void 0,
            n = this.pa.Rr(this.qt.Bh(), t, i, e, s, h),
            r = It();
          r.ht(n), this.va.set(i, r);
        }
        Ha() {
          const t = this.Qt().Et().N().enableConflation;
          if ("Custom" === this.wa && null === this.ma) return this.qt;
          if (!t) return this.qt;
          const i = this.Fa(),
            s = this.va.get(i);
          return s || (this.Ua(i), this.va.get(i) ?? this.qt);
        }
        $a(t) {
          const i = this.qt.Mh(t);
          return null === i
            ? null
            : "Bar" === this.wa ||
              "Candlestick" === this.wa ||
              "Custom" === this.wa
            ? { jr: i.Wt[0], qr: i.Wt[1], Yr: i.Wt[2], Kr: i.Wt[3] }
            : i.Wt[3];
        }
        ja(t) {
          const i = [];
          Zt(this.fa, Ht, "top", i);
          const s = this.ua;
          return null !== s && s.It()
            ? (null === this.da &&
                s.Ve() &&
                (this.da = setTimeout(() => {
                  (this.da = null), this.Qt().qa();
                }, 0)),
              s.Ie(),
              i.unshift(s),
              i)
            : i;
        }
        jn() {
          const t = [];
          this.Ya() || t.push(this._a), t.push(this.Yh, this.dr);
          const i = this.oa.map((t) => t.wr());
          return t.push(...i), Zt(this.fa, Ht, "normal", t), t;
        }
        Ka() {
          return this.Za(Ht, "bottom");
        }
        Ga(t) {
          return this.Za(Gt, t);
        }
        Xa(t) {
          return this.Za(Yt, t);
        }
        Ja(t, i) {
          return this.fa.map((s) => s.Qs(t, i)).filter((t) => null !== t);
        }
        cn() {
          return [this.pr, ...this.oa.map((t) => t.Mr())];
        }
        qn(t, i) {
          if (i !== this.hn && !this.Ya()) return [];
          const s = [...this.mn];
          for (const t of this.oa) s.push(t.gr());
          return (
            this.fa.forEach((t) => {
              s.push(...t.qn());
            }),
            s
          );
        }
        dn() {
          const t = [];
          return (
            this.fa.forEach((i) => {
              t.push(...i.dn());
            }),
            t
          );
        }
        la(t, i) {
          if (void 0 !== this.yn.autoscaleInfoProvider) {
            const s = this.yn.autoscaleInfoProvider(() => {
              const s = this.Qa(t, i);
              return null === s ? null : s.sr();
            });
            return bt.er(s);
          }
          return this.Qa(t, i);
        }
        Kh() {
          const t = this.yn.priceFormat;
          return t.base ?? 1 / t.minMove;
        }
        tl() {
          return this.il;
        }
        Nn() {
          this.Yh.kt();
          for (const t of this.mn) t.kt();
          for (const t of this.oa) t.kt();
          this.dr.kt(),
            this._a.kt(),
            this.ua?.kt(),
            this.fa.forEach((t) => t.Nn());
        }
        Ft() {
          return d(super.Ft());
        }
        At(t) {
          if (
            ("Line" !== this.wa &&
              "Area" !== this.wa &&
              "Baseline" !== this.wa) ||
            !this.yn.crosshairMarkerVisible
          )
            return null;
          const i = this.qt.Mh(t);
          return null === i
            ? null
            : {
                Mt: i.Wt[3],
                ft: this.nl(),
                Ht: this.sl(),
                Ot: this.el(),
                zt: this.rl(t),
              };
        }
        He() {
          return this.yn.title;
        }
        It() {
          return this.yn.visible;
        }
        hl(t) {
          this.fa.push(new At(t, this));
        }
        al(t) {
          this.fa = this.fa.filter((i) => i.Qh() !== t);
        }
        ll() {
          if ("Custom" === this.wa) return (t) => this.Yh.Wa(t);
        }
        ol() {
          if ("Custom" === this.wa) return (t) => this.Yh._l(t);
        }
        ul() {
          return this.qt.Lh();
        }
        Ya() {
          return !j(this.Ft().cl());
        }
        Qa(t, i) {
          if (!g(t) || !g(i) || this.qt.Gi()) return null;
          const s =
              "Line" === this.wa ||
              "Area" === this.wa ||
              "Baseline" === this.wa ||
              "Histogram" === this.wa
                ? [3]
                : [2, 1],
            e = this.qt.Eh(t, i, s);
          let h = null !== e ? new gt(e.Uh, e.$h) : null,
            n = null;
          if ("Histogram" === this.bh()) {
            const t = this.yn.base,
              i = new gt(t, t);
            h = null !== h ? h.Ss(i) : i;
          }
          return (
            this.fa.forEach((s) => {
              const e = s.la(t, i);
              if (e?.priceRange) {
                const t = new gt(e.priceRange.minValue, e.priceRange.maxValue);
                h = null !== h ? h.Ss(t) : t;
              }
              e?.margins && (n = e.margins);
            }),
            new bt(h, n)
          );
        }
        nl() {
          switch (this.wa) {
            case "Line":
            case "Area":
            case "Baseline":
              return this.yn.crosshairMarkerRadius;
          }
          return 0;
        }
        sl() {
          switch (this.wa) {
            case "Line":
            case "Area":
            case "Baseline": {
              const t = this.yn.crosshairMarkerBorderColor;
              if (0 !== t.length) return t;
            }
          }
          return null;
        }
        el() {
          switch (this.wa) {
            case "Line":
            case "Area":
            case "Baseline":
              return this.yn.crosshairMarkerBorderWidth;
          }
          return 0;
        }
        rl(t) {
          switch (this.wa) {
            case "Line":
            case "Area":
            case "Baseline": {
              const t = this.yn.crosshairMarkerBackgroundColor;
              if (0 !== t.length) return t;
            }
          }
          return this.Sa().Sh(t).sh;
        }
        Ma() {
          switch (this.yn.priceFormat.type) {
            case "custom": {
              const t = this.yn.priceFormat.formatter;
              this.il = {
                format: t,
                formatTickmarks:
                  this.yn.priceFormat.tickmarksFormatter ?? ((i) => i.map(t)),
              };
              break;
            }
            case "volume":
              this.il = new et(this.yn.priceFormat.precision);
              break;
            case "percent":
              this.il = new st(this.yn.priceFormat.precision);
              break;
            default: {
              const t = Math.pow(10, this.yn.priceFormat.precision);
              this.il = new it(t, this.yn.priceFormat.minMove * t);
            }
          }
          null !== this.hn && this.hn.dl();
        }
        Za(t, i) {
          const s = [];
          return Zt(this.fa, t, i, s), s;
        }
        Fa() {
          const { fl: t, pl: i, vl: s } = this.ml();
          return this.pa.Sr(t, i, s);
        }
        ml() {
          const t = this.Qt().Et(),
            i = t.fl(),
            s = window.devicePixelRatio || 1,
            e = t.N().conflationThresholdFactor;
          return {
            fl: i,
            pl: s,
            vl: this.yn.conflationThresholdFactor ?? e ?? 1,
          };
        }
        wl(t) {
          const i = this.qt.Bh();
          let s;
          if ("Custom" === this.wa && null !== this.ma) {
            const e = this.ll();
            if (!e)
              throw new Error(
                "Custom series with conflation reducer must have a priceValueBuilder method"
              );
            s = this.pa.Cr(i, t, this.ma, !0, (t) => e(t));
          } else s = this.pa.Cr(i, t);
          const e = It();
          return e.ht(s), e;
        }
        Ua(t) {
          const i = this.wl(t);
          this.va.set(t, i);
        }
        Da(t) {
          if ("Custom" === this.wa && (null === this.ma || !this.ll())) return;
          this.va.clear();
          const i = this.Qt().Et().Ml();
          for (const s of i) {
            const i = () => {
                this.gl(s);
              },
              e =
                ("object" == typeof window && window) ||
                ("object" == typeof self && self);
            e?.Sl?.bl
              ? e.Sl.bl(
                  () => {
                    i();
                  },
                  { se: t }
                )
              : Promise.resolve().then(() => i());
          }
        }
        gl(t) {
          if (this.va.has(t)) return;
          if (0 === this.qt.Bh().length) return;
          const i = this.wl(t);
          this.va.set(t, i);
        }
      }
      const Xt = [3],
        Jt = [0, 1, 2, 3];
      class ti {
        constructor(t) {
          this.yn = t;
        }
        xl(t, i, s) {
          let e = t;
          if (0 === this.yn.mode) return e;
          const h = s.Pn(),
            n = h.Lt();
          if (null === n) return e;
          const r = h.Nt(t, n),
            o = s
              .Cl()
              .filter((t) => t instanceof jt)
              .reduce((t, e) => {
                if (s.Zs(e) || !e.It()) return t;
                const h = e.Ft(),
                  n = e.Un();
                if (h.Gi() || !n.ze(i)) return t;
                const r = n.Mh(i);
                if (null === r) return t;
                const o = f(e.Lt()),
                  l = 3 === this.yn.mode ? Jt : Xt;
                return t.concat(l.map((t) => h.Nt(r.Wt[t], o.Wt)));
              }, []);
          if (0 === o.length) return e;
          o.sort((t, i) => Math.abs(t - r) - Math.abs(i - r));
          const l = o[0];
          return (e = h.Tn(l, n)), e;
        }
      }
      function ii(t, i, s) {
        return Math.min(Math.max(t, i), s);
      }
      function si(t, i, s) {
        return i - t <= s;
      }
      class ei extends T {
        constructor() {
          super(...arguments), (this.qt = null);
        }
        ht(t) {
          this.qt = t;
        }
        et({
          context: t,
          bitmapSize: i,
          horizontalPixelRatio: s,
          verticalPixelRatio: e,
        }) {
          if (null === this.qt) return;
          const h = Math.max(1, Math.floor(s));
          (t.lineWidth = h),
            (function (t, i) {
              t.save(),
                t.lineWidth % 2 && t.translate(0.5, 0.5),
                i(),
                t.restore();
            })(t, () => {
              const n = d(this.qt);
              if (n.yl) {
                (t.strokeStyle = n.kl), l(t, n.Pl), t.beginPath();
                for (const e of n.Tl) {
                  const n = Math.round(e.Rl * s);
                  t.moveTo(n, -h), t.lineTo(n, i.height + h);
                }
                t.stroke();
              }
              if (n.Dl) {
                (t.strokeStyle = n.Il), l(t, n.Vl), t.beginPath();
                for (const s of n.Bl) {
                  const n = Math.round(s.Rl * e);
                  t.moveTo(-h, n), t.lineTo(i.width + h, n);
                }
                t.stroke();
              }
            });
        }
      }
      class hi {
        constructor(t) {
          (this.Xt = new ei()), (this.xt = !0), (this.yt = t);
        }
        kt() {
          this.xt = !0;
        }
        Tt() {
          if (this.xt) {
            const t = this.yt.Qt().N().grid,
              i = {
                Dl: t.horzLines.visible,
                yl: t.vertLines.visible,
                Il: t.horzLines.color,
                kl: t.vertLines.color,
                Vl: t.horzLines.style,
                Pl: t.vertLines.style,
                Bl: this.yt.Pn().El(),
                Tl: (this.yt.Qt().Et().El() || []).map((t) => ({
                  Rl: t.coord,
                })),
              };
            this.Xt.ht(i), (this.xt = !1);
          }
          return this.Xt;
        }
      }
      class ni {
        constructor(t) {
          this.Yh = new hi(t);
        }
        wr() {
          return this.Yh;
        }
      }
      const ri = { Al: 4, Ll: 1e-4 };
      function oi(t, i) {
        const s = (100 * (t - i)) / i;
        return i < 0 ? -s : s;
      }
      function li(t, i) {
        const s = oi(t.Je(), i),
          e = oi(t.Qe(), i);
        return new gt(s, e);
      }
      function ai(t, i) {
        const s = (100 * (t - i)) / i + 100;
        return i < 0 ? -s : s;
      }
      function ui(t, i) {
        const s = ai(t.Je(), i),
          e = ai(t.Qe(), i);
        return new gt(s, e);
      }
      function ci(t, i) {
        const s = Math.abs(t);
        if (s < 1e-15) return 0;
        const e = Math.log10(s + i.Ll) + i.Al;
        return t < 0 ? -e : e;
      }
      function di(t, i) {
        const s = Math.abs(t);
        if (s < 1e-15) return 0;
        const e = Math.pow(10, s - i.Al) - i.Ll;
        return t < 0 ? -e : e;
      }
      function fi(t, i) {
        if (null === t) return null;
        const s = ci(t.Je(), i),
          e = ci(t.Qe(), i);
        return new gt(s, e);
      }
      function mi(t, i) {
        if (null === t) return null;
        const s = di(t.Je(), i),
          e = di(t.Qe(), i);
        return new gt(s, e);
      }
      function pi(t) {
        if (null === t) return ri;
        const i = Math.abs(t.Qe() - t.Je());
        if (i >= 1 || i < 1e-15) return ri;
        const s = Math.ceil(Math.abs(Math.log10(i))),
          e = ri.Al + s;
        return { Al: e, Ll: 1 / Math.pow(10, e) };
      }
      class vi {
        constructor(t, i) {
          if (
            ((this.zl = t),
            (this.Ol = i),
            (function (t) {
              if (t < 0) return !1;
              if (t > 1e18) return !0;
              for (let i = t; i > 1; i /= 10) if (i % 10 != 0) return !1;
              return !0;
            })(this.zl))
          )
            this.Nl = [2, 2.5, 2];
          else {
            this.Nl = [];
            for (let t = this.zl; 1 !== t; ) {
              if (t % 2 == 0) this.Nl.push(2), (t /= 2);
              else {
                if (t % 5 != 0) throw new Error("unexpected base");
                this.Nl.push(2, 2.5), (t /= 5);
              }
              if (this.Nl.length > 100)
                throw new Error("something wrong with base");
            }
          }
        }
        Fl(t, i, s) {
          const e = 0 === this.zl ? 0 : 1 / this.zl;
          let h = Math.pow(10, Math.max(0, Math.ceil(Math.log10(t - i)))),
            n = 0,
            r = this.Ol[0];
          for (;;) {
            const t = si(h, e, 1e-14) && h > e + 1e-14,
              i = si(h, s * r, 1e-14),
              o = si(h, 1, 1e-14);
            if (!(t && i && o)) break;
            (h /= r), (r = this.Ol[++n % this.Ol.length]);
          }
          if (
            (h <= e + 1e-14 && (h = e),
            (h = Math.max(1, h)),
            this.Nl.length > 0 && ((o = h), Math.abs(o - 1) < 1e-14))
          )
            for (n = 0, r = this.Nl[0]; si(h, s * r, 1e-14) && h > e + 1e-14; )
              (h /= r), (r = this.Nl[++n % this.Nl.length]);
          var o;
          return h;
        }
      }
      class gi {
        constructor(t, i, s, e) {
          (this.Wl = []),
            (this.Ki = t),
            (this.zl = i),
            (this.Hl = s),
            (this.Ul = e);
        }
        Fl(t, i) {
          if (t < i) throw new Error("high < low");
          const s = this.Ki.$t(),
            e = ((t - i) * this.$l()) / s,
            h = new vi(this.zl, [2, 2.5, 2]),
            n = new vi(this.zl, [2, 2, 2.5]),
            r = new vi(this.zl, [2.5, 2, 2]),
            o = [];
          return (
            o.push(h.Fl(t, i, e), n.Fl(t, i, e), r.Fl(t, i, e)),
            (function (t) {
              if (t.length < 1) throw Error("array is empty");
              let i = t[0];
              for (let s = 1; s < t.length; ++s) t[s] < i && (i = t[s]);
              return i;
            })(o)
          );
        }
        jl() {
          const t = this.Ki,
            i = t.Lt();
          if (null === i) return void (this.Wl = []);
          const s = t.$t(),
            e = this.Hl(s - 1, i),
            h = this.Hl(0, i),
            n = this.Ki.N().entireTextOnly ? this.ql() / 2 : 0,
            r = n,
            o = s - 1 - n,
            l = Math.max(e, h),
            a = Math.min(e, h);
          if (l === a) return void (this.Wl = []);
          const u = this.Fl(l, a);
          if ((this.Yl(i, u, l, a, r, o), t.Kl() && this.Zl(u, a, l))) {
            const t = this.Ki.Gl();
            this.Xl(i, u, r, o, t, 2 * t);
          }
          const c = this.Wl.map((t) => t.Jl),
            d = this.Ki.Ql(c);
          for (let t = 0; t < this.Wl.length; t++) this.Wl[t].io = d[t];
        }
        El() {
          return this.Wl;
        }
        ql() {
          return this.Ki.k();
        }
        $l() {
          return Math.ceil(this.ql() * this.Ki.N().tickMarkDensity);
        }
        Yl(t, i, s, e, h, n) {
          const r = this.Wl,
            o = this.Ki;
          let l = s % i;
          l += l < 0 ? i : 0;
          const a = s >= e ? 1 : -1;
          let u = null,
            c = 0;
          for (let d = s - l; d > e; d -= i) {
            const s = this.Ul(d, t, !0);
            (null !== u && Math.abs(s - u) < this.$l()) ||
              s < h ||
              s > n ||
              (c < r.length
                ? ((r[c].Rl = s), (r[c].io = o.no(d)), (r[c].Jl = d))
                : r.push({ Rl: s, io: o.no(d), Jl: d }),
              c++,
              (u = s),
              o.so() && (i = this.Fl(d * a, e)));
          }
          r.length = c;
        }
        Xl(t, i, s, e, h, n) {
          const r = this.Wl,
            o = this.eo(t, s, h, n),
            l = this.eo(t, e, -n, -h),
            a = this.Ul(0, t, !0) - this.Ul(i, t, !0);
          r.length > 0 && r[0].Rl - o.Rl < a / 2 && r.shift(),
            r.length > 0 && l.Rl - r[r.length - 1].Rl < a / 2 && r.pop(),
            r.unshift(o),
            r.push(l);
        }
        eo(t, i, s, e) {
          const h = (s + e) / 2,
            n = this.Hl(i + s, t),
            r = this.Hl(i + e, t),
            o = Math.min(n, r),
            l = Math.max(n, r),
            a = Math.max(0.1, this.Fl(l, o)),
            u = this.Hl(i + h, t),
            c = u - (u % a),
            d = this.Ul(c, t, !0);
          return { io: this.Ki.no(c), Rl: d, Jl: c };
        }
        Zl(t, i, s) {
          let e = f(this.Ki.ar());
          return (
            this.Ki.so() && (e = mi(e, this.Ki.ro())),
            e.Je() - i < t && s - e.Qe() < t
          );
        }
      }
      function bi(t) {
        return t.slice().sort((t, i) => d(t.ln()) - d(i.ln()));
      }
      var wi;
      !(function (t) {
        (t[(t.Normal = 0)] = "Normal"),
          (t[(t.Logarithmic = 1)] = "Logarithmic"),
          (t[(t.Percentage = 2)] = "Percentage"),
          (t[(t.IndexedTo100 = 3)] = "IndexedTo100");
      })(wi || (wi = {}));
      const Mi = new st(),
        yi = new it(100, 1);
      class Si {
        constructor(t, i, s, e, h) {
          (this.ho = 0),
            (this.ao = null),
            (this.rr = null),
            (this.lo = null),
            (this.oo = { _o: !1, uo: null }),
            (this.co = !1),
            (this.do = 0),
            (this.fo = 0),
            (this.po = new m()),
            (this.vo = new m()),
            (this.mo = []),
            (this.wo = null),
            (this.Mo = null),
            (this.bo = null),
            (this.So = null),
            (this.xo = null),
            (this.il = yi),
            (this.Co = pi(null)),
            (this.yo = t),
            (this.yn = i),
            (this.ko = s),
            (this.Po = e),
            (this.To = h),
            (this.Ro = new gi(
              this,
              100,
              this.Do.bind(this),
              this.Io.bind(this)
            ));
        }
        cl() {
          return this.yo;
        }
        N() {
          return this.yn;
        }
        vr(t) {
          if (
            (p(this.yn, t),
            this.dl(),
            void 0 !== t.mode && this.Vo({ _e: t.mode }),
            void 0 !== t.scaleMargins)
          ) {
            const i = c(t.scaleMargins.top),
              s = c(t.scaleMargins.bottom);
            if (i < 0 || i > 1)
              throw new Error(
                `Invalid top margin - expect value between 0 and 1, given=${i}`
              );
            if (s < 0 || s > 1)
              throw new Error(
                `Invalid bottom margin - expect value between 0 and 1, given=${s}`
              );
            if (i + s > 1)
              throw new Error(
                `Invalid margins - sum of margins must be less than 1, given=${
                  i + s
                }`
              );
            this.Bo(), (this.bo = null);
          }
        }
        Eo() {
          return this.yn.autoScale;
        }
        Ao() {
          return this.co;
        }
        so() {
          return 1 === this.yn.mode;
        }
        je() {
          return 2 === this.yn.mode;
        }
        Lo() {
          return 3 === this.yn.mode;
        }
        ro() {
          return this.Co;
        }
        _e() {
          return {
            hs: this.yn.autoScale,
            zo: this.yn.invertScale,
            _e: this.yn.mode,
          };
        }
        Vo(t) {
          const i = this._e();
          let s = null;
          void 0 !== t.hs && (this.yn.autoScale = t.hs),
            void 0 !== t._e &&
              ((this.yn.mode = t._e),
              (2 !== t._e && 3 !== t._e) || (this.yn.autoScale = !0),
              (this.oo._o = !1)),
            1 === i._e &&
              t._e !== i._e &&
              ((function (t, i) {
                if (null === t) return !1;
                const s = di(t.Je(), i),
                  e = di(t.Qe(), i);
                return isFinite(s) && isFinite(e);
              })(this.rr, this.Co)
                ? ((s = mi(this.rr, this.Co)), null !== s && this.Oo(s))
                : (this.yn.autoScale = !0)),
            1 === t._e &&
              t._e !== i._e &&
              ((s = fi(this.rr, this.Co)), null !== s && this.Oo(s));
          const e = i._e !== this.yn.mode;
          e && (2 === i._e || this.je()) && this.dl(),
            e && (3 === i._e || this.Lo()) && this.dl(),
            void 0 !== t.zo &&
              i.zo !== t.zo &&
              ((this.yn.invertScale = t.zo), this.No()),
            this.vo.p(i, this._e());
        }
        Fo() {
          return this.vo;
        }
        k() {
          return this.ko.fontSize;
        }
        $t() {
          return this.ho;
        }
        Wo(t) {
          this.ho !== t && ((this.ho = t), this.Bo(), (this.bo = null));
        }
        Ho() {
          if (this.ao) return this.ao;
          const t = this.$t() - this.Uo() - this.$o();
          return (this.ao = t), t;
        }
        ar() {
          return this.jo(), this.rr;
        }
        Oo(t, i) {
          const s = this.rr;
          (i || (null === s && null !== t) || (null !== s && !s.Ge(t))) &&
            ((this.bo = null), (this.rr = t));
        }
        qo(t) {
          this.Oo(t), this.Yo(null !== t);
        }
        Gi() {
          return this.jo(), 0 === this.ho || !this.rr || this.rr.Gi();
        }
        Ko(t) {
          return this.zo() ? t : this.$t() - 1 - t;
        }
        Nt(t, i) {
          return (
            this.je() ? (t = oi(t, i)) : this.Lo() && (t = ai(t, i)),
            this.Io(t, i)
          );
        }
        Zo(t, i, s) {
          this.jo();
          const e = this.$o(),
            h = d(this.ar()),
            n = h.Je(),
            r = h.Qe(),
            o = this.Ho() - 1,
            l = this.zo(),
            a = o / (r - n),
            u = void 0 === s ? 0 : s.from,
            c = void 0 === s ? t.length : s.to,
            f = this.Go();
          for (let s = u; s < c; s++) {
            const h = t[s],
              r = h.Mt;
            if (isNaN(r)) continue;
            let o = r;
            null !== f && (o = f(h.Mt, i));
            const u = e + a * (o - n),
              c = l ? u : this.ho - 1 - u;
            h.ut = c;
          }
        }
        Xo(t, i, s) {
          this.jo();
          const e = this.$o(),
            h = d(this.ar()),
            n = h.Je(),
            r = h.Qe(),
            o = this.Ho() - 1,
            l = this.zo(),
            a = o / (r - n),
            u = void 0 === s ? 0 : s.from,
            c = void 0 === s ? t.length : s.to,
            f = this.Go();
          for (let s = u; s < c; s++) {
            const h = t[s];
            let r = h.jr,
              o = h.qr,
              u = h.Yr,
              c = h.Kr;
            null !== f &&
              ((r = f(h.jr, i)),
              (o = f(h.qr, i)),
              (u = f(h.Yr, i)),
              (c = f(h.Kr, i)));
            let d = e + a * (r - n),
              m = l ? d : this.ho - 1 - d;
            (h.Jo = m),
              (d = e + a * (o - n)),
              (m = l ? d : this.ho - 1 - d),
              (h.Qo = m),
              (d = e + a * (u - n)),
              (m = l ? d : this.ho - 1 - d),
              (h.t_ = m),
              (d = e + a * (c - n)),
              (m = l ? d : this.ho - 1 - d),
              (h.i_ = m);
          }
        }
        Tn(t, i) {
          const s = this.Do(t, i);
          return this.n_(s, i);
        }
        n_(t, i) {
          let s = t;
          return (
            this.je()
              ? (s = (function (t, i) {
                  return i < 0 && (t = -t), (t / 100) * i + i;
                })(s, i))
              : this.Lo() &&
                (s = (function (t, i) {
                  return (t -= 100), i < 0 && (t = -t), (t / 100) * i + i;
                })(s, i)),
            s
          );
        }
        Cl() {
          return this.mo;
        }
        Dt() {
          return this.Mo || (this.Mo = bi(this.mo)), this.Mo;
        }
        s_(t) {
          -1 === this.mo.indexOf(t) && (this.mo.push(t), this.dl(), this.e_());
        }
        r_(t) {
          const i = this.mo.indexOf(t);
          if (-1 === i) throw new Error("source is not attached to scale");
          this.mo.splice(i, 1),
            0 === this.mo.length && (this.Vo({ hs: !0 }), this.Oo(null)),
            this.dl(),
            this.e_();
        }
        Lt() {
          let t = null;
          for (const i of this.mo) {
            const s = i.Lt();
            null !== s && (null === t || s.za < t.za) && (t = s);
          }
          return null === t ? null : t.Wt;
        }
        zo() {
          return this.yn.invertScale;
        }
        El() {
          const t = null === this.Lt();
          if (null !== this.bo && (t || this.bo.h_ === t)) return this.bo.El;
          this.Ro.jl();
          const i = this.Ro.El();
          return (this.bo = { El: i, h_: t }), this.po.p(), i;
        }
        a_() {
          return this.po;
        }
        l_(t) {
          this.je() ||
            this.Lo() ||
            (null === this.So &&
              null === this.lo &&
              (this.Gi() ||
                ((this.So = this.ho - t), (this.lo = d(this.ar()).Xe()))));
        }
        o_(t) {
          if (this.je() || this.Lo()) return;
          if (null === this.So) return;
          this.Vo({ hs: !1 }), (t = this.ho - t) < 0 && (t = 0);
          let i = (this.So + 0.2 * (this.ho - 1)) / (t + 0.2 * (this.ho - 1));
          const s = d(this.lo).Xe();
          (i = Math.max(i, 0.1)), s.ir(i), this.Oo(s);
        }
        __() {
          this.je() || this.Lo() || ((this.So = null), (this.lo = null));
        }
        u_(t) {
          this.Eo() ||
            (null === this.xo &&
              null === this.lo &&
              (this.Gi() || ((this.xo = t), (this.lo = d(this.ar()).Xe()))));
        }
        c_(t) {
          if (this.Eo()) return;
          if (null === this.xo) return;
          const i = d(this.ar()).tr() / (this.Ho() - 1);
          let s = t - this.xo;
          this.zo() && (s *= -1);
          const e = s * i,
            h = d(this.lo).Xe();
          h.nr(e), this.Oo(h, !0), (this.bo = null);
        }
        d_() {
          this.Eo() ||
            (null !== this.xo && ((this.xo = null), (this.lo = null)));
        }
        tl() {
          return this.il || this.dl(), this.il;
        }
        Ji(t, i) {
          switch (this.yn.mode) {
            case 2:
              return this.f_(oi(t, i));
            case 3:
              return this.tl().format(ai(t, i));
            default:
              return this.cr(t);
          }
        }
        no(t) {
          switch (this.yn.mode) {
            case 2:
              return this.f_(t);
            case 3:
              return this.tl().format(t);
            default:
              return this.cr(t);
          }
        }
        Ql(t) {
          switch (this.yn.mode) {
            case 2:
              return this.p_(t);
            case 3:
              return this.tl().formatTickmarks(t);
            default:
              return this.v_(t);
          }
        }
        xa(t) {
          return this.cr(t, d(this.wo).tl());
        }
        Ca(t, i) {
          return (t = oi(t, i)), this.f_(t, Mi);
        }
        m_() {
          return this.mo;
        }
        w_(t) {
          this.oo = { uo: t, _o: !1 };
        }
        Nn() {
          this.mo.forEach((t) => t.Nn());
        }
        Kl() {
          return this.yn.ensureEdgeTickMarksVisible && this.Eo();
        }
        Gl() {
          return this.k() / 2;
        }
        dl() {
          this.bo = null;
          let t = 1 / 0;
          this.wo = null;
          for (const i of this.mo) i.ln() < t && ((t = i.ln()), (this.wo = i));
          let i = 100;
          null !== this.wo && (i = Math.round(this.wo.Kh())),
            (this.il = yi),
            this.je()
              ? ((this.il = Mi), (i = 100))
              : this.Lo()
              ? ((this.il = new it(100, 1)), (i = 100))
              : null !== this.wo && (this.il = this.wo.tl()),
            (this.Ro = new gi(this, i, this.Do.bind(this), this.Io.bind(this))),
            this.Ro.jl();
        }
        e_() {
          this.Mo = null;
        }
        M_() {
          return null === this.wo || this.je() || this.Lo()
            ? 1
            : 1 / this.wo.Kh();
        }
        Xi() {
          return this.To;
        }
        Yo(t) {
          this.co = t;
        }
        Uo() {
          return this.zo()
            ? this.yn.scaleMargins.bottom * this.$t() + this.fo
            : this.yn.scaleMargins.top * this.$t() + this.do;
        }
        $o() {
          return this.zo()
            ? this.yn.scaleMargins.top * this.$t() + this.do
            : this.yn.scaleMargins.bottom * this.$t() + this.fo;
        }
        jo() {
          this.oo._o || ((this.oo._o = !0), this.g_());
        }
        Bo() {
          this.ao = null;
        }
        Io(t, i) {
          if ((this.jo(), this.Gi())) return 0;
          t = this.so() && t ? ci(t, this.Co) : t;
          const s = d(this.ar()),
            e = this.$o() + ((this.Ho() - 1) * (t - s.Je())) / s.tr();
          return this.Ko(e);
        }
        Do(t, i) {
          if ((this.jo(), this.Gi())) return 0;
          const s = this.Ko(t),
            e = d(this.ar()),
            h = e.Je() + e.tr() * ((s - this.$o()) / (this.Ho() - 1));
          return this.so() ? di(h, this.Co) : h;
        }
        No() {
          (this.bo = null), this.Ro.jl();
        }
        g_() {
          if (this.Ao() && !this.Eo()) return;
          const t = this.oo.uo;
          if (null === t) return;
          let i = null;
          const s = this.m_();
          let e = 0,
            h = 0;
          for (const n of s) {
            if (!n.It()) continue;
            const s = n.Lt();
            if (null === s) continue;
            const r = n.la(t.Oa(), t.bi());
            let o = r && r.ar();
            if (null !== o) {
              switch (this.yn.mode) {
                case 1:
                  o = fi(o, this.Co);
                  break;
                case 2:
                  o = li(o, s.Wt);
                  break;
                case 3:
                  o = ui(o, s.Wt);
              }
              if (((i = null === i ? o : i.Ss(d(o))), null !== r)) {
                const t = r.lr();
                null !== t &&
                  ((e = Math.max(e, t.above)), (h = Math.max(h, t.below)));
              }
            }
          }
          if (
            (this.Kl() &&
              ((e = Math.max(e, this.Gl())), (h = Math.max(h, this.Gl()))),
            (e === this.do && h === this.fo) ||
              ((this.do = e), (this.fo = h), (this.bo = null), this.Bo()),
            null !== i)
          ) {
            if (i.Je() === i.Qe()) {
              const t = 5 * this.M_();
              this.so() && (i = mi(i, this.Co)),
                (i = new gt(i.Je() - t, i.Qe() + t)),
                this.so() && (i = fi(i, this.Co));
            }
            if (this.so()) {
              const t = mi(i, this.Co),
                s = pi(t);
              if (((n = s), (r = this.Co), n.Al !== r.Al || n.Ll !== r.Ll)) {
                const e = null !== this.lo ? mi(this.lo, this.Co) : null;
                (this.Co = s),
                  (i = fi(t, s)),
                  null !== e && (this.lo = fi(e, s));
              }
            }
            this.Oo(i);
          } else
            null === this.rr &&
              (this.Oo(new gt(-0.5, 0.5)), (this.Co = pi(null)));
          var n, r;
        }
        Go() {
          return this.je()
            ? oi
            : this.Lo()
            ? ai
            : this.so()
            ? (t) => ci(t, this.Co)
            : null;
        }
        b_(t, i, s) {
          return void 0 === i
            ? (void 0 === s && (s = this.tl()), s.format(t))
            : i(t);
        }
        S_(t, i, s) {
          return void 0 === i
            ? (void 0 === s && (s = this.tl()), s.formatTickmarks(t))
            : i(t);
        }
        cr(t, i) {
          return this.b_(t, this.Po.priceFormatter, i);
        }
        v_(t, i) {
          const s = this.Po.priceFormatter;
          return this.S_(
            t,
            this.Po.tickmarksPriceFormatter ?? (s ? (t) => t.map(s) : void 0),
            i
          );
        }
        f_(t, i) {
          return this.b_(t, this.Po.percentageFormatter, i);
        }
        p_(t, i) {
          const s = this.Po.percentageFormatter;
          return this.S_(
            t,
            this.Po.tickmarksPercentageFormatter ??
              (s ? (t) => t.map(s) : void 0),
            i
          );
        }
      }
      function xi(t) {
        return t instanceof jt;
      }
      class _i {
        constructor(t, i) {
          (this.mo = []),
            (this.x_ = new Map()),
            (this.ho = 0),
            (this.C_ = 0),
            (this.y_ = 1),
            (this.Mo = null),
            (this.k_ = null),
            (this.P_ = !1),
            (this.T_ = new m()),
            (this.fa = []),
            (this.ia = t),
            (this.sn = i),
            (this.R_ = new ni(this));
          const s = i.N();
          (this.D_ = this.I_("left", s.leftPriceScale)),
            (this.V_ = this.I_("right", s.rightPriceScale)),
            this.D_.Fo().i(this.B_.bind(this, this.D_), this),
            this.V_.Fo().i(this.B_.bind(this, this.V_), this),
            this.E_(s);
        }
        E_(t) {
          if (
            (t.leftPriceScale && this.D_.vr(t.leftPriceScale),
            t.rightPriceScale && this.V_.vr(t.rightPriceScale),
            t.localization && (this.D_.dl(), this.V_.dl()),
            t.overlayPriceScales)
          ) {
            const i = Array.from(this.x_.values());
            for (const s of i) {
              const i = d(s[0].Ft());
              i.vr(t.overlayPriceScales), t.localization && i.dl();
            }
          }
        }
        A_(t) {
          switch (t) {
            case "left":
              return this.D_;
            case "right":
              return this.V_;
          }
          return this.x_.has(t) ? c(this.x_.get(t))[0].Ft() : null;
        }
        m() {
          this.Qt().L_().u(this),
            this.D_.Fo().u(this),
            this.V_.Fo().u(this),
            this.mo.forEach((t) => {
              t.m && t.m();
            }),
            (this.fa = this.fa.filter((t) => {
              const i = t.Qh();
              return i.detached && i.detached(), !1;
            })),
            this.T_.p();
        }
        z_() {
          return this.y_;
        }
        O_(t) {
          this.y_ = t;
        }
        Qt() {
          return this.sn;
        }
        nn() {
          return this.C_;
        }
        $t() {
          return this.ho;
        }
        N_(t) {
          (this.C_ = t), this.F_();
        }
        Wo(t) {
          (this.ho = t),
            this.D_.Wo(t),
            this.V_.Wo(t),
            this.mo.forEach((i) => {
              if (this.Zs(i)) {
                const s = i.Ft();
                null !== s && s.Wo(t);
              }
            }),
            this.F_();
        }
        W_(t) {
          this.P_ = t;
        }
        H_() {
          return this.P_;
        }
        U_() {
          return this.mo.filter(xi);
        }
        Cl() {
          return this.mo;
        }
        Zs(t) {
          const i = t.Ft();
          return null === i || (this.D_ !== i && this.V_ !== i);
        }
        s_(t, i, s) {
          this.j_(t, i, s ? t.ln() : this.mo.length);
        }
        r_(t, i) {
          const s = this.mo.indexOf(t);
          u(-1 !== s, "removeDataSource: invalid data source"),
            this.mo.splice(s, 1),
            i || this.mo.forEach((t, i) => t._n(i));
          const e = d(t.Ft()).cl();
          if (this.x_.has(e)) {
            const i = c(this.x_.get(e)),
              s = i.indexOf(t);
            -1 !== s && (i.splice(s, 1), 0 === i.length && this.x_.delete(e));
          }
          const h = t.Ft();
          h && h.Cl().indexOf(t) >= 0 && (h.r_(t), this.q_(h)), this.Y_();
        }
        Xs(t) {
          return t === this.D_ ? "left" : t === this.V_ ? "right" : "overlay";
        }
        K_() {
          return this.D_;
        }
        Z_() {
          return this.V_;
        }
        G_(t, i) {
          t.l_(i);
        }
        X_(t, i) {
          t.o_(i), this.F_();
        }
        J_(t) {
          t.__();
        }
        Q_(t, i) {
          t.u_(i);
        }
        tu(t, i) {
          t.c_(i), this.F_();
        }
        iu(t) {
          t.d_();
        }
        F_() {
          this.mo.forEach((t) => {
            t.Nn();
          });
        }
        Pn() {
          const [t, i] = this.nu();
          let s = null;
          return (
            t.N().visible && 0 !== t.Cl().length
              ? (s = t)
              : i.N().visible && 0 !== i.Cl().length
              ? (s = i)
              : 0 !== this.mo.length && (s = this.mo[0].Ft()),
            null === s && (s = this.Gs() ?? t),
            s
          );
        }
        Gs() {
          const [t, i] = this.nu();
          return t.N().visible ? t : i.N().visible ? i : null;
        }
        q_(t) {
          null !== t && t.Eo() && this.su(t);
        }
        eu(t) {
          const i = this.ia.Ee();
          t.Vo({ hs: !0 }), null !== i && t.w_(i), this.F_();
        }
        ru() {
          this.su(this.D_), this.su(this.V_);
        }
        hu() {
          this.q_(this.D_),
            this.q_(this.V_),
            this.mo.forEach((t) => {
              this.Zs(t) && this.q_(t.Ft());
            }),
            this.F_(),
            this.sn.mr();
        }
        Dt() {
          return null === this.Mo && (this.Mo = bi(this.mo)), this.Mo;
        }
        au() {
          const t = this.Dt(),
            i = this.sn.ou()?.lu,
            s = this.sn.N().hoveredSeriesOnTop,
            e = this.k_;
          if (null !== e && e.Kh === t && e._u === i && e.uu === s) return e.cu;
          const h = (function (t, i, s) {
            if (!s) return t;
            const e = t.indexOf(i);
            if (-1 === e || e === t.length - 1) return t;
            const h = [];
            for (let i = 0; i < t.length; i++) i !== e && h.push(t[i]);
            return h.push(t[e]), h;
          })(t, i, s);
          return (this.k_ = { Kh: t, _u: i, uu: s, cu: h }), h;
        }
        du(t, i) {
          i = ii(i, 0, this.mo.length - 1);
          const s = this.mo.indexOf(t);
          u(-1 !== s, "setSeriesOrder: invalid data source"),
            this.mo.splice(s, 1),
            this.mo.splice(i, 0, t),
            this.mo.forEach((t, i) => t._n(i)),
            this.Y_();
          for (const t of [this.D_, this.V_]) t.e_(), t.dl();
          this.sn.mr();
        }
        Vt() {
          return this.Dt().filter(xi);
        }
        fu() {
          return this.T_;
        }
        pu() {
          return this.R_;
        }
        hl(t) {
          this.fa.push(new Bt(t));
        }
        al(t) {
          (this.fa = this.fa.filter((i) => i.Qh() !== t)),
            t.detached && t.detached(),
            this.sn.mr();
        }
        vu() {
          return this.fa;
        }
        Ja(t, i) {
          return this.fa.map((s) => s.Qs(t, i)).filter((t) => null !== t);
        }
        su(t) {
          const i = t.m_();
          if (i && i.length > 0 && !this.ia.Gi()) {
            const i = this.ia.Ee();
            null !== i && t.w_(i);
          }
          t.Nn();
        }
        j_(t, i, s) {
          let e = this.A_(i);
          if (
            (null === e && (e = this.I_(i, this.sn.N().overlayPriceScales)),
            this.mo.splice(s, 0, t),
            !j(i))
          ) {
            const s = this.x_.get(i) || [];
            s.push(t), this.x_.set(i, s);
          }
          t._n(s), e.s_(t), t.un(e), this.q_(e), this.Y_();
        }
        Y_() {
          (this.Mo = null), (this.k_ = null);
        }
        nu() {
          return "left" === this.sn.N().defaultVisiblePriceScaleId
            ? [this.D_, this.V_]
            : [this.V_, this.D_];
        }
        B_(t, i, s) {
          i._e !== s._e && this.su(t);
        }
        I_(t, i) {
          const s = { visible: !0, autoScale: !0, ...M(i) },
            e = new Si(
              t,
              s,
              this.sn.N().layout,
              this.sn.N().localization,
              this.sn.Xi()
            );
          return e.Wo(this.$t()), e;
        }
      }
      function Ci(t, i) {
        return (
          null === i ||
          (2 === t.se && 2 !== i.se) ||
          ((2 !== i.se || 2 === t.se) && t.ne !== i.ne && t.ne < i.ne)
        );
      }
      function Ei(t) {
        return { te: t.te, ie: t.ie };
      }
      function zi(t) {
        return {
          ne: t.distance ?? 0,
          se: t.hitTestPriority ?? ("marker" === t.itemType ? 2 : 0),
          ee: t.itemType ?? "primitive",
          mu: t.cursorStyle,
          te: t.externalId,
        };
      }
      function ki(t) {
        return {
          lu: t.lu,
          wu: Ei(t.Mu),
          mu: t.Mu.mu,
          ee: t.Mu.ee ?? "primitive",
        };
      }
      function Ni(t, i, s, e) {
        let h = null;
        for (const n of t) {
          let t = n.Qs?.(i, s, e) ?? null;
          if (null === t) {
            const h = n.Tt(e);
            t = null !== h && h.Qs ? h.Qs(i, s) : null;
          }
          if (null !== t) {
            const i = { gu: n, Mu: t };
            (null === h || Ci(i.Mu, h.Mu)) && (h = i);
          }
        }
        return h;
      }
      function Ti(t) {
        return void 0 !== t.jn;
      }
      function Ri(t, i, s) {
        const e = [t, ...t.Dt()].reverse(),
          h = (function (t, i, s) {
            let e, h, n;
            for (const l of t) {
              const t = l.Ja?.(i, s) ?? [];
              for (const i of t) {
                const t = zi(i);
                (r = i.zOrder),
                  (o = e?.zOrder),
                  (!o ||
                    ("top" === r && "top" !== o) ||
                    ("normal" === r && "bottom" === o) ||
                    (i.zOrder === e?.zOrder && void 0 !== h && Ci(t, h)) ||
                    (i.zOrder === e?.zOrder && void 0 === h)) &&
                    ((e = i), (h = t), (n = l));
              }
            }
            var r, o;
            return e && n && h ? { Mu: h, bu: e, lu: n } : null;
          })(e, i, s);
        if ("top" === h?.bu.zOrder) return ki(h);
        let n = null,
          r = null;
        for (const o of e) {
          if (h && h.lu === o && "bottom" !== h.bu.zOrder && !h.bu.isBackground)
            return n ?? ki(h);
          if (Ti(o)) {
            const e = Ni(o.jn(t), i, s, t);
            if (null !== e) {
              const t = {
                lu: o,
                gu: e.gu,
                wu: Ei(e.Mu),
                mu: e.Mu.mu,
                ee: e.Mu.ee ?? "primitive",
              };
              (null === n || Ci(e.Mu, r)) && ((n = t), (r = e.Mu));
            }
          }
          if (h && h.lu === o && "bottom" !== h.bu.zOrder && h.bu.isBackground)
            return n ?? ki(h);
        }
        return null !== n ? n : h?.bu ? ki(h) : null;
      }
      class Li {
        constructor(t, i, s = 50) {
          (this.Vs = 0),
            (this.Bs = 1),
            (this.Es = 1),
            (this.Ls = new Map()),
            (this.As = new Map()),
            (this.Su = t),
            (this.xu = i),
            (this.zs = s);
        }
        Cu(t) {
          const i = t.time,
            s = this.xu.cacheKey(i),
            e = this.Ls.get(s);
          if (void 0 !== e) return e.yu;
          if (this.Vs === this.zs) {
            const t = this.As.get(this.Es);
            this.As.delete(this.Es), this.Ls.delete(c(t)), this.Es++, this.Vs--;
          }
          const h = this.Su(t);
          return (
            this.Ls.set(s, { yu: h, Ws: this.Bs }),
            this.As.set(this.Bs, s),
            this.Vs++,
            this.Bs++,
            h
          );
        }
      }
      class Pi {
        constructor(t, i) {
          u(t <= i, "right should be >= left"), (this.ku = t), (this.Pu = i);
        }
        Oa() {
          return this.ku;
        }
        bi() {
          return this.Pu;
        }
        Tu() {
          return this.Pu - this.ku + 1;
        }
        ze(t) {
          return this.ku <= t && t <= this.Pu;
        }
        Ge(t) {
          return this.ku === t.Oa() && this.Pu === t.bi();
        }
      }
      function Ii(t, i) {
        return null === t || null === i ? t === i : t.Ge(i);
      }
      class qi {
        constructor() {
          (this.Ru = new Map()), (this.Ls = null), (this.Du = !1);
        }
        Iu(t) {
          (this.Du = t), (this.Ls = null);
        }
        Vu(t, i) {
          this.Bu(i), (this.Ls = null);
          for (let s = i; s < t.length; ++s) {
            const i = t[s];
            let e = this.Ru.get(i.timeWeight);
            void 0 === e && ((e = []), this.Ru.set(i.timeWeight, e)),
              e.push({
                index: s,
                time: i.time,
                weight: i.timeWeight,
                originalTime: i.originalTime,
              });
          }
        }
        Eu(t, i, s, e, h) {
          const n = Math.ceil(i / t);
          return (
            (null !== this.Ls &&
              this.Ls.Au === n &&
              h === this.Ls.Lu &&
              s === this.Ls.zu) ||
              (this.Ls = { Lu: h, zu: s, El: this.Ou(n, s, e), Au: n }),
            this.Ls.El
          );
        }
        Bu(t) {
          if (0 === t) return void this.Ru.clear();
          const i = [];
          this.Ru.forEach((s, e) => {
            t <= s[0].index
              ? i.push(e)
              : s.splice(
                  kt(s, t, (i) => i.index < t),
                  1 / 0
                );
          });
          for (const t of i) this.Ru.delete(t);
        }
        Ou(t, i, s) {
          let e = [];
          const h = (t) => !i || s.has(t.index);
          for (const i of Array.from(this.Ru.keys()).sort((t, i) => i - t)) {
            if (!this.Ru.get(i)) continue;
            const s = e;
            e = [];
            const n = s.length;
            let r = 0;
            const o = c(this.Ru.get(i)),
              l = o.length;
            let a = 1 / 0,
              u = -1 / 0;
            for (let i = 0; i < l; i++) {
              const l = o[i],
                c = l.index;
              for (; r < n; ) {
                const t = s[r],
                  i = t.index;
                if (!(i < c && h(t))) {
                  a = i;
                  break;
                }
                r++, e.push(t), (u = i), (a = 1 / 0);
              }
              if (a - c >= t && c - u >= t && h(l)) e.push(l), (u = c);
              else if (this.Du) return s;
            }
            for (; r < n; r++) h(s[r]) && e.push(s[r]);
          }
          return e;
        }
      }
      class Oi {
        constructor(t) {
          this.Nu = t;
        }
        Fu() {
          return null === this.Nu
            ? null
            : new Pi(Math.floor(this.Nu.Oa()), Math.ceil(this.Nu.bi()));
        }
        Wu() {
          return this.Nu;
        }
        static Hu() {
          return new Oi(null);
        }
      }
      function Fi(t, i) {
        return t.weight > i.weight ? t : i;
      }
      class Wi {
        constructor(t, i, s, e) {
          (this.C_ = 0),
            (this.Uu = null),
            (this.$u = []),
            (this.xo = null),
            (this.So = null),
            (this.ju = new qi()),
            (this.qu = new Map()),
            (this.Yu = Oi.Hu()),
            (this.Ku = !0),
            (this.Zu = new m()),
            (this.Gu = new m()),
            (this.Xu = new m()),
            (this.Ju = null),
            (this.Qu = null),
            (this.tc = new Map()),
            (this.nc = -1),
            (this.sc = []),
            (this.ec = 1),
            (this.yn = i),
            (this.Po = s),
            (this.rc = i.rightOffset),
            (this.hc = i.barSpacing),
            (this.sn = t),
            this.ac(i),
            (this.xu = e),
            this.lc(),
            this.ju.Iu(i.uniformDistribution),
            this.oc(),
            this._c();
        }
        N() {
          return this.yn;
        }
        uc(t) {
          p(this.Po, t), this.cc(), this.lc();
        }
        vr(t, i) {
          p(this.yn, t),
            this.yn.fixLeftEdge && this.dc(),
            this.yn.fixRightEdge && this.fc(),
            void 0 !== t.barSpacing && this.sn.Ms(t.barSpacing),
            void 0 !== t.rightOffset && this.sn.gs(t.rightOffset),
            this.ac(t),
            (void 0 === t.minBarSpacing && void 0 === t.maxBarSpacing) ||
              this.sn.Ms(t.barSpacing ?? this.hc),
            void 0 !== t.ignoreWhitespaceIndices &&
              t.ignoreWhitespaceIndices !== this.yn.ignoreWhitespaceIndices &&
              this._c(),
            this.cc(),
            this.lc(),
            (void 0 === t.enableConflation &&
              void 0 === t.conflationThresholdFactor) ||
              this.oc(),
            this.Xu.p();
        }
        Rn(t) {
          return this.$u[t]?.time ?? null;
        }
        en(t) {
          return this.$u[t] ?? null;
        }
        vc(t, i) {
          if (this.$u.length < 1) return null;
          if (this.xu.key(t) > this.xu.key(this.$u[this.$u.length - 1].time))
            return i ? this.$u.length - 1 : null;
          const s = kt(
            this.$u,
            this.xu.key(t),
            (t, i) => this.xu.key(t.time) < i
          );
          return this.xu.key(t) < this.xu.key(this.$u[s].time)
            ? i
              ? s
              : null
            : s;
        }
        Gi() {
          return 0 === this.C_ || 0 === this.$u.length || null === this.Uu;
        }
        mc() {
          return this.$u.length > 0;
        }
        Ee() {
          return this.wc(), this.Yu.Fu();
        }
        Mc() {
          return this.wc(), this.Yu.Wu();
        }
        gc() {
          const t = this.Ee();
          if (null === t) return null;
          const i = { from: t.Oa(), to: t.bi() };
          return this.bc(i);
        }
        bc(t) {
          const i = Math.round(t.from),
            s = Math.round(t.to),
            e = d(this.Sc()),
            h = d(this.xc());
          return {
            from: d(this.en(Math.max(e, i))),
            to: d(this.en(Math.min(h, s))),
          };
        }
        Cc(t) {
          return { from: d(this.vc(t.from, !0)), to: d(this.vc(t.to, !0)) };
        }
        nn() {
          return this.C_;
        }
        N_(t) {
          if (!isFinite(t) || t <= 0) return;
          if (this.C_ === t) return;
          const i = this.Mc(),
            s = this.C_;
          if (
            ((this.C_ = t),
            (this.Ku = !0),
            this.yn.lockVisibleTimeRangeOnResize && 0 !== s)
          ) {
            const i = (this.hc * t) / s;
            this.hc = i;
          }
          if (this.yn.fixLeftEdge && null !== i && i.Oa() <= 0) {
            const i = s - t;
            (this.rc -= Math.round(i / this.hc) + 1), (this.Ku = !0);
          }
          this.yc(), this.kc();
        }
        jt(t) {
          if (this.Gi() || !g(t)) return 0;
          const i = this.Pc() + this.rc - t;
          return this.C_ - (i + 0.5) * this.hc - 1;
        }
        Tc(t, i) {
          const s = this.Pc(),
            e = void 0 === i ? 0 : i.from,
            h = void 0 === i ? t.length : i.to;
          for (let i = e; i < h; i++) {
            const e = t[i].wt,
              h = s + this.rc - e,
              n = this.C_ - (h + 0.5) * this.hc - 1;
            t[i]._t = n;
          }
        }
        Rc(t, i) {
          const s = Math.ceil(this.Dc(t));
          return i && this.yn.ignoreWhitespaceIndices && !this.Ic(s)
            ? this.Vc(s)
            : s;
        }
        gs(t) {
          (this.Ku = !0), (this.rc = t), this.kc(), this.sn.Bc(), this.sn.mr();
        }
        fl() {
          return this.hc;
        }
        Ms(t) {
          const i = this.hc;
          if ((this.Ec(t), void 0 !== this.yn.rightOffsetPixels && 0 !== i)) {
            const t = (this.rc * i) / this.hc;
            this.rc = t;
          }
          this.kc(), this.sn.Bc(), this.sn.mr();
        }
        Ac() {
          return this.rc;
        }
        El() {
          if (this.Gi()) return null;
          if (null !== this.Qu) return this.Qu;
          const t = this.hc,
            i =
              ((5 * (this.sn.N().layout.fontSize + 4)) / 8) *
              (this.yn.tickMarkMaxCharacterLength || 8),
            s = Math.round(i / t),
            e = d(this.Ee()),
            h = Math.max(e.Oa(), e.Oa() - s),
            n = Math.max(e.bi(), e.bi() - s),
            r = this.ju.Eu(
              t,
              i,
              this.yn.ignoreWhitespaceIndices,
              this.tc,
              this.nc
            ),
            o = this.Sc() + s,
            l = this.xc() - s,
            a = this.Lc(),
            u = this.yn.fixLeftEdge || a,
            c = this.yn.fixRightEdge || a;
          let f = 0;
          for (const t of r) {
            if (!(h <= t.index && t.index <= n)) continue;
            let s;
            f < this.sc.length
              ? ((s = this.sc[f]),
                (s.coord = this.jt(t.index)),
                (s.label = this.zc(t)),
                (s.weight = t.weight))
              : ((s = {
                  needAlignCoordinate: !1,
                  coord: this.jt(t.index),
                  label: this.zc(t),
                  weight: t.weight,
                }),
                this.sc.push(s)),
              this.hc > i / 2 && !a
                ? (s.needAlignCoordinate = !1)
                : (s.needAlignCoordinate =
                    (u && t.index <= o) || (c && t.index >= l)),
              f++;
          }
          return (this.sc.length = f), (this.Qu = this.sc), this.sc;
        }
        Oc() {
          let t;
          (this.Ku = !0),
            this.Ms(this.yn.barSpacing),
            (t =
              void 0 !== this.yn.rightOffsetPixels
                ? this.yn.rightOffsetPixels / this.fl()
                : this.yn.rightOffset),
            this.gs(t);
        }
        Nc(t) {
          (this.Ku = !0), (this.Uu = t), this.kc(), this.dc();
        }
        Fc(t, i) {
          const s = this.Dc(t),
            e = this.fl(),
            h = e + i * (e / 10);
          this.Ms(h),
            this.yn.rightBarStaysOnScroll ||
              this.gs(this.Ac() + (s - this.Dc(t)));
        }
        l_(t) {
          this.xo && this.d_(),
            null === this.So &&
              null === this.Ju &&
              (this.Gi() || ((this.So = t), this.Wc()));
        }
        o_(t) {
          if (null === this.Ju) return;
          const i = ii(this.C_ - t, 0, this.C_),
            s = ii(this.C_ - d(this.So), 0, this.C_);
          0 !== i && 0 !== s && this.Ms((this.Ju.fl * i) / s);
        }
        __() {
          null !== this.So && ((this.So = null), this.Hc());
        }
        u_(t) {
          null === this.xo &&
            null === this.Ju &&
            (this.Gi() || ((this.xo = t), this.Wc()));
        }
        c_(t) {
          if (null === this.xo) return;
          const i = (this.xo - t) / this.fl();
          (this.rc = d(this.Ju).Ac + i), (this.Ku = !0), this.kc();
        }
        d_() {
          null !== this.xo && ((this.xo = null), this.Hc());
        }
        Uc() {
          this.$c(this.yn.rightOffset);
        }
        $c(t, i = 400) {
          if (!isFinite(t))
            throw new RangeError(
              "offset is required and must be finite number"
            );
          if (!isFinite(i) || i <= 0)
            throw new RangeError(
              "animationDuration (optional) must be finite positive number"
            );
          const s = this.rc,
            e = performance.now();
          this.sn.ps({
            jc: (t) => (t - e) / i >= 1,
            qc: (h) => {
              const n = (h - e) / i;
              return n >= 1 ? t : s + (t - s) * n;
            },
          });
        }
        kt(t, i) {
          (this.Ku = !0), (this.$u = t), this.ju.Vu(t, i), this.kc();
        }
        Yc() {
          return this.Zu;
        }
        Kc() {
          return this.Gu;
        }
        Zc() {
          return this.Xu;
        }
        Pc() {
          return this.Uu || 0;
        }
        Gc(t, i) {
          const s = t.Tu(),
            e = (i && this.yn.rightOffsetPixels) || 0;
          this.Ec((this.C_ - e) / s),
            (this.rc = t.bi() - this.Pc()),
            i && (this.rc = e ? e / this.fl() : this.yn.rightOffset),
            this.kc(),
            (this.Ku = !0),
            this.sn.Bc(),
            this.sn.mr();
        }
        Xc() {
          const t = this.Sc(),
            i = this.xc();
          if (null === t || null === i) return;
          const s = (!this.yn.rightOffsetPixels && this.yn.rightOffset) || 0;
          this.Gc(new Pi(t, i + s), !0);
        }
        Jc(t) {
          const i = new Pi(t.from, t.to);
          this.Gc(i);
        }
        rn(t) {
          return void 0 !== this.Po.timeFormatter
            ? this.Po.timeFormatter(t.originalTime)
            : this.xu.formatHorzItem(t.time);
        }
        _c() {
          if (!this.yn.ignoreWhitespaceIndices) return;
          this.tc.clear();
          const t = this.sn.Jn();
          for (const i of t) for (const t of i.ul()) this.tc.set(t, !0);
          this.nc++;
        }
        Qc() {
          return this.ec;
        }
        Ml() {
          const t = 1 / (window.devicePixelRatio || 1),
            i = this.yn.minBarSpacing;
          if (i >= t) return [1];
          const s = [1];
          let e = 2;
          for (; e <= 512; ) i < t / e && s.push(e), (e *= 2);
          return s;
        }
        Lc() {
          const t = this.sn.N().handleScroll,
            i = this.sn.N().handleScale;
          return !(
            t.horzTouchDrag ||
            t.mouseWheel ||
            t.pressedMouseMove ||
            t.vertTouchDrag ||
            i.axisDoubleClickReset.time ||
            i.axisPressedMouseMove.time ||
            i.mouseWheel ||
            i.pinch
          );
        }
        Sc() {
          return 0 === this.$u.length ? null : 0;
        }
        xc() {
          return 0 === this.$u.length ? null : this.$u.length - 1;
        }
        td(t) {
          return (this.C_ - 1 - t) / this.hc;
        }
        Dc(t) {
          const i = this.td(t),
            s = this.Pc() + this.rc - i;
          return Math.round(1e6 * s) / 1e6;
        }
        Ec(t) {
          const i = this.hc;
          (this.hc = t),
            this.yc(),
            i !== this.hc && ((this.Ku = !0), this.nd(), this.oc());
        }
        wc() {
          if (!this.Ku) return;
          if (((this.Ku = !1), this.Gi())) return void this.sd(Oi.Hu());
          const t = this.Pc(),
            i = this.C_ / this.hc,
            s = this.rc + t,
            e = new Pi(s - i + 1, s);
          this.sd(new Oi(e));
        }
        yc() {
          const t = ii(this.hc, this.ed(), this.rd());
          this.hc !== t && ((this.hc = t), (this.Ku = !0));
        }
        rd() {
          return this.yn.maxBarSpacing > 0
            ? this.yn.maxBarSpacing
            : 0.5 * this.C_;
        }
        ed() {
          return this.yn.fixLeftEdge &&
            this.yn.fixRightEdge &&
            0 !== this.$u.length
            ? this.C_ / this.$u.length
            : this.yn.minBarSpacing;
        }
        oc() {
          if (!this.yn.enableConflation) return void (this.ec = 1);
          const t =
            (1 / (window.devicePixelRatio || 1)) *
            (this.yn.conflationThresholdFactor ?? 1);
          if (this.hc >= t) return void (this.ec = 1);
          const i = t / this.hc,
            s = Math.pow(2, Math.floor(Math.log2(i)));
          this.ec = Math.min(s, 512);
        }
        kc() {
          const t = this.hd();
          null !== t && this.rc < t && ((this.rc = t), (this.Ku = !0));
          const i = this.ad();
          this.rc > i && ((this.rc = i), (this.Ku = !0));
        }
        hd() {
          const t = this.Sc(),
            i = this.Uu;
          return null === t || null === i
            ? null
            : t -
                i -
                1 +
                (this.yn.fixLeftEdge
                  ? this.C_ / this.hc
                  : Math.min(2, this.$u.length));
        }
        ad() {
          return this.yn.fixRightEdge
            ? 0
            : this.C_ / this.hc - Math.min(2, this.$u.length);
        }
        Wc() {
          this.Ju = { fl: this.fl(), Ac: this.Ac() };
        }
        Hc() {
          this.Ju = null;
        }
        zc(t) {
          let i = this.qu.get(t.weight);
          return (
            void 0 === i &&
              ((i = new Li((t) => this.ld(t), this.xu)),
              this.qu.set(t.weight, i)),
            i.Cu(t)
          );
        }
        ld(t) {
          return this.xu.formatTickmark(t, this.Po);
        }
        sd(t) {
          const i = this.Yu;
          (this.Yu = t),
            Ii(i.Fu(), this.Yu.Fu()) || this.Zu.p(),
            Ii(i.Wu(), this.Yu.Wu()) || this.Gu.p(),
            this.nd();
        }
        nd() {
          this.Qu = null;
        }
        cc() {
          this.nd(), this.qu.clear();
        }
        lc() {
          this.xu.updateFormatter(this.Po);
        }
        dc() {
          if (!this.yn.fixLeftEdge) return;
          const t = this.Sc();
          if (null === t) return;
          const i = this.Ee();
          if (null === i) return;
          const s = i.Oa() - t;
          if (s < 0) {
            const t = this.rc - s - 1;
            this.gs(t);
          }
          this.yc();
        }
        fc() {
          this.kc(), this.yc();
        }
        Ic(t) {
          return !this.yn.ignoreWhitespaceIndices || this.tc.get(t) || !1;
        }
        Vc(t) {
          const i = (function* (t) {
              const i = Math.round(t),
                s = i < t;
              let e = 1;
              for (;;)
                s ? (yield i + e, yield i - e) : (yield i - e, yield i + e),
                  e++;
            })(t),
            s = this.xc();
          for (; s; ) {
            const t = i.next().value;
            if (this.tc.get(t)) return t;
            if (t < 0 || t > s) break;
          }
          return t;
        }
        ac(t) {
          if (void 0 !== t.rightOffsetPixels) {
            const i = t.rightOffsetPixels / (t.barSpacing || this.hc);
            this.sn.gs(i);
          }
        }
      }
      var Bi, Qi, Di, Ki, Vi;
      !(function (t) {
        (t[(t.OnTouchEnd = 0)] = "OnTouchEnd"),
          (t[(t.OnNextTap = 1)] = "OnNextTap");
      })(Bi || (Bi = {}));
      class $i {
        constructor(t, i, s) {
          (this.od = []),
            (this._d = []),
            (this.ud = null),
            (this.C_ = 0),
            (this.dd = null),
            (this.fd = new m()),
            (this.pd = new m()),
            (this.vd = null),
            (this.md = t),
            (this.yn = i),
            (this.xu = s),
            (this.To = new k(this.yn.layout.colorParsers)),
            (this.wd = new C(this)),
            (this.ia = new Wi(this, i.timeScale, this.yn.localization, s)),
            (this.Ct = new U(this, i.crosshair)),
            (this.Md = new ti(i.crosshair)),
            i.addDefaultPane && (this.gd(0), this.od[0].O_(2)),
            (this.bd = this.Sd(0)),
            (this.xd = this.Sd(1));
        }
        Pa() {
          this.Cd(X.ys());
        }
        mr() {
          this.Cd(X.Cs());
        }
        qa() {
          this.Cd(new X(1));
        }
        Ta(t) {
          const i = this.yd(t);
          this.Cd(i);
        }
        ou() {
          return this.dd;
        }
        kd(t) {
          if (
            this.dd?.lu === t?.lu &&
            this.dd?.wu?.te === t?.wu?.te &&
            this.dd?.wu?.ie === t?.wu?.ie &&
            this.dd?.mu === t?.mu &&
            this.dd?.ee === t?.ee
          )
            return;
          const i = this.dd;
          (this.dd = t),
            null !== i && this.Ta(i.lu),
            null !== t && t.lu !== i?.lu && this.Ta(t.lu);
        }
        N() {
          return this.yn;
        }
        vr(t) {
          p(this.yn, t),
            this.od.forEach((i) => i.E_(t)),
            void 0 !== t.timeScale && this.ia.vr(t.timeScale),
            void 0 !== t.localization && this.ia.uc(t.localization),
            (t.leftPriceScale || t.rightPriceScale) && this.fd.p(),
            (this.bd = this.Sd(0)),
            (this.xd = this.Sd(1)),
            this.Pa();
        }
        Pd(t, i, s = 0) {
          const e = this.od[s];
          if (void 0 === e) return;
          if ("left" === t)
            return (
              p(this.yn, { leftPriceScale: i }),
              e.E_({ leftPriceScale: i }),
              this.fd.p(),
              void this.Pa()
            );
          if ("right" === t)
            return (
              p(this.yn, { rightPriceScale: i }),
              e.E_({ rightPriceScale: i }),
              this.fd.p(),
              void this.Pa()
            );
          const h = this.Td(t, s);
          null !== h && (h.Ft.vr(i), this.fd.p());
        }
        Td(t, i) {
          const s = this.od[i];
          if (void 0 === s) return null;
          const e = s.A_(t);
          return null !== e ? { Kn: s, Ft: e } : null;
        }
        Et() {
          return this.ia;
        }
        Zn() {
          return this.od;
        }
        Rd() {
          return this.Ct;
        }
        Dd() {
          return this.pd;
        }
        Id(t, i) {
          t.Wo(i), this.Bc();
        }
        N_(t) {
          (this.C_ = t),
            this.ia.N_(this.C_),
            this.od.forEach((i) => i.N_(t)),
            this.Bc();
        }
        Vd(t) {
          1 !== this.od.length &&
            (u(t >= 0 && t < this.od.length, "Invalid pane index"),
            this.od.splice(t, 1),
            this.Pa());
        }
        Bd(t, i) {
          if (this.od.length < 2) return;
          u(t >= 0 && t < this.od.length, "Invalid pane index");
          const s = this.od[t],
            e = this.od.reduce((t, i) => t + i.z_(), 0),
            h = this.od.reduce((t, i) => t + i.$t(), 0),
            n = h - 30 * (this.od.length - 1);
          i = Math.min(n, Math.max(30, i));
          const r = e / h,
            o = s.$t();
          s.O_(i * r);
          let l = i - o,
            a = this.od.length - 1;
          for (const t of this.od)
            if (t !== s) {
              const i = Math.min(n, Math.max(30, t.$t() - l / a));
              (l -= t.$t() - i), (a -= 1);
              const s = i * r;
              t.O_(s);
            }
          this.Pa();
        }
        Ed(t, i) {
          u(
            t >= 0 && t < this.od.length && i >= 0 && i < this.od.length,
            "Invalid pane index"
          );
          const s = this.od[t],
            e = this.od[i];
          (this.od[t] = e), (this.od[i] = s), this.Pa();
        }
        Ad(t, i) {
          if (
            (u(
              t >= 0 && t < this.od.length && i >= 0 && i < this.od.length,
              "Invalid pane index"
            ),
            t === i)
          )
            return;
          const [s] = this.od.splice(t, 1);
          this.od.splice(i, 0, s), this.Pa();
        }
        G_(t, i, s) {
          t.G_(i, s);
        }
        X_(t, i, s) {
          t.X_(i, s), this.Ra(), this.Cd(this.Ld(t, 2));
        }
        J_(t, i) {
          t.J_(i), this.Cd(this.Ld(t, 2));
        }
        Q_(t, i, s) {
          i.Eo() || t.Q_(i, s);
        }
        tu(t, i, s) {
          i.Eo() || (t.tu(i, s), this.Ra(), this.Cd(this.Ld(t, 2)));
        }
        iu(t, i) {
          i.Eo() || (t.iu(i), this.Cd(this.Ld(t, 2)));
        }
        eu(t, i) {
          t.eu(i), this.Cd(this.Ld(t, 2));
        }
        zd(t) {
          this.ia.l_(t);
        }
        Od(t, i) {
          const s = this.Et();
          if (s.Gi() || 0 === i) return;
          const e = s.nn();
          (t = Math.max(1, Math.min(t, e))), s.Fc(t, i), this.Bc();
        }
        Nd(t) {
          this.Fd(0), this.Wd(t), this.Hd();
        }
        Ud(t) {
          this.ia.o_(t), this.Bc();
        }
        $d() {
          this.ia.__(), this.mr();
        }
        Fd(t) {
          this.ia.u_(t);
        }
        Wd(t) {
          this.ia.c_(t), this.Bc();
        }
        Hd() {
          this.ia.d_(), this.mr();
        }
        Jn() {
          return this._d;
        }
        Wn() {
          return (
            null === this.ud && (this.ud = this._d.filter((t) => t.It())),
            this.ud
          );
        }
        ka() {
          this.ud = null;
        }
        jd(t, i, s, e, h) {
          this.Ct.In(t, i);
          let n = NaN,
            r = this.ia.Rc(t, !0);
          const o = this.ia.Ee();
          null !== o && (r = Math.min(Math.max(o.Oa(), r), o.bi())),
            (r = this.Ct.Fn(r));
          const l = e.Pn(),
            a = l.Lt();
          if (
            (null !== a && (n = l.Tn(i, a)),
            (n = this.Md.xl(n, r, e)),
            this.Ct.An(r, n, e),
            this.qa(),
            !h)
          ) {
            const h = Ri(e, t, i);
            this.kd(h && { lu: h.lu, wu: h.wu, mu: h.mu || null, ee: h.ee }),
              this.pd.p(this.Ct.Bt(), { x: t, y: i }, s);
          }
        }
        qd(t, i, s) {
          const e = s.Pn(),
            h = e.Lt(),
            n = e.Nt(t, d(h)),
            r = this.ia.vc(i, !0),
            o = this.ia.jt(d(r));
          this.jd(o, n, null, s, !0);
        }
        Yd(t) {
          this.Rd().zn(), this.qa(), t || this.pd.p(null, null, null);
        }
        Ra() {
          const t = this.Ct.Kn();
          if (null !== t) {
            const i = this.Ct.Bn(),
              s = this.Ct.En();
            this.jd(i, s, null, t);
          }
          this.Ct.Nn();
        }
        Kd(t, i, s) {
          const e = this.ia.Rn(0);
          void 0 !== i && void 0 !== s && this.ia.kt(i, s);
          const h = this.ia.Rn(0),
            n = this.ia.Pc(),
            r = this.ia.Ee();
          if (null !== r && null !== e && null !== h) {
            const i = r.ze(n),
              o = this.xu.key(e) > this.xu.key(h),
              l = null !== t && t > n && !o,
              a = this.ia.N().allowShiftVisibleRangeOnWhitespaceReplacement,
              u =
                i &&
                (!(void 0 === s) || a) &&
                this.ia.N().shiftVisibleRangeOnNewBar;
            if (l && !u) {
              const i = t - n;
              this.ia.gs(this.ia.Ac() - i);
            }
          }
          this.ia.Nc(t);
        }
        Va(t) {
          null !== t && t.hu();
        }
        Ks(t) {
          if (
            (function (t) {
              return t instanceof _i;
            })(t)
          )
            return t;
          const i = this.od.find((i) => i.Dt().includes(t));
          return void 0 === i ? null : i;
        }
        Bc() {
          this.od.forEach((t) => t.hu()), this.Ra();
        }
        m() {
          this.od.forEach((t) => t.m()),
            (this.od.length = 0),
            (this.yn.localization.priceFormatter = void 0),
            (this.yn.localization.percentageFormatter = void 0),
            (this.yn.localization.timeFormatter = void 0);
        }
        Zd() {
          return this.wd;
        }
        Js() {
          return this.wd.N();
        }
        L_() {
          return this.fd;
        }
        Gd(t, i) {
          const s = this.gd(i);
          this.Xd(t, s),
            this._d.push(t),
            this.ka(),
            1 === this._d.length ? this.Pa() : this.mr();
        }
        Jd(t) {
          const i = this.Ks(t),
            s = this._d.indexOf(t);
          u(-1 !== s, "Series not found");
          const e = d(i);
          this._d.splice(s, 1),
            e.r_(t),
            t.m && t.m(),
            this.ka(),
            this.ia._c(),
            this.Qd(e);
        }
        ya(t, i) {
          const s = d(this.Ks(t));
          s.r_(t, !0), s.s_(t, i, !0);
        }
        Xc() {
          const t = X.Cs();
          t.us(), this.Cd(t);
        }
        tf(t) {
          const i = X.Cs();
          i.fs(t), this.Cd(i);
        }
        ws() {
          const t = X.Cs();
          t.ws(), this.Cd(t);
        }
        Ms(t) {
          const i = X.Cs();
          i.Ms(t), this.Cd(i);
        }
        gs(t) {
          const i = X.Cs();
          i.gs(t), this.Cd(i);
        }
        ps(t) {
          const i = X.Cs();
          i.ps(t), this.Cd(i);
        }
        cs() {
          const t = X.Cs();
          t.cs(), this.Cd(t);
        }
        if() {
          const t = this.yn.defaultVisiblePriceScaleId,
            i = this.yn.leftPriceScale.visible;
          return i !== this.yn.rightPriceScale.visible
            ? i
              ? "left"
              : "right"
            : t;
        }
        nf(t, i) {
          if (
            (u(i >= 0, "Index should be greater or equal to 0"),
            i === this.sf(t))
          )
            return;
          const s = d(this.Ks(t));
          s.r_(t);
          const e = this.gd(i);
          this.Xd(t, e);
          let h = !1;
          0 === s.Cl().length && (h = this.Qd(s)), h || this.Pa();
        }
        ef() {
          return this.xd;
        }
        $() {
          return this.bd;
        }
        Ut(t) {
          const i = this.xd,
            s = this.bd;
          if (i === s) return i;
          if (
            ((t = Math.max(0, Math.min(100, Math.round(100 * t)))),
            null === this.vd || this.vd.ah !== s || this.vd.oh !== i)
          )
            this.vd = { ah: s, oh: i, rf: new Map() };
          else {
            const i = this.vd.rf.get(t);
            if (void 0 !== i) return i;
          }
          const e = this.To.tt(s, i, t / 100);
          return this.vd.rf.set(t, e), e;
        }
        hf(t) {
          return this.od.indexOf(t);
        }
        Xi() {
          return this.To;
        }
        af() {
          return this.lf();
        }
        lf(t) {
          const i = new _i(this.ia, this);
          this.od.push(i);
          const s = t ?? this.od.length - 1,
            e = X.ys();
          return e.es(s, { rs: 0, hs: !0 }), this.Cd(e), i;
        }
        gd(t) {
          return (
            u(t >= 0, "Index should be greater or equal to 0"),
            (t = Math.min(this.od.length, t)) < this.od.length
              ? this.od[t]
              : this.lf(t)
          );
        }
        sf(t) {
          return this.od.findIndex((i) => i.U_().includes(t));
        }
        Ld(t, i) {
          const s = new X(i);
          if (null !== t) {
            const e = this.od.indexOf(t);
            s.es(e, { rs: i });
          }
          return s;
        }
        yd(t, i) {
          return void 0 === i && (i = 2), this.Ld(this.Ks(t), i);
        }
        Cd(t) {
          this.md && this.md(t), this.od.forEach((t) => t.pu().wr().kt());
        }
        Xd(t, i) {
          const s = t.N().priceScaleId,
            e = void 0 !== s ? s : this.if();
          i.s_(t, e), j(e) || t.vr(t.N());
        }
        Sd(t) {
          const i = this.yn.layout;
          return "gradient" === i.background.type
            ? 0 === t
              ? i.background.topColor
              : i.background.bottomColor
            : i.background.color;
        }
        Qd(t) {
          return (
            !t.H_() &&
            0 === t.Cl().length &&
            this.od.length > 1 &&
            (this.od.splice(this.hf(t), 1), this.Pa(), !0)
          );
        }
      }
      function Ai(t) {
        if (t >= 1) return 0;
        let i = 0;
        for (; i < 8; i++) {
          const s = Math.round(t);
          if (Math.abs(s - t) < 1e-8) return i;
          t *= 10;
        }
        return i;
      }
      function Zi(t) {
        return !v(t) && !b(t);
      }
      function Hi(t) {
        return v(t);
      }
      !(function (t) {
        (t[(t.Disabled = 0)] = "Disabled"),
          (t[(t.Continuous = 1)] = "Continuous"),
          (t[(t.OnDataUpdate = 2)] = "OnDataUpdate");
      })(Qi || (Qi = {})),
        (function (t) {
          (t[(t.LastBar = 0)] = "LastBar"),
            (t[(t.LastVisible = 1)] = "LastVisible");
        })(Di || (Di = {})),
        (function (t) {
          (t.Solid = "solid"), (t.VerticalGradient = "gradient");
        })(Ki || (Ki = {})),
        (function (t) {
          (t[(t.Year = 0)] = "Year"),
            (t[(t.Month = 1)] = "Month"),
            (t[(t.DayOfMonth = 2)] = "DayOfMonth"),
            (t[(t.Time = 3)] = "Time"),
            (t[(t.TimeWithSeconds = 4)] = "TimeWithSeconds");
        })(Vi || (Vi = {}));
      const Gi = (t) => t.getUTCFullYear();
      class Yi {
        constructor(t = "yyyy-MM-dd", i = "default") {
          (this._f = t), (this.uf = i);
        }
        Cu(t) {
          return (function (t, i, s) {
            return i
              .replace(/yyyy/g, ((t) => tt(Gi(t), 4))(t))
              .replace(/yy/g, ((t) => tt(Gi(t) % 100, 2))(t))
              .replace(
                /MMMM/g,
                ((t, i) =>
                  new Date(
                    t.getUTCFullYear(),
                    t.getUTCMonth(),
                    1
                  ).toLocaleString(i, { month: "long" }))(t, s)
              )
              .replace(
                /MMM/g,
                ((t, i) =>
                  new Date(
                    t.getUTCFullYear(),
                    t.getUTCMonth(),
                    1
                  ).toLocaleString(i, { month: "short" }))(t, s)
              )
              .replace(
                /MM/g,
                ((t) => tt(((t) => t.getUTCMonth() + 1)(t), 2))(t)
              )
              .replace(/dd/g, ((t) => tt(((t) => t.getUTCDate())(t), 2))(t));
          })(t, this._f, this.uf);
        }
      }
      class Ui {
        constructor(t) {
          this.cf = t || "%h:%m:%s";
        }
        Cu(t) {
          return this.cf
            .replace("%h", tt(t.getUTCHours(), 2))
            .replace("%m", tt(t.getUTCMinutes(), 2))
            .replace("%s", tt(t.getUTCSeconds(), 2));
        }
      }
      const ji = { df: "yyyy-MM-dd", ff: "%h:%m:%s", pf: " ", vf: "default" };
      class Xi {
        constructor(t = {}) {
          const i = { ...ji, ...t };
          (this.mf = new Yi(i.df, i.vf)),
            (this.wf = new Ui(i.ff)),
            (this.Mf = i.pf);
        }
        Cu(t) {
          return `${this.mf.Cu(t)}${this.Mf}${this.wf.Cu(t)}`;
        }
      }
      function Ji(t) {
        return 60 * t * 60 * 1e3;
      }
      function ts(t) {
        return 60 * t * 1e3;
      }
      const is = [
        { gf: 1e3, bf: 10 },
        { gf: ts(1), bf: 20 },
        { gf: ts(5), bf: 21 },
        { gf: ts(30), bf: 22 },
        { gf: Ji(1), bf: 30 },
        { gf: Ji(3), bf: 31 },
        { gf: Ji(6), bf: 32 },
        { gf: Ji(12), bf: 33 },
      ];
      function ss(t, i) {
        if (t.getUTCFullYear() !== i.getUTCFullYear()) return 70;
        if (t.getUTCMonth() !== i.getUTCMonth()) return 60;
        if (t.getUTCDate() !== i.getUTCDate()) return 50;
        for (let s = is.length - 1; s >= 0; --s)
          if (
            Math.floor(i.getTime() / is[s].gf) !==
            Math.floor(t.getTime() / is[s].gf)
          )
            return is[s].bf;
        return 0;
      }
      function es(t) {
        let i = t;
        if ((b(t) && (i = ns(t)), !Zi(i)))
          throw new Error("time must be of type BusinessDay");
        const s = new Date(Date.UTC(i.year, i.month - 1, i.day, 0, 0, 0, 0));
        return { Sf: Math.round(s.getTime() / 1e3), xf: i };
      }
      function hs(t) {
        if (!Hi(t)) throw new Error("time must be of type isUTCTimestamp");
        return { Sf: t };
      }
      function ns(t) {
        const i = new Date(t);
        if (isNaN(i.getTime()))
          throw new Error(
            `Invalid date string=${t}, expected format=yyyy-mm-dd`
          );
        return {
          day: i.getUTCDate(),
          month: i.getUTCMonth() + 1,
          year: i.getUTCFullYear(),
        };
      }
      function rs(t) {
        b(t.time) && (t.time = ns(t.time));
      }
      class os {
        options() {
          return this.yn;
        }
        setOptions(t) {
          (this.yn = t), this.updateFormatter(t.localization);
        }
        preprocessData(t) {
          Array.isArray(t)
            ? (function (t) {
                t.forEach(rs);
              })(t)
            : rs(t);
        }
        createConverterToInternalObj(t) {
          return d(
            (function (t) {
              return 0 === t.length
                ? null
                : Zi(t[0].time) || b(t[0].time)
                ? es
                : hs;
            })(t)
          );
        }
        key(t) {
          return "object" == typeof t && "Sf" in t
            ? t.Sf
            : this.key(this.convertHorzItemToInternal(t));
        }
        cacheKey(t) {
          const i = t;
          return void 0 === i.xf
            ? new Date(1e3 * i.Sf).getTime()
            : new Date(Date.UTC(i.xf.year, i.xf.month - 1, i.xf.day)).getTime();
        }
        convertHorzItemToInternal(t) {
          return Hi((i = t)) ? hs(i) : Zi(i) ? es(i) : es(ns(i));
          var i;
        }
        updateFormatter(t) {
          if (!this.yn) return;
          const i = t.dateFormat;
          this.yn.timeScale.timeVisible
            ? (this.Cf = new Xi({
                df: i,
                ff: this.yn.timeScale.secondsVisible ? "%h:%m:%s" : "%h:%m",
                pf: "   ",
                vf: t.locale,
              }))
            : (this.Cf = new Yi(i, t.locale));
        }
        formatHorzItem(t) {
          const i = t;
          return this.Cf.Cu(new Date(1e3 * i.Sf));
        }
        formatTickmark(t, i) {
          const s = (function (t, i, s) {
              switch (t) {
                case 0:
                case 10:
                  return i ? (s ? 4 : 3) : 2;
                case 20:
                case 21:
                case 22:
                case 30:
                case 31:
                case 32:
                case 33:
                  return i ? 3 : 2;
                case 50:
                  return 2;
                case 60:
                  return 1;
                case 70:
                  return 0;
              }
            })(
              t.weight,
              this.yn.timeScale.timeVisible,
              this.yn.timeScale.secondsVisible
            ),
            e = this.yn.timeScale;
          if (void 0 !== e.tickMarkFormatter) {
            const h = e.tickMarkFormatter(t.originalTime, s, i.locale);
            if (null !== h) return h;
          }
          return (function (t, i, s) {
            const e = {};
            switch (i) {
              case 0:
                e.year = "numeric";
                break;
              case 1:
                e.month = "short";
                break;
              case 2:
                e.day = "numeric";
                break;
              case 3:
                (e.hour12 = !1), (e.hour = "2-digit"), (e.minute = "2-digit");
                break;
              case 4:
                (e.hour12 = !1),
                  (e.hour = "2-digit"),
                  (e.minute = "2-digit"),
                  (e.second = "2-digit");
            }
            const h =
              void 0 === t.xf
                ? new Date(1e3 * t.Sf)
                : new Date(Date.UTC(t.xf.year, t.xf.month - 1, t.xf.day));
            return new Date(
              h.getUTCFullYear(),
              h.getUTCMonth(),
              h.getUTCDate(),
              h.getUTCHours(),
              h.getUTCMinutes(),
              h.getUTCSeconds(),
              h.getUTCMilliseconds()
            ).toLocaleString(s, e);
          })(t.time, s, i.locale);
        }
        maxTickMarkWeight(t) {
          let i = t.reduce(Fi, t[0]).weight;
          return i > 30 && i < 50 && (i = 30), i;
        }
        fillWeightsForPoints(t, i) {
          !(function (t, i = 0) {
            if (0 === t.length) return;
            let s = 0 === i ? null : t[i - 1].time.Sf,
              e = null !== s ? new Date(1e3 * s) : null,
              h = 0;
            for (let n = i; n < t.length; ++n) {
              const i = t[n],
                r = new Date(1e3 * i.time.Sf);
              null !== e && (i.timeWeight = ss(r, e)),
                (h += i.time.Sf - (s || i.time.Sf)),
                (s = i.time.Sf),
                (e = r);
            }
            if (0 === i && t.length > 1) {
              const i = Math.ceil(h / (t.length - 1)),
                s = new Date(1e3 * (t[0].time.Sf - i));
              t[0].timeWeight = ss(new Date(1e3 * t[0].time.Sf), s);
            }
          })(t, i);
        }
        static yf(t) {
          return p({ localization: { dateFormat: "dd MMM 'yy" } }, t ?? {});
        }
      }
      const ls = "undefined" != typeof window;
      function as() {
        return (
          !!ls &&
          window.navigator.userAgent.toLowerCase().indexOf("firefox") > -1
        );
      }
      function us() {
        return !!ls && /iPhone|iPad|iPod/.test(window.navigator.platform);
      }
      function cs(t, i) {
        switch (t) {
          case "custom":
            return void 0 !== i ? "custom-object" : "series";
          case "price-line":
            return "custom-price-line";
          case "marker":
            return "series-marker";
          case "primitive":
            return "primitive";
          default:
            return "series";
        }
      }
      function ds(t) {
        return t + (t % 2);
      }
      class fs {
        constructor(t, i, s) {
          (this.kf = 0),
            (this.Pf = null),
            (this.Tf = {
              _t: Number.NEGATIVE_INFINITY,
              ut: Number.POSITIVE_INFINITY,
            }),
            (this.Rf = 0),
            (this.Df = null),
            (this.If = {
              _t: Number.NEGATIVE_INFINITY,
              ut: Number.POSITIVE_INFINITY,
            }),
            (this.Vf = null),
            (this.Bf = !1),
            (this.Ef = null),
            (this.Af = null),
            (this.Lf = !1),
            (this.zf = !1),
            (this.Of = !1),
            (this.Nf = null),
            (this.Ff = null),
            (this.Wf = null),
            (this.Hf = null),
            (this.Uf = null),
            (this.$f = null),
            (this.jf = null),
            (this.qf = 0),
            (this.Yf = !1),
            (this.Kf = !1),
            (this.Zf = !1),
            (this.Gf = 0),
            (this.Xf = null),
            (this.Jf = !us()),
            (this.Qf = (t) => {
              this.tp(t);
            }),
            (this.ip = (t) => {
              if (this.np(t)) {
                const i = this.sp(t);
                if ((++this.Rf, this.Df && this.Rf > 1)) {
                  const { ep: s } = this.rp(vs(t), this.If);
                  s < 30 && !this.Of && this.hp(i, this.lp.ap), this.op();
                }
              } else {
                const i = this.sp(t);
                if ((++this.kf, this.Pf && this.kf > 1)) {
                  const { ep: s } = this.rp(vs(t), this.Tf);
                  s < 5 && !this.zf && this._p(i, this.lp.up), this.cp();
                }
              }
            }),
            (this.dp = t),
            (this.lp = i),
            (this.yn = s),
            this.fp();
        }
        m() {
          null !== this.Nf && (this.Nf(), (this.Nf = null)),
            null !== this.Ff && (this.Ff(), (this.Ff = null)),
            null !== this.Hf && (this.Hf(), (this.Hf = null)),
            null !== this.Uf && (this.Uf(), (this.Uf = null)),
            null !== this.$f && (this.$f(), (this.$f = null)),
            null !== this.Wf && (this.Wf(), (this.Wf = null)),
            this.pp(),
            this.cp();
        }
        vp(t) {
          this.Hf && this.Hf();
          const i = this.mp.bind(this);
          if (
            ((this.Hf = () => {
              this.dp.removeEventListener("mousemove", i);
            }),
            this.dp.addEventListener("mousemove", i),
            this.np(t))
          )
            return;
          const s = this.sp(t);
          this._p(s, this.lp.wp), (this.Jf = !0);
        }
        cp() {
          null !== this.Pf && clearTimeout(this.Pf),
            (this.kf = 0),
            (this.Pf = null),
            (this.Tf = {
              _t: Number.NEGATIVE_INFINITY,
              ut: Number.POSITIVE_INFINITY,
            });
        }
        op() {
          null !== this.Df && clearTimeout(this.Df),
            (this.Rf = 0),
            (this.Df = null),
            (this.If = {
              _t: Number.NEGATIVE_INFINITY,
              ut: Number.POSITIVE_INFINITY,
            });
        }
        mp(t) {
          if (this.Zf || null !== this.Af) return;
          if (this.np(t)) return;
          const i = this.sp(t);
          this._p(i, this.lp.Mp), (this.Jf = !0);
        }
        gp(t) {
          const i = bs(t.changedTouches, d(this.Xf));
          if (null === i) return;
          if (((this.Gf = gs(t)), null !== this.jf)) return;
          if (this.Kf) return;
          this.Yf = !0;
          const s = this.rp(vs(i), d(this.Af)),
            { bp: e, Sp: h, ep: n } = s;
          if (this.Lf || !(n < 5)) {
            if (!this.Lf) {
              const t = 0.5 * e,
                i = h >= t && !this.yn.xp(),
                s = t > h && !this.yn.Cp();
              i || s || (this.Kf = !0),
                (this.Lf = !0),
                (this.Of = !0),
                this.pp(),
                this.op();
            }
            if (!this.Kf) {
              const s = this.sp(t, i);
              this.hp(s, this.lp.yp), ps(t);
            }
          }
        }
        kp(t) {
          if (0 !== t.button) return;
          const i = this.rp(vs(t), d(this.Ef)),
            { ep: s } = i;
          if ((s >= 5 && ((this.zf = !0), this.cp()), this.zf)) {
            const i = this.sp(t);
            this._p(i, this.lp.Pp);
          }
        }
        rp(t, i) {
          const s = Math.abs(i._t - t._t),
            e = Math.abs(i.ut - t.ut);
          return { bp: s, Sp: e, ep: s + e };
        }
        Tp(t) {
          let i = bs(t.changedTouches, d(this.Xf));
          if (
            (null === i && 0 === t.touches.length && (i = t.changedTouches[0]),
            null === i)
          )
            return;
          (this.Xf = null),
            (this.Gf = gs(t)),
            this.pp(),
            (this.Af = null),
            this.$f && (this.$f(), (this.$f = null));
          const s = this.sp(t, i);
          if ((this.hp(s, this.lp.Rp), ++this.Rf, this.Df && this.Rf > 1)) {
            const { ep: t } = this.rp(vs(i), this.If);
            t < 30 && !this.Of && this.hp(s, this.lp.ap), this.op();
          } else this.Of || (this.hp(s, this.lp.Dp), this.lp.Dp && ps(t));
          0 === this.Rf && ps(t),
            0 === t.touches.length && this.Bf && ((this.Bf = !1), ps(t));
        }
        tp(t) {
          if (0 !== t.button) return;
          const i = this.sp(t);
          if (
            ((this.Ef = null),
            (this.Zf = !1),
            this.Uf && (this.Uf(), (this.Uf = null)),
            as() &&
              this.dp.ownerDocument.documentElement.removeEventListener(
                "mouseleave",
                this.Qf
              ),
            !this.np(t))
          )
            if ((this._p(i, this.lp.Ip), ++this.kf, this.Pf && this.kf > 1)) {
              const { ep: s } = this.rp(vs(t), this.Tf);
              s < 5 && !this.zf && this._p(i, this.lp.up), this.cp();
            } else this.zf || this._p(i, this.lp.Vp);
        }
        pp() {
          null !== this.Vf && (clearTimeout(this.Vf), (this.Vf = null));
        }
        Bp(t) {
          if (null !== this.Xf) return;
          const i = t.changedTouches[0];
          (this.Xf = i.identifier), (this.Gf = gs(t));
          const s = this.dp.ownerDocument.documentElement;
          (this.Of = !1),
            (this.Lf = !1),
            (this.Kf = !1),
            (this.Af = vs(i)),
            this.$f && (this.$f(), (this.$f = null));
          {
            const i = this.gp.bind(this),
              e = this.Tp.bind(this);
            (this.$f = () => {
              s.removeEventListener("touchmove", i),
                s.removeEventListener("touchend", e);
            }),
              s.addEventListener("touchmove", i, { passive: !1 }),
              s.addEventListener("touchend", e, { passive: !1 }),
              this.pp(),
              (this.Vf = setTimeout(this.Ep.bind(this, t), 240));
          }
          const e = this.sp(t, i);
          this.hp(e, this.lp.Ap),
            this.Df ||
              ((this.Rf = 0),
              (this.Df = setTimeout(this.op.bind(this), 500)),
              (this.If = vs(i)));
        }
        Lp(t) {
          if (0 !== t.button) return;
          const i = this.dp.ownerDocument.documentElement;
          as() && i.addEventListener("mouseleave", this.Qf),
            (this.zf = !1),
            (this.Ef = vs(t)),
            this.Uf && (this.Uf(), (this.Uf = null));
          {
            const t = this.kp.bind(this),
              s = this.tp.bind(this);
            (this.Uf = () => {
              i.removeEventListener("mousemove", t),
                i.removeEventListener("mouseup", s);
            }),
              i.addEventListener("mousemove", t),
              i.addEventListener("mouseup", s);
          }
          if (((this.Zf = !0), this.np(t))) return;
          const s = this.sp(t);
          this._p(s, this.lp.zp),
            this.Pf ||
              ((this.kf = 0),
              (this.Pf = setTimeout(this.cp.bind(this), 500)),
              (this.Tf = vs(t)));
        }
        fp() {
          this.dp.addEventListener("mouseenter", this.vp.bind(this)),
            this.dp.addEventListener("touchcancel", this.pp.bind(this));
          {
            const t = this.dp.ownerDocument,
              i = (t) => {
                this.lp.Op &&
                  ((t.composed && this.dp.contains(t.composedPath()[0])) ||
                    (t.target && this.dp.contains(t.target)) ||
                    this.lp.Op());
              };
            (this.Ff = () => {
              t.removeEventListener("touchstart", i);
            }),
              (this.Nf = () => {
                t.removeEventListener("mousedown", i);
              }),
              t.addEventListener("mousedown", i),
              t.addEventListener("touchstart", i, { passive: !0 });
          }
          us() &&
            ((this.Wf = () => {
              this.dp.removeEventListener("dblclick", this.ip);
            }),
            this.dp.addEventListener("dblclick", this.ip)),
            this.dp.addEventListener("mouseleave", this.Np.bind(this)),
            this.dp.addEventListener("touchstart", this.Bp.bind(this), {
              passive: !0,
            }),
            (function (t) {
              ls &&
                void 0 !== window.chrome &&
                t.addEventListener("mousedown", (t) => {
                  if (1 === t.button) return t.preventDefault(), !1;
                });
            })(this.dp),
            this.dp.addEventListener("mousedown", this.Lp.bind(this)),
            this.Fp(),
            this.dp.addEventListener("touchmove", () => {}, { passive: !1 });
        }
        Fp() {
          (void 0 === this.lp.Wp &&
            void 0 === this.lp.Hp &&
            void 0 === this.lp.Up) ||
            (this.dp.addEventListener("touchstart", (t) => this.$p(t.touches), {
              passive: !0,
            }),
            this.dp.addEventListener(
              "touchmove",
              (t) => {
                if (
                  2 === t.touches.length &&
                  null !== this.jf &&
                  void 0 !== this.lp.Hp
                ) {
                  const i = ms(t.touches[0], t.touches[1]) / this.qf;
                  this.lp.Hp(this.jf, i), ps(t);
                }
              },
              { passive: !1 }
            ),
            this.dp.addEventListener("touchend", (t) => {
              this.$p(t.touches);
            }));
        }
        $p(t) {
          1 === t.length && (this.Yf = !1),
            2 !== t.length || this.Yf || this.Bf ? this.jp() : this.qp(t);
        }
        qp(t) {
          const i = this.dp.getBoundingClientRect() || { left: 0, top: 0 };
          (this.jf = {
            _t: (t[0].clientX - i.left + (t[1].clientX - i.left)) / 2,
            ut: (t[0].clientY - i.top + (t[1].clientY - i.top)) / 2,
          }),
            (this.qf = ms(t[0], t[1])),
            void 0 !== this.lp.Wp && this.lp.Wp(),
            this.pp();
        }
        jp() {
          null !== this.jf &&
            ((this.jf = null), void 0 !== this.lp.Up && this.lp.Up());
        }
        Np(t) {
          if ((this.Hf && this.Hf(), this.np(t))) return;
          if (!this.Jf) return;
          const i = this.sp(t);
          this._p(i, this.lp.Yp), (this.Jf = !us());
        }
        Ep(t) {
          const i = bs(t.touches, d(this.Xf));
          if (null === i) return;
          const s = this.sp(t, i);
          this.hp(s, this.lp.Kp), (this.Of = !0), (this.Bf = !0);
        }
        np(t) {
          return t.sourceCapabilities &&
            void 0 !== t.sourceCapabilities.firesTouchEvents
            ? t.sourceCapabilities.firesTouchEvents
            : gs(t) < this.Gf + 500;
        }
        hp(t, i) {
          i && i.call(this.lp, t);
        }
        _p(t, i) {
          i && i.call(this.lp, t);
        }
        sp(t, i) {
          const s = i || t,
            e = this.dp.getBoundingClientRect() || { left: 0, top: 0 };
          return {
            clientX: s.clientX,
            clientY: s.clientY,
            pageX: s.pageX,
            pageY: s.pageY,
            screenX: s.screenX,
            screenY: s.screenY,
            localX: s.clientX - e.left,
            localY: s.clientY - e.top,
            ctrlKey: t.ctrlKey,
            altKey: t.altKey,
            shiftKey: t.shiftKey,
            metaKey: t.metaKey,
            Zp:
              !t.type.startsWith("mouse") &&
              "contextmenu" !== t.type &&
              "click" !== t.type,
            Gp: t.type,
            Xp: s.target,
            gu: t.view,
            Jp: () => {
              "touchstart" !== t.type && ps(t);
            },
          };
        }
      }
      function ms(t, i) {
        const s = t.clientX - i.clientX,
          e = t.clientY - i.clientY;
        return Math.sqrt(s * s + e * e);
      }
      function ps(t) {
        t.cancelable && t.preventDefault();
      }
      function vs(t) {
        return { _t: t.pageX, ut: t.pageY };
      }
      function gs(t) {
        return t.timeStamp || performance.now();
      }
      function bs(t, i) {
        for (let s = 0; s < t.length; ++s)
          if (t[s].identifier === i) return t[s];
        return null;
      }
      class ws {
        constructor(t, i, s) {
          (this.Qp = null),
            (this.tv = null),
            (this.iv = !0),
            (this.nv = null),
            (this.sv = t),
            (this.ev = t.rv()[i]),
            (this.hv = t.rv()[s]),
            (this.av = document.createElement("tr")),
            (this.av.style.height = "1px"),
            (this.lv = document.createElement("td")),
            (this.lv.style.position = "relative"),
            (this.lv.style.padding = "0"),
            (this.lv.style.margin = "0"),
            this.lv.setAttribute("colspan", "3"),
            this.ov(),
            this.av.appendChild(this.lv),
            (this.iv = this.sv.N().layout.panes.enableResize),
            this.iv ? this._v() : ((this.Qp = null), (this.tv = null));
        }
        m() {
          null !== this.tv && this.tv.m();
        }
        uv() {
          return this.av;
        }
        cv() {
          return e.size({ width: this.ev.cv().width, height: 1 });
        }
        dv() {
          return e.size({
            width: this.ev.dv().width,
            height: 1 * window.devicePixelRatio,
          });
        }
        fv(t, i, s) {
          const e = this.dv();
          (t.fillStyle = this.sv.N().layout.panes.separatorColor),
            t.fillRect(i, s, e.width, e.height);
        }
        kt() {
          this.ov(),
            this.sv.N().layout.panes.enableResize !== this.iv &&
              ((this.iv = this.sv.N().layout.panes.enableResize),
              this.iv
                ? this._v()
                : (null !== this.Qp &&
                    (this.lv.removeChild(this.Qp.pv),
                    this.lv.removeChild(this.Qp.vv),
                    (this.Qp = null)),
                  null !== this.tv && (this.tv.m(), (this.tv = null))));
        }
        _v() {
          const t = document.createElement("div"),
            i = t.style;
          (i.position = "fixed"),
            (i.display = "none"),
            (i.zIndex = "49"),
            (i.top = "0"),
            (i.left = "0"),
            (i.width = "100%"),
            (i.height = "100%"),
            (i.cursor = "row-resize"),
            this.lv.appendChild(t);
          const s = document.createElement("div"),
            e = s.style;
          (e.position = "absolute"),
            (e.zIndex = "50"),
            (e.top = "-4px"),
            (e.height = "9px"),
            (e.width = "100%"),
            (e.backgroundColor = ""),
            (e.cursor = "row-resize"),
            this.lv.appendChild(s);
          const h = {
            wp: this.mv.bind(this),
            Yp: this.wv.bind(this),
            zp: this.Mv.bind(this),
            Ap: this.Mv.bind(this),
            Pp: this.gv.bind(this),
            yp: this.gv.bind(this),
            Ip: this.bv.bind(this),
            Rp: this.bv.bind(this),
          };
          (this.tv = new fs(s, h, { xp: () => !1, Cp: () => !0 })),
            (this.Qp = { vv: s, pv: t });
        }
        ov() {
          this.lv.style.background = this.sv.N().layout.panes.separatorColor;
        }
        mv(t) {
          null !== this.Qp &&
            (this.Qp.vv.style.backgroundColor =
              this.sv.N().layout.panes.separatorHoverColor);
        }
        wv(t) {
          null !== this.Qp &&
            null === this.nv &&
            (this.Qp.vv.style.backgroundColor = "");
        }
        Mv(t) {
          if (null === this.Qp) return;
          const i = this.ev.Sv().z_() + this.hv.Sv().z_(),
            s = i / (this.ev.cv().height + this.hv.cv().height),
            e = 30 * s;
          i <= 2 * e ||
            ((this.nv = {
              xv: t.pageY,
              Cv: this.ev.Sv().z_(),
              yv: i - e,
              kv: i,
              Pv: s,
              Tv: e,
            }),
            (this.Qp.pv.style.display = "block"));
        }
        gv(t) {
          const i = this.nv;
          if (null === i) return;
          const s = (t.pageY - i.xv) * i.Pv,
            e = ii(i.Cv + s, i.Tv, i.yv);
          this.ev.Sv().O_(e), this.hv.Sv().O_(i.kv - e), this.sv.Qt().Pa();
        }
        bv(t) {
          null !== this.nv &&
            null !== this.Qp &&
            ((this.nv = null), (this.Qp.pv.style.display = "none"));
        }
      }
      function Ms(t, i) {
        return t.Rv - i.Rv;
      }
      function ys(t, i, s) {
        const e = (t.Rv - i.Rv) / (t.wt - i.wt);
        return Math.sign(e) * Math.min(Math.abs(e), s);
      }
      class Ss {
        constructor(t, i, s, e) {
          (this.Dv = null),
            (this.Iv = null),
            (this.Vv = null),
            (this.Bv = null),
            (this.Ev = null),
            (this.Av = 0),
            (this.Lv = 0),
            (this.zv = t),
            (this.Ov = i),
            (this.Nv = s),
            (this.ks = e);
        }
        Fv(t, i) {
          if (null !== this.Dv) {
            if (this.Dv.wt === i) return void (this.Dv.Rv = t);
            if (Math.abs(this.Dv.Rv - t) < this.ks) return;
          }
          (this.Bv = this.Vv),
            (this.Vv = this.Iv),
            (this.Iv = this.Dv),
            (this.Dv = { wt: i, Rv: t });
        }
        me(t, i) {
          if (null === this.Dv || null === this.Iv) return;
          if (i - this.Dv.wt > 50) return;
          let s = 0;
          const e = ys(this.Dv, this.Iv, this.Ov),
            h = Ms(this.Dv, this.Iv),
            n = [e],
            r = [h];
          if (((s += h), null !== this.Vv)) {
            const t = ys(this.Iv, this.Vv, this.Ov);
            if (Math.sign(t) === Math.sign(e)) {
              const i = Ms(this.Iv, this.Vv);
              if ((n.push(t), r.push(i), (s += i), null !== this.Bv)) {
                const t = ys(this.Vv, this.Bv, this.Ov);
                if (Math.sign(t) === Math.sign(e)) {
                  const i = Ms(this.Vv, this.Bv);
                  n.push(t), r.push(i), (s += i);
                }
              }
            }
          }
          let o = 0;
          for (let t = 0; t < n.length; ++t) o += (r[t] / s) * n[t];
          Math.abs(o) < this.zv ||
            ((this.Ev = { Rv: t, wt: i }),
            (this.Lv = o),
            (this.Av = (function (t, i) {
              const s = Math.log(i);
              return Math.log((1 * s) / -t) / s;
            })(Math.abs(o), this.Nv)));
        }
        qc(t) {
          const i = d(this.Ev),
            s = t - i.wt;
          return (
            i.Rv + (this.Lv * (Math.pow(this.Nv, s) - 1)) / Math.log(this.Nv)
          );
        }
        jc(t) {
          return null === this.Ev || this.Wv(t) === this.Av;
        }
        Wv(t) {
          const i = t - d(this.Ev).wt;
          return Math.min(i, this.Av);
        }
      }
      class xs {
        constructor(t, i) {
          (this.Hv = void 0),
            (this.Uv = void 0),
            (this.$v = void 0),
            (this.vn = !1),
            (this.jv = t),
            (this.qv = i),
            this.Yv();
        }
        kt() {
          this.Yv();
        }
        Kv() {
          this.Hv && this.jv.removeChild(this.Hv),
            this.Uv && this.jv.removeChild(this.Uv),
            (this.Hv = void 0),
            (this.Uv = void 0);
        }
        Zv() {
          return this.vn !== this.Gv() || this.$v !== this.Xv();
        }
        Xv() {
          return this.qv.Qt().Xi().J(this.qv.N().layout.textColor) > 160
            ? "dark"
            : "light";
        }
        Gv() {
          return this.qv.N().layout.attributionLogo;
        }
        Jv() {
          const t = new URL(location.href);
          return t.hostname ? "&utm_source=" + t.hostname + t.pathname : "";
        }
        Yv() {
          this.Zv() &&
            (this.Kv(),
            (this.vn = this.Gv()),
            this.vn &&
              ((this.$v = this.Xv()),
              (this.Uv = document.createElement("style")),
              (this.Uv.innerText =
                "a#tv-attr-logo{--fill:#131722;--stroke:#fff;position:absolute;left:10px;bottom:10px;height:19px;width:35px;margin:0;padding:0;border:0;z-index:3;}a#tv-attr-logo[data-dark]{--fill:#D1D4DC;--stroke:#131722;}"),
              (this.Hv = document.createElement("a")),
              (this.Hv.href = `https://www.tradingview.com/?utm_medium=lwc-link&utm_campaign=lwc-chart${this.Jv()}`),
              (this.Hv.title = "Charting by TradingView"),
              (this.Hv.id = "tv-attr-logo"),
              (this.Hv.target = "_blank"),
              (this.Hv.innerHTML =
                '<svg xmlns="http://www.w3.org/2000/svg" width="35" height="19" fill="none"><g fill-rule="evenodd" clip-path="url(#a)" clip-rule="evenodd"><path fill="var(--stroke)" d="M2 0H0v10h6v9h21.4l.5-1.3 6-15 1-2.7H23.7l-.5 1.3-.2.6a5 5 0 0 0-7-.9V0H2Zm20 17h4l5.2-13 .8-2h-7l-1 2.5-.2.5-1.5 3.8-.3.7V17Zm-.8-10a3 3 0 0 0 .7-2.7A3 3 0 1 0 16.8 7h4.4ZM14 7V2H2v6h6v9h4V7h2Z"/><path fill="var(--fill)" d="M14 2H2v6h6v9h6V2Zm12 15h-7l6-15h7l-6 15Zm-7-9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></g><defs><clipPath id="a"><path fill="var(--stroke)" d="M0 0h35v19H0z"/></clipPath></defs></svg>'),
              this.Hv.toggleAttribute("data-dark", "dark" === this.$v),
              this.jv.appendChild(this.Uv),
              this.jv.appendChild(this.Hv)));
        }
      }
      function _s(t, i) {
        const s = d(t.ownerDocument).createElement("canvas");
        t.appendChild(s);
        const h = (0, e.bindCanvasElementBitmapSizeTo)(s, {
          type: "device-pixel-content-box",
          options: { allowResizeObserver: !0 },
          transform: (t, i) => ({
            width: Math.max(t.width, i.width),
            height: Math.max(t.height, i.height),
          }),
        });
        return h.resizeCanvasElement(i), h;
      }
      function Cs(t) {
        (t.width = 1),
          (t.height = 1),
          t.getContext("2d")?.clearRect(0, 0, 1, 1);
      }
      function Es(t, i, s, e) {
        t.qh && t.qh(i, s, e);
      }
      function zs(t, i, s, e) {
        t.st(i, s, e);
      }
      function ks(t, i, s, e) {
        const h = t(s, e);
        for (const t of h) {
          const s = t.Tt(e);
          null !== s && i(s);
        }
      }
      function Ns(t, i) {
        return (s) =>
          (function (t) {
            return void 0 !== t.Ft;
          })(s)
            ? (s.Ft()?.cl() ?? "") !== i
              ? []
              : s.Ga?.(t) ?? []
            : [];
      }
      function Ts(t, i, s, e) {
        if (!t.length) return;
        let h = 0;
        const n = t[0].$t(e, !0);
        let r =
          1 === i ? s / 2 - (t[0].Hi() - n / 2) : t[0].Hi() - n / 2 - s / 2;
        r = Math.max(0, r);
        for (let n = 1; n < t.length; n++) {
          const o = t[n],
            l = t[n - 1],
            a = l.$t(e, !1),
            u = o.Hi(),
            c = l.Hi();
          if (1 === i ? u > c - a : u < c + a) {
            const e = c - a * i;
            o.Ui(e);
            const n = e - (i * a) / 2;
            if ((1 === i ? n < 0 : n > s) && r > 0) {
              const e = 1 === i ? -1 - n : n - s,
                o = Math.min(e, r);
              for (let s = h; s < t.length; s++) t[s].Ui(t[s].Hi() + i * o);
              r -= o;
            }
          } else (h = n), (r = 1 === i ? c - a - u : u - (c + a));
        }
      }
      class Rs {
        constructor(t, i, s, h) {
          (this.Ki = null),
            (this.Qv = null),
            (this.tm = !1),
            (this.im = new nt(200)),
            (this.nm = null),
            (this.sm = 0),
            (this.rm = !1),
            (this.hm = () => {
              this.rm || this.yt.am().Qt().mr();
            }),
            (this.lm = () => {
              this.rm || this.yt.am().Qt().mr();
            }),
            (this.yt = t),
            (this.yn = i),
            (this.ko = i.layout),
            (this.wd = s),
            (this.om = "left" === h),
            (this._m = Ns("normal", h)),
            (this.um = Ns("top", h)),
            (this.dm = Ns("bottom", h)),
            (this.lv = document.createElement("div")),
            (this.lv.style.height = "100%"),
            (this.lv.style.overflow = "hidden"),
            (this.lv.style.width = "25px"),
            (this.lv.style.left = "0"),
            (this.lv.style.position = "relative"),
            (this.fm = _s(this.lv, e.size({ width: 16, height: 16 }))),
            this.fm.subscribeSuggestedBitmapSizeChanged(this.hm);
          const n = this.fm.canvasElement;
          (n.style.position = "absolute"),
            (n.style.zIndex = "1"),
            (n.style.left = "0"),
            (n.style.top = "0"),
            (this.pm = _s(this.lv, e.size({ width: 16, height: 16 }))),
            this.pm.subscribeSuggestedBitmapSizeChanged(this.lm);
          const r = this.pm.canvasElement;
          (r.style.position = "absolute"),
            (r.style.zIndex = "2"),
            (r.style.left = "0"),
            (r.style.top = "0");
          const o = {
            zp: this.Mv.bind(this),
            Ap: this.Mv.bind(this),
            Pp: this.gv.bind(this),
            yp: this.gv.bind(this),
            Op: this.vm.bind(this),
            Ip: this.bv.bind(this),
            Rp: this.bv.bind(this),
            up: this.wm.bind(this),
            ap: this.wm.bind(this),
            wp: this.Mm.bind(this),
            Yp: this.wv.bind(this),
          };
          this.tv = new fs(this.pm.canvasElement, o, {
            xp: () => !this.yn.handleScroll.vertTouchDrag,
            Cp: () => !0,
          });
        }
        m() {
          this.tv.m(),
            this.pm.unsubscribeSuggestedBitmapSizeChanged(this.lm),
            Cs(this.pm.canvasElement),
            this.pm.dispose(),
            this.fm.unsubscribeSuggestedBitmapSizeChanged(this.hm),
            Cs(this.fm.canvasElement),
            this.fm.dispose(),
            null !== this.Ki && this.Ki.a_().u(this),
            (this.Ki = null);
        }
        uv() {
          return this.lv;
        }
        k() {
          return this.ko.fontSize;
        }
        gm() {
          const t = this.wd.N();
          return this.nm !== t.P && (this.im.Os(), (this.nm = t.P)), t;
        }
        bm() {
          if (null === this.Ki) return 0;
          let t = 0;
          const i = this.gm(),
            s = d(
              this.fm.canvasElement.getContext("2d", {
                colorSpace: this.yt.am().N().layout.colorSpace,
              })
            );
          s.save();
          const e = this.Ki.El();
          (s.font = this.Sm()),
            e.length > 0 &&
              (t = Math.max(
                this.im.Ii(s, e[0].io),
                this.im.Ii(s, e[e.length - 1].io)
              ));
          const h = this.xm();
          for (let i = h.length; i--; ) {
            const e = this.im.Ii(s, h[i].ri());
            e > t && (t = e);
          }
          const n = this.Ki.Lt();
          if (
            null !== n &&
            null !== this.Qv &&
            2 !== (r = this.yn.crosshair).mode &&
            r.horzLine.visible &&
            r.horzLine.labelVisible
          ) {
            const i = this.Ki.Tn(1, n),
              e = this.Ki.Tn(this.Qv.height - 2, n);
            t = Math.max(
              t,
              this.im.Ii(
                s,
                this.Ki.Ji(Math.floor(Math.min(i, e)) + 0.11111111111111, n)
              ),
              this.im.Ii(
                s,
                this.Ki.Ji(Math.ceil(Math.max(i, e)) - 0.11111111111111, n)
              )
            );
          }
          var r;
          s.restore();
          const o = t || 34;
          return ds(Math.ceil(i.S + i.C + i.V + i.B + 5 + o));
        }
        Cm(t) {
          (null !== this.Qv && (0, e.equalSizes)(this.Qv, t)) ||
            ((this.Qv = t),
            (this.rm = !0),
            this.fm.resizeCanvasElement(t),
            this.pm.resizeCanvasElement(t),
            (this.rm = !1),
            (this.lv.style.width = `${t.width}px`),
            (this.lv.style.height = `${t.height}px`));
        }
        ym() {
          return d(this.Qv).width;
        }
        un(t) {
          this.Ki !== t &&
            (null !== this.Ki && this.Ki.a_().u(this),
            (this.Ki = t),
            t.a_().i(this.po.bind(this), this));
        }
        Ft() {
          return this.Ki;
        }
        Os() {
          const t = this.yt.Sv();
          this.yt.am().Qt().eu(t, d(this.Ft()));
        }
        km(t) {
          if (null === this.Qv) return;
          const i = { colorSpace: this.yt.am().N().layout.colorSpace };
          if (1 !== t) {
            this.Pm(), this.fm.applySuggestedBitmapSize();
            const t = (0, e.tryCreateCanvasRenderingTarget2D)(this.fm, i);
            null !== t &&
              (t.useBitmapCoordinateSpace((t) => {
                this.Tm(t), this.Rm(t);
              }),
              this.yt.Dm(t, this.dm),
              this.Im(t),
              this.yt.Dm(t, this._m),
              this.Vm(t));
          }
          this.pm.applySuggestedBitmapSize();
          const s = (0, e.tryCreateCanvasRenderingTarget2D)(this.pm, i);
          null !== s &&
            (s.useBitmapCoordinateSpace(({ context: t, bitmapSize: i }) => {
              t.clearRect(0, 0, i.width, i.height);
            }),
            this.Bm(s),
            this.yt.Dm(s, this.um));
        }
        dv() {
          return this.fm.bitmapSize;
        }
        fv(t, i, s, e) {
          const h = this.dv();
          if (
            h.width > 0 &&
            h.height > 0 &&
            (t.drawImage(this.fm.canvasElement, i, s), e)
          ) {
            const e = this.pm.canvasElement;
            t.drawImage(e, i, s);
          }
        }
        kt() {
          this.Ki?.El();
        }
        Mv(t) {
          if (
            null === this.Ki ||
            this.Ki.Gi() ||
            !this.yn.handleScale.axisPressedMouseMove.price
          )
            return;
          const i = this.yt.am().Qt(),
            s = this.yt.Sv();
          (this.tm = !0), i.G_(s, this.Ki, t.localY);
        }
        gv(t) {
          if (
            null === this.Ki ||
            !this.yn.handleScale.axisPressedMouseMove.price
          )
            return;
          const i = this.yt.am().Qt(),
            s = this.yt.Sv(),
            e = this.Ki;
          i.X_(s, e, t.localY);
        }
        vm() {
          if (
            null === this.Ki ||
            !this.yn.handleScale.axisPressedMouseMove.price
          )
            return;
          const t = this.yt.am().Qt(),
            i = this.yt.Sv(),
            s = this.Ki;
          this.tm && ((this.tm = !1), t.J_(i, s));
        }
        bv(t) {
          if (
            null === this.Ki ||
            !this.yn.handleScale.axisPressedMouseMove.price
          )
            return;
          const i = this.yt.am().Qt(),
            s = this.yt.Sv();
          (this.tm = !1), i.J_(s, this.Ki);
        }
        wm(t) {
          this.yn.handleScale.axisDoubleClickReset.price && this.Os();
        }
        Mm(t) {
          null !== this.Ki &&
            (!this.yt.am().Qt().N().handleScale.axisPressedMouseMove.price ||
              this.Ki.je() ||
              this.Ki.Lo() ||
              this.Em(1));
        }
        wv(t) {
          this.Em(0);
        }
        xm() {
          const t = [],
            i = null === this.Ki ? void 0 : this.Ki;
          return (
            ((s) => {
              for (let e = 0; e < s.length; ++e) {
                const h = s[e].qn(this.yt.Sv(), i);
                for (let i = 0; i < h.length; i++) t.push(h[i]);
              }
            })(this.yt.Sv().Dt()),
            t
          );
        }
        Tm({ context: t, bitmapSize: i }) {
          const { width: s, height: e } = i,
            h = this.yt.Sv().Qt(),
            n = h.$(),
            r = h.ef();
          n === r ? W(t, 0, 0, s, e, n) : D(t, 0, 0, s, e, n, r);
        }
        Rm({ context: t, bitmapSize: i, horizontalPixelRatio: s }) {
          if (
            null === this.Qv ||
            null === this.Ki ||
            !this.Ki.N().borderVisible
          )
            return;
          t.fillStyle = this.Ki.N().borderColor;
          const e = Math.max(1, Math.floor(this.gm().S * s));
          let h;
          (h = this.om ? i.width - e : 0), t.fillRect(h, 0, e, i.height);
        }
        Im(t) {
          if (null === this.Qv || null === this.Ki) return;
          const i = this.Ki.El(),
            s = this.Ki.N(),
            e = this.gm(),
            h = this.om ? this.Qv.width - e.C : 0;
          s.borderVisible &&
            s.ticksVisible &&
            t.useBitmapCoordinateSpace(
              ({
                context: t,
                horizontalPixelRatio: n,
                verticalPixelRatio: r,
              }) => {
                t.fillStyle = s.borderColor;
                const o = Math.max(1, Math.floor(r)),
                  l = Math.floor(0.5 * r),
                  a = Math.round(e.C * n);
                t.beginPath();
                for (const s of i)
                  t.rect(Math.floor(h * n), Math.round(s.Rl * r) - l, a, o);
                t.fill();
              }
            ),
            t.useMediaCoordinateSpace(({ context: t }) => {
              (t.font = this.Sm()),
                (t.fillStyle = s.textColor ?? this.ko.textColor),
                (t.textAlign = this.om ? "right" : "left"),
                (t.textBaseline = "middle");
              const n = this.om
                  ? Math.round(h - e.V)
                  : Math.round(h + e.C + e.V),
                r = i.map((i) => this.im.Di(t, i.io));
              for (let s = i.length; s--; ) {
                const e = i[s];
                t.fillText(e.io, n, e.Rl + r[s]);
              }
            });
        }
        Pm() {
          if (null === this.Qv || null === this.Ki) return;
          let t = this.Qv.height / 2;
          const i = [],
            s = this.Ki.Dt().slice(),
            e = this.yt.Sv(),
            h = this.gm();
          this.Ki === e.Gs() &&
            this.yt
              .Sv()
              .Dt()
              .forEach((t) => {
                e.Zs(t) && s.push(t);
              });
          const n = this.Ki.Cl()[0],
            r = this.Ki;
          s.forEach((s) => {
            const h = s.qn(e, r);
            h.forEach((t) => {
              t.$i() && null === t.Wi() && (t.Ui(null), i.push(t));
            }),
              n === s && h.length > 0 && (t = h[0].Ei());
          }),
            this.Ki.N().alignLabels && this.Am(i, h, t);
        }
        Am(t, i, s) {
          if (null === this.Qv) return;
          const e = t.filter((t) => t.Ei() <= s),
            h = t.filter((t) => t.Ei() > s);
          e.sort((t, i) => i.Ei() - t.Ei()),
            e.length && h.length && h.push(e[0]),
            h.sort((t, i) => t.Ei() - i.Ei());
          for (const s of t) {
            const t = Math.floor(s.$t(i) / 2),
              e = s.Ei();
            e > -t && e < t && s.Ui(t),
              e > this.Qv.height - t &&
                e < this.Qv.height + t &&
                s.Ui(this.Qv.height - t);
          }
          Ts(e, 1, this.Qv.height, i), Ts(h, -1, this.Qv.height, i);
        }
        Vm(t) {
          if (null === this.Qv) return;
          const i = this.xm(),
            s = this.gm(),
            e = this.om ? "right" : "left";
          i.forEach((i) => {
            i.ji() && i.Tt(d(this.Ki)).st(t, s, this.im, e);
          });
        }
        Bm(t) {
          if (null === this.Qv || null === this.Ki) return;
          const i = this.yt.am().Qt(),
            s = [],
            e = this.yt.Sv(),
            h = i.Rd().qn(e, this.Ki);
          h.length && s.push(h);
          const n = this.gm(),
            r = this.om ? "right" : "left";
          s.forEach((i) => {
            i.forEach((i) => {
              i.Tt(d(this.Ki)).st(t, n, this.im, r);
            });
          });
        }
        Em(t) {
          this.lv.style.cursor = 1 === t ? "ns-resize" : "default";
        }
        po() {
          const t = this.bm();
          this.sm < t && this.yt.am().Qt().Pa(), (this.sm = t);
        }
        Sm() {
          return _(this.ko.fontSize, this.ko.fontFamily);
        }
      }
      function Ls(t, i) {
        return t.Ka?.(i) ?? [];
      }
      function Ps(t, i) {
        return t.jn?.(i) ?? [];
      }
      function Is(t, i) {
        return t.cn?.(i) ?? [];
      }
      function qs(t, i) {
        return t.ja?.(i) ?? [];
      }
      class Os {
        constructor(t, i) {
          (this.Qv = e.size({ width: 0, height: 0 })),
            (this.Lm = null),
            (this.zm = null),
            (this.Om = null),
            (this.Nm = null),
            (this.Fm = !1),
            (this.Wm = new m()),
            (this.Hm = new m()),
            (this.Um = 0),
            (this.$m = !1),
            (this.jm = null),
            (this.qm = !1),
            (this.Ym = null),
            (this.Km = null),
            (this.rm = !1),
            (this.hm = () => {
              this.rm || null === this.Zm || this.sn().mr();
            }),
            (this.lm = () => {
              this.rm || null === this.Zm || this.sn().mr();
            }),
            (this.qv = t),
            (this.Zm = i),
            this.Zm.fu().i(this.Gm.bind(this), this, !0),
            (this.Xm = document.createElement("td")),
            (this.Xm.style.padding = "0"),
            (this.Xm.style.position = "relative");
          const s = document.createElement("div");
          (s.style.width = "100%"),
            (s.style.height = "100%"),
            (s.style.position = "relative"),
            (s.style.overflow = "hidden"),
            (this.Jm = document.createElement("td")),
            (this.Jm.style.padding = "0"),
            (this.Qm = document.createElement("td")),
            (this.Qm.style.padding = "0"),
            this.Xm.appendChild(s),
            (this.fm = _s(s, e.size({ width: 16, height: 16 }))),
            this.fm.subscribeSuggestedBitmapSizeChanged(this.hm);
          const h = this.fm.canvasElement;
          (h.style.position = "absolute"),
            (h.style.zIndex = "1"),
            (h.style.left = "0"),
            (h.style.top = "0"),
            (this.pm = _s(s, e.size({ width: 16, height: 16 }))),
            this.pm.subscribeSuggestedBitmapSizeChanged(this.lm);
          const n = this.pm.canvasElement;
          (n.style.position = "absolute"),
            (n.style.zIndex = "2"),
            (n.style.left = "0"),
            (n.style.top = "0"),
            (this.av = document.createElement("tr")),
            this.av.appendChild(this.Jm),
            this.av.appendChild(this.Xm),
            this.av.appendChild(this.Qm),
            this.tw(),
            (this.tv = new fs(this.pm.canvasElement, this, {
              xp: () =>
                null === this.jm && !this.qv.N().handleScroll.vertTouchDrag,
              Cp: () =>
                null === this.jm && !this.qv.N().handleScroll.horzTouchDrag,
            }));
        }
        m() {
          null !== this.Lm && this.Lm.m(),
            null !== this.zm && this.zm.m(),
            (this.Om = null),
            this.pm.unsubscribeSuggestedBitmapSizeChanged(this.lm),
            Cs(this.pm.canvasElement),
            this.pm.dispose(),
            this.fm.unsubscribeSuggestedBitmapSizeChanged(this.hm),
            Cs(this.fm.canvasElement),
            this.fm.dispose(),
            null !== this.Zm && (this.Zm.fu().u(this), this.Zm.m()),
            this.tv.m();
        }
        Sv() {
          return d(this.Zm);
        }
        iw(t) {
          null !== this.Zm && this.Zm.fu().u(this),
            (this.Zm = t),
            null !== this.Zm &&
              this.Zm.fu().i(Os.prototype.Gm.bind(this), this, !0),
            this.tw(),
            this.qv.rv().indexOf(this) === this.qv.rv().length - 1
              ? ((this.Om = this.Om ?? new xs(this.Xm, this.qv)), this.Om.kt())
              : (this.Om?.Kv(), (this.Om = null));
        }
        am() {
          return this.qv;
        }
        uv() {
          return this.av;
        }
        tw() {
          if (null !== this.Zm && (this.nw(), 0 !== this.sn().Jn().length)) {
            if (null !== this.Lm) {
              const t = this.Zm.K_();
              this.Lm.un(d(t));
            }
            if (null !== this.zm) {
              const t = this.Zm.Z_();
              this.zm.un(d(t));
            }
          }
        }
        sw() {
          null !== this.Lm && this.Lm.kt(), null !== this.zm && this.zm.kt();
        }
        z_() {
          return null !== this.Zm ? this.Zm.z_() : 0;
        }
        O_(t) {
          this.Zm && this.Zm.O_(t);
        }
        wp(t) {
          if (!this.Zm) return;
          this.ew();
          const i = t.localX,
            s = t.localY;
          this.rw(i, s, t);
        }
        zp(t) {
          this.ew(), this.hw(), this.rw(t.localX, t.localY, t);
        }
        Mp(t) {
          if (!this.Zm) return;
          this.ew();
          const i = t.localX,
            s = t.localY;
          this.rw(i, s, t);
        }
        Vp(t) {
          null !== this.Zm &&
            (this.ew(), this.rw(t.localX, t.localY, t), this.aw(t));
        }
        up(t) {
          null !== this.Zm && this.lw(this.Hm, t);
        }
        ap(t) {
          this.up(t);
        }
        Pp(t) {
          this.ew(), this.ow(t), this.rw(t.localX, t.localY, t);
        }
        Ip(t) {
          null !== this.Zm && (this.ew(), (this.$m = !1), this._w(t));
        }
        Dp(t) {
          null !== this.Zm && this.aw(t);
        }
        Kp(t) {
          if (((this.$m = !0), null === this.jm)) {
            const i = { x: t.localX, y: t.localY };
            this.uw(i, i, t);
          }
        }
        Yp(t) {
          null !== this.Zm && (this.ew(), this.Zm.Qt().kd(null), this.cw());
        }
        dw() {
          return this.Wm;
        }
        fw() {
          return this.Hm;
        }
        Wp() {
          (this.Um = 1), this.sn().cs();
        }
        Hp(t, i) {
          if (!this.qv.N().handleScale.pinch) return;
          const s = 5 * (i - this.Um);
          (this.Um = i), this.sn().Od(t._t, s);
        }
        Ap(t) {
          (this.$m = !1), (this.qm = null !== this.jm), this.hw();
          const i = this.sn().Rd();
          null !== this.jm &&
            i.It() &&
            ((this.Ym = { x: i.ni(), y: i.si() }),
            (this.jm = { x: t.localX, y: t.localY }));
        }
        yp(t) {
          if (null === this.Zm) return;
          const i = t.localX,
            s = t.localY;
          if (null === this.jm) this.ow(t);
          else {
            this.qm = !1;
            const e = d(this.Ym),
              h = e.x + (i - this.jm.x),
              n = e.y + (s - this.jm.y);
            this.rw(h, n, t);
          }
        }
        Rp(t) {
          0 === this.am().N().trackingMode.exitMode && (this.qm = !0),
            this.pw(),
            this._w(t);
        }
        Qs(t, i) {
          const s = this.Zm;
          return null === s ? null : Ri(s, t, i);
        }
        mw(t, i) {
          d("left" === i ? this.Lm : this.zm).Cm(
            e.size({ width: t, height: this.Qv.height })
          );
        }
        cv() {
          return this.Qv;
        }
        Cm(t) {
          (0, e.equalSizes)(this.Qv, t) ||
            ((this.Qv = t),
            (this.rm = !0),
            this.fm.resizeCanvasElement(t),
            this.pm.resizeCanvasElement(t),
            (this.rm = !1),
            (this.Xm.style.width = t.width + "px"),
            (this.Xm.style.height = t.height + "px"));
        }
        ww() {
          const t = d(this.Zm);
          t.q_(t.K_()), t.q_(t.Z_());
          for (const i of t.Cl())
            if (t.Zs(i)) {
              const s = i.Ft();
              null !== s && t.q_(s), i.Nn();
            }
          for (const i of t.vu()) i.Nn();
        }
        dv() {
          return this.fm.bitmapSize;
        }
        fv(t, i, s, e) {
          const h = this.dv();
          if (
            h.width > 0 &&
            h.height > 0 &&
            (t.drawImage(this.fm.canvasElement, i, s), e)
          ) {
            const e = this.pm.canvasElement;
            null !== t && t.drawImage(e, i, s);
          }
        }
        km(t) {
          if (0 === t) return;
          if (null === this.Zm) return;
          t > 1 && this.ww(),
            null !== this.Lm && this.Lm.km(t),
            null !== this.zm && this.zm.km(t);
          const i = { colorSpace: this.qv.N().layout.colorSpace };
          if (1 !== t) {
            this.fm.applySuggestedBitmapSize();
            const t = (0, e.tryCreateCanvasRenderingTarget2D)(this.fm, i);
            null !== t &&
              (t.useBitmapCoordinateSpace((t) => {
                this.Tm(t);
              }),
              this.Zm &&
                (this.Mw(t, Ls), this.gw(t), this.Mw(t, Ps), this.Mw(t, Is)));
          }
          this.pm.applySuggestedBitmapSize();
          const s = (0, e.tryCreateCanvasRenderingTarget2D)(this.pm, i);
          null !== s &&
            (s.useBitmapCoordinateSpace(({ context: t, bitmapSize: i }) => {
              t.clearRect(0, 0, i.width, i.height);
            }),
            this.bw(s),
            this.Mw(s, qs),
            this.Mw(s, Is));
        }
        Sw() {
          return this.Lm;
        }
        xw() {
          return this.zm;
        }
        Dm(t, i) {
          this.Mw(t, i);
        }
        Gm() {
          null !== this.Zm && this.Zm.fu().u(this), (this.Zm = null);
        }
        aw(t) {
          this.lw(this.Wm, t);
        }
        lw(t, i) {
          const s = i.localX,
            e = i.localY;
          t.v() && t.p(this.sn().Et().Rc(s), { x: s, y: e }, i);
        }
        Tm({ context: t, bitmapSize: i }) {
          const { width: s, height: e } = i,
            h = this.sn(),
            n = h.$(),
            r = h.ef();
          n === r ? W(t, 0, 0, s, e, r) : D(t, 0, 0, s, e, n, r);
        }
        gw(t) {
          const i = d(this.Zm),
            s = i.pu().wr().Tt(i);
          null !== s && s.st(t, !1);
        }
        bw(t) {
          this.Cw(t, Ps, zs, this.sn().Rd());
        }
        Mw(t, i) {
          const s = d(this.Zm),
            e = s.au(),
            h = s.vu();
          for (const s of h) this.Cw(t, i, Es, s);
          for (const s of e) this.Cw(t, i, Es, s);
          for (const s of h) this.Cw(t, i, zs, s);
          for (const s of e) this.Cw(t, i, zs, s);
        }
        Cw(t, i, s, e) {
          const h = d(this.Zm),
            n = h.Qt().ou(),
            r = null !== n && n.lu === e,
            o = null !== n && r && void 0 !== n.wu ? n.wu.ie : void 0;
          ks(i, (i) => s(i, t, r, o), e, h);
        }
        nw() {
          if (null === this.Zm) return;
          const t = this.qv,
            i = this.Zm.K_().N().visible,
            s = this.Zm.Z_().N().visible;
          i ||
            null === this.Lm ||
            (this.Jm.removeChild(this.Lm.uv()), this.Lm.m(), (this.Lm = null)),
            s ||
              null === this.zm ||
              (this.Qm.removeChild(this.zm.uv()),
              this.zm.m(),
              (this.zm = null));
          const e = t.Qt().Zd();
          i &&
            null === this.Lm &&
            ((this.Lm = new Rs(this, t.N(), e, "left")),
            this.Jm.appendChild(this.Lm.uv())),
            s &&
              null === this.zm &&
              ((this.zm = new Rs(this, t.N(), e, "right")),
              this.Qm.appendChild(this.zm.uv()));
        }
        yw(t) {
          return (t.Zp && this.$m) || null !== this.jm;
        }
        rw(t, i, s) {
          (t = Math.max(0, Math.min(t, this.Qv.width - 1))),
            (i = Math.max(0, Math.min(i, this.Qv.height - 1))),
            this.sn().jd(t, i, s, d(this.Zm));
        }
        cw() {
          this.sn().Yd();
        }
        pw() {
          this.qm && ((this.jm = null), this.cw());
        }
        uw(t, i, s) {
          (this.jm = t), (this.qm = !1), this.rw(i.x, i.y, s);
          const e = this.sn().Rd();
          this.Ym = { x: e.ni(), y: e.si() };
        }
        sn() {
          return this.qv.Qt();
        }
        _w(t) {
          if (!this.Fm) return;
          const i = this.sn(),
            s = this.Sv();
          if (
            (i.iu(s, s.Pn()),
            (this.Nm = null),
            (this.Fm = !1),
            i.Hd(),
            null !== this.Km)
          ) {
            const t = performance.now(),
              s = i.Et();
            this.Km.me(s.Ac(), t), this.Km.jc(t) || i.ps(this.Km);
          }
        }
        ew() {
          this.jm = null;
        }
        hw() {
          if (this.Zm) {
            if (
              (this.sn().cs(),
              document.activeElement !== document.body &&
                document.activeElement !== document.documentElement)
            )
              d(document.activeElement).blur();
            else {
              const t = document.getSelection();
              null !== t && t.removeAllRanges();
            }
            !this.Zm.Pn().Gi() && this.sn().Et().Gi();
          }
        }
        ow(t) {
          if (null === this.Zm) return;
          const i = this.sn(),
            s = i.Et();
          if (s.Gi()) return;
          const e = this.qv.N(),
            h = e.handleScroll,
            n = e.kineticScroll;
          if (
            (!h.pressedMouseMove || t.Zp) &&
            ((!h.horzTouchDrag && !h.vertTouchDrag) || !t.Zp)
          )
            return;
          const r = this.Zm.Pn(),
            o = performance.now();
          if (
            (null !== this.Nm ||
              this.yw(t) ||
              (this.Nm = {
                x: t.clientX,
                y: t.clientY,
                Sf: o,
                kw: t.localX,
                Pw: t.localY,
              }),
            null !== this.Nm &&
              !this.Fm &&
              (this.Nm.x !== t.clientX || this.Nm.y !== t.clientY))
          ) {
            if ((t.Zp && n.touch) || (!t.Zp && n.mouse)) {
              const t = s.fl();
              (this.Km = new Ss(0.2 / t, 7 / t, 0.997, 15 / t)),
                this.Km.Fv(s.Ac(), this.Nm.Sf);
            } else this.Km = null;
            r.Gi() || i.Q_(this.Zm, r, t.localY),
              i.Fd(t.localX),
              (this.Fm = !0);
          }
          this.Fm &&
            (r.Gi() || i.tu(this.Zm, r, t.localY),
            i.Wd(t.localX),
            null !== this.Km && this.Km.Fv(s.Ac(), o));
        }
      }
      class Fs {
        constructor(t, i, s, h, n) {
          (this.xt = !0),
            (this.Qv = e.size({ width: 0, height: 0 })),
            (this.hm = () => this.km(3)),
            (this.om = "left" === t),
            (this.wd = s.Zd),
            (this.yn = i),
            (this.Tw = h),
            (this.Rw = n),
            (this.lv = document.createElement("div")),
            (this.lv.style.width = "25px"),
            (this.lv.style.height = "100%"),
            (this.lv.style.overflow = "hidden"),
            (this.fm = _s(this.lv, e.size({ width: 16, height: 16 }))),
            this.fm.subscribeSuggestedBitmapSizeChanged(this.hm);
        }
        m() {
          this.fm.unsubscribeSuggestedBitmapSizeChanged(this.hm),
            Cs(this.fm.canvasElement),
            this.fm.dispose();
        }
        uv() {
          return this.lv;
        }
        cv() {
          return this.Qv;
        }
        Cm(t) {
          (0, e.equalSizes)(this.Qv, t) ||
            ((this.Qv = t),
            this.fm.resizeCanvasElement(t),
            (this.lv.style.width = `${t.width}px`),
            (this.lv.style.height = `${t.height}px`),
            (this.xt = !0));
        }
        km(t) {
          if (t < 3 && !this.xt) return;
          if (0 === this.Qv.width || 0 === this.Qv.height) return;
          (this.xt = !1), this.fm.applySuggestedBitmapSize();
          const i = (0, e.tryCreateCanvasRenderingTarget2D)(this.fm, {
            colorSpace: this.yn.layout.colorSpace,
          });
          null !== i &&
            i.useBitmapCoordinateSpace((t) => {
              this.Tm(t), this.Rm(t);
            });
        }
        dv() {
          return this.fm.bitmapSize;
        }
        fv(t, i, s) {
          const e = this.dv();
          e.width > 0 &&
            e.height > 0 &&
            t.drawImage(this.fm.canvasElement, i, s);
        }
        Rm({
          context: t,
          bitmapSize: i,
          horizontalPixelRatio: s,
          verticalPixelRatio: e,
        }) {
          if (!this.Tw()) return;
          t.fillStyle = this.yn.timeScale.borderColor;
          const h = Math.floor(this.wd.N().S * s),
            n = Math.floor(this.wd.N().S * e),
            r = this.om ? i.width - h : 0;
          t.fillRect(r, 0, h, n);
        }
        Tm({ context: t, bitmapSize: i }) {
          W(t, 0, 0, i.width, i.height, this.Rw());
        }
      }
      function Ws(t) {
        return (i) => i.Xa?.(t) ?? [];
      }
      const Bs = Ws("normal"),
        Qs = Ws("top"),
        Ds = Ws("bottom");
      class Ks {
        constructor(t, i) {
          (this.Dw = null),
            (this.Iw = null),
            (this.M = null),
            (this.Vw = !1),
            (this.Qv = e.size({ width: 0, height: 0 })),
            (this.Bw = new m()),
            (this.im = new nt(5)),
            (this.rm = !1),
            (this.hm = () => {
              this.rm || this.qv.Qt().mr();
            }),
            (this.lm = () => {
              this.rm || this.qv.Qt().mr();
            }),
            (this.qv = t),
            (this.xu = i),
            (this.yn = t.N().layout),
            (this.Hv = document.createElement("tr")),
            (this.Ew = document.createElement("td")),
            (this.Ew.style.padding = "0"),
            (this.Aw = document.createElement("td")),
            (this.Aw.style.padding = "0"),
            (this.lv = document.createElement("td")),
            (this.lv.style.height = "25px"),
            (this.lv.style.padding = "0"),
            (this.Lw = document.createElement("div")),
            (this.Lw.style.width = "100%"),
            (this.Lw.style.height = "100%"),
            (this.Lw.style.position = "relative"),
            (this.Lw.style.overflow = "hidden"),
            this.lv.appendChild(this.Lw),
            (this.fm = _s(this.Lw, e.size({ width: 16, height: 16 }))),
            this.fm.subscribeSuggestedBitmapSizeChanged(this.hm);
          const s = this.fm.canvasElement;
          (s.style.position = "absolute"),
            (s.style.zIndex = "1"),
            (s.style.left = "0"),
            (s.style.top = "0"),
            (this.pm = _s(this.Lw, e.size({ width: 16, height: 16 }))),
            this.pm.subscribeSuggestedBitmapSizeChanged(this.lm);
          const h = this.pm.canvasElement;
          (h.style.position = "absolute"),
            (h.style.zIndex = "2"),
            (h.style.left = "0"),
            (h.style.top = "0"),
            this.Hv.appendChild(this.Ew),
            this.Hv.appendChild(this.lv),
            this.Hv.appendChild(this.Aw),
            this.zw(),
            this.qv.Qt().L_().i(this.zw.bind(this), this),
            (this.tv = new fs(this.pm.canvasElement, this, {
              xp: () => !0,
              Cp: () => !this.qv.N().handleScroll.horzTouchDrag,
            }));
        }
        m() {
          this.tv.m(),
            null !== this.Dw && this.Dw.m(),
            null !== this.Iw && this.Iw.m(),
            this.pm.unsubscribeSuggestedBitmapSizeChanged(this.lm),
            Cs(this.pm.canvasElement),
            this.pm.dispose(),
            this.fm.unsubscribeSuggestedBitmapSizeChanged(this.hm),
            Cs(this.fm.canvasElement),
            this.fm.dispose();
        }
        uv() {
          return this.Hv;
        }
        Ow() {
          return this.Dw;
        }
        Nw() {
          return this.Iw;
        }
        zp(t) {
          if (this.Vw) return;
          this.Vw = !0;
          const i = this.qv.Qt();
          !i.Et().Gi() &&
            this.qv.N().handleScale.axisPressedMouseMove.time &&
            i.zd(t.localX);
        }
        Ap(t) {
          this.zp(t);
        }
        Op() {
          const t = this.qv.Qt();
          !t.Et().Gi() &&
            this.Vw &&
            ((this.Vw = !1),
            this.qv.N().handleScale.axisPressedMouseMove.time && t.$d());
        }
        Pp(t) {
          const i = this.qv.Qt();
          !i.Et().Gi() &&
            this.qv.N().handleScale.axisPressedMouseMove.time &&
            i.Ud(t.localX);
        }
        yp(t) {
          this.Pp(t);
        }
        Ip() {
          this.Vw = !1;
          const t = this.qv.Qt();
          (t.Et().Gi() && !this.qv.N().handleScale.axisPressedMouseMove.time) ||
            t.$d();
        }
        Rp() {
          this.Ip();
        }
        up() {
          this.qv.N().handleScale.axisDoubleClickReset.time &&
            this.qv.Qt().ws();
        }
        ap() {
          this.up();
        }
        wp() {
          this.qv.Qt().N().handleScale.axisPressedMouseMove.time && this.Em(1);
        }
        Yp() {
          this.Em(0);
        }
        cv() {
          return this.Qv;
        }
        Fw() {
          return this.Bw;
        }
        Ww(t, i, s) {
          (0, e.equalSizes)(this.Qv, t) ||
            ((this.Qv = t),
            (this.rm = !0),
            this.fm.resizeCanvasElement(t),
            this.pm.resizeCanvasElement(t),
            (this.rm = !1),
            (this.lv.style.width = `${t.width}px`),
            (this.lv.style.height = `${t.height}px`),
            this.Bw.p(t)),
            null !== this.Dw &&
              this.Dw.Cm(e.size({ width: i, height: t.height })),
            null !== this.Iw &&
              this.Iw.Cm(e.size({ width: s, height: t.height }));
        }
        Hw() {
          const t = this.Uw();
          return Math.ceil(t.S + t.C + t.k + t.A + t.I + t.$w);
        }
        kt() {
          this.qv.Qt().Et().El();
        }
        dv() {
          return this.fm.bitmapSize;
        }
        fv(t, i, s, e) {
          const h = this.dv();
          if (
            h.width > 0 &&
            h.height > 0 &&
            (t.drawImage(this.fm.canvasElement, i, s), e)
          ) {
            const e = this.pm.canvasElement;
            t.drawImage(e, i, s);
          }
        }
        km(t) {
          if (0 === t) return;
          const i = { colorSpace: this.yn.colorSpace };
          if (1 !== t) {
            this.fm.applySuggestedBitmapSize();
            const s = (0, e.tryCreateCanvasRenderingTarget2D)(this.fm, i);
            null !== s &&
              (s.useBitmapCoordinateSpace((t) => {
                this.Tm(t), this.Rm(t), this.jw(s, Ds);
              }),
              this.Im(s),
              this.jw(s, Bs)),
              null !== this.Dw && this.Dw.km(t),
              null !== this.Iw && this.Iw.km(t);
          }
          this.pm.applySuggestedBitmapSize();
          const s = (0, e.tryCreateCanvasRenderingTarget2D)(this.pm, i);
          null !== s &&
            (s.useBitmapCoordinateSpace(({ context: t, bitmapSize: i }) => {
              t.clearRect(0, 0, i.width, i.height);
            }),
            this.qw([...this.qv.Qt().Jn(), this.qv.Qt().Rd()], s),
            this.jw(s, Qs));
        }
        jw(t, i) {
          const s = this.qv.Qt().Jn();
          for (const e of s) ks(i, (i) => Es(i, t, !1, void 0), e, void 0);
          for (const e of s) ks(i, (i) => zs(i, t, !1, void 0), e, void 0);
        }
        Tm({ context: t, bitmapSize: i }) {
          W(t, 0, 0, i.width, i.height, this.qv.Qt().ef());
        }
        Rm({ context: t, bitmapSize: i, verticalPixelRatio: s }) {
          if (this.qv.N().timeScale.borderVisible) {
            t.fillStyle = this.Yw();
            const e = Math.max(1, Math.floor(this.Uw().S * s));
            t.fillRect(0, 0, i.width, e);
          }
        }
        Im(t) {
          const i = this.qv.Qt().Et(),
            s = i.El();
          if (!s || 0 === s.length) return;
          const e = this.xu.maxTickMarkWeight(s),
            h = this.Uw(),
            n = i.N();
          n.borderVisible &&
            n.ticksVisible &&
            t.useBitmapCoordinateSpace(
              ({
                context: t,
                horizontalPixelRatio: i,
                verticalPixelRatio: e,
              }) => {
                (t.strokeStyle = this.Yw()), (t.fillStyle = this.Yw());
                const n = Math.max(1, Math.floor(i)),
                  r = Math.floor(0.5 * i);
                t.beginPath();
                const o = Math.round(h.C * e);
                for (let e = s.length; e--; ) {
                  const h = Math.round(s[e].coord * i);
                  t.rect(h - r, 0, n, o);
                }
                t.fill();
              }
            ),
            t.useMediaCoordinateSpace(({ context: t }) => {
              const i = h.S + h.C + h.A + h.k / 2;
              (t.textAlign = "center"),
                (t.textBaseline = "middle"),
                (t.fillStyle = this.H()),
                (t.font = this.Sm());
              for (const h of s)
                if (h.weight < e) {
                  const s = h.needAlignCoordinate
                    ? this.Kw(t, h.coord, h.label)
                    : h.coord;
                  t.fillText(h.label, s, i);
                }
              this.qv.N().timeScale.allowBoldLabels && (t.font = this.Zw());
              for (const h of s)
                if (h.weight >= e) {
                  const s = h.needAlignCoordinate
                    ? this.Kw(t, h.coord, h.label)
                    : h.coord;
                  t.fillText(h.label, s, i);
                }
            });
        }
        Kw(t, i, s) {
          const e = this.im.Ii(t, s),
            h = e / 2,
            n = Math.floor(i - h) + 0.5;
          return (
            n < 0
              ? (i += Math.abs(0 - n))
              : n + e > this.Qv.width &&
                (i -= Math.abs(this.Qv.width - (n + e))),
            i
          );
        }
        qw(t, i) {
          const s = this.Uw();
          for (const e of t) for (const t of e.dn()) t.Tt().st(i, s);
        }
        Yw() {
          return this.qv.N().timeScale.borderColor;
        }
        H() {
          return this.yn.textColor;
        }
        F() {
          return this.yn.fontSize;
        }
        Sm() {
          return _(this.F(), this.yn.fontFamily);
        }
        Zw() {
          return _(this.F(), this.yn.fontFamily, "bold");
        }
        Uw() {
          null === this.M &&
            (this.M = {
              S: 1,
              L: NaN,
              A: NaN,
              I: NaN,
              tn: NaN,
              C: 5,
              k: NaN,
              P: "",
              Qi: new nt(),
              $w: 0,
            });
          const t = this.M,
            i = this.Sm();
          if (t.P !== i) {
            const s = this.F();
            (t.k = s),
              (t.P = i),
              (t.A = (3 * s) / 12),
              (t.I = (3 * s) / 12),
              (t.tn = (9 * s) / 12),
              (t.L = 0),
              (t.$w = (4 * s) / 12),
              t.Qi.Os();
          }
          return this.M;
        }
        Em(t) {
          this.lv.style.cursor = 1 === t ? "ew-resize" : "default";
        }
        zw() {
          const t = this.qv.Qt(),
            i = t.N();
          i.leftPriceScale.visible ||
            null === this.Dw ||
            (this.Ew.removeChild(this.Dw.uv()), this.Dw.m(), (this.Dw = null)),
            i.rightPriceScale.visible ||
              null === this.Iw ||
              (this.Aw.removeChild(this.Iw.uv()),
              this.Iw.m(),
              (this.Iw = null));
          const s = { Zd: this.qv.Qt().Zd() },
            e = () =>
              i.leftPriceScale.borderVisible && t.Et().N().borderVisible,
            h = () => t.ef();
          i.leftPriceScale.visible &&
            null === this.Dw &&
            ((this.Dw = new Fs("left", i, s, e, h)),
            this.Ew.appendChild(this.Dw.uv())),
            i.rightPriceScale.visible &&
              null === this.Iw &&
              ((this.Iw = new Fs("right", i, s, e, h)),
              this.Aw.appendChild(this.Iw.uv()));
        }
      }
      const Vs =
        !!ls &&
        !!navigator.userAgentData &&
        navigator.userAgentData.brands.some((t) =>
          t.brand.includes("Chromium")
        ) &&
        !!ls &&
        (navigator?.userAgentData?.platform
          ? "Windows" === navigator.userAgentData.platform
          : navigator.userAgent.toLowerCase().indexOf("win") >= 0);
      class $s {
        constructor(t, i, s) {
          var e;
          (this.Gw = []),
            (this.Xw = []),
            (this.Jw = 0),
            (this.ho = 0),
            (this.C_ = 0),
            (this.Qw = 0),
            (this.tM = 0),
            (this.iM = null),
            (this.nM = !1),
            (this.Wm = new m()),
            (this.Hm = new m()),
            (this.pd = new m()),
            (this.sM = null),
            (this.eM = null),
            (this.jv = t),
            (this.yn = i),
            (this.xu = s),
            (this.Hv = document.createElement("div")),
            this.Hv.classList.add("tv-lightweight-charts"),
            (this.Hv.style.overflow = "hidden"),
            (this.Hv.style.direction = "ltr"),
            (this.Hv.style.width = "100%"),
            (this.Hv.style.height = "100%"),
            ((e = this.Hv).style.userSelect = "none"),
            (e.style.webkitUserSelect = "none"),
            (e.style.msUserSelect = "none"),
            (e.style.MozUserSelect = "none"),
            (e.style.webkitTapHighlightColor = "transparent"),
            (this.rM = document.createElement("table")),
            this.rM.setAttribute("cellspacing", "0"),
            this.Hv.appendChild(this.rM),
            (this.hM = this.aM.bind(this)),
            As(this.yn) && this.lM(!0),
            (this.sn = new $i(this.md.bind(this), this.yn, s)),
            this.Qt().Dd().i(this.oM.bind(this), this),
            (this._M = new Ks(this, this.xu)),
            this.rM.appendChild(this._M.uv());
          const h = i.autoSize && this.uM();
          let n = this.yn.width,
            r = this.yn.height;
          if (h || 0 === n || 0 === r) {
            const i = t.getBoundingClientRect();
            (n = n || i.width), (r = r || i.height);
          }
          this.cM(n, r),
            this.dM(),
            t.appendChild(this.Hv),
            this.fM(),
            this.sn.Et().Zc().i(this.sn.Pa.bind(this.sn), this),
            this.sn.L_().i(this.sn.Pa.bind(this.sn), this);
        }
        Qt() {
          return this.sn;
        }
        N() {
          return this.yn;
        }
        rv() {
          return this.Gw;
        }
        pM() {
          return this._M;
        }
        m() {
          this.lM(!1),
            0 !== this.Jw && window.cancelAnimationFrame(this.Jw),
            this.sn.Dd().u(this),
            this.sn.Et().Zc().u(this),
            this.sn.L_().u(this),
            this.sn.m();
          for (const t of this.Gw)
            this.rM.removeChild(t.uv()), t.dw().u(this), t.fw().u(this), t.m();
          this.Gw = [];
          for (const t of this.Xw) this.vM(t);
          (this.Xw = []),
            d(this._M).m(),
            null !== this.Hv.parentElement &&
              this.Hv.parentElement.removeChild(this.Hv),
            this.pd.m(),
            this.Wm.m(),
            this.Hm.m(),
            this.mM();
        }
        cM(t, i, s = !1) {
          if (this.ho === i && this.C_ === t) return;
          const h = (function (t) {
            const i = Math.floor(t.width),
              s = Math.floor(t.height);
            return e.size({ width: i - (i % 2), height: s - (s % 2) });
          })(e.size({ width: t, height: i }));
          (this.ho = h.height), (this.C_ = h.width);
          const n = this.ho + "px",
            r = this.C_ + "px";
          if (
            (this.wM() ||
              ((d(this.Hv).style.height = n), (d(this.Hv).style.width = r)),
            (this.rM.style.height = n),
            (this.rM.style.width = r),
            s)
          ) {
            0 !== this.Jw &&
              (window.cancelAnimationFrame(this.Jw), (this.Jw = 0)),
              (this.nM = !1);
            const t = X.ys();
            null !== this.iM && (t.Ss(this.iM), (this.iM = null)),
              this.MM(t, performance.now());
          } else this.sn.Pa();
        }
        km(t) {
          void 0 === t && (t = X.ys());
          for (let i = 0; i < this.Gw.length; i++) this.Gw[i].km(t._s(i).rs);
          this.yn.timeScale.visible && this._M.km(t.ls());
        }
        vr(t) {
          const i = As(this.yn);
          this.sn.vr(t);
          const s = As(this.yn);
          s !== i && this.lM(s),
            t.layout?.panes && this.gM(),
            this.fM(),
            this.bM(t);
        }
        dw() {
          return this.Wm;
        }
        fw() {
          return this.Hm;
        }
        Dd() {
          return this.pd;
        }
        SM(t = !1) {
          null !== this.iM &&
            (this.MM(this.iM, performance.now()), (this.iM = null));
          const i = this.xM(null),
            s = document.createElement("canvas");
          (s.width = i.width), (s.height = i.height);
          const e = d(s.getContext("2d"));
          return this.xM(e, t), s;
        }
        CM(t) {
          return ("left" !== t || this.yM()) && ("right" !== t || this.kM())
            ? 0 === this.Gw.length
              ? 0
              : d("left" === t ? this.Gw[0].Sw() : this.Gw[0].xw()).ym()
            : 0;
        }
        wM() {
          return this.yn.autoSize && null !== this.sM;
        }
        vv() {
          return this.Hv;
        }
        PM(t) {
          (this.eM = t),
            this.eM
              ? this.vv().style.setProperty("cursor", t)
              : this.vv().style.removeProperty("cursor");
        }
        TM() {
          return this.eM;
        }
        RM(t) {
          return c(this.Gw[t]).cv();
        }
        gM() {
          this.Xw.forEach((t) => {
            t.kt();
          });
        }
        bM(t) {
          (void 0 !== t.autoSize ||
            !this.sM ||
            (void 0 === t.width && void 0 === t.height)) &&
            (t.autoSize && !this.sM && this.uM(),
            !1 === t.autoSize && null !== this.sM && this.mM(),
            t.autoSize ||
              (void 0 === t.width && void 0 === t.height) ||
              this.cM(t.width || this.C_, t.height || this.ho));
        }
        xM(t, i) {
          let s = 0,
            h = 0;
          const n = this.Gw[0],
            r = (s, e) => {
              let h = 0;
              for (let n = 0; n < this.Gw.length; n++) {
                const r = this.Gw[n],
                  o = d("left" === s ? r.Sw() : r.xw()),
                  l = o.dv();
                if (
                  (null !== t && o.fv(t, e, h, i),
                  (h += l.height),
                  n < this.Gw.length - 1)
                ) {
                  const i = this.Xw[n],
                    s = i.dv();
                  null !== t && i.fv(t, e, h), (h += s.height);
                }
              }
            };
          this.yM() && (r("left", 0), (s += d(n.Sw()).dv().width));
          for (let e = 0; e < this.Gw.length; e++) {
            const n = this.Gw[e],
              r = n.dv();
            if (
              (null !== t && n.fv(t, s, h, i),
              (h += r.height),
              e < this.Gw.length - 1)
            ) {
              const i = this.Xw[e],
                n = i.dv();
              null !== t && i.fv(t, s, h), (h += n.height);
            }
          }
          (s += n.dv().width),
            this.kM() && (r("right", s), (s += d(n.xw()).dv().width));
          const o = (i, s, e) => {
            d("left" === i ? this._M.Ow() : this._M.Nw()).fv(d(t), s, e);
          };
          if (this.yn.timeScale.visible) {
            const s = this._M.dv();
            if (null !== t) {
              let e = 0;
              this.yM() && (o("left", e, h), (e = d(n.Sw()).dv().width)),
                this._M.fv(t, e, h, i),
                (e += s.width),
                this.kM() && o("right", e, h);
            }
            h += s.height;
          }
          return e.size({ width: s, height: h });
        }
        DM() {
          let t = 0,
            i = 0,
            s = 0;
          for (const e of this.Gw)
            this.yM() &&
              (i = Math.max(
                i,
                d(e.Sw()).bm(),
                this.yn.leftPriceScale.minimumWidth
              )),
              this.kM() &&
                (s = Math.max(
                  s,
                  d(e.xw()).bm(),
                  this.yn.rightPriceScale.minimumWidth
                )),
              (t += e.z_());
          (i = ds(i)), (s = ds(s));
          const h = this.C_,
            n = this.ho,
            r = Math.max(h - i - s, 0),
            o = 1 * this.Xw.length,
            l = this.yn.timeScale.visible;
          let a = l
            ? Math.max(this._M.Hw(), this.yn.timeScale.minimumHeight)
            : 0;
          var u;
          a = (u = a) + (u % 2);
          const c = o + a,
            f = n < c ? 0 : n - c,
            m = f / t;
          let p = 0;
          const v = window.devicePixelRatio || 1;
          for (let t = 0; t < this.Gw.length; ++t) {
            const h = this.Gw[t];
            h.iw(this.sn.Zn()[t]);
            let n = 0,
              o = 0;
            (o =
              t === this.Gw.length - 1
                ? Math.ceil((f - p) * v) / v
                : Math.round(h.z_() * m * v) / v),
              (n = Math.max(o, 2)),
              (p += n),
              h.Cm(e.size({ width: r, height: n })),
              this.yM() && h.mw(i, "left"),
              this.kM() && h.mw(s, "right"),
              h.Sv() && this.sn.Id(h.Sv(), n);
          }
          this._M.Ww(
            e.size({ width: l ? r : 0, height: a }),
            l ? i : 0,
            l ? s : 0
          ),
            this.sn.N_(r),
            this.Qw !== i && (this.Qw = i),
            this.tM !== s && (this.tM = s);
        }
        lM(t) {
          t
            ? this.Hv.addEventListener("wheel", this.hM, { passive: !1 })
            : this.Hv.removeEventListener("wheel", this.hM);
        }
        IM(t) {
          switch (t.deltaMode) {
            case t.DOM_DELTA_PAGE:
              return 120;
            case t.DOM_DELTA_LINE:
              return 32;
          }
          return Vs ? 1 / window.devicePixelRatio : 1;
        }
        aM(t) {
          if (
            !(
              (0 !== t.deltaX && this.yn.handleScroll.mouseWheel) ||
              (0 !== t.deltaY && this.yn.handleScale.mouseWheel)
            )
          )
            return;
          const i = this.IM(t),
            s = (i * t.deltaX) / 100,
            e = (-i * t.deltaY) / 100;
          if (
            (t.cancelable && t.preventDefault(),
            0 !== e && this.yn.handleScale.mouseWheel)
          ) {
            const i = Math.sign(e) * Math.min(1, Math.abs(e)),
              s = t.clientX - this.Hv.getBoundingClientRect().left;
            this.Qt().Od(s, i);
          }
          0 !== s && this.yn.handleScroll.mouseWheel && this.Qt().Nd(-80 * s);
        }
        MM(t, i) {
          const s = t.ls();
          3 === s && this.VM(),
            (3 !== s && 2 !== s) ||
              (this.BM(t),
              this.EM(t, i),
              this._M.kt(),
              this.Gw.forEach((t) => {
                t.sw();
              }),
              3 === this.iM?.ls() &&
                (this.iM.Ss(t),
                this.VM(),
                this.BM(this.iM),
                this.EM(this.iM, i),
                (t = this.iM),
                (this.iM = null))),
            this.km(t);
        }
        EM(t, i) {
          for (const s of t.bs()) this.xs(s, i);
        }
        BM(t) {
          const i = this.sn.Zn();
          for (let s = 0; s < i.length; s++) t._s(s).hs && i[s].ru();
        }
        xs(t, i) {
          const s = this.sn.Et();
          switch (t.ds) {
            case 0:
              s.Xc();
              break;
            case 1:
              s.Jc(t.Wt);
              break;
            case 2:
              s.Ms(t.Wt);
              break;
            case 3:
              s.gs(t.Wt);
              break;
            case 4:
              s.Oc();
              break;
            case 5:
              t.Wt.jc(i) || s.gs(t.Wt.qc(i));
          }
        }
        md(t) {
          null !== this.iM ? this.iM.Ss(t) : (this.iM = t),
            this.nM ||
              ((this.nM = !0),
              (this.Jw = window.requestAnimationFrame((t) => {
                if (((this.nM = !1), (this.Jw = 0), null !== this.iM)) {
                  const i = this.iM;
                  (this.iM = null), this.MM(i, t);
                  for (const s of i.bs())
                    if (5 === s.ds && !s.Wt.jc(t)) {
                      this.Qt().ps(s.Wt);
                      break;
                    }
                }
              })));
        }
        VM() {
          this.dM();
        }
        vM(t) {
          this.rM.removeChild(t.uv()), t.m();
        }
        dM() {
          const t = this.sn.Zn(),
            i = t.length,
            s = this.Gw.length;
          for (let t = i; t < s; t++) {
            const t = c(this.Gw.pop());
            this.rM.removeChild(t.uv()), t.dw().u(this), t.fw().u(this), t.m();
            const i = this.Xw.pop();
            void 0 !== i && this.vM(i);
          }
          for (let e = s; e < i; e++) {
            const i = new Os(this, t[e]);
            if (
              (i.dw().i(this.AM.bind(this, i), this),
              i.fw().i(this.LM.bind(this, i), this),
              this.Gw.push(i),
              e > 0)
            ) {
              const t = new ws(this, e - 1, e);
              this.Xw.push(t), this.rM.insertBefore(t.uv(), this._M.uv());
            }
            this.rM.insertBefore(i.uv(), this._M.uv());
          }
          for (let s = 0; s < i; s++) {
            const i = t[s],
              e = this.Gw[s];
            e.Sv() !== i ? e.iw(i) : e.tw();
          }
          this.fM(), this.DM();
        }
        zM(t, i, s, e) {
          const h = new Map();
          let n;
          if (
            (null !== t &&
              this.sn.Jn().forEach((i) => {
                const s = i.Un().Hn(t);
                null !== s && h.set(i, s);
              }),
            null !== t)
          ) {
            const i = this.sn.Et().en(t)?.originalTime;
            void 0 !== i && (n = i);
          }
          const r = this.Qt().ou(),
            o = this.OM(e),
            l = (function (t, i) {
              const s = null !== t && t.lu instanceof jt ? t.lu : void 0,
                e = t?.wu?.te,
                h = void 0 !== i && -1 !== i ? i : void 0;
              return null === t || void 0 === t.ee
                ? { NM: s, FM: e }
                : {
                    NM: s,
                    FM: e,
                    WM: {
                      ds: t.ee,
                      HM:
                        ((n = t.lu),
                        (r = t.ee),
                        n instanceof _i
                          ? "pane-primitive"
                          : "marker" === r || "primitive" === r
                          ? "series-primitive"
                          : "series"),
                      UM: cs(t.ee, e),
                      U_: s,
                      $M: e,
                      jM: h,
                    },
                  };
              var n, r;
            })(r, o);
          return {
            Qr: n,
            $n: t ?? void 0,
            qM: i ?? void 0,
            jM: -1 !== o ? o : void 0,
            NM: l.NM,
            YM: h,
            FM: l.FM,
            WM: l.WM,
            KM: s ?? void 0,
          };
        }
        OM(t) {
          let i = -1;
          if (t) i = this.Gw.indexOf(t);
          else {
            const t = this.Qt().Rd().Kn();
            null !== t && (i = this.Qt().Zn().indexOf(t));
          }
          return i;
        }
        AM(t, i, s, e) {
          this.Wm.p(() => this.zM(i, s, e, t));
        }
        LM(t, i, s, e) {
          this.Hm.p(() => this.zM(i, s, e, t));
        }
        oM(t, i, s) {
          this.PM(this.Qt().ou()?.mu ?? null),
            this.pd.p(() => this.zM(t, i, s));
        }
        fM() {
          const t = this.yn.timeScale.visible ? "" : "none";
          this._M.uv().style.display = t;
        }
        yM() {
          return this.Gw[0].Sv().K_().N().visible;
        }
        kM() {
          return this.Gw[0].Sv().Z_().N().visible;
        }
        uM() {
          return (
            "ResizeObserver" in window &&
            ((this.sM = new ResizeObserver((t) => {
              const i = t[t.length - 1];
              if (!i) return;
              const s = i.contentRect.width,
                e = i.contentRect.height;
              this.cM(s, e, !0);
            })),
            this.sM.observe(this.jv, { box: "border-box" }),
            !0)
          );
        }
        mM() {
          null !== this.sM && this.sM.disconnect(), (this.sM = null);
        }
      }
      function As(t) {
        return Boolean(t.handleScroll.mouseWheel || t.handleScale.mouseWheel);
      }
      function Zs(t) {
        return void 0 === t.open && void 0 === t.value;
      }
      function Hs(t) {
        return (
          (function (t) {
            return void 0 !== t.open;
          })(t) ||
          (function (t) {
            return void 0 !== t.value;
          })(t)
        );
      }
      function Gs(t, i, s, e) {
        const h = s.value,
          n = { $n: i, wt: t, Wt: [h, h, h, h], Qr: e };
        return void 0 !== s.color && (n.R = s.color), n;
      }
      function Ys(t, i, s, e) {
        const h = s.value,
          n = { $n: i, wt: t, Wt: [h, h, h, h], Qr: e };
        return (
          void 0 !== s.lineColor && (n.vt = s.lineColor),
          void 0 !== s.topColor && (n.ah = s.topColor),
          void 0 !== s.bottomColor && (n.oh = s.bottomColor),
          n
        );
      }
      function Us(t, i, s, e) {
        const h = s.value,
          n = { $n: i, wt: t, Wt: [h, h, h, h], Qr: e };
        return (
          void 0 !== s.topLineColor && (n._h = s.topLineColor),
          void 0 !== s.bottomLineColor && (n.uh = s.bottomLineColor),
          void 0 !== s.topFillColor1 && (n.dh = s.topFillColor1),
          void 0 !== s.topFillColor2 && (n.fh = s.topFillColor2),
          void 0 !== s.bottomFillColor1 && (n.ph = s.bottomFillColor1),
          void 0 !== s.bottomFillColor2 && (n.mh = s.bottomFillColor2),
          n
        );
      }
      function js(t, i, s, e) {
        const h = { $n: i, wt: t, Wt: [s.open, s.high, s.low, s.close], Qr: e };
        return void 0 !== s.color && (h.R = s.color), h;
      }
      function Xs(t, i, s, e) {
        const h = { $n: i, wt: t, Wt: [s.open, s.high, s.low, s.close], Qr: e };
        return (
          void 0 !== s.color && (h.R = s.color),
          void 0 !== s.borderColor && (h.Ht = s.borderColor),
          void 0 !== s.wickColor && (h.hh = s.wickColor),
          h
        );
      }
      function Js(t, i, s, e, h) {
        const n = c(h)(s),
          r = Math.max(...n),
          o = Math.min(...n),
          l = n[n.length - 1],
          a = [l, r, o, l],
          { time: u, color: d, ...f } = s;
        return { $n: i, wt: t, Wt: a, Qr: e, ue: f, R: d };
      }
      function te(t) {
        return void 0 !== t.Wt;
      }
      function ie(t, i) {
        return void 0 !== i.customValues && (t.ZM = i.customValues), t;
      }
      function se(t) {
        return (i, s, e, h, n, r) =>
          (function (t, i) {
            return i ? i(t) : Zs(t);
          })(e, r)
            ? ie({ wt: i, $n: s, Qr: h }, e)
            : ie(t(i, s, e, h, n), e);
      }
      function ee(t) {
        return {
          Candlestick: se(Xs),
          Bar: se(js),
          Area: se(Ys),
          Baseline: se(Us),
          Histogram: se(Gs),
          Line: se(Gs),
          Custom: se(Js),
        }[t];
      }
      function he(t) {
        return { $n: 0, GM: new Map(), za: t };
      }
      function ne(t, i) {
        if (void 0 !== t && 0 !== t.length)
          return { XM: i.key(t[0].wt), JM: i.key(t[t.length - 1].wt) };
      }
      function re(t) {
        let i;
        return (
          t.forEach((t) => {
            void 0 === i && (i = t.Qr);
          }),
          c(i)
        );
      }
      class oe {
        constructor(t) {
          (this.QM = new Map()),
            (this.tg = new Map()),
            (this.ig = new Map()),
            (this.ng = []),
            (this.xu = t);
        }
        m() {
          this.QM.clear(), this.tg.clear(), this.ig.clear(), (this.ng = []);
        }
        sg(t, i) {
          let s = 0 !== this.QM.size,
            e = !1;
          const h = this.tg.get(t);
          if (void 0 !== h)
            if (1 === this.tg.size) (s = !1), (e = !0), this.QM.clear();
            else for (const i of this.ng) i.pointData.GM.delete(t) && (e = !0);
          let n = [];
          if (0 !== i.length) {
            const s = i.map((t) => t.time),
              h = this.xu.createConverterToInternalObj(i),
              r = ee(t.bh()),
              o = t.ll(),
              l = t.ol();
            n = i.map((i, n) => {
              const a = h(i.time),
                u = this.xu.key(a);
              let c = this.QM.get(u);
              void 0 === c && ((c = he(a)), this.QM.set(u, c), (e = !0));
              const d = r(a, c.$n, i, s[n], o, l);
              return c.GM.set(t, d), d;
            });
          }
          s && this.eg(), this.rg(t, n);
          let r = -1;
          if (e) {
            const t = [];
            this.QM.forEach((i) => {
              t.push({
                timeWeight: 0,
                time: i.za,
                pointData: i,
                originalTime: re(i.GM),
              });
            }),
              t.sort((t, i) => this.xu.key(t.time) - this.xu.key(i.time)),
              (r = this.hg(t));
          }
          return this.ag(
            t,
            r,
            (function (t, i, s) {
              const e = ne(t, s),
                h = ne(i, s);
              if (void 0 !== e && void 0 !== h)
                return { lg: !1, Ia: e.JM >= h.JM && e.XM >= h.XM };
            })(this.tg.get(t), h, this.xu)
          );
        }
        Jd(t) {
          return this.sg(t, []);
        }
        og(t, i, s) {
          if (s && t.Na())
            throw new Error(
              "Historical updates are not supported when conflation is enabled. Conflation requires data to be processed in order."
            );
          const e = i;
          !(function (t) {
            void 0 === t.Qr && (t.Qr = t.time);
          })(e),
            this.xu.preprocessData(i);
          const h = this.xu.createConverterToInternalObj([i])(i.time),
            n = this.ig.get(t);
          if (!s && void 0 !== n && this.xu.key(h) < this.xu.key(n))
            throw new Error(
              `Cannot update oldest data, last time=${n}, new time=${h}`
            );
          let r = this.QM.get(this.xu.key(h));
          if (s && void 0 === r)
            throw new Error(
              "Cannot update non-existing data point when historicalUpdate is true"
            );
          const o = void 0 === r;
          void 0 === r && ((r = he(h)), this.QM.set(this.xu.key(h), r));
          const l = ee(t.bh()),
            a = t.ll(),
            u = t.ol(),
            c = l(h, r.$n, i, e.Qr, a, u),
            d = !s && !o && void 0 !== n && this.xu.key(h) === this.xu.key(n);
          r.GM.set(t, c),
            s
              ? this._g(t, c, r.$n)
              : d && t.Na() && te(c)
              ? (t.Rr(c), this.ug(t, c))
              : this.ug(t, c);
          const f = { Ia: te(c), lg: s };
          if (!o) return this.ag(t, -1, f);
          const m = {
              timeWeight: 0,
              time: r.za,
              pointData: r,
              originalTime: re(r.GM),
            },
            p = kt(
              this.ng,
              this.xu.key(m.time),
              (t, i) => this.xu.key(t.time) < i
            );
          this.ng.splice(p, 0, m);
          for (let t = p; t < this.ng.length; ++t) le(this.ng[t].pointData, t);
          return this.xu.fillWeightsForPoints(this.ng, p), this.ag(t, p, f);
        }
        cg(t, i) {
          const s = this.tg.get(t);
          if (void 0 === s || i <= 0) return [[], this.dg()];
          i = Math.min(i, s.length);
          const e = s.splice(-i).reverse();
          0 === s.length
            ? this.ig.delete(t)
            : this.ig.set(t, s[s.length - 1].wt);
          for (const i of e) {
            const s = this.QM.get(this.xu.key(i.wt));
            if (s && (s.GM.delete(t), 0 === s.GM.size)) {
              this.QM.delete(this.xu.key(s.za)), this.ng.splice(s.$n, 1);
              for (let t = s.$n; t < this.ng.length; ++t)
                le(this.ng[t].pointData, t);
            }
          }
          return [e, this.ag(t, this.ng.length - 1, { lg: !1, Ia: !1 })];
        }
        ug(t, i) {
          let s = this.tg.get(t);
          void 0 === s && ((s = []), this.tg.set(t, s));
          const e = 0 !== s.length ? s[s.length - 1] : null;
          null === e || this.xu.key(i.wt) > this.xu.key(e.wt)
            ? te(i) && s.push(i)
            : te(i)
            ? (s[s.length - 1] = i)
            : s.splice(-1, 1),
            this.ig.set(t, i.wt);
        }
        _g(t, i, s) {
          const e = this.tg.get(t);
          if (void 0 === e) return;
          const h = kt(e, s, (t, i) => t.$n < i);
          te(i) ? (e[h] = i) : e.splice(h, 1);
        }
        rg(t, i) {
          0 !== i.length
            ? (this.tg.set(t, i.filter(te)), this.ig.set(t, i[i.length - 1].wt))
            : (this.tg.delete(t), this.ig.delete(t));
        }
        eg() {
          for (const t of this.ng)
            0 === t.pointData.GM.size && this.QM.delete(this.xu.key(t.time));
        }
        hg(t) {
          let i = -1;
          for (let s = 0; s < this.ng.length && s < t.length; ++s) {
            const e = this.ng[s],
              h = t[s];
            if (this.xu.key(e.time) !== this.xu.key(h.time)) {
              i = s;
              break;
            }
            (h.timeWeight = e.timeWeight), le(h.pointData, s);
          }
          if (
            (-1 === i &&
              this.ng.length !== t.length &&
              (i = Math.min(this.ng.length, t.length)),
            -1 === i)
          )
            return -1;
          for (let s = i; s < t.length; ++s) le(t[s].pointData, s);
          return this.xu.fillWeightsForPoints(t, i), (this.ng = t), i;
        }
        fg() {
          if (0 === this.tg.size) return null;
          let t = 0;
          return (
            this.tg.forEach((i) => {
              0 !== i.length && (t = Math.max(t, i[i.length - 1].$n));
            }),
            t
          );
        }
        ag(t, i, s) {
          const e = this.dg();
          if (-1 !== i)
            this.tg.forEach((i, h) => {
              e.U_.set(h, { ue: i, pg: h === t ? s : void 0 });
            }),
              this.tg.has(t) || e.U_.set(t, { ue: [], pg: s }),
              (e.Et.vg = this.ng),
              (e.Et.mg = i);
          else {
            const i = this.tg.get(t);
            e.U_.set(t, { ue: i || [], pg: s });
          }
          return e;
        }
        dg() {
          return { U_: new Map(), Et: { Pc: this.fg() } };
        }
      }
      function le(t, i) {
        (t.$n = i),
          t.GM.forEach((t) => {
            t.$n = i;
          });
      }
      function ae(t, i) {
        return t._t < i;
      }
      function ue(t, i) {
        return i < t._t;
      }
      function ce(t, i, s, e) {
        return kt(t, i, ae, s, e);
      }
      function de(t, i, s, e) {
        return Nt(t, i, ue, s, e);
      }
      function fe(t, i, s) {
        return { ne: t, se: i, ee: s };
      }
      function me(t, i, s, e) {
        return t >= i - e && t <= s + e;
      }
      function pe(t, i, s, e, h, n) {
        const r = h - s,
          o = n - e;
        if (0 === r && 0 === o) return Math.hypot(t - s, i - e);
        const l = ((t - s) * r + (i - e) * o) / (r * r + o * o),
          a = Math.max(0, Math.min(1, l)),
          u = s + r * a,
          c = e + o * a;
        return Math.hypot(t - u, i - c);
      }
      const ve = [0, 0];
      function ge(t, i, s) {
        return void 0 === i || i.wt !== t.wt - 1
          ? t._t - s / 2
          : (i._t + t._t) / 2;
      }
      function be(t, i, s) {
        return void 0 === i || i.wt !== t.wt + 1
          ? t._t + s / 2
          : (t._t + i._t) / 2;
      }
      function we(t, i, s, e, h, n, r) {
        if (null === i || i.from >= i.to || 0 === t.length) return null;
        const o = h / 2 + n,
          l = ce(t, s - o, i.from, i.to),
          a = de(t, s + o, l, i.to);
        if (l >= a) return null;
        let u = Number.POSITIVE_INFINITY;
        for (let o = l; o < a; o++) {
          const l = t[o],
            a = o > i.from ? t[o - 1] : void 0,
            c = o < i.to - 1 ? t[o + 1] : void 0,
            d = ge(l, a, h) - n,
            f = be(l, c, h) + n;
          if (s < d || s > f) continue;
          r(l, ve);
          const m = ve[0],
            p = ve[1],
            v = Math.min(m, p),
            g = Math.max(m, p),
            b = v - n,
            w = g + n;
          if (e >= v && e <= g) u = Math.min(u, 0);
          else if (e >= b && e <= w) {
            const t = Math.min(Math.abs(e - v), Math.abs(g - e));
            u = Math.min(u, t);
          }
        }
        return Number.isFinite(u) ? fe(u, 0, "series-range") : null;
      }
      function Me(t, i) {
        return t.wt < i;
      }
      function ye(t, i) {
        return i < t.wt;
      }
      function Se(t, i, s) {
        const e = i.Oa(),
          h = i.bi(),
          n = kt(t, e, Me),
          r = Nt(t, h, ye);
        if (!s) return { from: n, to: r };
        let o = n,
          l = r;
        return (
          n > 0 && n < t.length && t[n].wt >= e && (o = n - 1),
          r > 0 && r < t.length && t[r - 1].wt <= h && (l = r + 1),
          { from: o, to: l }
        );
      }
      class xe {
        constructor(t, i, s) {
          (this.wg = !0),
            (this.Mg = !0),
            (this.gg = !0),
            (this.bg = []),
            (this.Sg = null),
            (this.xg = -1),
            (this.ae = t),
            (this.le = i),
            (this.Cg = s);
        }
        kt(t) {
          (this.wg = !0),
            "data" === t && (this.Mg = !0),
            "options" === t && (this.gg = !0);
        }
        Tt() {
          return this.ae.It()
            ? (this.yg(), null === this.Sg ? null : this.kg)
            : null;
        }
        Qs(t, i) {
          return this.ae.It()
            ? (this.yg(), null === this.Sg ? null : this.Pg(t, i))
            : null;
        }
        Pg(t, i) {
          return null;
        }
        Tg() {
          this.bg = this.bg.map((t) => ({ ...t, ...this.ae.Sa().Sh(t.wt) }));
        }
        Rg() {
          this.Sg = null;
        }
        yg() {
          const t = this.le.Et(),
            i = t.N().enableConflation ? t.Qc() : 0;
          i !== this.xg && ((this.Mg = !0), (this.xg = i)),
            this.Mg && (this.Dg(), (this.Mg = !1)),
            this.gg && (this.Tg(), (this.gg = !1)),
            this.wg && (this.Ig(), (this.wg = !1));
        }
        Ig() {
          const t = this.ae.Ft(),
            i = this.le.Et();
          if ((this.Rg(), i.Gi() || t.Gi())) return;
          const s = i.Ee();
          if (null === s) return;
          if (0 === this.ae.Un().Th()) return;
          const e = this.ae.Lt();
          null !== e &&
            ((this.Sg = Se(this.bg, s, this.Cg)),
            this.Vg(t, i, e.Wt),
            this.Bg());
        }
      }
      class _e {
        constructor(t, i) {
          (this.Eg = t), (this.Ki = i);
        }
        st(t, i, s) {
          this.Eg.draw(t, this.Ki, i, s);
        }
      }
      function Ce(t) {
        switch (t) {
          case "point":
            return 2;
          case "range":
            return 0;
          default:
            return 1;
        }
      }
      class Ee extends xe {
        constructor(t, i, s) {
          super(t, i, !1),
            (this.Yh = s),
            (this.Eg = this.Yh.renderer()),
            (this.kg = new _e(this.Eg, (t) => this.Ag(t)));
        }
        get ga() {
          return this.Yh.conflationReducer;
        }
        Wa(t) {
          return this.Yh.priceValueBuilder(t);
        }
        _l(t) {
          return this.Yh.isWhitespace(t);
        }
        Pg(t, i) {
          const s = this.Eg.hitTest?.(t, i, (t) => this.Ag(t));
          if (null != s)
            return {
              ne: (e = s).distance,
              se: Ce(e.type),
              ee: "custom",
              mu: e.cursorStyle,
              te: e.objectId,
              ie: e.hitTestData,
            };
          var e;
          const h = we(
            this.bg,
            this.Sg,
            t,
            i,
            this.le.Et().fl(),
            this.ae.N().hitTestTolerance,
            (t, i) => {
              const s = t.Lg;
              let e = NaN,
                h = NaN;
              if (void 0 !== s && !this.Yh.isWhitespace(s))
                for (const t of this.Yh.priceValueBuilder(s)) {
                  const i = this.Ag(t);
                  null !== i &&
                    ((e = Number.isNaN(e) ? i : Math.min(e, i)),
                    (h = Number.isNaN(h) ? i : Math.max(h, i)));
                }
              (i[0] = e), (i[1] = h);
            }
          );
          return null === h ? null : { ...h, ee: "custom" };
        }
        Dg() {
          const t = this.ae.Sa();
          this.bg = this.ae
            .Ha()
            .Bh()
            .map((i) => ({ wt: i.$n, _t: NaN, ...t.Sh(i.$n), Lg: i.ue }));
        }
        Vg(t, i) {
          i.Tc(this.bg, S(this.Sg));
        }
        Bg() {
          this.Yh.update(
            {
              bars: this.bg.map(ze),
              barSpacing: this.le.Et().fl(),
              visibleRange: this.Sg,
              conflationFactor: this.le.Et().Qc(),
            },
            this.ae.N()
          );
        }
        Ag(t) {
          const i = this.ae.Lt();
          return null === i ? null : this.ae.Ft().Nt(t, i.Wt);
        }
      }
      function ze(t) {
        return { x: t._t, time: t.wt, originalData: t.Lg, barColor: t.sh };
      }
      const ke = { color: "#2196f3" },
        Ne = (t, i, s) => {
          const e = f(s);
          return new Ee(t, i, e);
        };
      function Te(t) {
        const i = { value: t.Wt[3], time: t.Qr };
        return void 0 !== t.ZM && (i.customValues = t.ZM), i;
      }
      function Re(t) {
        const i = Te(t);
        return void 0 !== t.R && (i.color = t.R), i;
      }
      function Le(t) {
        const i = Te(t);
        return (
          void 0 !== t.vt && (i.lineColor = t.vt),
          void 0 !== t.ah && (i.topColor = t.ah),
          void 0 !== t.oh && (i.bottomColor = t.oh),
          i
        );
      }
      function Pe(t) {
        const i = Te(t);
        return (
          void 0 !== t._h && (i.topLineColor = t._h),
          void 0 !== t.uh && (i.bottomLineColor = t.uh),
          void 0 !== t.dh && (i.topFillColor1 = t.dh),
          void 0 !== t.fh && (i.topFillColor2 = t.fh),
          void 0 !== t.ph && (i.bottomFillColor1 = t.ph),
          void 0 !== t.mh && (i.bottomFillColor2 = t.mh),
          i
        );
      }
      function Ie(t) {
        const i = {
          open: t.Wt[0],
          high: t.Wt[1],
          low: t.Wt[2],
          close: t.Wt[3],
          time: t.Qr,
        };
        return void 0 !== t.ZM && (i.customValues = t.ZM), i;
      }
      function qe(t) {
        const i = Ie(t);
        return void 0 !== t.R && (i.color = t.R), i;
      }
      function Oe(t) {
        const i = Ie(t),
          { R: s, Ht: e, hh: h } = t;
        return (
          void 0 !== s && (i.color = s),
          void 0 !== e && (i.borderColor = e),
          void 0 !== h && (i.wickColor = h),
          i
        );
      }
      function Fe(t) {
        return {
          Area: Le,
          Line: Re,
          Baseline: Pe,
          Histogram: Re,
          Bar: qe,
          Candlestick: Oe,
          Custom: We,
        }[t];
      }
      function We(t) {
        const i = t.Qr;
        return { ...t.ue, time: i };
      }
      const Be = {
          vertLine: {
            color: "#9598A1",
            width: 1,
            style: 3,
            visible: !0,
            labelVisible: !0,
            labelBackgroundColor: "#131722",
          },
          horzLine: {
            color: "#9598A1",
            width: 1,
            style: 3,
            visible: !0,
            labelVisible: !0,
            labelBackgroundColor: "#131722",
          },
          mode: 1,
          doNotSnapToHiddenSeriesIndices: !1,
        },
        Qe = {
          vertLines: { color: "#D6DCDE", style: 0, visible: !0 },
          horzLines: { color: "#D6DCDE", style: 0, visible: !0 },
        },
        De = {
          background: { type: "solid", color: "#FFFFFF" },
          textColor: "#191919",
          fontSize: 12,
          fontFamily: x,
          panes: {
            enableResize: !0,
            separatorColor: "#E0E3EB",
            separatorHoverColor: "rgba(178, 181, 189, 0.2)",
          },
          attributionLogo: !0,
          colorSpace: "srgb",
          colorParsers: [],
        },
        Ke = {
          autoScale: !0,
          mode: 0,
          invertScale: !1,
          alignLabels: !0,
          borderVisible: !0,
          borderColor: "#2B2B43",
          entireTextOnly: !1,
          visible: !1,
          ticksVisible: !1,
          scaleMargins: { bottom: 0.1, top: 0.2 },
          minimumWidth: 0,
          ensureEdgeTickMarksVisible: !1,
          tickMarkDensity: 2.5,
        },
        Ve = {
          rightOffset: 0,
          barSpacing: 6,
          minBarSpacing: 0.5,
          maxBarSpacing: 0,
          fixLeftEdge: !1,
          fixRightEdge: !1,
          lockVisibleTimeRangeOnResize: !1,
          rightBarStaysOnScroll: !1,
          borderVisible: !0,
          borderColor: "#2B2B43",
          visible: !0,
          timeVisible: !1,
          secondsVisible: !0,
          shiftVisibleRangeOnNewBar: !0,
          allowShiftVisibleRangeOnWhitespaceReplacement: !1,
          ticksVisible: !1,
          uniformDistribution: !1,
          minimumHeight: 0,
          allowBoldLabels: !0,
          ignoreWhitespaceIndices: !1,
          enableConflation: !1,
          conflationThresholdFactor: 1,
          precomputeConflationOnInit: !1,
          precomputeConflationPriority: "background",
        };
      function $e() {
        return {
          addDefaultPane: !0,
          hoveredSeriesOnTop: !0,
          width: 0,
          height: 0,
          autoSize: !1,
          layout: De,
          crosshair: Be,
          grid: Qe,
          overlayPriceScales: { ...Ke },
          leftPriceScale: { ...Ke, visible: !1 },
          rightPriceScale: { ...Ke, visible: !0 },
          defaultVisiblePriceScaleId: "right",
          timeScale: Ve,
          localization: {
            locale: ls ? navigator.language : "",
            dateFormat: "dd MMM 'yy",
          },
          handleScroll: {
            mouseWheel: !0,
            pressedMouseMove: !0,
            horzTouchDrag: !0,
            vertTouchDrag: !0,
          },
          handleScale: {
            axisPressedMouseMove: { time: !0, price: !0 },
            axisDoubleClickReset: { time: !0, price: !0 },
            mouseWheel: !0,
            pinch: !0,
          },
          kineticScroll: { mouse: !1, touch: !0 },
          trackingMode: { exitMode: 1 },
        };
      }
      class Ae {
        constructor(t, i, s) {
          (this.sv = t), (this.zg = i), (this.Og = s ?? 0);
        }
        applyOptions(t) {
          this.sv.Qt().Pd(this.zg, t, this.Og);
        }
        options() {
          return this.Ki().N();
        }
        width() {
          return j(this.zg) ? this.sv.CM(this.zg) : 0;
        }
        setVisibleRange(t) {
          this.setAutoScale(!1), this.Ki().qo(new gt(t.from, t.to));
        }
        getVisibleRange() {
          let t,
            i,
            s = this.Ki().ar();
          if (null === s) return null;
          if (this.Ki().so()) {
            const e = this.Ki().M_(),
              h = Ai(e);
            (s = mi(s, this.Ki().ro())),
              (t = Number((Math.round(s.Je() / e) * e).toFixed(h))),
              (i = Number((Math.round(s.Qe() / e) * e).toFixed(h)));
          } else (t = s.Je()), (i = s.Qe());
          return { from: t, to: i };
        }
        setAutoScale(t) {
          this.applyOptions({ autoScale: t });
        }
        Ki() {
          return d(this.sv.Qt().Td(this.zg, this.Og)).Ft;
        }
      }
      class Ze {
        constructor(t, i, s, e) {
          (this.sv = t), (this.yt = s), (this.Ng = i), (this.Fg = e);
        }
        getHeight() {
          return this.yt.$t();
        }
        setHeight(t) {
          const i = this.sv.Qt(),
            s = i.hf(this.yt);
          i.Bd(s, t);
        }
        getStretchFactor() {
          return this.yt.z_();
        }
        setStretchFactor(t) {
          this.yt.O_(t), this.sv.Qt().Pa();
        }
        paneIndex() {
          return this.sv.Qt().hf(this.yt);
        }
        moveTo(t) {
          const i = this.paneIndex();
          i !== t &&
            (u(t >= 0 && t < this.sv.rv().length, "Invalid pane index"),
            this.sv.Qt().Ad(i, t));
        }
        getSeries() {
          return this.yt.U_().map((t) => this.Ng(t)) ?? [];
        }
        getHTMLElement() {
          const t = this.sv.rv();
          return t && 0 !== t.length && t[this.paneIndex()]
            ? t[this.paneIndex()].uv()
            : null;
        }
        attachPrimitive(t) {
          this.yt.hl(t),
            t.attached &&
              t.attached({
                chart: this.Fg,
                requestUpdate: () => this.yt.Qt().Pa(),
              });
        }
        detachPrimitive(t) {
          this.yt.al(t);
        }
        priceScale(t) {
          if (null === this.yt.A_(t))
            throw new Error(`Cannot find price scale with id: ${t}`);
          return new Ae(this.sv, t, this.paneIndex());
        }
        setPreserveEmptyPane(t) {
          this.yt.W_(t);
        }
        preserveEmptyPane() {
          return this.yt.H_();
        }
        addCustomSeries(t, i = {}, s = 0) {
          return this.Fg.addCustomSeries(t, i, s);
        }
        addSeries(t, i = {}) {
          return this.Fg.addSeries(t, i, this.paneIndex());
        }
      }
      const He = {
        color: "#FF0000",
        price: 0,
        lineStyle: 2,
        lineWidth: 1,
        lineVisible: !0,
        axisLabelVisible: !0,
        title: "",
        axisLabelColor: "",
        axisLabelTextColor: "",
      };
      class Ge {
        constructor(t) {
          this._r = t;
        }
        applyOptions(t) {
          this._r.vr(t);
        }
        options() {
          return this._r.N();
        }
        Wg() {
          return this._r;
        }
      }
      class Ye {
        constructor(t, i, s, e, h, n) {
          (this.Hg = new m()),
            (this.ae = t),
            (this.Ug = i),
            (this.$g = s),
            (this.xu = h),
            (this.Fg = e),
            (this.jg = n);
        }
        m() {
          this.Hg.m();
        }
        priceFormatter() {
          return this.ae.tl();
        }
        priceToCoordinate(t) {
          const i = this.ae.Lt();
          return null === i ? null : this.ae.Ft().Nt(t, i.Wt);
        }
        coordinateToPrice(t) {
          const i = this.ae.Lt();
          return null === i ? null : this.ae.Ft().Tn(t, i.Wt);
        }
        barsInLogicalRange(t) {
          if (null === t) return null;
          const i = new Oi(new Pi(t.from, t.to)).Fu(),
            s = this.ae.Un();
          if (s.Gi()) return null;
          const e = s.Hn(i.Oa(), 1),
            h = s.Hn(i.bi(), -1),
            n = d(s.Rh()),
            r = d(s.Qn());
          if (null !== e && null !== h && e.$n > h.$n)
            return { barsBefore: t.from - n, barsAfter: r - t.to };
          const o = {
            barsBefore: null === e || e.$n === n ? t.from - n : e.$n - n,
            barsAfter: null === h || h.$n === r ? r - t.to : r - h.$n,
          };
          return (
            null !== e && null !== h && ((o.from = e.Qr), (o.to = h.Qr)), o
          );
        }
        setData(t) {
          this.xu, this.ae.bh(), this.Ug.qg(this.ae, t), this.Yg("full");
        }
        update(t, i = !1) {
          this.ae.bh(), this.Ug.Kg(this.ae, t, i), this.Yg("update");
        }
        pop(t = 1) {
          const i = this.Ug.Zg(this.ae, t);
          0 !== i.length && this.Yg("update");
          const s = Fe(this.seriesType());
          return i.map((t) => s(t));
        }
        dataByIndex(t, i) {
          const s = this.ae.Un().Hn(t, i);
          return null === s ? null : Fe(this.seriesType())(s);
        }
        data() {
          const t = Fe(this.seriesType());
          return this.ae
            .Un()
            .Bh()
            .map((i) => t(i));
        }
        subscribeDataChanged(t) {
          this.Hg.i(t);
        }
        unsubscribeDataChanged(t) {
          this.Hg._(t);
        }
        applyOptions(t) {
          this.ae.vr(t);
        }
        options() {
          return M(this.ae.N());
        }
        priceScale() {
          return this.$g.priceScale(
            this.ae.Ft().cl(),
            this.getPane().paneIndex()
          );
        }
        createPriceLine(t) {
          const i = p(M(He), t),
            s = this.ae.Ba(i);
          return new Ge(s);
        }
        removePriceLine(t) {
          this.ae.Ea(t.Wg());
        }
        priceLines() {
          return this.ae.Aa().map((t) => new Ge(t));
        }
        seriesType() {
          return this.ae.bh();
        }
        lastValueData(t) {
          const i = this.ae.Ae(t);
          return i.Le
            ? { noData: !0 }
            : { noData: !1, price: i.Mt, color: i.R };
        }
        attachPrimitive(t) {
          this.ae.hl(t),
            t.attached &&
              t.attached({
                chart: this.Fg,
                series: this,
                requestUpdate: () => this.ae.Qt().Pa(),
                horzScaleBehavior: this.xu,
              });
        }
        detachPrimitive(t) {
          this.ae.al(t), t.detached && t.detached(), this.ae.Qt().Pa();
        }
        getPane() {
          const t = this.ae,
            i = d(this.ae.Qt().Ks(t));
          return this.jg(i);
        }
        moveToPane(t) {
          this.ae.Qt().nf(this.ae, t);
        }
        seriesOrder() {
          const t = this.ae.Qt().Ks(this.ae);
          return null === t ? -1 : t.U_().indexOf(this.ae);
        }
        setSeriesOrder(t) {
          const i = this.ae.Qt().Ks(this.ae);
          null !== i && i.du(this.ae, t);
        }
        Yg(t) {
          this.Hg.v() && this.Hg.p(t);
        }
      }
      class Ue {
        constructor(t, i, s) {
          (this.Gg = new m()),
            (this.Gu = new m()),
            (this.Bw = new m()),
            (this.sn = t),
            (this.ia = t.Et()),
            (this._M = i),
            this.ia.Yc().i(this.Xg.bind(this)),
            this.ia.Kc().i(this.Jg.bind(this)),
            this._M.Fw().i(this.Qg.bind(this)),
            (this.xu = s);
        }
        m() {
          this.ia.Yc().u(this),
            this.ia.Kc().u(this),
            this._M.Fw().u(this),
            this.Gg.m(),
            this.Gu.m(),
            this.Bw.m();
        }
        scrollPosition() {
          return this.ia.Ac();
        }
        scrollToPosition(t, i) {
          i ? this.ia.$c(t, 1e3) : this.sn.gs(t);
        }
        scrollToRealTime() {
          this.ia.Uc();
        }
        getVisibleRange() {
          const t = this.ia.gc();
          return null === t
            ? null
            : { from: t.from.originalTime, to: t.to.originalTime };
        }
        setVisibleRange(t) {
          const i = {
              from: this.xu.convertHorzItemToInternal(t.from),
              to: this.xu.convertHorzItemToInternal(t.to),
            },
            s = this.ia.Cc(i);
          this.sn.tf(s);
        }
        getVisibleLogicalRange() {
          const t = this.ia.Mc();
          return null === t ? null : { from: t.Oa(), to: t.bi() };
        }
        setVisibleLogicalRange(t) {
          u(t.from <= t.to, "The from index cannot be after the to index."),
            this.sn.tf(t);
        }
        resetTimeScale() {
          this.sn.ws();
        }
        fitContent() {
          this.sn.Xc();
        }
        logicalToCoordinate(t) {
          const i = this.sn.Et();
          return i.Gi() ? null : i.jt(t);
        }
        coordinateToLogical(t) {
          return this.ia.Gi() ? null : this.ia.Rc(t);
        }
        timeToIndex(t, i) {
          const s = this.xu.convertHorzItemToInternal(t);
          return this.ia.vc(s, i);
        }
        timeToCoordinate(t) {
          const i = this.timeToIndex(t, !1);
          return null === i ? null : this.ia.jt(i);
        }
        coordinateToTime(t) {
          const i = this.sn.Et(),
            s = i.Rc(t),
            e = i.en(s);
          return null === e ? null : e.originalTime;
        }
        width() {
          return this._M.cv().width;
        }
        height() {
          return this._M.cv().height;
        }
        subscribeVisibleTimeRangeChange(t) {
          this.Gg.i(t);
        }
        unsubscribeVisibleTimeRangeChange(t) {
          this.Gg._(t);
        }
        subscribeVisibleLogicalRangeChange(t) {
          this.Gu.i(t);
        }
        unsubscribeVisibleLogicalRangeChange(t) {
          this.Gu._(t);
        }
        subscribeSizeChange(t) {
          this.Bw.i(t);
        }
        unsubscribeSizeChange(t) {
          this.Bw._(t);
        }
        applyOptions(t) {
          this.ia.vr(t);
        }
        options() {
          return { ...M(this.ia.N()), barSpacing: this.ia.fl() };
        }
        Xg() {
          this.Gg.v() && this.Gg.p(this.getVisibleRange());
        }
        Jg() {
          this.Gu.v() && this.Gu.p(this.getVisibleLogicalRange());
        }
        Qg(t) {
          this.Bw.p(t.width, t.height);
        }
      }
      function je(t) {
        return (
          (function (t) {
            if (w(t.handleScale)) {
              const i = t.handleScale;
              t.handleScale = {
                axisDoubleClickReset: { time: i, price: i },
                axisPressedMouseMove: { time: i, price: i },
                mouseWheel: i,
                pinch: i,
              };
            } else if (void 0 !== t.handleScale) {
              const { axisPressedMouseMove: i, axisDoubleClickReset: s } =
                t.handleScale;
              w(i) &&
                (t.handleScale.axisPressedMouseMove = { time: i, price: i }),
                w(s) &&
                  (t.handleScale.axisDoubleClickReset = { time: s, price: s });
            }
            const i = t.handleScroll;
            w(i) &&
              (t.handleScroll = {
                horzTouchDrag: i,
                vertTouchDrag: i,
                mouseWheel: i,
                pressedMouseMove: i,
              });
          })(t),
          t
        );
      }
      class Xe {
        constructor(t, i, s) {
          (this.tb = new Map()),
            (this.ib = new Map()),
            (this.nb = new m()),
            (this.sb = new m()),
            (this.eb = new m()),
            (this.od = new WeakMap()),
            (this.rb = new oe(i));
          const e = void 0 === s ? M($e()) : p(M($e()), je(s));
          (this.hb = i),
            (this.sv = new $s(t, e, i)),
            this.sv.dw().i((t) => {
              this.nb.v() && this.nb.p(this.ab(t()));
            }, this),
            this.sv.fw().i((t) => {
              this.sb.v() && this.sb.p(this.ab(t()));
            }, this),
            this.sv.Dd().i((t) => {
              this.eb.v() && this.eb.p(this.ab(t()));
            }, this);
          const h = this.sv.Qt();
          this.lb = new Ue(h, this.sv.pM(), this.hb);
        }
        remove() {
          this.sv.dw().u(this),
            this.sv.fw().u(this),
            this.sv.Dd().u(this),
            this.lb.m(),
            this.sv.m(),
            this.tb.clear(),
            this.ib.clear(),
            this.nb.m(),
            this.sb.m(),
            this.eb.m(),
            this.rb.m();
        }
        resize(t, i, s) {
          this.autoSizeActive() || this.sv.cM(t, i, s);
        }
        addCustomSeries(t, i = {}, s = 0) {
          const e = ((t) => ({
            type: "Custom",
            isBuiltIn: !1,
            defaultOptions: { ...ke, ...t.defaultOptions() },
            ob: Ne,
            _b: t,
          }))(f(t));
          return this.ub(e, i, s);
        }
        addSeries(t, i = {}, s = 0) {
          return this.ub(t, i, s);
        }
        removeSeries(t) {
          const i = c(this.tb.get(t)),
            s = this.rb.Jd(i);
          this.sv.Qt().Jd(i), this.cb(s), this.tb.delete(t), this.ib.delete(i);
        }
        qg(t, i) {
          this.cb(this.rb.sg(t, i));
        }
        Kg(t, i, s) {
          this.cb(this.rb.og(t, i, s));
        }
        Zg(t, i) {
          const [s, e] = this.rb.cg(t, i);
          return 0 !== s.length && this.cb(e), s;
        }
        subscribeClick(t) {
          this.nb.i(t);
        }
        unsubscribeClick(t) {
          this.nb._(t);
        }
        subscribeCrosshairMove(t) {
          this.eb.i(t);
        }
        unsubscribeCrosshairMove(t) {
          this.eb._(t);
        }
        subscribeDblClick(t) {
          this.sb.i(t);
        }
        unsubscribeDblClick(t) {
          this.sb._(t);
        }
        priceScale(t, i = 0) {
          return new Ae(this.sv, t, i);
        }
        timeScale() {
          return this.lb;
        }
        applyOptions(t) {
          this.sv.vr(je(t));
        }
        options() {
          return this.sv.N();
        }
        takeScreenshot(t = !1, i = !1) {
          let s, e;
          try {
            i ||
              ((s = this.sv.Qt().N().crosshair.mode),
              this.sv.vr({ crosshair: { mode: 2 } })),
              (e = this.sv.SM(t));
          } finally {
            i || void 0 === s || this.sv.Qt().vr({ crosshair: { mode: s } });
          }
          return e;
        }
        addPane(t = !1) {
          const i = this.sv.Qt().af();
          return i.W_(t), this.fb(i);
        }
        removePane(t) {
          this.sv.Qt().Vd(t);
        }
        swapPanes(t, i) {
          this.sv.Qt().Ed(t, i);
        }
        autoSizeActive() {
          return this.sv.wM();
        }
        chartElement() {
          return this.sv.vv();
        }
        panes() {
          return this.sv
            .Qt()
            .Zn()
            .map((t) => this.fb(t));
        }
        paneSize(t = 0) {
          const i = this.sv.RM(t);
          return { height: i.height, width: i.width };
        }
        setCrosshairPosition(t, i, s) {
          const e = this.tb.get(s);
          if (void 0 === e) return;
          const h = this.sv.Qt().Ks(e);
          null !== h && this.sv.Qt().qd(t, i, h);
        }
        clearCrosshairPosition() {
          this.sv.Qt().Yd(!0);
        }
        horzBehaviour() {
          return this.hb;
        }
        ub(t, i = {}, s = 0) {
          u(void 0 !== t.ob),
            (function (t) {
              if (void 0 === t || "custom" === t.type) return;
              const i = t;
              void 0 !== i.minMove &&
                void 0 === i.precision &&
                (i.precision = Ai(i.minMove));
            })(i.priceFormat),
            "Candlestick" === t.type &&
              (function (t) {
                void 0 !== t.borderColor &&
                  ((t.borderUpColor = t.borderColor),
                  (t.borderDownColor = t.borderColor)),
                  void 0 !== t.wickColor &&
                    ((t.wickUpColor = t.wickColor),
                    (t.wickDownColor = t.wickColor));
              })(i);
          const e = p(M(h), M(t.defaultOptions), i),
            n = t.ob,
            r = new jt(this.sv.Qt(), t.type, e, n, t._b);
          this.sv.Qt().Gd(r, s);
          const o = new Ye(r, this, this, this, this.hb, (t) => this.fb(t));
          return this.tb.set(o, r), this.ib.set(r, o), o;
        }
        cb(t) {
          const i = this.sv.Qt();
          i.Kd(t.Et.Pc, t.Et.vg, t.Et.mg),
            t.U_.forEach((t, i) => i.ht(t.ue, t.pg)),
            i.Et()._c(),
            i.Bc();
        }
        pb(t) {
          return c(this.ib.get(t));
        }
        mb(t) {
          return void 0 !== t && this.ib.has(t) ? this.pb(t) : void 0;
        }
        ab(t) {
          const i = new Map();
          t.YM.forEach((t, s) => {
            const e = s.bh(),
              h = Fe(e)(t);
            if ("Custom" !== e) u(Hs(h));
            else {
              const t = s.ol();
              u(!t || !1 === t(h));
            }
            i.set(this.pb(s), h);
          });
          const s = this.mb(t.NM),
            e =
              void 0 === t.WM
                ? void 0
                : {
                    type: t.WM.ds,
                    sourceKind: t.WM.HM,
                    objectKind: t.WM.UM,
                    series: this.mb(t.WM.U_),
                    objectId: t.WM.$M,
                    paneIndex: t.WM.jM,
                  };
          return {
            time: t.Qr,
            logical: t.$n,
            point: t.qM,
            paneIndex: t.jM,
            hoveredInfo: e,
            hoveredSeries: s,
            hoveredObjectId: t.FM,
            seriesData: i,
            sourceEvent: t.KM,
          };
        }
        fb(t) {
          let i = this.od.get(t);
          return (
            i ||
              ((i = new Ze(this.sv, (t) => this.pb(t), t, this)),
              this.od.set(t, i)),
            i
          );
        }
      }
      function Je(t) {
        if (b(t)) {
          const i = document.getElementById(t);
          return u(null !== i, `Cannot find element in DOM with id=${t}`), i;
        }
        return t;
      }
      function th(t, i, s) {
        const e = Je(t),
          h = new Xe(e, i, s);
        return i.setOptions(h.options()), h;
      }
      function ih() {
        return os;
      }
      function sh(t, i, s, e) {
        return Math.hypot(s - t, e - i);
      }
      function eh(t, i, s, e, h, n, r, o = 0) {
        if (0 === i.length || e.from >= i.length || e.to <= 0) return;
        const {
            context: l,
            horizontalPixelRatio: a,
            verticalPixelRatio: u,
          } = t,
          c = i[e.from];
        let d = n(t, c),
          f = c;
        if (e.to - e.from < 2) {
          const i = h / 2;
          l.beginPath();
          const s = { _t: c._t - i, ut: c.ut },
            e = { _t: c._t + i, ut: c.ut };
          l.moveTo(s._t * a, s.ut * u),
            l.lineTo(e._t * a, e.ut * u),
            r(t, d, s, e);
        } else {
          const h = o > 0;
          let m = 0;
          const p = (i, s) => {
            if ((r(t, d, f, s), l.beginPath(), (d = i), (f = s), h)) {
              const t = m % o;
              (l.lineDashOffset = t), (m = t);
            }
          };
          let v = f;
          l.beginPath(), l.moveTo(c._t * a, c.ut * u);
          for (let r = e.from + 1; r < e.to; ++r) {
            v = i[r];
            const e = v._t * a,
              o = v.ut * u,
              c = n(t, v);
            switch (s) {
              case 0:
                if ((l.lineTo(e, o), h)) {
                  const t = i[r - 1],
                    s = t._t * a,
                    h = t.ut * u;
                  m += sh(s, h, e, o);
                }
                break;
              case 1: {
                const t = i[r - 1],
                  s = t.ut * u;
                l.lineTo(e, s),
                  h && (m += Math.abs(v._t - t._t) * a),
                  c !== d && (p(c, v), l.lineTo(e, s)),
                  l.lineTo(e, o),
                  h && (m += Math.abs(v.ut - t.ut) * u);
                break;
              }
              case 2: {
                const [t, s] = rh(i, r - 1, r),
                  n = t._t * a,
                  c = t.ut * u,
                  d = s._t * a,
                  f = s.ut * u;
                if ((l.bezierCurveTo(n, c, d, f, e, o), h)) {
                  const t = i[r - 1],
                    s = t._t * a,
                    h = t.ut * u,
                    l = sh(s, h, e, o),
                    p = sh(s, h, n, c) + sh(n, c, d, f) + sh(d, f, e, o);
                  m += (l + p) / 2;
                }
                break;
              }
            }
            1 !== s && c !== d && (p(c, v), l.moveTo(e, o));
          }
          (f !== v || (f === v && 1 === s)) && r(t, d, f, v),
            h && (l.lineDashOffset = 0);
        }
      }
      function hh(t, i) {
        return { _t: t._t - i._t, ut: t.ut - i.ut };
      }
      function nh(t, i) {
        return { _t: t._t / i, ut: t.ut / i };
      }
      function rh(t, i, s) {
        const e = Math.max(0, i - 1),
          h = Math.min(t.length - 1, s + 1);
        var n, r;
        return [
          ((n = t[i]),
          (r = nh(hh(t[s], t[e]), 6)),
          { _t: n._t + r._t, ut: n.ut + r.ut }),
          hh(t[s], nh(hh(t[h], t[i]), 6)),
        ];
      }
      function oh(t, i) {
        const s = t.context;
        (s.strokeStyle = i), s.stroke();
      }
      class lh extends T {
        constructor() {
          super(...arguments), (this.rt = null);
        }
        ht(t) {
          this.rt = t;
        }
        et(t) {
          if (null === this.rt) return;
          const { ot: i, lt: s, wb: e, Mb: h, ct: n, Zt: r, gb: o } = this.rt;
          if (null === s) return;
          const a = t.context;
          (a.lineCap = "butt"), (a.lineWidth = n * t.verticalPixelRatio);
          const u = l(a, r);
          a.lineJoin = "round";
          const c = this.bb.bind(this),
            d = (function (t) {
              return t.reduce((t, i) => t + i, 0);
            })(u);
          void 0 !== h && eh(t, i, h, s, e, c, oh, d),
            o &&
              (function (t, i, s, e, h) {
                if (e.to - e.from <= 0) return;
                const {
                  horizontalPixelRatio: n,
                  verticalPixelRatio: r,
                  context: o,
                } = t;
                let l = null;
                const a = (Math.max(1, Math.floor(n)) % 2) / 2,
                  u = s * r + a;
                for (let s = e.to - 1; s >= e.from; --s) {
                  const e = i[s];
                  if (e) {
                    const i = h(t, e);
                    i !== l &&
                      (null !== l && o.fill(),
                      o.beginPath(),
                      (o.fillStyle = i),
                      (l = i));
                    const s = Math.round(e._t * n) + a,
                      c = e.ut * r;
                    o.moveTo(s, c), o.arc(s, c, u, 0, 2 * Math.PI);
                  }
                }
                o.fill();
              })(t, i, o, s, c);
        }
      }
      class ah extends lh {
        bb(t, i) {
          return i.vt;
        }
      }
      function uh(t, i, s, e, h) {
        const n = 1 - h;
        return (
          n * n * n * t + 3 * n * n * h * i + 3 * n * h * h * s + h * h * h * e
        );
      }
      function ch(t, i, s, e, h) {
        if (2 === s) {
          const [s, n] = rh(e, h - 1, h);
          return [
            Math.min(t._t, i._t, s._t, n._t),
            Math.max(t._t, i._t, s._t, n._t),
          ];
        }
        return [Math.min(t._t, i._t), Math.max(t._t, i._t)];
      }
      function dh(t, i, s, e, h, n, r, o) {
        switch (h) {
          case 1: {
            const h = pe(t, i, s._t, s.ut, e._t, s.ut),
              n = pe(t, i, e._t, s.ut, e._t, e.ut),
              r = Math.min(h, n);
            return r <= o ? r : null;
          }
          case 2: {
            const [h, l] = rh(n, r - 1, r),
              a = (function (t, i, s) {
                let e = Number.POSITIVE_INFINITY,
                  h = s[0];
                for (let n = 1; n <= 12; n++) {
                  const r = n / 12,
                    o = {
                      _t: uh(s[0]._t, s[1]._t, s[2]._t, s[3]._t, r),
                      ut: uh(s[0].ut, s[1].ut, s[2].ut, s[3].ut, r),
                    };
                  (e = Math.min(e, pe(t, i, h._t, h.ut, o._t, o.ut))), (h = o);
                }
                return e;
              })(t, i, [s, h, l, e]);
            return a <= o ? a : null;
          }
          default: {
            const h = pe(t, i, s._t, s.ut, e._t, e.ut);
            return h <= o ? h : null;
          }
        }
      }
      class fh extends xe {
        constructor(t, i) {
          super(t, i, !0);
        }
        Vg(t, i, s) {
          i.Tc(this.bg, S(this.Sg)), t.Zo(this.bg, s, S(this.Sg));
        }
        Sb(t, i) {
          return { wt: t, Mt: i, _t: NaN, ut: NaN };
        }
        Dg() {
          const t = this.ae.Sa();
          this.bg = this.ae
            .Ha()
            .Bh()
            .map((i) => {
              let s;
              if ((i.Zr ?? 1) > 1) {
                const t = i.Wt[1],
                  e = i.Wt[2],
                  h = i.Wt[3];
                s = Math.abs(t - h) > Math.abs(e - h) ? t : e;
              } else s = i.Wt[3];
              return this.xb(i.$n, s, t);
            });
        }
      }
      class mh extends fh {
        Pg(t, i) {
          const s = this.ae.N();
          return (function (t, i, s, e, h, n, r, o = 0, l = 0) {
            if (null === i || i.from >= i.to || 0 === t.length) return null;
            const a = Math.max(n / 2, r ?? 0) + l;
            let u = Number.POSITIVE_INFINITY;
            if (void 0 !== r) {
              const h = r + l,
                n = ce(t, s - h, i.from, i.to),
                o = de(t, s + h, n, i.to);
              for (let i = n; i < o; i++) {
                const h = t[i];
                if (!me(s, h._t, h._t, r + l)) continue;
                const n = Math.hypot(s - h._t, e - h.ut);
                n <= r + l && (u = Math.min(u, n));
              }
            }
            if (i.to - i.from < 2) {
              const h = t[i.from],
                n = Math.max(o / 2, a),
                r = pe(s, e, h._t - n, h.ut, h._t + n, h.ut);
              return (
                r <= a && (u = Math.min(u, r)),
                Number.isFinite(u) ? fe(u, 2, "series-point") : null
              );
            }
            let c = Number.POSITIVE_INFINITY;
            const d = ce(t, s - a, i.from, i.to),
              f = de(t, s + a, d, i.to),
              m = Math.max(i.from + 1, d),
              p = Math.min(i.to, f + 1);
            for (let i = m; i < p; i++) {
              const n = t[i - 1],
                r = t[i],
                [o, l] = ch(n, r, h, t, i);
              if (!me(s, o, l, a)) continue;
              const u = dh(s, e, n, r, h, t, i, a);
              null !== u && (c = Math.min(c, u));
            }
            return Number.isFinite(u)
              ? fe(u, 2, "series-point")
              : Number.isFinite(c)
              ? fe(c, 1, "series-line")
              : null;
          })(
            this.bg,
            this.Sg,
            t,
            i,
            s.lineType,
            s.lineVisible ? s.lineWidth : 1,
            s.pointMarkersVisible
              ? s.pointMarkersRadius || s.lineWidth / 2 + 2
              : void 0,
            this.le.Et().fl(),
            s.hitTestTolerance
          );
        }
      }
      class ph extends mh {
        constructor() {
          super(...arguments), (this.kg = new ah());
        }
        xb(t, i, s) {
          return { ...this.Sb(t, i), ...s.Sh(t) };
        }
        Bg() {
          const t = this.ae.N(),
            i = {
              ot: this.bg,
              Zt: t.lineStyle,
              Mb: t.lineVisible ? t.lineType : void 0,
              ct: t.lineWidth,
              gb: t.pointMarkersVisible
                ? t.pointMarkersRadius || t.lineWidth / 2 + 2
                : void 0,
              lt: this.Sg,
              wb: this.le.Et().fl(),
            };
          this.kg.ht(i);
        }
      }
      const vh = {
        type: "Line",
        isBuiltIn: !0,
        defaultOptions: {
          color: "#2196f3",
          lineStyle: 0,
          lineWidth: 3,
          lineType: 0,
          lineVisible: !0,
          crosshairMarkerVisible: !0,
          crosshairMarkerRadius: 4,
          crosshairMarkerBorderColor: "",
          crosshairMarkerBorderWidth: 2,
          crosshairMarkerBackgroundColor: "",
          lastPriceAnimation: 0,
          pointMarkersVisible: !1,
        },
        ob: (t, i) => new ph(t, i),
      };
      function gh(t, i, s, e, h) {
        const {
          context: n,
          horizontalPixelRatio: r,
          verticalPixelRatio: o,
        } = i;
        n.lineTo(h._t * r, t * o),
          n.lineTo(e._t * r, t * o),
          n.closePath(),
          (n.fillStyle = s),
          n.fill();
      }
      class bh extends T {
        constructor() {
          super(...arguments), (this.rt = null);
        }
        ht(t) {
          this.rt = t;
        }
        et(t) {
          if (null === this.rt) return;
          const { ot: i, lt: s, wb: e, ct: h, Zt: n, Mb: r } = this.rt,
            o = this.rt.Db ?? (this.rt.Ib ? 0 : t.mediaSize.height);
          if (null === s) return;
          const a = t.context;
          (a.lineCap = "butt"),
            (a.lineJoin = "round"),
            (a.lineWidth = h),
            l(a, n),
            (a.lineWidth = 1),
            eh(t, i, r, s, e, this.Vb.bind(this), gh.bind(null, o));
        }
      }
      class wh {
        Bb(t, i) {
          const s = this.Eb,
            { Ab: e, Lb: h, zb: n, Ob: r, Db: o, Nb: l, Fb: a } = i;
          if (
            void 0 === this.Wb ||
            void 0 === s ||
            s.Ab !== e ||
            s.Lb !== h ||
            s.zb !== n ||
            s.Ob !== r ||
            s.Db !== o ||
            s.Nb !== l ||
            s.Fb !== a
          ) {
            const { verticalPixelRatio: s } = t,
              u = o || l > 0 ? s : 1,
              c = l * u,
              d = a === t.bitmapSize.height ? a : a * u,
              f = (o ?? 0) * u,
              m = t.context.createLinearGradient(0, c, 0, d);
            if ((m.addColorStop(0, e), null != o)) {
              const t = ii((f - c) / (d - c), 0, 1);
              m.addColorStop(t, h), m.addColorStop(t, n);
            }
            m.addColorStop(1, r), (this.Wb = m), (this.Eb = i);
          }
          return this.Wb;
        }
      }
      class Mh extends bh {
        constructor() {
          super(...arguments), (this.Hb = new wh());
        }
        Vb(t, i) {
          const s = this.rt;
          return this.Hb.Bb(t, {
            Ab: i.dh,
            Lb: i.fh,
            zb: i.ph,
            Ob: i.mh,
            Db: s.Db,
            Nb: s.Nb ?? 0,
            Fb: s.Fb ?? t.bitmapSize.height,
          });
        }
      }
      class yh extends lh {
        constructor() {
          super(...arguments), (this.Ub = new wh());
        }
        bb(t, i) {
          const s = this.rt;
          return this.Ub.Bb(t, {
            Ab: i._h,
            Lb: i._h,
            zb: i.uh,
            Ob: i.uh,
            Db: s.Db,
            Nb: s.Nb ?? 0,
            Fb: s.Fb ?? t.bitmapSize.height,
          });
        }
      }
      class Sh extends mh {
        constructor(t, i) {
          super(t, i),
            (this.kg = new N()),
            (this.$b = new Mh()),
            (this.jb = new yh()),
            this.kg.nt([this.$b, this.jb]);
        }
        xb(t, i, s) {
          return { ...this.Sb(t, i), ...s.Sh(t) };
        }
        Bg() {
          const t = this.ae.Lt();
          if (null === t) return;
          const i = this.ae.N(),
            s = this.ae.Ft().Nt(i.baseValue.price, t.Wt),
            e = this.le.Et().fl();
          if (null === this.Sg || 0 === this.bg.length) return;
          let h, n;
          if (i.relativeGradient) {
            (h = this.bg[this.Sg.from].ut), (n = this.bg[this.Sg.from].ut);
            for (let t = this.Sg.from; t < this.Sg.to; t++) {
              const i = this.bg[t];
              i.ut < h && (h = i.ut), i.ut > n && (n = i.ut);
            }
          }
          this.$b.ht({
            ot: this.bg,
            ct: i.lineWidth,
            Zt: i.lineStyle,
            Mb: i.lineType,
            Db: s,
            Nb: h,
            Fb: n,
            Ib: !1,
            lt: this.Sg,
            wb: e,
          }),
            this.jb.ht({
              ot: this.bg,
              ct: i.lineWidth,
              Zt: i.lineStyle,
              Mb: i.lineVisible ? i.lineType : void 0,
              gb: i.pointMarkersVisible
                ? i.pointMarkersRadius || i.lineWidth / 2 + 2
                : void 0,
              Db: s,
              Nb: h,
              Fb: n,
              lt: this.Sg,
              wb: e,
            });
        }
      }
      const xh = {
        type: "Baseline",
        isBuiltIn: !0,
        defaultOptions: {
          baseValue: { type: "price", price: 0 },
          relativeGradient: !1,
          topFillColor1: "rgba(38, 166, 154, 0.28)",
          topFillColor2: "rgba(38, 166, 154, 0.05)",
          topLineColor: "rgba(38, 166, 154, 1)",
          bottomFillColor1: "rgba(239, 83, 80, 0.05)",
          bottomFillColor2: "rgba(239, 83, 80, 0.28)",
          bottomLineColor: "rgba(239, 83, 80, 1)",
          lineWidth: 3,
          lineStyle: 0,
          lineType: 0,
          lineVisible: !0,
          crosshairMarkerVisible: !0,
          crosshairMarkerRadius: 4,
          crosshairMarkerBorderColor: "",
          crosshairMarkerBorderWidth: 2,
          crosshairMarkerBackgroundColor: "",
          lastPriceAnimation: 0,
          pointMarkersVisible: !1,
        },
        ob: (t, i) => new Sh(t, i),
      };
      class _h extends bh {
        constructor() {
          super(...arguments), (this.Hb = new wh());
        }
        Vb(t, i) {
          return this.Hb.Bb(t, {
            Ab: i.ah,
            Lb: "",
            zb: "",
            Ob: i.oh,
            Nb: this.rt?.Nb ?? 0,
            Fb: t.bitmapSize.height,
          });
        }
      }
      class Ch extends mh {
        constructor(t, i) {
          super(t, i),
            (this.kg = new N()),
            (this.qb = new _h()),
            (this.Yb = new ah()),
            this.kg.nt([this.qb, this.Yb]);
        }
        xb(t, i, s) {
          return { ...this.Sb(t, i), ...s.Sh(t) };
        }
        Bg() {
          const t = this.ae.N();
          if (null === this.Sg || 0 === this.bg.length) return;
          let i;
          if (t.relativeGradient) {
            i = this.bg[this.Sg.from].ut;
            for (let t = this.Sg.from; t < this.Sg.to; t++) {
              const s = this.bg[t];
              s.ut < i && (i = s.ut);
            }
          }
          this.qb.ht({
            Mb: t.lineType,
            ot: this.bg,
            Zt: t.lineStyle,
            ct: t.lineWidth,
            Db: null,
            Nb: i,
            Ib: t.invertFilledArea,
            lt: this.Sg,
            wb: this.le.Et().fl(),
          }),
            this.Yb.ht({
              Mb: t.lineVisible ? t.lineType : void 0,
              ot: this.bg,
              Zt: t.lineStyle,
              ct: t.lineWidth,
              lt: this.Sg,
              wb: this.le.Et().fl(),
              gb: t.pointMarkersVisible
                ? t.pointMarkersRadius || t.lineWidth / 2 + 2
                : void 0,
            });
        }
      }
      const Eh = {
        type: "Area",
        isBuiltIn: !0,
        defaultOptions: {
          topColor: "rgba( 46, 220, 135, 0.4)",
          bottomColor: "rgba( 40, 221, 100, 0)",
          invertFilledArea: !1,
          relativeGradient: !1,
          lineColor: "#33D778",
          lineStyle: 0,
          lineWidth: 3,
          lineType: 0,
          lineVisible: !0,
          crosshairMarkerVisible: !0,
          crosshairMarkerRadius: 4,
          crosshairMarkerBorderColor: "",
          crosshairMarkerBorderWidth: 2,
          crosshairMarkerBackgroundColor: "",
          lastPriceAnimation: 0,
          pointMarkersVisible: !1,
        },
        ob: (t, i) => new Ch(t, i),
      };
      class zh extends T {
        constructor() {
          super(...arguments), (this.qt = null), (this.Kb = 0), (this.Zb = 0);
        }
        ht(t) {
          this.qt = t;
        }
        et({ context: t, horizontalPixelRatio: i, verticalPixelRatio: s }) {
          if (
            null === this.qt ||
            0 === this.qt.Un.length ||
            null === this.qt.lt
          )
            return;
          (this.Kb = this.Gb(i)),
            this.Kb >= 2 &&
              Math.max(1, Math.floor(i)) % 2 != this.Kb % 2 &&
              this.Kb--,
            (this.Zb = this.qt.Xb ? Math.min(this.Kb, Math.floor(i)) : this.Kb);
          let e = null;
          const h = this.Zb <= this.Kb && this.qt.fl >= Math.floor(1.5 * i);
          for (let n = this.qt.lt.from; n < this.qt.lt.to; ++n) {
            const r = this.qt.Un[n];
            e !== r.sh && ((t.fillStyle = r.sh), (e = r.sh));
            const o = Math.floor(0.5 * this.Zb),
              l = Math.round(r._t * i),
              a = l - o,
              u = this.Zb,
              c = a + u - 1,
              d = Math.min(r.Qo, r.t_),
              f = Math.max(r.Qo, r.t_),
              m = Math.round(d * s) - o,
              p = Math.round(f * s) + o,
              v = Math.max(p - m, this.Zb);
            t.fillRect(a, m, u, v);
            const g = Math.ceil(1.5 * this.Kb);
            if (h) {
              if (this.qt.Jb) {
                const i = l - g;
                let e = Math.max(m, Math.round(r.Jo * s) - o),
                  h = e + u - 1;
                h > m + v - 1 && ((h = m + v - 1), (e = h - u + 1)),
                  t.fillRect(i, e, a - i, h - e + 1);
              }
              const i = l + g;
              let e = Math.max(m, Math.round(r.i_ * s) - o),
                h = e + u - 1;
              h > m + v - 1 && ((h = m + v - 1), (e = h - u + 1)),
                t.fillRect(c + 1, e, i - c, h - e + 1);
            }
          }
        }
        Gb(t) {
          const i = Math.floor(t);
          return Math.max(
            i,
            Math.floor(
              (function (t, i) {
                return Math.floor(0.3 * t * i);
              })(d(this.qt).fl, t)
            )
          );
        }
      }
      class kh extends xe {
        constructor(t, i) {
          super(t, i, !1);
        }
        Pg(t, i) {
          return we(
            this.bg,
            this.Sg,
            t,
            i,
            this.le.Et().fl(),
            this.ae.N().hitTestTolerance,
            (t, i) => {
              (i[0] = t.Qo), (i[1] = t.t_);
            }
          );
        }
        Vg(t, i, s) {
          i.Tc(this.bg, S(this.Sg)), t.Xo(this.bg, s, S(this.Sg));
        }
        Qb(t, i, s) {
          return {
            wt: t,
            jr: i.Wt[0],
            qr: i.Wt[1],
            Yr: i.Wt[2],
            Kr: i.Wt[3],
            _t: NaN,
            Jo: NaN,
            Qo: NaN,
            t_: NaN,
            i_: NaN,
          };
        }
        Dg() {
          const t = this.ae.Sa();
          this.bg = this.ae
            .Ha()
            .Bh()
            .map((i) => this.xb(i.$n, i, t));
        }
      }
      class Nh extends kh {
        constructor() {
          super(...arguments), (this.kg = new zh());
        }
        xb(t, i, s) {
          return { ...this.Qb(t, i, s), ...s.Sh(t) };
        }
        Bg() {
          const t = this.ae.N();
          this.kg.ht({
            Un: this.bg,
            fl: this.le.Et().fl(),
            Jb: t.openVisible,
            Xb: t.thinBars,
            lt: this.Sg,
          });
        }
      }
      const Th = {
        type: "Bar",
        isBuiltIn: !0,
        defaultOptions: {
          upColor: "#26a69a",
          downColor: "#ef5350",
          openVisible: !0,
          thinBars: !0,
        },
        ob: (t, i) => new Nh(t, i),
      };
      class Rh extends T {
        constructor() {
          super(...arguments), (this.qt = null), (this.Kb = 0);
        }
        ht(t) {
          this.qt = t;
        }
        et(t) {
          if (
            null === this.qt ||
            0 === this.qt.Un.length ||
            null === this.qt.lt
          )
            return;
          const { horizontalPixelRatio: i } = t;
          (this.Kb = (function (t, i) {
            if (t >= 2.5 && t <= 4) return Math.floor(3 * i);
            const s =
                1 - (0.2 * Math.atan(Math.max(4, t) - 4)) / (0.5 * Math.PI),
              e = Math.floor(t * s * i),
              h = Math.floor(t * i),
              n = Math.min(e, h);
            return Math.max(Math.floor(i), n);
          })(this.qt.fl, i)),
            this.Kb >= 2 && Math.floor(i) % 2 != this.Kb % 2 && this.Kb--;
          const s = this.qt.Un;
          this.qt.tS && this.iS(t, s, this.qt.lt),
            this.qt.gi && this.Rm(t, s, this.qt.lt);
          const e = this.nS(i);
          (!this.qt.gi || this.Kb > 2 * e) && this.sS(t, s, this.qt.lt);
        }
        iS(t, i, s) {
          if (null === this.qt) return;
          const {
            context: e,
            horizontalPixelRatio: h,
            verticalPixelRatio: n,
          } = t;
          let r = "",
            o = Math.min(Math.floor(h), Math.floor(this.qt.fl * h));
          o = Math.max(Math.floor(h), Math.min(o, this.Kb));
          const l = Math.floor(0.5 * o);
          let a = null;
          for (let t = s.from; t < s.to; t++) {
            const s = i[t];
            s.rh !== r && ((e.fillStyle = s.rh), (r = s.rh));
            const u = Math.round(Math.min(s.Jo, s.i_) * n),
              c = Math.round(Math.max(s.Jo, s.i_) * n),
              d = Math.round(s.Qo * n),
              f = Math.round(s.t_ * n);
            let m = Math.round(h * s._t) - l;
            const p = m + o - 1;
            null !== a && ((m = Math.max(a + 1, m)), (m = Math.min(m, p)));
            const v = p - m + 1;
            e.fillRect(m, d, v, u - d), e.fillRect(m, c + 1, v, f - c), (a = p);
          }
        }
        nS(t) {
          let i = Math.floor(1 * t);
          this.Kb <= 2 * i && (i = Math.floor(0.5 * (this.Kb - 1)));
          const s = Math.max(Math.floor(t), i);
          return this.Kb <= 2 * s
            ? Math.max(Math.floor(t), Math.floor(1 * t))
            : s;
        }
        Rm(t, i, s) {
          if (null === this.qt) return;
          const {
            context: e,
            horizontalPixelRatio: h,
            verticalPixelRatio: n,
          } = t;
          let r = "";
          const o = this.nS(h);
          let l = null;
          for (let t = s.from; t < s.to; t++) {
            const s = i[t];
            s.eh !== r && ((e.fillStyle = s.eh), (r = s.eh));
            let a = Math.round(s._t * h) - Math.floor(0.5 * this.Kb);
            const u = a + this.Kb - 1,
              c = Math.round(Math.min(s.Jo, s.i_) * n),
              d = Math.round(Math.max(s.Jo, s.i_) * n);
            if (
              (null !== l && ((a = Math.max(l + 1, a)), (a = Math.min(a, u))),
              this.qt.fl * h > 2 * o)
            )
              F(e, a, c, u - a + 1, d - c + 1, o);
            else {
              const t = u - a + 1;
              e.fillRect(a, c, t, d - c + 1);
            }
            l = u;
          }
        }
        sS(t, i, s) {
          if (null === this.qt) return;
          const {
            context: e,
            horizontalPixelRatio: h,
            verticalPixelRatio: n,
          } = t;
          let r = "";
          const o = this.nS(h);
          for (let t = s.from; t < s.to; t++) {
            const s = i[t];
            let l = Math.round(Math.min(s.Jo, s.i_) * n),
              a = Math.round(Math.max(s.Jo, s.i_) * n),
              u = Math.round(s._t * h) - Math.floor(0.5 * this.Kb),
              c = u + this.Kb - 1;
            if (s.sh !== r) {
              const t = s.sh;
              (e.fillStyle = t), (r = t);
            }
            this.qt.gi && ((u += o), (l += o), (c -= o), (a -= o)),
              l > a || e.fillRect(u, l, c - u + 1, a - l + 1);
          }
        }
      }
      class Lh extends kh {
        constructor() {
          super(...arguments), (this.kg = new Rh());
        }
        xb(t, i, s) {
          return { ...this.Qb(t, i, s), ...s.Sh(t) };
        }
        Bg() {
          const t = this.ae.N();
          this.kg.ht({
            Un: this.bg,
            fl: this.le.Et().fl(),
            tS: t.wickVisible,
            gi: t.borderVisible,
            lt: this.Sg,
          });
        }
      }
      const Ph = {
        type: "Candlestick",
        isBuiltIn: !0,
        defaultOptions: {
          upColor: "#26a69a",
          downColor: "#ef5350",
          wickVisible: !0,
          borderVisible: !0,
          borderColor: "#378658",
          borderUpColor: "#26a69a",
          borderDownColor: "#ef5350",
          wickColor: "#737375",
          wickUpColor: "#26a69a",
          wickDownColor: "#ef5350",
        },
        ob: (t, i) => new Lh(t, i),
      };
      class Ih extends T {
        constructor() {
          super(...arguments), (this.qt = null), (this.eS = []);
        }
        ht(t) {
          (this.qt = t), (this.eS = []);
        }
        et({ context: t, horizontalPixelRatio: i, verticalPixelRatio: s }) {
          if (
            null === this.qt ||
            0 === this.qt.ot.length ||
            null === this.qt.lt
          )
            return;
          this.eS.length || this.rS(i);
          const e = Math.max(1, Math.floor(s)),
            h = Math.round(this.qt.hS * s) - Math.floor(e / 2),
            n = h + e;
          for (let i = this.qt.lt.from; i < this.qt.lt.to; i++) {
            const r = this.qt.ot[i],
              o = this.eS[i - this.qt.lt.from],
              l = Math.round(r.ut * s);
            let a, u;
            (t.fillStyle = r.sh),
              l <= h
                ? ((a = l), (u = n))
                : ((a = h), (u = l - Math.floor(e / 2) + e)),
              t.fillRect(o.Oa, a, o.bi - o.Oa + 1, u - a);
          }
        }
        rS(t) {
          if (
            null === this.qt ||
            0 === this.qt.ot.length ||
            null === this.qt.lt
          )
            return void (this.eS = []);
          const i =
              Math.ceil(this.qt.fl * t) <= 1 ? 0 : Math.max(1, Math.floor(t)),
            s = Math.round(this.qt.fl * t) - i;
          this.eS = new Array(this.qt.lt.to - this.qt.lt.from);
          for (let i = this.qt.lt.from; i < this.qt.lt.to; i++) {
            const e = this.qt.ot[i],
              h = Math.round(e._t * t);
            let n, r;
            if (s % 2) {
              const t = (s - 1) / 2;
              (n = h - t), (r = h + t);
            } else {
              const t = s / 2;
              (n = h - t), (r = h + t - 1);
            }
            this.eS[i - this.qt.lt.from] = {
              Oa: n,
              bi: r,
              aS: h,
              ce: e._t * t,
              wt: e.wt,
            };
          }
          for (let t = this.qt.lt.from + 1; t < this.qt.lt.to; t++) {
            const s = this.eS[t - this.qt.lt.from],
              e = this.eS[t - this.qt.lt.from - 1];
            s.wt === e.wt + 1 &&
              s.Oa - e.bi !== i + 1 &&
              (e.aS > e.ce ? (e.bi = s.Oa - i - 1) : (s.Oa = e.bi + i + 1));
          }
          let e = Math.ceil(this.qt.fl * t);
          for (let t = this.qt.lt.from; t < this.qt.lt.to; t++) {
            const i = this.eS[t - this.qt.lt.from];
            i.bi < i.Oa && (i.bi = i.Oa);
            const s = i.bi - i.Oa + 1;
            e = Math.min(s, e);
          }
          if (i > 0 && e < 4)
            for (let t = this.qt.lt.from; t < this.qt.lt.to; t++) {
              const i = this.eS[t - this.qt.lt.from];
              i.bi - i.Oa + 1 > e && (i.aS > i.ce ? (i.bi -= 1) : (i.Oa += 1));
            }
        }
      }
      class qh extends fh {
        constructor() {
          super(...arguments), (this.kg = new Ih());
        }
        Pg(t, i) {
          const s = this.ae.Ft().Nt(this.ae.N().base, d(this.ae.Lt()).Wt);
          return null === s
            ? null
            : we(
                this.bg,
                this.Sg,
                t,
                i,
                this.le.Et().fl(),
                this.ae.N().hitTestTolerance,
                (t, i) => {
                  (i[0] = t.ut), (i[1] = s);
                }
              );
        }
        xb(t, i, s) {
          return { ...this.Sb(t, i), ...s.Sh(t) };
        }
        Bg() {
          const t = {
            ot: this.bg,
            fl: this.le.Et().fl(),
            lt: this.Sg,
            hS: this.ae.Ft().Nt(this.ae.N().base, d(this.ae.Lt()).Wt),
          };
          this.kg.ht(t);
        }
      }
      const Oh = {
        type: "Histogram",
        isBuiltIn: !0,
        defaultOptions: { color: "#26a69a", base: 0 },
        ob: (t, i) => new qh(t, i),
      };
      class Fh {
        constructor(t, i) {
          (this.yt = t), (this.lS = i), this.oS();
        }
        detach() {
          this.yt.detachPrimitive(this.lS);
        }
        getPane() {
          return this.yt;
        }
        applyOptions(t) {
          this.lS.vr?.(t);
        }
        oS() {
          this.yt.attachPrimitive(this.lS);
        }
      }
      const Wh = {
          visible: !0,
          horzAlign: "center",
          vertAlign: "center",
          lines: [],
        },
        Bh = {
          color: "rgba(0, 0, 0, 0.5)",
          fontSize: 48,
          fontFamily: x,
          fontStyle: "",
          text: "",
        };
      class Qh {
        constructor(t) {
          (this._S = new Map()), (this.qt = t);
        }
        draw(t) {
          t.useMediaCoordinateSpace((t) => {
            if (!this.qt.visible) return;
            const { context: i, mediaSize: s } = t;
            let e = 0;
            for (const t of this.qt.lines) {
              if (0 === t.text.length) continue;
              i.font = t.P;
              const h = this.uS(i, t.text);
              h > s.width ? (t.Fc = s.width / h) : (t.Fc = 1),
                (e += t.lineHeight * t.Fc);
            }
            let h = 0;
            switch (this.qt.vertAlign) {
              case "top":
                h = 0;
                break;
              case "center":
                h = Math.max((s.height - e) / 2, 0);
                break;
              case "bottom":
                h = Math.max(s.height - e, 0);
            }
            for (const t of this.qt.lines) {
              i.save(), (i.fillStyle = t.color);
              let e = 0;
              switch (this.qt.horzAlign) {
                case "left":
                  (i.textAlign = "left"), (e = t.lineHeight / 2);
                  break;
                case "center":
                  (i.textAlign = "center"), (e = s.width / 2);
                  break;
                case "right":
                  (i.textAlign = "right"), (e = s.width - 1 - t.lineHeight / 2);
              }
              i.translate(e, h),
                (i.textBaseline = "top"),
                (i.font = t.P),
                i.scale(t.Fc, t.Fc),
                i.fillText(t.text, 0, t.cS),
                i.restore(),
                (h += t.lineHeight * t.Fc);
            }
          });
        }
        uS(t, i) {
          const s = this.dS(t.font);
          let e = s.get(i);
          return void 0 === e && ((e = t.measureText(i).width), s.set(i, e)), e;
        }
        dS(t) {
          let i = this._S.get(t);
          return void 0 === i && ((i = new Map()), this._S.set(t, i)), i;
        }
      }
      class Dh {
        constructor(t) {
          this.yn = Vh(t);
        }
        kt(t) {
          this.yn = Vh(t);
        }
        renderer() {
          return new Qh(this.yn);
        }
      }
      function Kh(t) {
        return {
          ...t,
          P: _(t.fontSize, t.fontFamily, t.fontStyle),
          lineHeight: t.lineHeight || 1.2 * t.fontSize,
          cS: 0,
          Fc: 0,
        };
      }
      function Vh(t) {
        return { ...t, lines: t.lines.map(Kh) };
      }
      function $h(t) {
        return { ...Bh, ...t };
      }
      function Ah(t) {
        return { ...Wh, ...t, lines: t.lines?.map($h) ?? [] };
      }
      class Zh {
        constructor(t) {
          (this.yn = Ah(t)), (this.fS = [new Dh(this.yn)]);
        }
        updateAllViews() {
          this.fS.forEach((t) => t.kt(this.yn));
        }
        paneViews() {
          return this.fS;
        }
        attached({ requestUpdate: t }) {
          this.pS = t;
        }
        detached() {
          this.pS = void 0;
        }
        vr(t) {
          (this.yn = Ah({ ...this.yn, ...t })), this.pS && this.pS();
        }
      }
      function Hh(t, i) {
        return new Fh(t, new Zh(i));
      }
      const Gh = { ...h, color: "#2196f3" };
    },
  },
]);
