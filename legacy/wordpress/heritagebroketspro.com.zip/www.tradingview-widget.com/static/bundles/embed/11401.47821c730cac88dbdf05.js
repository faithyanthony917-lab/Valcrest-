"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [11401],
  {
    66721(e, i, r) {
      r.d(i, { numOfDecimalPlaces: () => n });
      var t = r(712745),
        a = r.n(t);
      function n(e) {
        return (new (a())(e).toFixed().split(".")[1] || "").length;
      }
    },
    135190(e, i, r) {
      function t(e, i, r, t) {
        let a = 0;
        if (e > 0 && i > 0) {
          let i = e;
          for (r && t && (i /= t); i > 1; ) (i /= 10), a++;
        }
        return a;
      }
      r.d(i, { calculateDecimal: () => t });
    },
    584221(e, i, r) {
      r.d(i, { DecimalPriceFormatterImpl: () => c });
      var t = r(712745),
        a = r(948102),
        n = r(837483),
        o = r(925639),
        s = r(454858);
      class c extends s.PriceFormatterImplementationBase {
        hasForexAdditionalPrecision() {
          return 10 === this._minMove2;
        }
        _parseUnsigned(e, i) {
          return this._parseAsDecimal(e, i);
        }
        _formatUnsigned(e, i) {
          const {
              tailSize: r,
              cutFractionalByPrecision: t = !1,
              variableMinTickDataPrice: a,
              ignoreLocaleNumberFormat: n,
              noExponentialForm: o,
              removeAllEndingZeros: c = !1,
            } = i,
            l = {
              price: Math.abs(e),
              priceScale: this._priceScale,
              minMove: this._minMove,
              fractionalLength: this._fractionalLength,
              tailSize: r,
              cutFractionalByPrecision: t,
              ignoreLocaleNumberFormat: n,
              noExponentialForm: o,
              removeAllEndingZeros: c,
            };
          return (
            void 0 !== this._variableMinTickData &&
              (Object.assign(
                l,
                (0, s.variableMinTickParamsByPrice)(
                  !1,
                  this._variableMinTickData,
                  a ?? l.price
                )
              ),
              this._ignoreMinMove && (l.minMove = 1)),
            this._formatAsDecimal(l)
          );
        }
        _formatAsDecimal(e) {
          const {
              price: i,
              priceScale: r,
              minMove: s,
              fractionalLength: c = 0,
              tailSize: l = 0,
              cutFractionalByPrecision: m,
              ignoreLocaleNumberFormat: h = this._ignoreLocaleNumberFormat,
              noExponentialForm: u = this._noExponentialForm,
              removeAllEndingZeros: p,
            } = e,
            v = (0, o.getNumberFormat)(h);
          if (i >= 1e21 && !u) return i.toString().replace(".", v.decimalSign);
          const g = (Math.pow(10, l) * r) / (m ? 1 : s),
            M = 1 / g;
          let _;
          if (g > 1) _ = Math.floor(i);
          else {
            const e = Math.round(i / M) * M;
            _ = 0 === Math.round((i - e) / M) ? e : e + M;
          }
          let d = "";
          if (g > 1) {
            let e = m
              ? new t.Big(i)
                  .mul(g)
                  .round(void 0, 0)
                  .minus(new t.Big(_).mul(g))
                  .toNumber()
              : parseFloat((Math.round(i * g) - _ * g).toFixed(c));
            e >= g && ((e -= g), (_ += 1)),
              (e = m
                ? new t.Big(e).round(c, 0).toNumber()
                : Math.round(parseFloat(e.toFixed(c)) * s));
            const r = (0, a.numberToStringWithLeadingZero)(e, c + l);
            if (!u && i < 1 && c >= 10 && r.startsWith("0000")) {
              let e = 4;
              for (let i = e; i < r.length && "0" === r[i]; i++) e++;
              const i = this._removeEndingZeros(r.slice(e), c);
              return "" === i ? "0" : `0${v.decimalSign}${i}e-${e}`;
            }
            const n = this._removeEndingZeros(r, p ? r.length : l);
            d = n ? v.decimalSign + n : n;
          }
          const f = (0, n.formatNumber)(_, v, void 0, u);
          return f.includes("e") ? f : f + d;
        }
        _parseAsDecimal(e, i = {}) {
          const { ignoreLocaleNumberFormat: r } = i,
            t = (0, o.getNumberFormat)(this._ignoreLocaleNumberFormat || r),
            a = (0, n.parseNumber)(e, t);
          return Number.isFinite(a)
            ? { value: a, res: !0, suggest: this.formatImpl(a) }
            : { error: this._formatterErrors.custom, res: !1 };
        }
        constructor(e) {
          super(e);
          const { ignoreLocaleNumberFormat: i, noExponentialForm: r } = e;
          (this._ignoreLocaleNumberFormat = i), (this._noExponentialForm = r);
        }
      }
    },
    873741(e, i, r) {
      r.d(i, { FractionalPriceFormatterImpl: () => c });
      var t = r(146961),
        a = r(948102),
        n = r(454858);
      const o = "'",
        s = new RegExp(/^(-?)[0-9]+$/);
      class c extends n.PriceFormatterImplementationBase {
        hasForexAdditionalPrecision() {
          return !1;
        }
        _parseUnsigned(e) {
          return this._minMove2
            ? this._parseAsDoubleFractional(e)
            : this._parseAsSingleFractional(e);
        }
        _formatUnsigned(e, i) {
          const { tailSize: r, variableMinTickDataPrice: a } = i,
            o = {
              price: Math.abs(e),
              priceScale: this._priceScale,
              minMove: this._minMove,
              minMove2: this._minMove2,
              fractionalLength: (0, t.ensureDefined)(this._fractionalLength),
              tailSize: r,
            };
          return (
            void 0 !== this._variableMinTickData &&
              Object.assign(
                o,
                (0, n.variableMinTickParamsByPrice)(
                  !0,
                  this._variableMinTickData,
                  a ?? o.price
                )
              ),
            this._formatAsFractional(o)
          );
        }
        _parseAsSingleFractional(e) {
          let i = s.exec(e);
          if (i) {
            const i = parseFloat(e);
            return { value: i, res: !0, suggest: this.formatImpl(i) };
          }
          if (((i = new RegExp("^(-?)([0-9]+)\\'([0-9]+)$").exec(e)), i)) {
            const e = !!i[1],
              r = parseInt(i[2]),
              t = this._priceScale,
              a = this._patchFractPart(parseInt(i[3]), 1, t);
            if (a >= t || a < 0)
              return { error: this._formatterErrors.fraction, res: !1 };
            let n = r + a / t;
            return (
              e && (n = -n), { value: n, res: !0, suggest: this.formatImpl(n) }
            );
          }
          return { error: this._formatterErrors.custom, res: !1 };
        }
        _parseAsDoubleFractional(e) {
          let i = s.exec(e);
          if (i) {
            const i = parseFloat(e);
            return { value: i, res: !0, suggest: this.formatImpl(i) };
          }
          if (
            ((i = new RegExp("^(-?)([0-9]+)\\'([0-9]+)\\'([0-9]+)$").exec(e)),
            i)
          ) {
            const e = !!i[1],
              r = parseInt(i[2]),
              t =
                void 0 !== this._minMove2 && null !== this._minMove2
                  ? this._minMove2
                  : NaN,
              a = this._priceScale / t,
              n = this._minMove2,
              o = this._patchFractPart(parseInt(i[3]), 1, a),
              s = this._patchFractPart(parseInt(i[4]), 2, n);
            if (o >= a || o < 0)
              return { error: this._formatterErrors.fraction, res: !1 };
            if ((null != n && s >= n) || s < 0)
              return { error: this._formatterErrors.secondFraction, res: !1 };
            let c = null != n ? r + o / a + s / (a * n) : NaN;
            return (
              e && (c = -c), { value: c, res: !0, suggest: this.formatImpl(c) }
            );
          }
          return { error: this._formatterErrors.custom, res: !1 };
        }
        _patchFractPart(e, i, r) {
          const t = { 0: 0, 5: 1 },
            a = { 0: 0, 2: 1, 5: 2, 7: 3 },
            n = { 0: 0, 1: 1, 2: 2, 3: 3, 5: 4, 6: 5, 7: 6, 8: 7 };
          return 2 === r
            ? void 0 === t[e]
              ? -1
              : t[e]
            : 4 === r
            ? void 0 === a[e]
              ? -1
              : a[e]
            : 8 === r && 2 === i
            ? void 0 === n[e]
              ? -1
              : n[e]
            : e;
        }
        _formatAsFractional(e) {
          const {
              price: i,
              tailSize: r,
              priceScale: t,
              minMove: n,
              minMove2: s,
              fractionalLength: c,
            } = e,
            l = t / n;
          let m = Math.floor(i),
            h = r ? Math.floor(i * l) - m * l : Math.round(i * l) - m * l;
          h === l && ((h = 0), (m += 1));
          let u = "";
          if (r) {
            let e = (i - m - h / l) * l;
            (e = Math.round(e * Math.pow(10, r))),
              (u = (0, a.numberToStringWithLeadingZero)(e, r)),
              (u = this._removeEndingZeros(u, r));
          }
          if (!c) throw new Error("_fractionalLength is not calculated");
          let p = "";
          if (s) {
            const e = h % s;
            h = (h - e) / s;
            const i = (0, a.numberToStringWithLeadingZero)(h, c),
              r = this._getFractPart(e, 2, s);
            p = i + o + r;
          } else
            (h = this._getFractPart(h, 1, t)),
              (p = (0, a.numberToStringWithLeadingZero)(h * n, c));
          return m.toString() + o + p + u;
        }
        _getFractPart(e, i, r) {
          const t = [0, 5],
            a = [0, 2, 5, 7],
            n = [0, 1, 2, 3, 5, 6, 7, 8];
          return 2 === r
            ? void 0 === t[e]
              ? -1
              : t[e]
            : 4 === r
            ? void 0 === a[e]
              ? -1
              : a[e]
            : 8 === r && 2 === i
            ? void 0 === n[e]
              ? -1
              : n[e]
            : e;
        }
      }
    },
    958633(e, i, r) {
      r.d(i, { PriceFormatter: () => s });
      var t = r(881014),
        a = r(135190),
        n = r(584221),
        o = r(873741);
      class s {
        isFractional() {
          return !!this._fractional;
        }
        state() {
          return {
            minMove: this._minMove,
            minMove2: this._minMove2,
            priceScale: this._priceScale,
            variableMinTick: this._variableMinTick,
            ignoreMinMove: this._ignoreMinMove,
            fractional: this._fractional,
            noExponentialForm: this._noExponentialForm,
          };
        }
        formatChange(e, i, r) {
          return this._implementation.formatImpl(e - i, {
            ...r,
            variableMinTickDataPrice: Math.min(Math.abs(e), Math.abs(i)),
          });
        }
        format(e, i) {
          return this._implementation.formatImpl(e, i);
        }
        parse(e, i) {
          return this._implementation.parse(e, i);
        }
        hasForexAdditionalPrecision() {
          return this._implementation.hasForexAdditionalPrecision();
        }
        static serialize(e) {
          return e.state();
        }
        static deserialize(e) {
          return new s(e);
        }
        constructor(e = {}) {
          this.type = "price";
          const {
              minMove2: i,
              fractional: r,
              variableMinTick: s,
              ignoreMinMove: c,
              ignoreLocaleNumberFormat: l,
            } = e,
            m =
              (0, t.isNumber)(e.priceScale) && (0, t.isInteger)(e.priceScale)
                ? e.priceScale
                : 100;
          if (m < 0) throw new TypeError("invalid base");
          const h = !e.minMove || c ? 1 : e.minMove,
            u = (0, a.calculateDecimal)(m, h, r, i),
            p = { ...e, minMove: h, priceScale: m, fractionalLength: u };
          (this._priceScale = m),
            (this._minMove = h),
            (this._minMove2 = i),
            (this._fractional = r),
            (this._variableMinTick = s),
            (this._ignoreMinMove = c),
            (this._fractionalLength = u),
            (this._ignoreLocaleNumberFormat = l),
            (this._noExponentialForm = e.noExponentialForm),
            (this._implementation = r
              ? new o.FractionalPriceFormatterImpl(p)
              : new n.DecimalPriceFormatterImpl(p));
        }
      }
    },
    454858(e, i, r) {
      r.d(i, {
        PriceFormatterImplementationBase: () => l,
        variableMinTickParamsByPrice: () => c,
      });
      var t = r(383636),
        a = r(146961),
        n = r(135190),
        o = r(334120),
        s = r(505519);
      function c(e, i, r) {
        const t = (0, a.ensureNotNull)(
            (0, s.getMinTickData)({
              price: r,
              minTick: null,
              variableMinTickData: i,
              shouldCheckForEquality: !0,
            })
          ),
          { priceScale: o, minMove: c, minMove2: l } = t;
        return {
          priceScale: o,
          minMove: c,
          fractionalLength: (0, n.calculateDecimal)(o, c, e, l),
        };
      }
      class l {
        formatImpl(e, i = {}) {
          const {
            signPositive: r,
            signNegative: t = !0,
            tailSize: a,
            cutFractionalByPrecision: n = !1,
            useRtlFormat: s = !0,
            variableMinTickDataPrice: c,
            ignoreLocaleNumberFormat: l,
            noExponentialForm: m,
            removeAllEndingZeros: h,
          } = i;
          let u = "";
          e < 0 ? (u = !1 === t ? "" : "−") : e && !0 === r && (u = "+");
          const p = this._formatUnsigned(Math.abs(e), {
              tailSize: a,
              cutFractionalByPrecision: n,
              variableMinTickDataPrice: c,
              ignoreLocaleNumberFormat: l,
              noExponentialForm: m,
              removeAllEndingZeros: h,
            }),
            v = "0" === p ? p : u + p;
          return s ? (0, o.forceLTRStr)(v) : v;
        }
        parse(e, i) {
          return (
            "+" === (e = (e = (0, o.stripLTRMarks)(e)).replace("−", "-"))[0] &&
              (e = e.substring(1)),
            this._parseUnsigned(e, i)
          );
        }
        _removeEndingZeros(e, i) {
          for (let r = 0; r < i && "0" === e[e.length - 1]; r++)
            e = e.substring(0, e.length - 1);
          return e;
        }
        constructor(e) {
          this._formatterErrors = {
            custom: t.t(null, void 0, r(61618)),
            fraction: t.t(null, void 0, r(968815)),
            secondFraction: t.t(null, void 0, r(850298)),
          };
          const {
            priceScale: i,
            minMove: a,
            minMove2: n,
            ignoreMinMove: o,
            variableMinTick: c,
            fractionalLength: l,
          } = e;
          (this._priceScale = i),
            (this._minMove = a),
            (this._minMove2 = n),
            (this._ignoreMinMove = o),
            (this._fractionalLength = l),
            (this._variableMinTickData =
              void 0 === c
                ? void 0
                : (0, s.makeVariableMinTickData)(
                    { priceScale: i, minMove: a, minMove2: n },
                    c
                  ));
        }
      }
    },
  },
]);
