(() => {
  "use strict";
  var e,
    r,
    t,
    n = {},
    a = {};
  function i(e) {
    var r = a[e];
    if (void 0 !== r) return r.exports;
    var t = (a[e] = { exports: {} });
    return n[e].call(t.exports, t, t.exports, i), t.exports;
  }
  (i.m = n),
    (i._plural = {
      ar: (
        e,
        r = 6,
        t = 0 == e
          ? 0
          : 1 == e
          ? 1
          : 2 == e
          ? 2
          : e % 100 >= 3 && e % 100 <= 10
          ? 3
          : e % 100 >= 11 && e % 100 <= 99
          ? 4
          : 5
      ) => (null == e ? 0 : +t),
      cs: (e, r = 3, t = 1 == e ? 0 : e >= 2 && e <= 4 ? 1 : 2) =>
        null == e ? 0 : +t,
      ru: (
        e,
        r = 3,
        t = e % 10 == 1 && e % 100 != 11
          ? 0
          : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20)
          ? 1
          : 2
      ) => (null == e ? 0 : +t),
      ro: (
        e,
        r = 3,
        t = 1 == e ? 0 : e % 100 > 19 || (e % 100 == 0 && 0 != e) ? 2 : 1
      ) => (null == e ? 0 : +t),
      pl: (
        e,
        r = 3,
        t = 1 == e
          ? 0
          : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20)
          ? 1
          : 2
      ) => (null == e ? 0 : +t),
      pt: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      de: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      en: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      es: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      sv: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      it: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      tr: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      el: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      fr: (e, r = 2, t = e > 1) => (null == e ? 0 : +t),
      fa: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      ja: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      ko: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      th: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      vi: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      zh: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      he_IL: (
        e,
        r = 4,
        t = 1 == e ? 0 : 2 == e ? 1 : e > 10 && e % 10 == 0 ? 2 : 3
      ) => (null == e ? 0 : +t),
      ca_ES: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      nl_NL: (e, r = 2, t = 1 != e) => (null == e ? 0 : +t),
      hu_HU: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      id_ID: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      ms_MY: (e, r = 1, t = 0) => (null == e ? 0 : +t),
      zh_TW: (e, r = 1, t = 0) => (null == e ? 0 : +t),
    }),
    (e = []),
    (i.O = (r, t, n, a) => {
      if (!t) {
        var l = 1 / 0;
        for (u = 0; u < e.length; u++) {
          for (var [t, n, a] = e[u], o = !0, c = 0; c < t.length; c++)
            (!1 & a || l >= a) && Object.keys(i.O).every((e) => i.O[e](t[c]))
              ? t.splice(c--, 1)
              : ((o = !1), a < l && (l = a));
          if (o) {
            e.splice(u--, 1);
            var d = n();
            void 0 !== d && (r = d);
          }
        }
        return r;
      }
      a = a || 0;
      for (var u = e.length; u > 0 && e[u - 1][2] > a; u--) e[u] = e[u - 1];
      e[u] = [t, n, a];
    }),
    (i.n = (e) => {
      var r = e && e.__esModule ? () => e.default : () => e;
      return i.d(r, { a: r }), r;
    }),
    (i.d = (e, r) => {
      for (var t in r)
        i.o(r, t) &&
          !i.o(e, t) &&
          Object.defineProperty(e, t, { enumerable: !0, get: r[t] });
    }),
    (i.f = {}),
    (i.e = (e) =>
      Promise.all(Object.keys(i.f).reduce((r, t) => (i.f[t](e, r), r), []))),
    (i.u = (e) =>
      23567 === e
        ? "__LANG__." + e + ".5fddc15998142cbc61ef.js"
        : ({
            1646: "legend-view-renderer",
            7397: "period-formatter",
            13993: "pushstream-multiplexer",
            16813: "tradingview-copyright-with-border-data-impl",
            28507: "get-error-card",
            35592: "error-lottie-animation",
            44162: "time-frame-view-renderer",
            66399: "snowplow-tracker",
            69874: "lottie.worker",
            71394: "cmoneycomtw-copyright-data-impl",
            76040: "tradingview-copyright-new-data-impl",
            79041: "tradingview-copyright-trade-with-data-impl",
            85038: "lentaru-copyright-data-impl",
            93279: "mini-chart-bar-builder",
            97509: "tradingview-copyright-data-impl",
          }[e] || e) +
          "." +
          {
            1646: "8248186f06bfbf13b93f",
            2011: "64cc6b77735b34be320d",
            5220: "3e3907c7b338f67a80ff",
            7397: "27c3118d2bd705cbbec9",
            12181: "b65a58355ff7cc34950f",
            13993: "0b36831186d26dbae937",
            16813: "1b4159004e1387cc7a92",
            27046: "335346a3db4a7ad06275",
            28507: "9b3d791477d91f7e87d2",
            35592: "c54ffccdaacb9b36c929",
            44162: "5b6029997e947595d1cd",
            50488: "b66afb42cd52e6574eaa",
            66399: "46ebfe68016e0a7b9006",
            69874: "375d9607d867556f88e9",
            71394: "feec6c3c16afdcaaf709",
            76040: "c870111e24cd5e3d624e",
            79041: "a9a5ba87385a3fc19728",
            85038: "55ea5a645ed2e08cf36d",
            91951: "e53796999f83c412edaf",
            93279: "4467dfe01fa9de250afb",
            97509: "97af3ea79214fb14155d",
          }[e] +
          ".js"),
    (i.miniCssF = (e) =>
      82727 === e
        ? e + ".d01f1dd46a1d1676fb9d.css"
        : 24827 === e
        ? e + ".78561ebdef05ce648b5d.css"
        : 96212 === e
        ? e + ".2ddf934f8edc2802d90a.css"
        : 20750 === e
        ? e + ".76948764014ae1d4ccfb.css"
        : e +
          "." +
          {
            16350: "e88c7d3ba4fd368f1921",
            17007: "c17ab88c079fa242b861",
            38213: "5595b0bd6c3964d97cbd",
            61483: "152c78f4d708c449032c",
            70715: "a325ebd9ba9063aec486",
            76281: "fe58154576615f501f8d",
            84351: "ee41920526450899c2d5",
            84435: "9bfb5b3a8be8d5ec9556",
            92991: "6ce41a3759fd4d2ad4c5",
            98373: "05118b64bf5334f0296c",
          }[e] +
          ".css"),
    (i.g = (function () {
      if ("object" == typeof globalThis) return globalThis;
      try {
        return this || new Function("return this")();
      } catch (e) {
        if ("object" == typeof window) return window;
      }
    })()),
    (i.o = (e, r) => Object.prototype.hasOwnProperty.call(e, r)),
    (r = {}),
    (t = "tradingview:"),
    (i.l = (e, n, a, l) => {
      if (r[e]) r[e].push(n);
      else {
        var o, c;
        if (void 0 !== a)
          for (
            var d = document.getElementsByTagName("script"), u = 0;
            u < d.length;
            u++
          ) {
            var f = d[u];
            if (
              f.getAttribute("src") == e ||
              f.getAttribute("data-webpack") == t + a
            ) {
              o = f;
              break;
            }
          }
        o ||
          ((c = !0),
          ((o = document.createElement("script")).charset = "utf-8"),
          i.nc && o.setAttribute("nonce", i.nc),
          o.setAttribute("data-webpack", t + a),
          (o.src = e),
          0 !== o.src.indexOf(window.location.origin + "/") &&
            (o.crossOrigin = "anonymous")),
          (r[e] = [n]);
        var s = (t, n) => {
            (o.onerror = o.onload = null), clearTimeout(b);
            var a = r[e];
            if (
              (delete r[e],
              o.parentNode && o.parentNode.removeChild(o),
              a && a.forEach((e) => e(n)),
              t)
            )
              return t(n);
          },
          b = setTimeout(
            s.bind(null, void 0, { type: "timeout", target: o }),
            12e4
          );
        (o.onerror = s.bind(null, o.onerror)),
          (o.onload = s.bind(null, o.onload)),
          c && document.head.appendChild(o);
      }
    }),
    (i.r = (e) => {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (i.j = 92833),
    (() => {
      var e;
      i.g.importScripts && (e = i.g.location + "");
      var r = i.g.document;
      if (
        !e &&
        r &&
        (r.currentScript &&
          "SCRIPT" === r.currentScript.tagName.toUpperCase() &&
          (e = r.currentScript.src),
        !e)
      ) {
        var t = r.getElementsByTagName("script");
        if (t.length)
          for (var n = t.length - 1; n > -1 && (!e || !/^http(s?):/.test(e)); )
            e = t[n--].src;
      }
      if (!e)
        throw new Error(
          "Automatic publicPath is not supported in this browser"
        );
      (e = e
        .replace(/^blob:/, "")
        .replace(/#.*$/, "")
        .replace(/\?.*$/, "")
        .replace(/\/[^\/]+$/, "/")),
        (i.p = e);
    })(),
    i.g.location &&
      i.p.startsWith(i.g.location.origin) &&
      (i.p = i.p.slice(i.g.location.origin.length)),
    (() => {
      const e = i.u;
      i.u = (r) => e(r).replace("__LANG__", i.g.language);
    })(),
    (() => {
      var e = i.e,
        r = Object.create(null);
      function t(r, n) {
        return e(r).catch(function () {
          return new Promise(function (a) {
            var i = function () {
              self.removeEventListener("online", i, !1),
                !1 === navigator.onLine
                  ? self.addEventListener("online", i, !1)
                  : a(n < 2 ? t(r, n + 1) : e(r));
            };
            setTimeout(i, n * n * 1e3);
          });
        });
      }
      i.e = function (e) {
        if (!r[e]) {
          r[e] = t(e, 0);
          var n = function () {
            delete r[e];
          };
          r[e].then(n, n);
        }
        return r[e];
      };
    })(),
    (() => {
      if ("undefined" != typeof document) {
        var e = (e) =>
            new Promise((r, t) => {
              var n = i.miniCssF(e),
                a = i.p + n;
              if (
                ((e, r) => {
                  for (
                    var t = document.getElementsByTagName("link"), n = 0;
                    n < t.length;
                    n++
                  ) {
                    var a =
                      (l = t[n]).getAttribute("data-href") ||
                      l.getAttribute("href");
                    if ("stylesheet" === l.rel && (a === e || a === r))
                      return l;
                  }
                  var i = document.getElementsByTagName("style");
                  for (n = 0; n < i.length; n++) {
                    var l;
                    if (
                      (a = (l = i[n]).getAttribute("data-href")) === e ||
                      a === r
                    )
                      return l;
                  }
                })(n, a)
              )
                return r();
              ((e, r, t, n, a) => {
                var i = document.createElement("link");
                (i.rel = "stylesheet"),
                  (i.type = "text/css"),
                  (i.onerror = i.onload =
                    (t) => {
                      if (((i.onerror = i.onload = null), "load" === t.type))
                        n();
                      else {
                        var l = t && ("load" === t.type ? "missing" : t.type),
                          o = (t && t.target && t.target.href) || r,
                          c = new Error(
                            "Loading CSS chunk " + e + " failed.\n(" + o + ")"
                          );
                        (c.code = "CSS_CHUNK_LOAD_FAILED"),
                          (c.type = l),
                          (c.request = o),
                          i.parentNode && i.parentNode.removeChild(i),
                          a(c);
                      }
                    }),
                  (i.href = r),
                  0 !== i.href.indexOf(window.location.origin + "/") &&
                    (i.crossOrigin = "anonymous"),
                  t
                    ? t.parentNode.insertBefore(i, t.nextSibling)
                    : document.head.appendChild(i);
              })(e, a, null, r, t);
            }),
          r = { 92833: 0 };
        i.f.miniCss = (t, n) => {
          r[t]
            ? n.push(r[t])
            : 0 !== r[t] &&
              {
                16350: 1,
                17007: 1,
                20750: 1,
                24827: 1,
                38213: 1,
                61483: 1,
                70715: 1,
                76281: 1,
                82727: 1,
                84351: 1,
                84435: 1,
                92991: 1,
                96212: 1,
                98373: 1,
              }[t] &&
              n.push(
                (r[t] = e(t).then(
                  () => {
                    r[t] = 0;
                  },
                  (e) => {
                    throw (delete r[t], e);
                  }
                ))
              );
        };
      }
    })(),
    (i.i18next = (e, r = {}, t, n = i.g.language) => {
      if (null === e) {
        if (Array.isArray(t))
          return t[void 0 === r.count ? 0 : i._plural[n](r.count)].replace(
            /{(\w+)}/g,
            (e, t) => (void 0 !== (r.replace || r)[t] ? (r.replace || r)[t] : e)
          );
        if ("object" == typeof t)
          return t[i.g.language]
            ? i.i18next(null, r, t[i.g.language])
            : i.i18next(null, r, t.en, "en");
      } else if (t && e) {
        const n = `${e}${r.context ? `_${r.context}` : ""}`;
        if (t[n]) return i.i18next(null, r, t[n]);
      }
      return "number" == typeof e
        ? e.toString()
        : "string" != typeof e
        ? ""
        : e;
    }),
    (() => {
      i.b =
        ("undefined" != typeof document && document.baseURI) ||
        self.location.href;
      var e = {
        92833: 0,
        63501: 0,
        26830: 0,
        81263: 0,
        95350: 0,
        74916: 0,
        11709: 0,
        923: 0,
        18510: 0,
        63264: 0,
        35723: 0,
        98550: 0,
      };
      (i.f.j = (r, t) => {
        var n = i.o(e, r) ? e[r] : void 0;
        if (0 !== n)
          if (n) t.push(n[2]);
          else if (
            /^(1(1709|6350|7007|8510)|2(0750|4827|6830)|6(1483|3264|3501)|7(0715|4916|6281)|8(1263|2727|4351|4435)|9(2(3|833|991)|(53|85)50|6212|8373)|35723|38213)$/.test(
              r
            )
          )
            e[r] = 0;
          else {
            var a = new Promise((t, a) => (n = e[r] = [t, a]));
            t.push((n[2] = a));
            var l = i.p + i.u(r),
              o = new Error();
            i.l(
              l,
              (t) => {
                if (i.o(e, r) && (0 !== (n = e[r]) && (e[r] = void 0), n)) {
                  var a = t && ("load" === t.type ? "missing" : t.type),
                    l = t && t.target && t.target.src;
                  (o.message =
                    "Loading chunk " + r + " failed.\n(" + a + ": " + l + ")"),
                    (o.name = "ChunkLoadError"),
                    (o.type = a),
                    (o.request = l),
                    n[1](o);
                }
              },
              "chunk-" + r,
              r
            );
          }
      }),
        (i.O.j = (r) => 0 === e[r]);
      var r = (r, t) => {
          var n,
            a,
            [l, o, c] = t,
            d = 0;
          if (l.some((r) => 0 !== e[r])) {
            for (n in o) i.o(o, n) && (i.m[n] = o[n]);
            if (c) var u = c(i);
          }
          for (r && r(t); d < l.length; d++)
            (a = l[d]), i.o(e, a) && e[a] && e[a][0](), (e[a] = 0);
          return i.O(u);
        },
        t = (self.webpackChunktradingview = self.webpackChunktradingview || []);
      t.forEach(r.bind(null, 0)), (t.push = r.bind(null, t.push.bind(t)));
    })(),
    (i.p = (i.g && i.g.WEBPACK_PUBLIC_PATH) || i.p);
})();
