"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [6529, 45394],
  {
    986061(e, t, i) {
      i.d(t, { createQuoteTicker: () => r });
      var s = i(490506);
      const r = (e, t, i) => new s.QuoteTicker(e, t, i);
    },
    744024(e, t, i) {
      i.d(t, { frameElementId: () => r });
      const s = window.initData.hashSettings || {},
        r = "string" == typeof s.frameElementId ? s.frameElementId : null;
    },
    770627(e, t, i) {
      i.d(t, { handleTVLinksClick: () => o });
      var s = i(498728),
        r = i(356656),
        n = i(863644);
      const a = "iglu:com.tradingview/widget_tv_link_click/jsonschema/1-0-0";
      function o() {
        document.addEventListener("click", (e) => {
          const t = e.target.closest(":link");
          t?.hostname &&
            (0, n.isInternalHost)(t.hostname, "tradingview.com") &&
            (async function (e, t) {
              const i = (function () {
                const e = window.initData.hashSettings;
                if (Object.keys(e).length > 0) return (0, r.filterUtmInfo)(e);
                const t = new URLSearchParams(location.href);
                return {
                  utm_campaign: t.get("utm_campaign") || void 0,
                  utm_source: t.get("utm_source") || void 0,
                };
              })();
              (await (0, s.getUnboundTracker)())?.trackSelfDesc(a, {
                widget_type: h(i),
                domain: l(i),
                link: e,
                target_type: t,
              });
            })(t.href, t.dataset.targetType || null);
        });
      }
      function l(e) {
        const t = location.ancestorOrigins?.[0] || document.referrer;
        return (
          e.utm_source ||
          (function (e) {
            try {
              return new URL(e).host;
            } catch (e) {
              return "";
            }
          })(t)
        );
      }
      function h(e) {
        if (e.utm_campaign) return e.utm_campaign;
        const t = location.pathname;
        return t.includes("embed-widget") ? t.split("/")[2] : t;
      }
    },
    106529(e, t, i) {
      i.d(t, {
        MiniChartPlotBase: () => F,
        isTimePointIndex: () => R,
        seriesHorzMarginsDefaults: () => k,
      });
      var s = i(663046),
        r = i(678312),
        n = i(740162),
        a = i(304221),
        o = i(146961),
        l = i(378305),
        h = i(819511),
        u = i(881014),
        d = i(140136),
        c = i(635774),
        _ = i(521239),
        m = i(966193),
        p = i(570071),
        g = i(213610),
        f = i(80365),
        y = i(301510),
        S = i(383636),
        C = i(377979),
        v = i(511538),
        w = i(246823),
        b = i(419082),
        x = i(365907),
        I = i(714945),
        T = i(969301),
        O = i(769215),
        M = i(775303);
      const D = (0, h.getLogger)("Chart.MiniChart"),
        L = new C.VolumeFormatter();
      function V(e, t, i, s) {
        return { time: t, color: s, value: i[e] };
      }
      function B(e, t) {
        return {
          time: e,
          open: t[g.SeriesPlotIndex.Open],
          high: t[g.SeriesPlotIndex.High],
          low: t[g.SeriesPlotIndex.Low],
          close: t[g.SeriesPlotIndex.Close],
        };
      }
      function P(e, t, i, s, r) {
        return {
          time: e,
          topColor: s,
          bottomColor: r,
          lineColor: i,
          value: t[g.SeriesPlotIndex.Close],
        };
      }
      function E(e) {
        const t = new Date(e);
        return (
          Date.UTC(
            t.getFullYear(),
            t.getMonth(),
            t.getDate(),
            t.getHours(),
            t.getMinutes(),
            t.getSeconds()
          ) / 1e3
        );
      }
      function R(e) {
        return (0, u.isInteger)(e);
      }
      const A = (0, s.default)(I.resetTransparency);
      const k = { leftLogical: 0, rightLogical: 0, leftPx: 0, rightPx: 4 };
      function N(e) {
        if (0 === e.series.length) return null;
        const t = e.series[0],
          i = t.value ?? t.close,
          s = e.series[e.series.length - 1],
          r = s.value ?? s.close;
        return {
          first: { value: i, time: t.time },
          last: { value: r, time: s.time },
        };
      }
      class F {
        destroy() {
          this._status.unsubscribe(),
            this._timeFrame.destroy(),
            this._isDestroyed.setValue(!0),
            this._isLastSessionInterval.destroy(),
            this._barBuilderLoader?.destroy();
        }
        id() {
          return this._id;
        }
        status() {
          return this._status.readonly();
        }
        noData() {
          return this._noData.readonly();
        }
        chartType() {
          return this._chartType.readonly();
        }
        symbolInfo() {
          return this._symbolInfo;
        }
        symbolInfoWV() {
          return this._symbolInfoWV.readonly();
        }
        symbol() {
          return this._symbol.symbol;
        }
        subSession() {
          return this._sessionId.value();
        }
        setSymbol(e, t) {
          return (
            (0, a.default)(e) &&
              (e = (0, b.isEncodedExtendedSymbol)(e)
                ? (0, b.decodeExtendedSymbol)(e)
                : { ...this._symbol, symbol: e }),
            void 0 !== t && this._updateSeriesOptions(t),
            !(0, b.compareSymbols)(this._symbol, e) &&
              ((this._symbol = e),
              this._updateSessionId(),
              this._symbolChanged.fire(),
              !0)
          );
        }
        extendedSymbol() {
          return { ...this._symbol, session: this._sessionId.value() };
        }
        quotesSymbol() {
          return { ...this.extendedSymbol(), metric: void 0 };
        }
        updateSeriesOptions(e) {
          let t = !1;
          void 0 !== e.chartType &&
          this._originalSeriesOptions.chartType !== e.chartType
            ? (t = !0)
            : (this._originalSeriesOptions.chartType !== v.ChartType.Line &&
                this._originalSeriesOptions.chartType !== v.ChartType.Area) ||
              (t =
                ("postmarketLineColor" in e &&
                  this._originalSeriesOptions.postmarketLineColor !==
                    e.postmarketLineColor) ||
                ("premarketLineColor" in e &&
                  this._originalSeriesOptions.premarketLineColor !==
                    e.premarketLineColor) ||
                ("nightLineColor" in e &&
                  this._originalSeriesOptions.nightLineColor !==
                    e.nightLineColor)),
            this._updateSeriesOptions(e),
            t ? this._onChartStyleChanged() : this._series.applyOptions(e);
        }
        applyOptions(e) {
          (0, n.default)(this._options, e);
        }
        symbolResolved() {
          return this._symbolResolved;
        }
        symbolChanged() {
          return this._symbolChanged;
        }
        seriesChanged() {
          return this._seriesChanged;
        }
        timeFrameInvalidated() {
          return this._timeFrameInvalidated;
        }
        restoreOriginalScaleMode() {
          null !== this._originalScaleMode &&
            this._series
              .priceScale()
              .applyOptions({ mode: this._originalScaleMode });
        }
        switchToPercentageScaleMode() {
          null === this._originalScaleMode &&
            (this._originalScaleMode = this._series
              .priceScale()
              .options().mode),
            this._series
              .priceScale()
              .applyOptions({ mode: r.PriceScaleMode.Percentage });
        }
        chartSession() {
          return this._miniChart.chartSession();
        }
        currentSeriesOptions() {
          return this._currentSeriesOptions;
        }
        volumeOptions() {
          return this._originalVolumeOptions;
        }
        updateVolumeOptions(e) {
          (this._originalVolumeOptions = (0, n.default)(
            this._originalVolumeOptions,
            e
          )),
            this._volume.applyOptions(this._originalVolumeOptions),
            e.scaleMargins &&
              this._volume
                .priceScale()
                .applyOptions({
                  scaleMargins: this._originalVolumeOptions.scaleMargins,
                });
        }
        series() {
          return this._series;
        }
        volume() {
          return this._originalVolumeOptions.visible ? this._volume : null;
        }
        updateData(e, t, i) {
          e && this.clearSourceData();
          const s = this._originalSeriesOptions,
            r = this._buildViewData(i),
            n = r.series.length;
          (this._historyUpdateReceived =
            this._historyUpdateReceived || void 0 === i),
            void 0 !== i ||
              (s.chartType !== v.ChartType.Area &&
                s.chartType !== v.ChartType.Line) ||
              (this._firstValueCache = r.series[0]?.value ?? null);
          const a =
            this._historyUpdateReceived && null === this._dataLengthInfo;
          if (void 0 !== i && !a) {
            const e = this._dataLengthInfo;
            if (null === e) return;
            const t = { ...e };
            e.lastBarSession = r.lastBarSession;
            let i = null;
            for (const t of r.series)
              this._series.update(t),
                (null === e.lastBarTime || e.lastBarTime < t.time) &&
                  ((i = t.time),
                  (e.lastBarTime = i),
                  (e.realtime += 1),
                  (e.lastBarIndex = (e.lastBarIndex ?? -1) + 1));
            if (
              (r.additionalSeries &&
                this._updateAdditionalSeriesData(r.additionalSeries),
              r.volume)
            )
              for (const e of r.volume) this._volume.update(e);
            if (void 0 !== this._whitespacesData && null !== i) {
              const t = this._whitespacesData.findIndex((e) => e.time > i);
              -1 === t
                ? ((e.whitespaces = 0), this._updateWhitespaces([]))
                : 0 !== t &&
                  ((e.whitespaces -= t),
                  this._updateWhitespaces(this._whitespacesData.slice(t)));
            }
            null !== i &&
              (void 0 !== e.fixLeftEdgeUntil
                ? (this._isMainPlot() &&
                    e.fixLeftEdgeUntil >= i &&
                    this._miniChart.fitContent(),
                  i > e.fixLeftEdgeUntil &&
                    ((e.history += e.realtime - 1),
                    (e.realtime = 0),
                    (e.fixLeftEdgeUntil = void 0),
                    (e.timeFrameInvalidated = !0),
                    this._timeFrameInvalidated.fire()))
                : e.timeFrameInvalidated ||
                  ((e.timeFrameInvalidated = !0),
                  this._timeFrameInvalidated.fire())),
              this._updateSeriesColor(r.series[r.series.length - 1]),
              this._dataUpdated(r, e, t);
            const s = N(r);
            return void (
              null !== s &&
              (this._lastValue.setValue(s.last.value),
              this._onLastBarDataMayChange())
            );
          }
          const o = r.whitespaces,
            l = o?.length ?? 0;
          (this._dataLengthInfo = {
            history: n,
            realtime: 0,
            lastBarIndex: 0 === n ? null : n - 1,
            lastBarTime: 0 === n ? null : r.series[n - 1].time,
            whitespaces: l,
            fixLeftEdgeUntil: r.fixLeftEdgeUntil,
            timeFrameInvalidated: !1,
            lastBarSession: r.lastBarSession,
          }),
            this._updateSeriesColor(0 === n ? void 0 : r.series[n - 1]),
            this._series.applyOptions(this._currentSeriesOptions),
            this._applyPriceScaleFormatter(),
            t || this._beforeDataReady(),
            this._series.setData(r.series),
            r.additionalSeries &&
              this._setAdditionalSeriesData(r.additionalSeries),
            r.volume && this._volume.setData(r.volume),
            this._updateWhitespaces(r.whitespaces),
            this._dataUpdated(r, this._dataLengthInfo);
          const h = N(r);
          if (null !== h) {
            const { first: e, last: t } = h;
            this._lastValue.setValue(t.value),
              this._firstBarTime.setValue(e.time),
              this._onLastBarDataMayChange();
          }
        }
        titles() {
          return this._currentSeriesOptions.title
            ? [this._currentSeriesOptions.title]
            : [];
        }
        deleteView() {
          this._series.setData([]),
            this._whitespaces?.setData([]),
            this._volume.setData([]);
        }
        clearData() {
          (this._symbolInfo = null),
            this._symbolInfoWV.setValue(null),
            (this._historyUpdateReceived = !1),
            (this._dataLengthInfo = null),
            (this._firstValueCache = null),
            (this._customPriceFormatter = null),
            this._status.setValue(w.PlotStatus.Initialized),
            this._noData.setValue(null),
            this._directionBasedColor.setValue(null);
        }
        resolution() {
          return this._miniChart.resolution();
        }
        minBarIndex() {
          return this._minBarIndex;
        }
        maxBarIndex() {
          return this._maxBarIndex;
        }
        forcePercentageMode() {
          return !1;
        }
        lastBarTime() {
          return this._dataLengthInfo?.lastBarTime ?? void 0;
        }
        lastBarIndex() {
          return this._dataLengthInfo?.lastBarIndex ?? null;
        }
        getViewData(e) {
          return this._buildViewData(e);
        }
        getLegendData(e, t) {
          const s = this.series(),
            r = this.volume();
          if (void 0 === e) return [];
          const n = s.dataByIndex(e, t);
          if (null === n) return [];
          const a = [],
            o = s.priceFormatter(),
            l = this.currentSeriesOptions();
          if (!1 === l.visible) return [];
          if (
            "Area" === s.seriesType() ||
            "Line" === s.seriesType() ||
            "Baseline" === s.seriesType() ||
            "legend" === l.tooltipType ||
            "line" === l.tooltipType
          ) {
            const { value: e } = n;
            let t;
            t = l.chartType === v.ChartType.Area ? n.lineColor : n.color;
            const i = this.symbolInfo(),
              s = l.color || l.lineColor;
            a.push({
              title: l.tooltipTitle || i?.name || "",
              value: o.format(e),
              color: t || s,
              unit: l.showUnit
                ? (0, O.prepareCurrencyValue)({
                    currency_code: i?.currency_code,
                    unit_id: i?.unit_id,
                    value_unit_id: i?.value_unit_id,
                    measure: i?.measure,
                  })
                : void 0,
            });
          } else {
            const { open: e, high: t, low: r, close: l } = n,
              h = (function (e, t) {
                if (null === t) return;
                const i = e ? t.up : t.down;
                return A(i);
              })(l >= e, this._miniChart.upDownColors(s.seriesType()));
            [
              [S.t(null, { context: "in_legend" }, i(960513)), o.format(e)],
              [S.t(null, { context: "in_legend" }, i(954614)), o.format(t)],
              [S.t(null, { context: "in_legend" }, i(839463)), o.format(r)],
              [S.t(null, { context: "in_legend" }, i(229994)), o.format(l)],
            ].forEach(([e, t]) => {
              a.push({ value: t, title: e, color: h });
            });
          }
          const h = r && r.dataByIndex(e, t),
            u = this.volumeOptions();
          if (h) {
            const { value: e, color: t } = h;
            a.push({
              title:
                u.tooltipTitle ??
                S.t(null, { context: "in_legend" }, i(565321)),
              value: L.format(e),
              color: u.ignoreColor ? void 0 : t && (0, I.resetTransparency)(t),
              unit: u.showUnit ? this.symbolInfo()?.currency_code : void 0,
            });
          }
          return a;
        }
        legendLastBarData() {
          return (
            this._legendLastBarData ||
              ((this._legendLastBarData = new c.WatchedObject(null)),
              this._onLastBarDataMayChange()),
            this._legendLastBarData.readonly()
          );
        }
        sessionAtTime(e) {
          return this._barBuilderLoader?.get()?.session(e) ?? null;
        }
        lastValue() {
          return this._lastValue.readonly();
        }
        firstBarTime() {
          return this._firstBarTime.readonly();
        }
        isVisible() {
          return this._isVisible.readonly();
        }
        symbolName() {
          return this._symbol.symbol;
        }
        lineColor() {
          const e = this.currentSeriesOptions();
          return "line" === e.chartType
            ? e.color ?? ""
            : "area" === e.chartType
            ? e.lineColor ?? ""
            : void (0, o.assert)(!1, `Unexpected chart type: ${e.chartType}`);
        }
        isDestroyed() {
          return this._isDestroyed.readonly();
        }
        _hasOvernightSession() {
          return !1;
        }
        _isMainPlot() {
          return !1;
        }
        _onChartStyleChanged() {
          this._recreateSeries(),
            this._status.value() === w.PlotStatus.DataReady &&
              this.updateData(!1, !0);
        }
        _beforeDataReady() {
          this._currentlyShownDataDescription.setValue({
            timeframe: this._timeFrame.value(),
            symbol: this.symbol(),
          });
        }
        _dataUpdated(e, t, i) {}
        _onSymbolResolved(e) {
          this._barBuilderLoader?.destroy(),
            (this._barBuilderLoader = null),
            (this._symbolInfo = e),
            this._symbolInfoWV.setValue(e),
            this._symbolResolved.fire(this._symbolInfo);
        }
        _getViewData(e, t) {
          const i = [],
            s = { series: [], volume: i };
          let r = -1 / 0;
          const n = this._bars();
          if (n.isEmpty()) return s;
          const a = this.minBarIndex(),
            o = this.maxBarIndex();
          if (null === a || null === o) return s;
          const l = t ?? (R(a) ? a : n.firstIndex()),
            h = n.lastIndex();
          if (null === l || null === h) return s;
          let u;
          const {
              premarketLineColor: d,
              postmarketLineColor: c,
              nightLineColor: _,
              premarketTopColor: m,
              premarketBottomColor: p,
              postmarketTopColor: S,
              postmarketBottomColor: C,
              nightTopColor: w,
              nightBottomColor: b,
            } = this._getPrePostMarketColors(),
            x = (e) => {
              switch (e) {
                case v.SessionPhase.Pre:
                  return [d, m, p];
                case v.SessionPhase.Post:
                  return [c, S, C];
                case v.SessionPhase.Night:
                  return [_, w, b];
                default:
                  return [];
              }
            };
          for (const t of n.rangeIterator(l, h)) {
            const { value: n, index: a } = t;
            if (a <= y.UNPLOTTABLE_TIME_POINT_INDEX) continue;
            const o = this._miniChart.indexToTime(a);
            if (null === o) {
              D.logWarn(`Couldn't find time for index ${a}`);
              continue;
            }
            const l = !this._miniChart.isDWMResolution() ? E(1e3 * o) : o;
            if (l <= r) continue;
            (r = l), (u = l);
            const h = this._barIndexSession(a);
            (s.lastBarSession = h), s.series.push(e(l, n, ...x(h)));
            const d =
              n[g.SeriesPlotIndex.Close] >= n[g.SeriesPlotIndex.Open]
                ? this._originalVolumeOptions.upColor
                : this._originalVolumeOptions.downColor;
            i.push({ time: l, value: n[g.SeriesPlotIndex.Volume], color: d });
          }
          if (this._isMainPlot() && void 0 === t && void 0 !== u)
            switch ((0, f.convertTimeFrameToStr)(this._timeFrame.value())) {
              case "1D":
                s.fixLeftEdgeUntil = u + 86400 - 1;
                break;
              case "LASTSESSION": {
                let e = [],
                  t = u + 87840 - 1;
                const i = this._generateBarsToSessionEnd();
                i?.length &&
                  null !== o &&
                  o > h &&
                  ((e = i), (t = i[i.length - 1].time)),
                  (s.fixLeftEdgeUntil = t),
                  (s.whitespaces = e);
              }
            }
          return s;
        }
        _buildViewData(e) {
          switch (this._originalSeriesOptions.chartType) {
            case v.ChartType.PrettyHistogram:
            case v.ChartType.Histogram: {
              const t = this._currentSeriesOptions;
              return this._getViewData(
                (e, i) =>
                  (function (e, t, i, s) {
                    const r = t[g.SeriesPlotIndex.Close];
                    return { time: e, color: r > 0 ? i : s, value: r };
                  })(e, i, t.upColor, t.downColor),
                e
              );
            }
            case v.ChartType.Line: {
              const t = this._currentSeriesOptions;
              return this._getViewData(
                V.bind(null, t.sourcePlotIndex ?? g.SeriesPlotIndex.Close),
                e
              );
            }
            case v.ChartType.Area:
            case v.ChartType.Baseline:
              return this._getViewData(P, e);
            case v.ChartType.Bars:
            case v.ChartType.Candlesticks:
              return this._getViewData(B, e);
          }
        }
        _setAdditionalSeriesData(e) {}
        _updateAdditionalSeriesData(e) {}
        _barIndexSession(e) {}
        _onSymbolError(e) {
          D.logWarn(
            (0, b.encodeExtendedSymbolOrGetSimpleSymbolString)(
              this._symbol,
              !0
            ) +
              " symbol resolving error: " +
              e
          ),
            this.updateData(!0),
            this._status.setValue(w.PlotStatus.SymbolError);
        }
        _onSymbolNotPermitted() {
          this._noData.setValue(v.NoDataReason.NoPermission);
        }
        _onIntradaySpreadNotPermitted() {
          this._status.setValue(w.PlotStatus.SeriesError),
            this._noData.setValue(v.NoDataReason.IntradaySpreadError),
            this._isMainPlot() &&
              this._miniChart.showMessage(
                S.t(null, { context: "mini chart error message" }, i(829273))
              );
        }
        _onSymbolGroupNotPermitted() {
          this._noData.setValue(v.NoDataReason.NoPermission);
        }
        _onSymbolInvalid() {
          this._noData.setValue(v.NoDataReason.NoSuchSymbol);
        }
        _onResolutionOrExchangeNotPermittedError() {
          D.logError(
            (0, b.encodeExtendedSymbolOrGetSimpleSymbolString)(
              this._symbol,
              !0
            ) + " resolution or exchange permission error"
          ),
            this.updateData(!0),
            this._isMainPlot() &&
              this._miniChart.showMessage(
                S.t(null, { context: "mini chart error message" }, i(285893))
              ),
            setTimeout(() => this._miniChart.updateAvailableTimeframes(), 1e3);
        }
        _onDataError() {
          this._status.value() !== w.PlotStatus.SymbolError &&
            this._status.setValue(w.PlotStatus.SeriesError),
            this._noData.setValue(v.NoDataReason.DataError);
        }
        _onDataCompleted() {
          this._status.setValue(w.PlotStatus.DataReady),
            this._noData.setValue(
              0 === this._bars().size() ? v.NoDataReason.NoData : null
            ),
            this._noData.value() === v.NoDataReason.NoData &&
              this._isMainPlot() &&
              this._showNoDataMessage();
        }
        _showNoDataMessage() {
          this._miniChart.showMessage(
            S.t(null, { context: "mini chart error message" }, i(299153))
          );
        }
        async _onData(e, t) {
          null !== this.minBarIndex() &&
            null !== this.maxBarIndex() &&
            (this.updateData(!1, void 0, e),
            this._status.value() === w.PlotStatus.DataReady &&
              this._noData.setValue(
                0 === this._bars().size() ? v.NoDataReason.NoData : null
              ));
        }
        _updateSeriesOptions(e) {
          (this._originalSeriesOptions = (0, n.default)(
            this._originalSeriesOptions,
            e
          )),
            (this._currentSeriesOptions = (0, n.default)(
              this._currentSeriesOptions,
              this._originalSeriesOptions
            )),
            this._updateSeriesColor(),
            void 0 !== this._currentSeriesOptions.visible &&
              this._isVisible.setValue(this._currentSeriesOptions.visible);
        }
        _recreateSeries() {
          const e = this._miniChart.widget();
          e.removeSeries(this._series),
            e.removeSeries(this._volume),
            this._whitespaces &&
              (e.removeSeries(this._whitespaces), (this._whitespaces = null)),
            (this._series = this._createSeries()),
            (this._volume = this._createVolume()),
            this._chartType.setValue(this._currentSeriesOptions.chartType),
            this._seriesChanged.fire();
        }
        _initBarBuilder(e) {
          return (
            null === this._barBuilderLoader &&
              (this._barBuilderLoader = new T.AsyncResourceWrapper(
                Promise.all([i.e(12181), i.e(2011), i.e(27046), i.e(93279)])
                  .then(i.bind(i, 121505))
                  .then((t) => new t.MiniChartBarBuilder(e))
              )),
            this._barBuilderLoader.promise()
          );
        }
        _firstAndLastValuesForSeriesColor(e, t) {
          if (null === this._firstValueCache || !this._dataLengthInfo)
            return null;
          if (e !== v.ChartType.Line && e !== v.ChartType.Area) return null;
          const i =
            null === this._dataLengthInfo.lastBarIndex
              ? null
              : this._series.dataByIndex(this._dataLengthInfo.lastBarIndex);
          return null !== i || t
            ? ((t = t ?? i), [this._firstValueCache, t.value])
            : null;
        }
        _updateSeriesColor(e) {
          const t = this._originalSeriesOptions,
            i = t.chartType,
            s = this._firstAndLastValuesForSeriesColor(i, e);
          if (null === s) return;
          const [r, n] = s;
          if (i === v.ChartType.Line || i === v.ChartType.Area) {
            const e = i === v.ChartType.Line ? n >= r : n > r;
            if (i === v.ChartType.Area) {
              const i = this._currentSeriesOptions;
              e
                ? ((i.lineColor = t.growingLineColor || t.lineColor),
                  (i.topColor = t.growingTopColor || t.topColor),
                  (i.bottomColor = t.growingBottomColor || t.bottomColor))
                : ((i.lineColor = t.fallingLineColor || t.lineColor),
                  (i.topColor = t.fallingTopColor || t.topColor),
                  (i.bottomColor = t.fallingBottomColor || t.bottomColor)),
                i.lineColor || (i.lineColor = this._series.options().lineColor),
                this._series.applyOptions({
                  topColor: i.topColor,
                  bottomColor: i.bottomColor,
                  lineColor: i.lineColor,
                }),
                this._directionBasedColor.setValue(i.lineColor);
            } else if (i === v.ChartType.Line) {
              const { color: i, growingColor: s = i, fallingColor: r = i } = t,
                n = this._currentSeriesOptions;
              (n.color = e ? s : r),
                n.color || (n.color = this._series.options().color),
                this._series.applyOptions({ color: n.color }),
                this._directionBasedColor.setValue(n.color);
            }
          }
        }
        _priceFormat() {
          const e = this._symbolInfo ?? this._miniChart.mainPlot().symbolInfo();
          return null === e
            ? null
            : (function (e) {
                const t = (0, x.createSeriesFormatter)(e, "default");
                return {
                  type: "custom",
                  minMove: e.minmov / e.pricescale,
                  base: e.pricescale / e.minmov,
                  formatter: (e) => t.format(e),
                };
              })(e);
        }
        _onLastBarDataMayChange() {
          if (!this._legendLastBarData) return;
          const e = this._miniChart.mainPlot().lastBarIndex();
          null !== e
            ? this._legendLastBarData.setValue(
                this.getLegendData(e, r.MismatchDirection.NearestLeft)
              )
            : this._legendLastBarData.setValue(null);
        }
        _createSeries() {
          const e = this._miniChart.widget();
          let t;
          switch (this._currentSeriesOptions.chartType) {
            case v.ChartType.Line:
              t = e.addSeries(r.LineSeries, this._currentSeriesOptions);
              break;
            case v.ChartType.Histogram:
              t = e.addSeries(r.HistogramSeries, this._currentSeriesOptions);
              break;
            case v.ChartType.Area:
              t = e.addSeries(r.AreaSeries, this._currentSeriesOptions);
              break;
            case v.ChartType.Bars:
              t = e.addSeries(r.BarSeries, this._currentSeriesOptions);
              break;
            case v.ChartType.Candlesticks:
              t = e.addSeries(r.CandlestickSeries, this._currentSeriesOptions);
              break;
            case v.ChartType.Baseline:
              t = e.addSeries(r.BaselineSeries, this._currentSeriesOptions);
              break;
            case v.ChartType.PrettyHistogram: {
              const i = new M.PrettyHistogramSeries();
              t = e.addCustomSeries(i, this._currentSeriesOptions);
            }
          }
          return (
            null === this._originalScaleMode &&
              (this._originalScaleMode = t.priceScale().options().mode),
            this._isVisible.setValue(t.options().visible),
            t
              .priceScale()
              .applyOptions({
                scaleMargins: this._currentSeriesOptions.scaleMargins,
              }),
            t
          );
        }
        _createVolume() {
          const e = this._miniChart
            .widget()
            .addSeries(r.HistogramSeries, this._originalVolumeOptions);
          return (
            e
              .priceScale()
              .applyOptions({
                scaleMargins: this._originalVolumeOptions.scaleMargins,
              }),
            e
          );
        }
        _applyPriceScaleFormatter() {
          if ("priceFormat" in this._originalSeriesOptions) return;
          const e = this._priceFormat();
          e &&
            ((this._currentSeriesOptions.priceFormat = e),
            this._series.applyOptions(this._currentSeriesOptions));
        }
        _updateSessionId() {
          this._isLastSessionInterval.value()
            ? this._sessionId.setValue(
                this._hasOvernightSession() ? "24h" : "extended"
              )
            : this._sessionId.setValue(this._symbol.session);
        }
        _updateWhitespaces(e) {
          void 0 === e || 0 === e.length
            ? null !== this._whitespaces &&
              (this._miniChart.widget().removeSeries(this._whitespaces),
              (this._whitespaces = null))
            : (null === this._whitespaces &&
                (this._whitespaces = this._miniChart
                  .widget()
                  .addSeries(r.LineSeries)),
              (this._whitespacesData = null === this._whitespaces ? void 0 : e),
              this._whitespaces.setData(e));
        }
        _generateBarsToSessionEnd() {
          const e = this.symbolInfo(),
            t = this._bars().lastIndex(),
            i = this.maxBarIndex();
          if (e && t && i && this._isLastSessionInterval.value()) {
            let e = this._miniChart.indexToTime(t);
            if (null === e) return;
            const s = [];
            for (let r = t + 1; r <= i; r += 1) {
              const t = this._miniChart.indexToTime(r) ?? e + 60;
              s.push({ time: E(1e3 * t) }), (e = t);
            }
            return s;
          }
        }
        _getPrePostMarketColors() {
          if (!this._isMainPlot()) return {};
          let e, t, i, s, r, n;
          const a = this._originalSeriesOptions.premarketLineColor,
            o = this._originalSeriesOptions.postmarketLineColor,
            h = this._originalSeriesOptions.nightLineColor;
          if (
            this._originalSeriesOptions.chartType === v.ChartType.Area &&
            a &&
            o &&
            h
          ) {
            const u = this._currentSeriesOptions,
              d = u.growingTopColor || u.fallingTopColor || u.topColor;
            if (void 0 !== d) {
              const t = (0, l.tryParseRgba)(d);
              if (null !== t) {
                const s = t[3];
                (e = (0, I.applyAlpha)(a, s)),
                  (i = (0, I.applyAlpha)(o, s)),
                  (r = (0, I.applyAlpha)(h, s));
              }
            }
            const c =
              u.growingBottomColor || u.fallingBottomColor || u.bottomColor;
            if (void 0 !== c) {
              const e = (0, l.tryParseRgba)(c);
              if (null !== e) {
                const i = e[3];
                (t = (0, I.applyAlpha)(a, i)),
                  (s = (0, I.applyAlpha)(o, i)),
                  (n = (0, I.applyAlpha)(h, i));
              }
            }
          }
          return {
            premarketLineColor: a,
            postmarketLineColor: o,
            nightLineColor: h,
            premarketTopColor: e,
            postmarketTopColor: i,
            nightTopColor: r,
            premarketBottomColor: t,
            postmarketBottomColor: s,
            nightBottomColor: n,
          };
        }
        _timeScaleSizeChanged() {
          this._isMainPlot() &&
            Promise.resolve().then(() => this._miniChart.fitContent());
        }
        constructor(e, t, i, s) {
          (this._symbolChanged = new p.Delegate()),
            (this._seriesChanged = new p.Delegate()),
            (this._whitespaces = null),
            (this._symbolResolved = new p.Delegate()),
            (this._originalScaleMode = null),
            (this._customPriceFormatter = null),
            (this._isDestroyed = new d.WatchedValue(!1)),
            (this._status = new d.WatchedValue(w.PlotStatus.Initialized)),
            (this._noData = new d.WatchedValue(null)),
            (this._chartType = new d.WatchedValue(null)),
            (this._directionBasedColor = new d.WatchedValue(null)),
            (this._dataLengthInfo = null),
            (this._sessionId = new d.WatchedValue()),
            (this._barBuilderLoader = null),
            (this._symbolInfo = null),
            (this._symbolInfoWV = new c.WatchedObject(null)),
            (this._symbol = { symbol: "" }),
            (this._minBarIndex = null),
            (this._maxBarIndex = null),
            (this._lastValue = new d.WatchedValue(null)),
            (this._isVisible = new d.WatchedValue(!1)),
            (this._id = (0, m.randomHash)()),
            (this._timeFrameInvalidated = new p.Delegate()),
            (this._firstValueCache = null),
            (this._firstBarTime = new d.WatchedValue(null)),
            (this._legendLastBarData = null),
            (this._historyUpdateReceived = !1),
            (this._miniChart = e),
            (this._originalSeriesOptions = t),
            (this._currentSeriesOptions = (0, n.default)({}, t)),
            (this._options = s),
            (this._series = this._createSeries()),
            this._chartType.setValue(t.chartType ?? null),
            (this._originalVolumeOptions = i),
            (this._volume = this._createVolume()),
            (this._timeFrame = e.timeframe().spawn()),
            this._timeFrame.subscribe(this._updateSessionId.bind(this)),
            (this._currentlyShownDataDescription = new c.WatchedObject({
              timeframe: this._timeFrame.value(),
              symbol: this.symbol(),
            })),
            (this._isLastSessionInterval = (0, _.combine)(
              (e) => "LASTSESSION" === (0, f.convertTimeFrameToStr)(e),
              this._miniChart.timeframe().weakReference()
            )),
            this._isLastSessionInterval.subscribe(
              this._updateSessionId.bind(this)
            ),
            this._miniChart
              .timeScaleSizeChanged()
              .subscribe(null, this._timeScaleSizeChanged.bind(this)),
            this._status.subscribe((e) => {
              e !== w.PlotStatus.DataReady &&
                (this._lastValue.setValue(null),
                this._onLastBarDataMayChange());
            });
        }
      }
    },
    146961(e, t, i) {
      function s(e, t) {
        if (!e) throw new Error("Assertion failed" + (t ? `: ${t}` : ""));
      }
      function r(e, t) {
        if (void 0 === e) throw new Error(`${t ?? "Value"} is undefined`);
        return e;
      }
      function n(e, t) {
        if (null === e) throw new Error(`${t ?? "Value"} is null`);
        return e;
      }
      function a(e, t) {
        return n(r(e, t), t);
      }
      i.d(t, {
        assert: () => s,
        ensure: () => a,
        ensureDefined: () => r,
        ensureNotNull: () => n,
      });
    },
    726115(e, t, i) {
      function s(e) {
        const t = e;
        return (t.release = () => t.destroy()), (t.ownership = () => t), t;
      }
      i.d(t, { ownership: () => s });
    },
    715471(e, t, i) {
      function s(e, t, i) {
        return Math.min(Math.max(e, t), i);
      }
      function r(e) {
        return e > 0 ? Math.floor(e) : Math.ceil(e);
      }
      function n(e) {
        return e % 2 == 0;
      }
      i.d(t, { clamp: () => s, isEven: () => n, toInt: () => r });
    },
    246759(e, t, i) {
      i.d(t, { decodeHTMLEntities: () => l, htmlEscape: () => h });
      const s = /[<"'&>]/g,
        r = (e) => `&#${e.charCodeAt(0)};`,
        n = {
          "&lt;": "<",
          "&gt;": ">",
          "&quot;": '"',
          "&apos;": "'",
          "&amp;": "&",
          "&#60;": "<",
          "&#62;": ">",
          "&#34;": '"',
          "&#39;": "'",
          "&#039;": "'",
          "&#38;": "&",
        },
        a = Object.assign(
          {},
          ...Object.entries(n).map(([e, t]) => ({ [t]: e }))
        ),
        o = new RegExp(Object.keys(n).join("|"), "g");
      new RegExp(Object.keys(a).join("|"), "g");
      function l(e) {
        return e.replace(o, (e) => n[e] || e);
      }
      function h(e) {
        return e.replace(s, r);
      }
    },
    135277(e, t, i) {
      i.d(t, {
        getLanguage: () => n,
        mapLanguageCode: () => h,
        registerLanguageCodeMapper: () => l,
        registerLanguageGetter: () => r,
        tryGetLanguage: () => a,
      });
      let s = null;
      function r(e) {
        s = e;
      }
      function n() {
        if (!s)
          throw new Error(
            "Language getter not registered. Call registerLanguageGetter() first."
          );
        return s();
      }
      function a() {
        return s ? s() : void 0;
      }
      let o = (e) => e;
      function l(e) {
        o = e;
      }
      function h(e) {
        return o(e);
      }
    },
    467242(e, t, i) {
      i.d(t, {
        isAndroid: () => l,
        isAnyMobile: () => _,
        isIOS: () => u,
        isIPad: () => c,
        isMac: () => o,
        mobiletouch: () => n,
        touch: () => a,
      });
      const s = "undefined" != typeof window && "undefined" != typeof navigator,
        r = s && "ontouchstart" in window,
        n = s && r && "onorientationchange" in window,
        a = s && (r || !!navigator.maxTouchPoints),
        o =
          (s && window.chrome && window.chrome.runtime,
          s && window.navigator.userAgent.toLowerCase().indexOf("firefox"),
          s && /\sEdge\/\d\d\b/.test(navigator.userAgent),
          s &&
            Boolean(navigator.vendor) &&
            navigator.vendor.indexOf("Apple") > -1 &&
            -1 === navigator.userAgent.indexOf("CriOS") &&
            navigator.userAgent.indexOf("FxiOS"),
          s && /mac/i.test(navigator.platform)),
        l =
          (s && /Win32|Win64/i.test(navigator.platform),
          s && /Linux/i.test(navigator.platform),
          s && /Android/i.test(navigator.userAgent)),
        h = s && /BlackBerry/i.test(navigator.userAgent),
        u = s && /iPhone|iPad|iPod/.test(navigator.platform),
        d = s && /Opera Mini/i.test(navigator.userAgent),
        c =
          s &&
          (("MacIntel" === navigator.platform &&
            navigator.maxTouchPoints > 1) ||
            /iPad/.test(navigator.platform)),
        _ = l || h || u || d;
    },
    425268(e, t, i) {
      i.d(t, { getMiniTimeFrameOptions: () => a });
      var s = i(182002);
      function r(e) {
        const t = new Date();
        return t.setMonth(t.getMonth() - e), Math.trunc(t.valueOf() / 1e3);
      }
      function n(e) {
        const t = new Date();
        return (
          t.setFullYear(t.getFullYear() - e), Math.trunc(t.valueOf() / 1e3)
        );
      }
      function a(e) {
        const t = (0, s.getTimeFrames)();
        return [
          { ...t[e ? "lastsession" : "1d"] },
          { ...t["1m"], targetResolution: "1D", from: r(1) },
          { ...t["3m"], targetResolution: "1D", from: r(3) },
          { ...t["12m"], from: n(1) },
          { ...t["60m"], targetResolution: "1M", from: n(5) },
          { ...t.all },
        ];
      }
    },
    493616(e, t, i) {
      i.d(t, { color: () => n, dur: () => s, easingFunc: () => r });
      const s = 350,
        r = {
          linear: (e) => e,
          easeInQuad: (e) => e * e,
          easeOutQuad: (e) => e * (2 - e),
          easeInOutQuad: (e) => (e < 0.5 ? 2 * e * e : (4 - 2 * e) * e - 1),
          easeInCubic: (e) => e * e * e,
          easeOutCubic: (e) => --e * e * e + 1,
          easeInOutCubic: (e) =>
            e < 0.5 ? 4 * e * e * e : (e - 1) * (2 * e - 2) * (2 * e - 2) + 1,
          easeInQuart: (e) => e * e * e * e,
          easeOutQuart: (e) => 1 - --e * e * e * e,
          easeInOutQuart: (e) =>
            e < 0.5 ? 8 * e * e * e * e : 1 - 8 * --e * e * e * e,
          easeInQuint: (e) => e * e * e * e * e,
          easeOutQuint: (e) => 1 + --e * e * e * e * e,
          easeInOutQuint: (e) =>
            e < 0.5 ? 16 * e * e * e * e * e : 1 + 16 * --e * e * e * e * e,
        };
      const n = { black70: "#4A4A4A", black80: "#535353" };
    },
    382044(e, t, i) {
      i.d(t, { PlotList: () => c });
      var s = i(146961),
        r = i(819511),
        n = i(834758),
        a = i(301510),
        o = i(208345);
      const l = (0, r.getLogger)("Chart.PlotList"),
        h = 30;
      function u(e) {
        return e.index;
      }
      function d(e) {
        return e.value[0];
      }
      class c {
        clear() {
          (this._items = []),
            (this._start = 0),
            (this._end = 0),
            (this._shareRead = !1),
            this._minMaxCache.clear(),
            this._invalidateSearchCaches();
        }
        first() {
          return this.size() > 0 ? this._items[this._start] : null;
        }
        last() {
          return this.size() > 0 ? this._items[this._end - 1] : null;
        }
        firstIndex() {
          return this.size() > 0 ? this._indexAt(this._start) : null;
        }
        firstPlottableIndex() {
          if (this.isEmpty()) return null;
          for (let e = this._start; e < this._end; ++e) {
            const t = this._indexAt(e);
            if (t > a.UNPLOTTABLE_TIME_POINT_INDEX) return t;
          }
          return null;
        }
        lastIndex() {
          return this.size() > 0 ? this._indexAt(this._end - 1) : null;
        }
        clone() {
          const e = this.firstIndex(),
            t = this.lastIndex();
          return null === e || null === t ? new c() : this.range(e, t);
        }
        size() {
          return this._end - this._start;
        }
        isEmpty() {
          return 0 === this.size();
        }
        contains(e) {
          return null !== this.search(e, o.PlotRowSearchMode.Exact);
        }
        valueAt(e) {
          const t = this.search(e);
          return null !== t ? t.value : null;
        }
        add(e, t) {
          if (this._shareRead)
            return (
              l.logDebug("add: readonly collection modification attempt"), !1
            );
          const i = { index: e, value: t },
            s = this._nonCachedSearch(e, o.PlotRowSearchMode.Exact, u);
          return (
            this._invalidateSearchCaches(),
            null === s
              ? (this._items.splice(this._lowerbound(e, u), 0, i),
                (this._start = 0),
                (this._end = this._items.length),
                !0)
              : ((this._items[s] = i), !1)
          );
        }
        search(e, t = o.PlotRowSearchMode.Exact, i) {
          return this._searchImpl(
            e,
            t,
            this._rowSearchCacheByIndex,
            this._rowSearchCacheByIndexWithoutEmptyValues,
            u,
            i
          );
        }
        searchByTime(e, t = o.PlotRowSearchMode.Exact, i) {
          return this._searchImpl(
            e,
            t,
            this._rowSearchCacheByTime,
            this._rowSearchCacheByTimeWithoutEmptyValues,
            d,
            i
          );
        }
        fold(e, t) {
          let i = t;
          for (let t = this._start; t < this._end; ++t) {
            i = e(this._indexAt(t), this._valueAt(t), i);
          }
          return i;
        }
        findFirst(e, t) {
          const i =
            (void 0 !== t && Math.min(this._start + t, this._end)) || this._end;
          for (let t = this._start; t < i; ++t) {
            const i = this._indexAt(t),
              s = this._valueAt(t);
            if (e(i, s)) return { index: i, value: s };
          }
          return null;
        }
        findLast(e, t) {
          const i =
            (void 0 !== t && Math.max(this._end - t, this._start)) ||
            this._start;
          for (let t = this._end - 1; t >= i; --t) {
            const i = this._indexAt(t),
              s = this._valueAt(t);
            if (e(i, s)) return { index: i, value: s };
          }
          return null;
        }
        each(e) {
          for (let t = this._start; t < this._end; ++t) {
            if (e(this._indexAt(t), this._valueAt(t))) break;
          }
        }
        reduce(e, t) {
          let i = t;
          for (let t = this._start; t < this._end; ++t) {
            i = e(i, this._indexAt(t), this._valueAt(t));
          }
          return i;
        }
        range(e, t) {
          const i = new c(this._plotFunctions, this._emptyValuePredicate);
          return (
            (i._items = this._items),
            (i._start = this._lowerbound(e, u)),
            (i._end = this._upperbound(t)),
            (i._shareRead = !0),
            i
          );
        }
        plottableRange(e) {
          const t = new c(this._plotFunctions, this._emptyValuePredicate);
          return (
            (t._items = this._items),
            (t._start = this._upperbound(a.UNPLOTTABLE_TIME_POINT_INDEX)),
            (t._end = this._end),
            (t._shareRead = !0),
            !0 === e && t._start > this._start && (t._start -= 1),
            t
          );
        }
        rangeCountback(e, t) {
          if (null === this.firstIndex()) return new c();
          const i = new c(this._plotFunctions, this._emptyValuePredicate);
          return (
            (i._items = this._items),
            (i._end = this._upperbound(e)),
            (i._start = Math.max(this._start, i._end - t)),
            (i._shareRead = !0),
            i
          );
        }
        rangeIterator(e, t) {
          const i = this._lowerbound(e, u),
            s = this._upperbound(t);
          return this._rangeIteratorImpl(i, s);
        }
        fullRangeIterator() {
          return this._rangeIteratorImpl(this._start, this._end);
        }
        minMaxOnRangeCached(e, t, i) {
          if (this.isEmpty()) return null;
          let s = null;
          for (const r of i) {
            s = _(
              s,
              this._minMaxOnRangeCachedImpl(e - r.offset, t - r.offset, r.name)
            );
          }
          return s;
        }
        minMaxOnRange(e, t, i) {
          if (this.isEmpty()) return null;
          let s = null;
          for (const r of i) {
            s = _(s, this._minMaxOnRange(e - r.offset, t - r.offset, r.name));
          }
          return s;
        }
        merge(e) {
          return this._shareRead
            ? (l.logDebug("merge: readonly collection modification attempt"),
              null)
            : 0 === e.length
            ? null
            : this.isEmpty() || e[e.length - 1].index < this._items[0].index
            ? this._prepend(e)
            : e[0].index > this._items[this._items.length - 1].index
            ? this._append(e)
            : 1 === e.length &&
              e[0].index === this._items[this._items.length - 1].index
            ? (this._updateLast(e[0]), e[0])
            : this._merge(e);
        }
        addTail(e, t = !1) {
          if (0 === e.length) return;
          let i = 0;
          t &&
            this._end - this._start > 0 &&
            ((i = 1),
            (this._items[this._end - this._start - 1].value = e[0].value));
          for (let t = i; t < e.length; ++t) {
            const i = e[t],
              s = this.lastIndex();
            if (null === s) {
              l.logError("Can't add tail to the empty plotlist");
              break;
            }
            this.add(s + 1, i.value);
          }
          this._invalidateSearchCaches();
        }
        move(e) {
          if (this._shareRead)
            return void l.logDebug(
              "move: readonly collection modification attempt"
            );
          if (0 === e.length) return;
          const t = this._items.slice();
          for (const i of e) {
            const e = this._bsearch(i.old, u);
            if (null !== e && void 0 !== t[e])
              if (i.new === a.INVALID_TIME_POINT_INDEX) t[e] = void 0;
              else {
                t[e] = { index: i.new, value: t[e].value };
                const s = this._bsearch(i.new, u);
                if (null !== s) {
                  const e = t[s];
                  void 0 !== e && e.index === i.new && (t[s] = void 0);
                }
              }
          }
          (this._items = t
            .filter((e) => void 0 !== e)
            .sort((e, t) => e.index - t.index)),
            this._invalidateSearchCaches(),
            this._minMaxCache.clear(),
            (this._start = 0),
            (this._end = this._items.length);
        }
        remove(e) {
          if (this._shareRead)
            return (
              l.logDebug("remove: readonly collection modification attempt"),
              null
            );
          const t = this._nonCachedSearch(
            e,
            o.PlotRowSearchMode.NearestRight,
            u
          );
          if (null === t) return null;
          const i = this._items.splice(t);
          return (
            (this._end = this._items.length),
            this._minMaxCache.clear(),
            this._invalidateSearchCaches(),
            i.length > 0 ? i[0] : null
          );
        }
        state() {
          const e = this._items.slice(this._start, this._end);
          return { start: 0, end: e.length, data: e };
        }
        restoreState(e) {
          e
            ? ((this._start = e.start),
              (this._end = e.end),
              (this._shareRead = !1),
              (this._items = e.data),
              this._minMaxCache.clear(),
              this._invalidateSearchCaches())
            : this.clear();
        }
        _indexAt(e) {
          return this._items[e].index;
        }
        _valueAt(e) {
          return this._items[e].value;
        }
        _length() {
          return this._items.length;
        }
        _searchImpl(e, t, i, s, r, n) {
          const a = void 0 !== n ? i : s,
            o = void 0 !== n ? 1e4 * (t + 1) + n : t;
          let l = a.get(e);
          if (void 0 !== l) {
            const e = l.get(o);
            if (void 0 !== e) return e;
          }
          const h = this._nonCachedSearch(e, t, r, n);
          if (null === h) return null;
          const u = { index: this._indexAt(h), value: this._valueAt(h) };
          return void 0 === l && ((l = new Map()), a.set(e, l)), l.set(o, u), u;
        }
        _nonCachedSearch(e, t, i, s) {
          const r = this._lowerbound(e, i),
            n = r === this._end || e !== i(this._items[r]);
          if (n && t !== o.PlotRowSearchMode.Exact)
            switch (t) {
              case o.PlotRowSearchMode.NearestLeft:
                return this._searchNearestLeft(r, s);
              case o.PlotRowSearchMode.NearestRight:
                return this._searchNearestRight(r, s);
              default:
                throw new TypeError("Unknown search mode");
            }
          if (void 0 === s || n || t === o.PlotRowSearchMode.Exact)
            return n ? null : r;
          switch (t) {
            case o.PlotRowSearchMode.NearestLeft:
              return this._nonEmptyNearestLeft(r, s);
            case o.PlotRowSearchMode.NearestRight:
              return this._nonEmptyNearestRight(r, s);
            default:
              throw new TypeError("Unknown search mode");
          }
        }
        _nonEmptyNearestRight(e, t) {
          const i = (0, s.ensure)(this._emptyValuePredicate),
            r = (0, s.ensure)(t);
          for (; e < this._end && i(this._valueAt(e), r); ) e += 1;
          return e === this._end ? null : e;
        }
        _nonEmptyNearestLeft(e, t) {
          const i = (0, s.ensureNotNull)(this._emptyValuePredicate),
            r = (0, s.ensure)(t);
          for (; e >= this._start && i(this._valueAt(e), r); ) e -= 1;
          return e < this._start ? null : e;
        }
        _searchNearestLeft(e, t) {
          if (e === this._start) return null;
          const i = e - 1,
            s = i !== this._end ? i : null;
          return void 0 !== t && null !== s
            ? this._nonEmptyNearestLeft(s, t)
            : s;
        }
        _searchNearestRight(e, t) {
          const i = e,
            s = i !== this._end ? i : null;
          return void 0 !== t && null !== s
            ? this._nonEmptyNearestRight(s, t)
            : s;
        }
        _bsearch(e, t) {
          const i = this._lowerbound(e, t);
          return i !== this._end && e === t(this._items[i]) ? i : null;
        }
        _lowerbound(e, t) {
          return (0, n.lowerbound)(
            this._items,
            e,
            (e, i) => t(e) < i,
            this._start,
            this._end
          );
        }
        _upperbound(e) {
          return (0, n.upperbound)(
            this._items,
            e,
            (e, t) => t.index > e,
            this._start,
            this._end
          );
        }
        _plotMinMax(e, t, i) {
          let s = null;
          const r = this._plotFunctions.get(i);
          if (void 0 === r) throw new Error(`Plot "${i}" is not registered`);
          for (let i = e; i < t; i++) {
            const e = r(this._items[i].value);
            null == e ||
              Number.isNaN(e) ||
              (null === s
                ? (s = { min: e, max: e })
                : (e < s.min && (s.min = e), e > s.max && (s.max = e)));
          }
          return s;
        }
        _invalidateCacheForRow(e) {
          const t = Math.floor(e.index / h);
          this._minMaxCache.forEach((e) => e.delete(t));
        }
        _prepend(e) {
          return (
            (0, s.assert)(
              !this._shareRead,
              "collection should not be readonly"
            ),
            (0, s.assert)(0 !== e.length, "plotRows should not be empty"),
            this._invalidateSearchCaches(),
            this._minMaxCache.clear(),
            (this._items = e.concat(this._items)),
            (this._start = 0),
            (this._end = this._items.length),
            e[0]
          );
        }
        _append(e) {
          return (
            (0, s.assert)(
              !this._shareRead,
              "collection should not be readonly"
            ),
            (0, s.assert)(0 !== e.length, "plotRows should not be empty"),
            this._invalidateSearchCaches(),
            this._minMaxCache.clear(),
            (this._items = this._items.concat(e)),
            (this._start = 0),
            (this._end = this._items.length),
            e[0]
          );
        }
        _updateLast(e) {
          (0, s.assert)(!this.isEmpty(), "plot list should not be empty");
          const t = this._items[this._end - 1];
          (0, s.assert)(
            t.index === e.index,
            "last row index should match new row index"
          ),
            this._invalidateCacheForRow(e),
            this._invalidateSearchCaches(),
            (this._items[this._end - 1] = e);
        }
        _merge(e) {
          return (
            (0, s.assert)(0 !== e.length, "plot rows should not be empty"),
            this._invalidateSearchCaches(),
            this._minMaxCache.clear(),
            (this._items = (function (e, t) {
              const i = (function (e, t) {
                  const i = e.length,
                    s = t.length;
                  let r = i + s,
                    n = 0,
                    a = 0;
                  for (; n < i && a < s; )
                    e[n].index < t[a].index
                      ? n++
                      : e[n].index > t[a].index
                      ? a++
                      : (n++, a++, r--);
                  return r;
                })(e, t),
                s = new Array(i);
              let r = 0,
                n = 0;
              const a = e.length,
                o = t.length;
              let l = 0;
              for (; r < a && n < o; )
                e[r].index < t[n].index
                  ? ((s[l] = e[r]), r++)
                  : e[r].index > t[n].index
                  ? ((s[l] = t[n]), n++)
                  : ((s[l] = t[n]), r++, n++),
                  l++;
              for (; r < a; ) (s[l] = e[r]), r++, l++;
              for (; n < o; ) (s[l] = t[n]), n++, l++;
              return s;
            })(this._items, e)),
            (this._start = 0),
            (this._end = this._items.length),
            e[0]
          );
        }
        _minMaxOnRangeCachedImpl(e, t, i) {
          if (this.isEmpty()) return null;
          let r = null;
          const n = (0, s.ensureNotNull)(this.firstIndex()),
            a = (0, s.ensureNotNull)(this.lastIndex()),
            o = Math.max(e, n),
            l = Math.min(t, a),
            u = Math.ceil(o / h) * h,
            d = Math.max(u, Math.floor(l / h) * h);
          r = _(r, this._minMaxOnRange(o, Math.min(u, t, l), i));
          let c = this._minMaxCache.get(i);
          void 0 === c && ((c = new Map()), this._minMaxCache.set(i, c));
          for (let e = Math.max(u + 1, o); e < d; e += h) {
            const t = Math.floor(e / h);
            let s = c.get(t);
            if (void 0 === s) {
              const e = t * h,
                r = (t + 1) * h - 1;
              (s = this._minMaxOnRange(e, r, i)), c.set(t, s);
            }
            r = _(r, s);
          }
          r = _(r, this._minMaxOnRange(d, l, i));
          return r;
        }
        _minMaxOnRange(e, t, i) {
          return this._plotMinMax(
            this._lowerbound(e, u),
            this._upperbound(t),
            i
          );
        }
        _rangeIteratorImpl(e, t) {
          let i = e - 1;
          return {
            [Symbol.iterator]() {
              return this;
            },
            next: () => (
              (i += 1),
              i >= t
                ? { done: !0, value: void 0 }
                : { done: !1, value: this._items[i] }
            ),
          };
        }
        _invalidateSearchCaches() {
          this._rowSearchCacheByIndex.clear(),
            this._rowSearchCacheByIndexWithoutEmptyValues.clear(),
            this._rowSearchCacheByTime.clear(),
            this._rowSearchCacheByTimeWithoutEmptyValues.clear();
        }
        constructor(e = null, t = null) {
          (this._items = []),
            (this._start = 0),
            (this._end = 0),
            (this._shareRead = !1),
            (this._minMaxCache = new Map()),
            (this._rowSearchCacheByIndex = new Map()),
            (this._rowSearchCacheByIndexWithoutEmptyValues = new Map()),
            (this._rowSearchCacheByTime = new Map()),
            (this._rowSearchCacheByTimeWithoutEmptyValues = new Map()),
            (this._plotFunctions = e || new Map()),
            (this._emptyValuePredicate = t);
        }
      }
      function _(e, t) {
        if (null === e) return t;
        if (null === t) return e;
        return { min: Math.min(e.min, t.min), max: Math.max(e.max, t.max) };
      }
    },
    80365(e, t, i) {
      i.d(t, {
        TimeFrameType: () => s,
        areEqualTimeFrames: () => r,
        convertStrToTimeFrame: () => a,
        convertTimeFrameToStr: () => n,
      });
      var s = (function (e) {
        return (e.PeriodBack = "period-back"), (e.TimeRange = "time-range"), e;
      })({});
      function r(e, t) {
        return "period-back" === e.type && "period-back" === t.type
          ? e.value === t.value
          : "time-range" === e.type &&
              "time-range" === t.type &&
              e.from === t.from &&
              e.to === t.to;
      }
      function n(e, t = !1) {
        if ("period-back" === e.type) {
          let i = e.value;
          return (
            t && "YTD" !== i && "D" === i.slice(-1) && (i = i.slice(0, -1)), i
          );
        }
        return "r," + e.from + ":" + e.to;
      }
      function a(e) {
        const t = /r,(\d+):(\d+)/.exec(e);
        return null !== t
          ? { from: Number(t[1]), to: Number(t[2]), type: "time-range" }
          : { value: e, type: "period-back" };
      }
    },
    937321(e, t, i) {
      i.r(t), (0, i(334120).setDocumentDirGetter)(() => window.document.dir);
    },
  },
]);
