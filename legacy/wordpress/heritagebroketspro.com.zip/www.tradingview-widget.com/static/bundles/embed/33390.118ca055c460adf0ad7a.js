"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [33390],
  {
    565199(e, _, t) {
      t.d(_, { deepExtend: () => i });
      const s = new Set(["__proto__", "prototype", "constructor"]);
      function i(e, ..._) {
        return e && "object" == typeof e
          ? (0 === _.length ||
              _.forEach((_) => {
                null != _ &&
                  "object" == typeof _ &&
                  Object.keys(_).forEach((t) => {
                    if (
                      (function (e) {
                        return s.has(e);
                      })(t)
                    )
                      return;
                    const a = e[t],
                      o = _[t];
                    if (o === e) return;
                    const r = Array.isArray(o);
                    if (o && (n(o) || r)) {
                      let _;
                      (_ = r
                        ? a && Array.isArray(a)
                          ? a
                          : []
                        : a && n(a)
                        ? a
                        : {}),
                        (e[t] = i(_, o));
                    } else void 0 !== o && (e[t] = o);
                  });
              }),
            e)
          : e;
      }
      function n(e) {
        if (!e || "[object Object]" !== Object.prototype.toString.call(e))
          return !1;
        const _ = Object.getPrototypeOf(e);
        if (!_) return !0;
        const t = Object.hasOwnProperty.toString,
          s = _.hasOwnProperty("constructor") && _.constructor;
        return "function" == typeof s && t.call(s) === t.call(Object);
      }
    },
    661313(e, _, t) {
      t.d(_, { QUOTE_FIELDS: () => i, QUOTE_FIELDS_CACHE: () => n });
      var s = t(146961);
      const i = new Set([
          "pro_name",
          "base_name",
          "logo",
          "logoid",
          "currency-logoid",
          "base-currency-logoid",
          "source-logoid",
          "short_name",
          "web_site_url",
          "pro_perm",
          "timezone",
          "current_session",
          "session_holidays",
          "last_price",
          "lp_time",
          "subsessions",
          "prev_close_price",
          "open_price",
          "high_price",
          "low_price",
          "price_52_week_high",
          "price_52_week_low",
          "ask",
          "ask_size",
          "bid",
          "bid_size",
          "rch",
          "rchp",
          "rtc",
          "rtc_time",
          "nch",
          "nchp",
          "ntc",
          "ntc_time",
          "data_frequency",
          "reference-last-period-start",
          "business_description",
          "web_site_url",
          "figi",
          "number_of_employees",
          "float_shares_outstanding",
          "earnings_release_next_calendar_date",
          "root",
          "description",
          "exchange",
          "listed_exchange",
          "type",
          "country_code",
          "provider_id",
          "is_tradable",
          "sector",
          "typespecs",
          "visible-plots-set",
          "industry",
          "currency_id",
          "last_price",
          "fractional",
          "minmov",
          "minmove2",
          "pricescale",
          "variable_tick_size",
          "change",
          "change_percent",
          "volume",
          "average_volume",
          "market_cap_basic",
          "market_cap_calc",
          "total_revenue",
          "earnings_per_share_basic_ttm",
          "price_earnings_ttm",
          "beta_1_year",
          "dps_common_stock_prim_issue_fy",
          "dividends_yield",
          "earnings_release_next_date",
          "earnings_per_share_forecast_next_fq",
          "earnings_publication_type_next_fq",
          "earnings_release_date",
          "earnings_per_share_fq",
          "earnings_per_share_forecast_fq",
          "forecast_raw",
          "last_release_date",
          "next_release_date",
          "reference_last_period",
          "fundamental_currency_code",
          "number_of_employees",
          "web_site_url",
          "business_description",
          "founded",
          "ceo",
          "float_shares_outstanding",
          "total_shares_outstanding",
          "dividend_payout_ratio_ttm",
          "dividends_yield_current",
          "dividend_ex_date_upcoming",
          "dividend_amount_upcoming",
          "dividend_amount_recent",
          "dividend_ex_date_recent",
          "dividend_amount_h",
          "dividend_payment_date_upcoming",
          "dividend_payment_date_recent",
          "total_revenue_fq_h",
          "total_revenue_fy_h",
          "net_income_fy_h",
          "net_income_fq_h",
          "total_assets_fy_h",
          "total_assets_fq_h",
          "total_liabilities_fy_h",
          "total_liabilities_fq_h",
          "cash_f_operating_activities_fy_h",
          "cash_f_operating_activities_fq_h",
          "cash_f_investing_activities_fy_h",
          "cash_f_investing_activities_fq_h",
          "cash_f_financing_activities_fy_h",
          "cash_f_financing_activities_fq_h",
          "fiscal_period_fy_h",
          "fiscal_period_fq_h",
          "fiscal_period_fh_h",
          "earnings_release_date_fq_h",
          "earnings_release_next_date_fq",
          "earnings_per_share_forecast_next_fq",
          "earnings_per_share_forecast_fq_h",
          "earnings_per_share_fq_h",
          "earnings_fiscal_period_fq_h",
          "next_earnings_fiscal_period_fq",
          "is_next_earnings_release_date_estimated",
          "symbol-primaryname",
          "currency_code",
          "rates_mc",
          "rates_fy",
          "rates_ttm",
          "measure",
          "value_unit_id",
          "value-unit-id",
          "update_mode",
          "language",
          "local_description",
          "short_description",
          "source",
          "source2",
          "format",
          "recommendation_mark",
          "last_report_frequency",
          "price_target_estimates_num",
          "price_target_average",
          "update_mode_seconds",
          "recommendation_total",
          "recommendation_buy",
          "recommendation_over",
          "recommendation_hold",
          "recommendation_under",
          "recommendation_sell",
          "recommendation_total",
          "price_target_high",
          "price_target_low",
          "rates_pt",
          "rates_pt",
          "total_revenue_fy_h",
          "total_revenue_fq_h",
          "total_revenue_fh_h",
          "net_revenue_fy_h",
          "net_revenue_fq_h",
          "net_revenue_fh_h",
          "net_income_fy_h",
          "net_income_fq_h",
          "net_income_fh_h",
          "total_assets_fy_h",
          "total_assets_fq_h",
          "total_assets_fh_h",
          "total_liabilities_fy_h",
          "total_liabilities_fq_h",
          "total_liabilities_fh_h",
          "cash_f_operating_activities_fy_h",
          "cash_f_operating_activities_fq_h",
          "cash_f_operating_activities_fh_h",
          "cash_f_investing_activities_fy_h",
          "cash_f_investing_activities_fq_h",
          "cash_f_investing_activities_fh_h",
          "cash_f_financing_activities_fy_h",
          "cash_f_financing_activities_fq_h",
          "cash_f_financing_activities_fh_h",
          "fiscal_period_fy",
          "fiscal_period_fq",
          "fiscal_period_fh",
          "earnings_release_date_fq_h",
          "earnings_release_date_fy_h",
          "earnings_release_date_fh_h",
          "earnings_release_next_date_fq",
          "earnings_release_next_date_fy",
          "earnings_release_next_date_fh",
          "earnings_release_next_time",
          "earnings_release_time",
          "is_next_earnings_release_date_estimated",
          "earnings_per_share_forecast_next_fq",
          "earnings_per_share_forecast_next_fy",
          "earnings_per_share_forecast_next_fh",
          "earnings_per_share_forecast_fq_h",
          "earnings_per_share_forecast_fy_h",
          "earnings_per_share_forecast_fh_h",
          "earnings_per_share_fq_h",
          "earnings_per_share_fy_h",
          "earnings_per_share_fh_h",
          "earnings_fiscal_period_fq_h",
          "earnings_fiscal_period_fy_h",
          "earnings_fiscal_period_fh_h",
          "next_earnings_fiscal_period_fq",
          "next_earnings_fiscal_period_fy",
          "next_earnings_fiscal_period_fh",
          "revenue_fq_h",
          "revenue_fy_h",
          "revenue_fh_h",
          "revenue_forecast_fq_h",
          "revenue_forecast_fy_h",
          "revenue_forecast_fh_h",
          "revenue_forecast_next_fq",
          "revenue_forecast_next_fy",
          "revenue_forecast_next_fh",
          "revenue_seg_by_business_h",
          "revenue_seg_by_region_h",
          "total_revenue_fy",
          "total_revenue_fq",
          "total_revenue_fh",
          "gross_profit_fy",
          "gross_profit_fq",
          "gross_profit_fh",
          "ebitda_fy",
          "ebit_fy",
          "net_income_fy",
          "net_income_fq",
          "net_income_fh",
          "total_debt_fy_h",
          "total_debt_fq_h",
          "total_debt_fh_h",
          "free_cash_flow_fy_h",
          "free_cash_flow_fq_h",
          "free_cash_flow_fh_h",
          "cash_n_equivalents_fy_h",
          "cash_n_equivalents_fq_h",
          "cash_n_equivalents_fh_h",
          "total_current_assets_fy",
          "total_current_assets_fq",
          "total_current_assets_fh",
          "total_current_liabilities_fy",
          "total_current_liabilities_fq",
          "total_current_liabilities_fh",
          "total_non_current_assets_fy",
          "total_non_current_assets_fq",
          "total_non_current_assets_fh",
          "total_non_current_liabilities_fy",
          "total_non_current_liabilities_fq",
          "total_non_current_liabilities_fh",
          "loans_net_fy",
          "loans_net_fy_h",
          "loans_net_fq_h",
          "loans_net_fh_h",
          "total_deposits_fy",
          "total_deposits_fy_h",
          "total_deposits_fq_h",
          "total_deposits_fh_h",
          "loan_loss_allowances_fy",
          "loan_loss_allowances_fy_h",
          "loan_loss_allowances_fq_h",
          "loan_loss_allowances_fh_h",
          "reserve_to_total_capital_fy_h",
          "reserve_to_total_capital_fq_h",
          "reserve_to_total_capital_fh_h",
          "unearned_premium_to_total_capital_fy_h",
          "unearned_premium_to_total_capital_fq_h",
          "unearned_premium_to_total_capital_fh_h",
          "insurance_reserves_fy_h",
          "insurance_reserves_fq_h",
          "insurance_reserves_fh_h",
          "policy_claims_fy_h",
          "policy_claims_fq_h",
          "policy_claims_fh_h",
          "premiums_earned_fy_h",
          "premiums_earned_fq_h",
          "premiums_earned_fh_h",
          "price_earnings_fq_h",
          "price_earnings_fy_h",
          "price_earnings_fh_h",
          "price_sales_fq_h",
          "price_sales_fy_h",
          "price_sales_fh_h",
          "diluted_net_income_ttm",
          "total_revenue_ttm",
          "net_revenue_ttm",
          "price_earnings_current",
          "price_sales_current",
          "isin-displayed",
          "cusip",
          "cfi_code",
          "interest_income_fy_h",
          "interest_income_fq_h",
          "interest_income_fh_h",
          "non_interest_income_fy_h",
          "non_interest_income_fq_h",
          "non_interest_income_fh_h",
          "website",
          "doc",
          "explorer",
          "sources",
          "contracts",
          "crypto_common_categories",
          "crypto_asset",
          "community",
          "dividends_availability",
          "earnings_availability",
          "financials_availability",
          "documents",
          "etf_asset_type_exposure",
          "etf_region_exposure",
          "top_holdings",
          "unit-id",
          "options-info",
          "option-type",
          "interest_income_fy",
          "interest_income_fq",
          "interest_income_fh",
          "non_interest_income_fy",
          "non_interest_income_fq",
          "non_interest_income_fh",
          "interest_expense_fy",
          "interest_expense_fq",
          "interest_expense_fh",
          "loan_loss_provision_fy",
          "loan_loss_provision_fq",
          "loan_loss_provision_fh",
          "non_interest_expense_fy",
          "non_interest_expense_fq",
          "non_interest_expense_fh",
          "non_oper_income_fy",
          "non_oper_income_fq",
          "non_oper_income_fh",
          "unusual_expense_inc_fy",
          "unusual_expense_inc_fq",
          "unusual_expense_inc_fh",
          "pretax_income_fy",
          "pretax_income_fq",
          "pretax_income_fh",
          "income_tax_fy",
          "income_tax_fq",
          "income_tax_fh",
          "after_tax_other_income_fy",
          "after_tax_other_income_fq",
          "after_tax_other_income_fh",
          "total_non_oper_income_fy",
          "total_non_oper_income_fq",
          "total_non_oper_income_fh",
          "oper_income_fy",
          "oper_income_fq",
          "oper_income_fh",
          "operating_expenses_fy",
          "operating_expenses_fq",
          "operating_expenses_fh",
          "cost_of_goods_fy",
          "cost_of_goods_fq",
          "cost_of_goods_fh",
          "equity_in_earnings_fy",
          "equity_in_earnings_fq",
          "equity_in_earnings_fh",
          "minority_interest_exp_fy",
          "minority_interest_exp_fq",
          "minority_interest_exp_fh",
          "discontinued_operations_fy",
          "discontinued_operations_fq",
          "discontinued_operations_fh",
          "front_contract",
          "min_contract",
          "pointvalue",
          "unit_id",
          "expiration",
          "aum",
          "asset_class",
          "focus",
          "expense_ratio",
          "launch_date",
          "issuer",
          "brand",
          "homepage",
          "index_tracked",
          "actively_managed",
          "fund_view_modes",
          "common_equity_tier1_ratio_fy_h",
          "common_equity_tier1_ratio_fq_h",
          "common_equity_tier1_ratio_fh_h",
          "tier1_capital_ratio_fy_h",
          "tier1_capital_ratio_fq_h",
          "tier1_capital_ratio_fh_h",
          "total_capital_ratio_fy_h",
          "total_capital_ratio_fq_h",
          "total_capital_ratio_fh_h",
          "preferred_stock_carrying_value_fh",
          "preferred_stock_carrying_value_fq",
          "total_debt_fq",
          "minority_interest_fh",
          "minority_interest_fq",
          "cash_n_short_term_invest_fq",
          "cash_n_due_f_banks_fh",
          "cash_n_due_f_banks_fq",
          "enterprise_value_current",
          "etf_holdings_count",
          "contract-description",
          "reference-last-period",
          "all_time_high",
          "all_time_high_day",
          "all_time_low",
          "all_time_low_day",
          "outstanding_amount",
          "nominal_value",
          "denom_min",
          "current_coupon",
          "coupon_type_general",
          "coupon_frequency",
          "yield_to_maturity",
          "maturity-date",
          "days_to_maturity",
          "bond_issuer",
          "issue_date",
          "bond_issuer_stock_symbol",
          "total_issued_amount",
          "paid_amount",
          "bond_snp_rating_lt_h",
          "placement_type",
          "duration_type",
          "maturity_type",
          "offer_type",
          "redemption_type",
          "conversion_option",
          "sinking_fund",
          "ownership_form",
          "daily-summary-ast",
          "issue_status",
          "coupon_h",
          "sinking_fund_next_date",
          "sinking_fund_min_amount_next",
          "call_next_date",
          "redemptions_h",
          "call_notice_days",
          "put_next_date",
          "put_notice_days_min",
          "seniority_level",
          "inflation_protection",
          "pledge_status",
          "bond_issuer_country_of_risk",
          "bond_issuer_cr_parent",
          "credit_enhancement_type",
          "credit_enhancement_status",
          "use_of_proceeds",
          "bond_issuer_snp_rating_lt_h",
          "bond_issuer_snp_rating_st_h",
          "bond_agents_tr",
          "first_bar_time_1d",
          "financial-indicator-id",
          "exchange-info",
          "underlying-symbol",
          "strike",
          "lotsize",
          "option-style",
          "has_bonds",
          "open_time",
          "has_bonds",
          "dex_buys_15m",
          "dex_sells_15m",
          "dex_buy_volume_15m",
          "dex_sell_volume_15m",
          "dex_buyers_15m",
          "dex_sellers_15m",
          "dex_buys_1h",
          "dex_sells_1h",
          "dex_buy_volume_1h",
          "dex_sell_volume_1h",
          "dex_buyers_1h",
          "dex_sellers_1h",
          "dex_buys_4h",
          "dex_sells_4h",
          "dex_buy_volume_4h",
          "dex_sell_volume_4h",
          "dex_buyers_4h",
          "dex_sellers_4h",
          "dex_buys_12h",
          "dex_sells_12h",
          "dex_buy_volume_12h",
          "dex_sell_volume_12h",
          "dex_buyers_12h",
          "dex_sellers_12h",
          "dex_buys_24h",
          "dex_sells_24h",
          "dex_buy_volume_24h",
          "dex_sell_volume_24h",
          "dex_buyers_24h",
          "dex_sellers_24h",
          "dex_converted_symbol",
          "dex_trading_volume_24h",
          "dex_created_time",
          "dex_currency",
          "dex_currency_logoid",
          "blockchain_addresses_urls",
          "blockchain_addresses",
          "base_currency",
          "base_currency_id",
          "ipo_offer_status",
          "has_ipo_details_visible",
          "ipo_price_range_usd_max",
          "ipo_price_range_usd_min",
          "ipo_price_range_usd",
          "ipo_price_range",
          "ipo_offer_price_usd",
          "ipo_offer_price",
          "ipo_offered_shares",
          "ipo_deal_amount_usd",
          "ipo_announcement_date",
          "ipo_offer_date",
          "available_data_range_begin_date",
          "available_data_range_end_date",
          "has_etf_ownership",
          "symbol_primary_listing",
          "metric_ytm",
          "metrics",
          "eps_estimates_fy_h",
          "eps_estimates_fq_h",
          "eps_estimates_fh_h",
          "revenue_estimates_fy_h",
          "revenue_estimates_fq_h",
          "revenue_estimates_fh_h",
          "dps_estimates_fy_h",
          "dps_estimates_fq_h",
          "dps_estimates_fh_h",
          "cost_of_goods_estimates_fy_h",
          "cost_of_goods_estimates_fq_h",
          "cost_of_goods_estimates_fh_h",
          "gross_profit_estimates_fy_h",
          "gross_profit_estimates_fq_h",
          "gross_profit_estimates_fh_h",
          "sell_gen_admin_exp_total_estimates_fy_h",
          "sell_gen_admin_exp_total_estimates_fq_h",
          "sell_gen_admin_exp_total_estimates_fh_h",
          "research_and_dev_estimates_fy_h",
          "research_and_dev_estimates_fq_h",
          "research_and_dev_estimates_fh_h",
          "ebitda_estimates_fy_h",
          "ebitda_estimates_fq_h",
          "ebitda_estimates_fh_h",
          "ebit_estimates_fy_h",
          "ebit_estimates_fq_h",
          "ebit_estimates_fh_h",
          "net_income_estimates_fy_h",
          "net_income_estimates_fq_h",
          "net_income_estimates_fh_h",
          "total_assets_estimates_fy_h",
          "total_assets_estimates_fq_h",
          "total_assets_estimates_fh_h",
          "cash_n_short_term_invest_estimates_fy_h",
          "cash_n_short_term_invest_estimates_fq_h",
          "cash_n_short_term_invest_estimates_fh_h",
          "total_debt_estimates_fy_h",
          "total_debt_estimates_fq_h",
          "total_debt_estimates_fh_h",
          "book_value_per_share_estimates_fy_h",
          "book_value_per_share_estimates_fq_h",
          "book_value_per_share_estimates_fh_h",
          "cash_f_operating_activities_estimates_fy_h",
          "cash_f_operating_activities_estimates_fq_h",
          "cash_f_operating_activities_estimates_fh_h",
          "cash_f_investing_activities_estimates_fy_h",
          "cash_f_investing_activities_estimates_fq_h",
          "cash_f_investing_activities_estimates_fh_h",
          "capital_expenditures_estimates_fy_h",
          "capital_expenditures_estimates_fq_h",
          "capital_expenditures_estimates_fh_h",
          "cash_f_financing_activities_estimates_fy_h",
          "cash_f_financing_activities_estimates_fq_h",
          "cash_f_financing_activities_estimates_fh_h",
          "free_cash_flow_estimates_fy_h",
          "free_cash_flow_estimates_fq_h",
          "free_cash_flow_estimates_fh_h",
          "estimates_fiscal_period_fy_h",
          "estimates_fiscal_period_fq_h",
          "estimates_fiscal_period_fh_h",
          "forecast_availability",
        ]),
        n = new (class {
          update(e, _, t) {
            const i = (0, s.ensureDefined)(e.symbolname),
              n = Date.now();
            if (
              (this._cache.has(i) ||
                this._cache.set(i, {
                  symbolname: i,
                  status: e.status,
                  values: {},
                }),
              this._times.has(i) || this._times.set(i, new Map()),
              "error" === e.status)
            )
              return;
            const a = (0, s.ensureDefined)(this._cache.get(i)),
              o = (0, s.ensureDefined)(this._times.get(i));
            a.status = e.status;
            for (const s of this._fields)
              _.has(s) &&
                (t || void 0 !== e.values[s]) &&
                ((a.values[s] = e.values[s]), o.set(s, n));
          }
          get(e) {
            return this._cache.get(e) ?? null;
          }
          getTimes(e) {
            return this._times.get(e) ?? null;
          }
          fields() {
            return this._fields;
          }
          constructor(e) {
            (this._cache = new Map()),
              (this._times = new Map()),
              (this._fields = [...e.fields]);
          }
        })({ fields: i });
    },
    933390(e, _, t) {
      t.d(_, { QuoteSessionMultiplexer: () => p });
      var s = t(587168),
        i = t(547851),
        n = t(448245),
        a = t(146961),
        o = t(819511),
        r = t(570071),
        h = t(565199),
        c = t(966193),
        l = t(661313),
        f = t(220455);
      let d = !1;
      var u = t(595583);
      const m = (0, o.getLogger)("WebchartClient.QuoteSessionMultiplexer");
      class p {
        destroy() {
          this._session.destroy(),
            (this._connected = !1),
            this.onDisconnect.fire();
        }
        internals() {
          return {
            session: () => this._session,
            subscriptions: () => this._subscriptions,
            data: () => this._symbol_data,
          };
        }
        connect() {
          this._session.connect(this.quoteHandler.bind(this));
        }
        quoteHandler(e) {
          const { method: _, params: t } = e;
          switch (_) {
            case "connected":
              this._connected || ((this._connected = !0), this.onConnected());
              break;
            case "quote_list_fields":
              break;
            case "quote_symbol_data":
              this._connected && this.onSymbolData(t[0]);
              break;
            case "quote_completed":
              this._connected &&
                this.onSymbolData({
                  symbolname: t[0],
                  complete: performance.now(),
                  values: {},
                });
              break;
            case "disconnected":
              this._connected &&
                ((this._connected = !1), this.onDisconnect.fire());
          }
        }
        onConnected() {
          this.setFields();
          const e = Object.keys(this._symbol_data);
          e.length &&
            (this._session.quoteAddSymbols(e), this._delayUpdateFastSymbols()),
            this.onConnect.fire();
        }
        setFields() {
          const { fields: e } = this.options;
          e && e.length && this._session.quoteSetFields(e);
        }
        onSymbolData(e) {
          try {
            e.status && l.QUOTE_FIELDS_CACHE.update(e, l.QUOTE_FIELDS, !1);
          } catch (e) {}
          const _ = e.symbolname;
          let t = this._throttledSymbolData[_];
          d &&
            (delete e.values.prev_close_price,
            void 0 !== e.values.regular_close &&
              (e.values.prev_close_price = e.values.regular_close)),
            t ||
              (t = this._throttledSymbolData[_] =
                {
                  fnDispatch: (0, s.default)(
                    this.dispatchSymbolData.bind(this),
                    this.options.throttleTimeout
                  ),
                }),
            t.cache ? (0, h.deepExtend)(t.cache, e) : (t.cache = e),
            t.fnDispatch(_);
        }
        dispatchSymbolData(e) {
          const _ = this._symbol_data[e],
            t = this._throttledSymbolData[e].cache;
          if (
            (delete this._throttledSymbolData[e].cache, this._symbol_data[e])
          ) {
            (0, h.deepExtend)(_, t),
              _.values && this._parseUpdateMode(_.values);
            for (const s in this._subscriptions) {
              const i = this._subscriptions[s];
              if (i.has(e)) {
                [...(0, a.ensureDefined)(i.get(e))].forEach((e) => {
                  e(_, t);
                });
              }
            }
          }
        }
        subscribe(e, _, t) {
          this._subscriptions[e] = this._subscriptions[e] || new Map();
          const s = this._subscriptions[e];
          _ = Array.isArray(_) ? [..._] : [_];
          const i = [];
          _.forEach((e) => {
            this._symbol_data[e]
              ? (s && s.has(e)) || this._symbol_data[e].subscribers_count++
              : ((this._symbol_data[e] = { subscribers_count: 1 }), i.push(e)),
              s.has(e) || s.set(e, []);
            const _ = (0, a.ensureDefined)(s.get(e));
            _.push(t),
              (_.fast = !0),
              this._symbol_data[e] &&
                this._symbol_data[e].values &&
                t(this._symbol_data[e], this._symbol_data[e]);
          }),
            i.length &&
              this._connected &&
              (this._session.quoteAddSymbols(i),
              this._delayUpdateFastSymbols());
        }
        unsubscribe(e, _, t) {
          _ = Array.isArray(_) ? [..._] : [_];
          const s = this._subscriptions[e],
            i = [];
          for (let n = 0; n < _.length; n++) {
            const o = _[n];
            if (s && s.has(o)) {
              if (t) {
                const e = (0, a.ensureDefined)(s.get(o)),
                  _ = e.indexOf(t);
                ~_ && e.splice(_, 1), e.length || s.delete(o);
              } else s.delete(o);
              0 === s.size && delete this._subscriptions[e],
                this._symbol_data.hasOwnProperty(o) &&
                  (s.has(o) || this._symbol_data[o].subscribers_count--,
                  this._symbol_data[o].subscribers_count ||
                    (delete this._symbol_data[o], i.push(o)));
            } else
              m.logWarn(
                `Check your sub/unsub looks it is leaking (client_id=${e}, symbol=${o})`
              );
          }
          i.length &&
            this._connected &&
            (this._session.quoteRemoveSymbols(i),
            this._delayUpdateFastSymbols());
        }
        setFastSymbols(e, _) {
          if (this._subscriptions[e]) {
            const t = this._subscriptions[e],
              s = Array.from(t.keys());
            for (let e = 0; e < s.length; ++e) {
              const i = s[e];
              (0, a.ensureDefined)(t.get(i)).fast = -1 !== _.indexOf(i);
            }
          }
          this._delayUpdateFastSymbols();
        }
        snapshot(e) {
          return void 0 === this._extensions.snapshot
            ? Promise.reject("No formatter extension provided")
            : this._extensions.snapshot(e);
        }
        formatter(e, _) {
          return void 0 === this._extensions.formatter
            ? Promise.reject("No formatter extension provided")
            : this._extensions.formatter(e, _);
        }
        _updateFastSymbols() {
          if (!this._connected) return;
          const e = this._fastSymbols();
          0 === e.length
            ? this._session.quoteHibernateAll()
            : this._session.quoteFastSymbols(e);
        }
        _fastSymbols() {
          let e = [];
          for (const _ in this._subscriptions) {
            const t = this._subscriptions[_],
              s = Array.from(t.keys());
            for (let _ = 0; _ < s.length; ++_) {
              const i = s[_];
              (0, a.ensureDefined)(t.get(i)).fast && e.push(i);
            }
          }
          return (e = (0, n.default)(e)), e;
        }
        _parseUpdateMode(e) {
          (0, f.normalizeUpdateMode)(e);
        }
        constructor(e) {
          (this.onConnect = new r.Delegate()),
            (this.onDisconnect = new r.Delegate()),
            (this._connected = !1),
            (this._subscriptions = {}),
            (this._symbol_data = {}),
            (this._delayUpdateFastSymbols = (0, i.default)(
              this._updateFastSymbols,
              250
            )),
            (this._throttledSymbolData = {}),
            (this._extensions = {}),
            (this.options = { throttleTimeout: 125, ...e }),
            (this._session = new u.QuoteSession(
              e.api,
              ["multiplexer", e.name, (0, c.randomHash)()]
                .filter(Boolean)
                .join("_")
            )),
            this.options.extensions?.formatter &&
              (this._extensions.formatter =
                this.options.extensions.formatter(this)),
            this.options.extensions?.snapshot &&
              (this._extensions.snapshot =
                this.options.extensions.snapshot(this)),
            this.connect();
        }
      }
    },
    595583(e, _, t) {
      t.d(_, { QuoteSession: () => i });
      var s = t(966193);
      class i {
        destroy() {
          this._sessionstarted &&
            (this._chartApi.quoteDeleteSession(this._sessionid),
            (this._sessionstarted = !1));
        }
        connected() {
          return this._chartApi.connected();
        }
        connect(e) {
          (this._globalHandler = e),
            this._chartApi.createSession(this._sessionid, this),
            this._chartApi.connect();
        }
        disconnect() {
          this._chartApi.disconnect();
        }
        quoteAddSymbols(e) {
          this._chartApi.quoteAddSymbols(this._sessionid, e);
        }
        quoteRemoveSymbols(e) {
          this._chartApi.quoteRemoveSymbols(this._sessionid, e);
        }
        quoteFastSymbols(e) {
          this._chartApi.quoteFastSymbols(this._sessionid, e);
        }
        quoteSetFields(e) {
          this._chartApi.quoteSetFields(this._sessionid, e);
        }
        onMessage(e) {
          switch (e.method) {
            case "connected":
              this._sessionstarted ||
                (this._chartApi.quoteCreateSession(this._sessionid),
                (this._sessionstarted = !0));
              break;
            case "disconnected":
              this._sessionstarted = !1;
          }
          this._globalHandler?.(e);
        }
        quoteHibernateAll() {
          this._chartApi.quoteHibernateAll(this._sessionid);
        }
        constructor(e, _ = (0, s.randomHash)()) {
          (this._sessionstarted = !1),
            (this._globalHandler = null),
            (this._chartApi = e),
            (this._sessionid = "qs_" + _);
        }
      }
    },
  },
]);
