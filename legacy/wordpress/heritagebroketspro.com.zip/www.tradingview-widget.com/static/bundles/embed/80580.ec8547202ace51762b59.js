(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [80580],
  {
    756851(t) {
      "use strict";
      t.exports = function (t) {
        for (var e = [], r = t.length, n = 0; n < r; n++) {
          var u = t.charCodeAt(n);
          if (u >= 55296 && u <= 56319 && r > n + 1) {
            var a = t.charCodeAt(n + 1);
            a >= 56320 &&
              a <= 57343 &&
              ((u = 1024 * (u - 55296) + a - 56320 + 65536), (n += 1));
          }
          u < 128
            ? e.push(u)
            : u < 2048
            ? (e.push((u >> 6) | 192), e.push((63 & u) | 128))
            : u < 55296 || (u >= 57344 && u < 65536)
            ? (e.push((u >> 12) | 224),
              e.push(((u >> 6) & 63) | 128),
              e.push((63 & u) | 128))
            : u >= 65536 && u <= 1114111
            ? (e.push((u >> 18) | 240),
              e.push(((u >> 12) & 63) | 128),
              e.push(((u >> 6) & 63) | 128),
              e.push((63 & u) | 128))
            : e.push(239, 191, 189);
        }
        return new Uint8Array(e).buffer;
      };
    },
    504402(t, e, r) {
      var n = r(638221);
      t.exports = function (t) {
        return (
          (t = n((t ^= t >>> 16), 2246822507)),
          (t = n((t ^= t >>> 13), 3266489909)),
          (t ^= t >>> 16) >>> 0
        );
      };
    },
    638221(t) {
      "use strict";
      t.exports =
        Math.imul ||
        function (t, e) {
          var r = 65535 & t,
            n = 65535 & e;
          return (
            (r * n +
              (((((t >>> 16) & 65535) * n + r * ((e >>> 16) & 65535)) << 16) >>>
                0)) |
            0
          );
        };
    },
    100595(t, e, r) {
      var n = r(638221),
        u = r(504402),
        a = r(756851),
        o = new Uint32Array([3432918353, 461845907]);
      function c(t, e) {
        return (t << e) | (t >>> (32 - e));
      }
      t.exports = function (t, e) {
        if (
          ((e = e ? 0 | e : 0),
          "string" == typeof t && (t = a(t)),
          !(t instanceof ArrayBuffer))
        )
          throw new TypeError("Expected key to be ArrayBuffer or string");
        var r = new Uint32Array([e]);
        return (
          (function (t, e) {
            for (
              var r = (t.byteLength / 4) | 0,
                u = new Uint32Array(t, 0, r),
                a = 0;
              a < r;
              a++
            )
              (u[a] = n(u[a], o[0])),
                (u[a] = c(u[a], 15)),
                (u[a] = n(u[a], o[1])),
                (e[0] = e[0] ^ u[a]),
                (e[0] = c(e[0], 13)),
                (e[0] = n(e[0], 5) + 3864292196);
          })(t, r),
          (function (t, e) {
            var r = (t.byteLength / 4) | 0,
              u = t.byteLength % 4,
              a = 0,
              f = new Uint8Array(t, 4 * r, u);
            switch (u) {
              case 3:
                a ^= f[2] << 16;
              case 2:
                a ^= f[1] << 8;
              case 1:
                (a ^= f[0]),
                  (a = c((a = n(a, o[0])), 15)),
                  (a = n(a, o[1])),
                  (e[0] = e[0] ^ a);
            }
          })(t, r),
          (function (t, e) {
            (e[0] = e[0] ^ t.byteLength), (e[0] = u(e[0]));
          })(t, r),
          r.buffer
        );
      };
    },
    414123(t, e, r) {
      "use strict";
      r.d(e, { default: () => a });
      var n = r(162316),
        u = r(981523);
      const a = (0, n.default)(u.default, "Set");
    },
    886514(t, e, r) {
      "use strict";
      r.d(e, { default: () => l });
      var n = r(735983);
      const u = function () {
        (this.__data__ = new n.default()), (this.size = 0);
      };
      const a = function (t) {
        var e = this.__data__,
          r = e.delete(t);
        return (this.size = e.size), r;
      };
      const o = function (t) {
        return this.__data__.get(t);
      };
      const c = function (t) {
        return this.__data__.has(t);
      };
      var f = r(69421),
        s = r(713148);
      const i = function (t, e) {
        var r = this.__data__;
        if (r instanceof n.default) {
          var u = r.__data__;
          if (!f.default || u.length < 199)
            return u.push([t, e]), (this.size = ++r.size), this;
          r = this.__data__ = new s.default(u);
        }
        return r.set(t, e), (this.size = r.size), this;
      };
      function d(t) {
        var e = (this.__data__ = new n.default(t));
        this.size = e.size;
      }
      (d.prototype.clear = u),
        (d.prototype.delete = a),
        (d.prototype.get = o),
        (d.prototype.has = c),
        (d.prototype.set = i);
      const l = d;
    },
    865330(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = r(981523).default.Uint8Array;
    },
    928453(t, e, r) {
      "use strict";
      r.d(e, { default: () => a });
      var n = r(162316),
        u = r(981523);
      const a = (0, n.default)(u.default, "WeakMap");
    },
    820975(t, e, r) {
      "use strict";
      r.d(e, { default: () => i });
      const n = function (t, e) {
        for (var r = -1, n = Array(t); ++r < t; ) n[r] = e(r);
        return n;
      };
      var u = r(531557),
        a = r(295635),
        o = r(659018),
        c = r(921143),
        f = r(165267),
        s = Object.prototype.hasOwnProperty;
      const i = function (t, e) {
        var r = (0, a.default)(t),
          i = !r && (0, u.default)(t),
          d = !r && !i && (0, o.default)(t),
          l = !r && !i && !d && (0, f.default)(t),
          p = r || i || d || l,
          v = p ? n(t.length, String) : [],
          y = v.length;
        for (var b in t)
          (!e && !s.call(t, b)) ||
            (p &&
              ("length" == b ||
                (d && ("offset" == b || "parent" == b)) ||
                (l &&
                  ("buffer" == b || "byteLength" == b || "byteOffset" == b)) ||
                (0, c.default)(b, y))) ||
            v.push(b);
        return v;
      };
    },
    448626(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = function (t, e) {
        for (var r = -1, n = e.length, u = t.length; ++r < n; ) t[u + r] = e[r];
        return t;
      };
    },
    916085(t, e, r) {
      "use strict";
      r.d(e, { default: () => a });
      var n = r(448626),
        u = r(295635);
      const a = function (t, e, r) {
        var a = e(t);
        return (0, u.default)(t) ? a : (0, n.default)(a, r(t));
      };
    },
    830875(t, e, r) {
      "use strict";
      r.d(e, { default: () => o });
      var n = r(693941);
      const u = (0, r(139849).default)(Object.keys, Object);
      var a = Object.prototype.hasOwnProperty;
      const o = function (t) {
        if (!(0, n.default)(t)) return u(t);
        var e = [];
        for (var r in Object(t))
          a.call(t, r) && "constructor" != r && e.push(r);
        return e;
      };
    },
    899339(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = function (t) {
        return function (e) {
          return t(e);
        };
      };
    },
    806240(t, e, r) {
      "use strict";
      r.d(e, { default: () => o });
      var n = r(916085),
        u = r(230951),
        a = r(309080);
      const o = function (t) {
        return (0, n.default)(t, a.default, u.default);
      };
    },
    230951(t, e, r) {
      "use strict";
      r.d(e, { default: () => c });
      const n = function (t, e) {
        for (
          var r = -1, n = null == t ? 0 : t.length, u = 0, a = [];
          ++r < n;

        ) {
          var o = t[r];
          e(o, r, t) && (a[u++] = o);
        }
        return a;
      };
      var u = r(177655),
        a = Object.prototype.propertyIsEnumerable,
        o = Object.getOwnPropertySymbols;
      const c = o
        ? function (t) {
            return null == t
              ? []
              : ((t = Object(t)),
                n(o(t), function (e) {
                  return a.call(t, e);
                }));
          }
        : u.default;
    },
    969785(t, e, r) {
      "use strict";
      r.d(e, { default: () => A });
      var n = r(162316),
        u = r(981523);
      const a = (0, n.default)(u.default, "DataView");
      var o = r(69421);
      const c = (0, n.default)(u.default, "Promise");
      var f = r(414123),
        s = r(928453),
        i = r(178497),
        d = r(730503),
        l = "[object Map]",
        p = "[object Promise]",
        v = "[object Set]",
        y = "[object WeakMap]",
        b = "[object DataView]",
        h = (0, d.default)(a),
        j = (0, d.default)(o.default),
        g = (0, d.default)(c),
        m = (0, d.default)(f.default),
        _ = (0, d.default)(s.default),
        w = i.default;
      ((a && w(new a(new ArrayBuffer(1))) != b) ||
        (o.default && w(new o.default()) != l) ||
        (c && w(c.resolve()) != p) ||
        (f.default && w(new f.default()) != v) ||
        (s.default && w(new s.default()) != y)) &&
        (w = function (t) {
          var e = (0, i.default)(t),
            r = "[object Object]" == e ? t.constructor : void 0,
            n = r ? (0, d.default)(r) : "";
          if (n)
            switch (n) {
              case h:
                return b;
              case j:
                return l;
              case g:
                return p;
              case m:
                return v;
              case _:
                return y;
            }
          return e;
        });
      const A = w;
    },
    921143(t, e, r) {
      "use strict";
      r.d(e, { default: () => u });
      var n = /^(?:0|[1-9]\d*)$/;
      const u = function (t, e) {
        var r = typeof t;
        return (
          !!(e = e ?? 9007199254740991) &&
          ("number" == r || ("symbol" != r && n.test(t))) &&
          t > -1 &&
          t % 1 == 0 &&
          t < e
        );
      };
    },
    693941(t, e, r) {
      "use strict";
      r.d(e, { default: () => u });
      var n = Object.prototype;
      const u = function (t) {
        var e = t && t.constructor;
        return t === (("function" == typeof e && e.prototype) || n);
      };
    },
    369899(t, e, r) {
      "use strict";
      r.d(e, { default: () => c });
      var n = r(602942),
        u =
          "object" == typeof exports && exports && !exports.nodeType && exports,
        a =
          u &&
          "object" == typeof module &&
          module &&
          !module.nodeType &&
          module,
        o = a && a.exports === u && n.default.process;
      const c = (function () {
        try {
          var t = a && a.require && a.require("util").types;
          return t || (o && o.binding && o.binding("util"));
        } catch (t) {}
      })();
    },
    139849(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = function (t, e) {
        return function (r) {
          return t(e(r));
        };
      };
    },
    547851(t, e, r) {
      "use strict";
      r.d(e, { default: () => s });
      var n = r(880115),
        u = r(981523);
      const a = function () {
        return u.default.Date.now();
      };
      var o = r(406449),
        c = Math.max,
        f = Math.min;
      const s = function (t, e, r) {
        var u,
          s,
          i,
          d,
          l,
          p,
          v = 0,
          y = !1,
          b = !1,
          h = !0;
        if ("function" != typeof t) throw new TypeError("Expected a function");
        function j(e) {
          var r = u,
            n = s;
          return (u = s = void 0), (v = e), (d = t.apply(n, r));
        }
        function g(t) {
          var r = t - p;
          return void 0 === p || r >= e || r < 0 || (b && t - v >= i);
        }
        function m() {
          var t = a();
          if (g(t)) return _(t);
          l = setTimeout(
            m,
            (function (t) {
              var r = e - (t - p);
              return b ? f(r, i - (t - v)) : r;
            })(t)
          );
        }
        function _(t) {
          return (l = void 0), h && u ? j(t) : ((u = s = void 0), d);
        }
        function w() {
          var t = a(),
            r = g(t);
          if (((u = arguments), (s = this), (p = t), r)) {
            if (void 0 === l)
              return (function (t) {
                return (v = t), (l = setTimeout(m, e)), y ? j(t) : d;
              })(p);
            if (b) return clearTimeout(l), (l = setTimeout(m, e)), j(p);
          }
          return void 0 === l && (l = setTimeout(m, e)), d;
        }
        return (
          (e = (0, o.default)(e) || 0),
          (0, n.default)(r) &&
            ((y = !!r.leading),
            (i = (b = "maxWait" in r)
              ? c((0, o.default)(r.maxWait) || 0, e)
              : i),
            (h = "trailing" in r ? !!r.trailing : h)),
          (w.cancel = function () {
            void 0 !== l && clearTimeout(l), (v = 0), (u = p = s = l = void 0);
          }),
          (w.flush = function () {
            return void 0 === l ? d : _(a());
          }),
          w
        );
      };
    },
    531557(t, e, r) {
      "use strict";
      r.d(e, { default: () => i });
      var n = r(178497),
        u = r(360620);
      const a = function (t) {
        return (0, u.default)(t) && "[object Arguments]" == (0, n.default)(t);
      };
      var o = Object.prototype,
        c = o.hasOwnProperty,
        f = o.propertyIsEnumerable,
        s = a(
          (function () {
            return arguments;
          })()
        )
          ? a
          : function (t) {
              return (
                (0, u.default)(t) && c.call(t, "callee") && !f.call(t, "callee")
              );
            };
      const i = s;
    },
    295635(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = Array.isArray;
    },
    392908(t, e, r) {
      "use strict";
      r.d(e, { default: () => a });
      var n = r(928132),
        u = r(990604);
      const a = function (t) {
        return null != t && (0, u.default)(t.length) && !(0, n.default)(t);
      };
    },
    659018(t, e, r) {
      "use strict";
      r.d(e, { default: () => f });
      var n = r(981523);
      const u = function () {
        return !1;
      };
      var a =
          "object" == typeof exports && exports && !exports.nodeType && exports,
        o =
          a &&
          "object" == typeof module &&
          module &&
          !module.nodeType &&
          module,
        c = o && o.exports === a ? n.default.Buffer : void 0;
      const f = (c ? c.isBuffer : void 0) || u;
    },
    990604(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = function (t) {
        return (
          "number" == typeof t && t > -1 && t % 1 == 0 && t <= 9007199254740991
        );
      };
    },
    360620(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = function (t) {
        return null != t && "object" == typeof t;
      };
    },
    717332(t, e, r) {
      "use strict";
      r.d(e, { default: () => a });
      var n = r(178497),
        u = r(360620);
      const a = function (t) {
        return (
          "symbol" == typeof t ||
          ((0, u.default)(t) && "[object Symbol]" == (0, n.default)(t))
        );
      };
    },
    165267(t, e, r) {
      "use strict";
      r.d(e, { default: () => d });
      var n = r(178497),
        u = r(990604),
        a = r(360620),
        o = {};
      (o["[object Float32Array]"] =
        o["[object Float64Array]"] =
        o["[object Int8Array]"] =
        o["[object Int16Array]"] =
        o["[object Int32Array]"] =
        o["[object Uint8Array]"] =
        o["[object Uint8ClampedArray]"] =
        o["[object Uint16Array]"] =
        o["[object Uint32Array]"] =
          !0),
        (o["[object Arguments]"] =
          o["[object Array]"] =
          o["[object ArrayBuffer]"] =
          o["[object Boolean]"] =
          o["[object DataView]"] =
          o["[object Date]"] =
          o["[object Error]"] =
          o["[object Function]"] =
          o["[object Map]"] =
          o["[object Number]"] =
          o["[object Object]"] =
          o["[object RegExp]"] =
          o["[object Set]"] =
          o["[object String]"] =
          o["[object WeakMap]"] =
            !1);
      const c = function (t) {
        return (
          (0, a.default)(t) &&
          (0, u.default)(t.length) &&
          !!o[(0, n.default)(t)]
        );
      };
      var f = r(899339),
        s = r(369899),
        i = s.default && s.default.isTypedArray;
      const d = i ? (0, f.default)(i) : c;
    },
    309080(t, e, r) {
      "use strict";
      r.d(e, { default: () => o });
      var n = r(820975),
        u = r(830875),
        a = r(392908);
      const o = function (t) {
        return (0, a.default)(t) ? (0, n.default)(t) : (0, u.default)(t);
      };
    },
    177655(t, e, r) {
      "use strict";
      r.d(e, { default: () => n });
      const n = function () {
        return [];
      };
    },
    406449(t, e, r) {
      "use strict";
      r.d(e, { default: () => p });
      var n = /\s/;
      const u = function (t) {
        for (var e = t.length; e-- && n.test(t.charAt(e)); );
        return e;
      };
      var a = /^\s+/;
      const o = function (t) {
        return t ? t.slice(0, u(t) + 1).replace(a, "") : t;
      };
      var c = r(880115),
        f = r(717332),
        s = /^[-+]0x[0-9a-f]+$/i,
        i = /^0b[01]+$/i,
        d = /^0o[0-7]+$/i,
        l = parseInt;
      const p = function (t) {
        if ("number" == typeof t) return t;
        if ((0, f.default)(t)) return NaN;
        if ((0, c.default)(t)) {
          var e = "function" == typeof t.valueOf ? t.valueOf() : t;
          t = (0, c.default)(e) ? e + "" : e;
        }
        if ("string" != typeof t) return 0 === t ? t : +t;
        t = o(t);
        var r = i.test(t);
        return r || d.test(t) ? l(t.slice(2), r ? 2 : 8) : s.test(t) ? NaN : +t;
      };
    },
  },
]);
