(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [66708],
  {
    296297(t) {
      t.exports = {
        "common-tooltip": "common-tooltip-Hp4KzOJw",
        "common-tooltip--hidden": "common-tooltip--hidden-Hp4KzOJw",
        "common-tooltip--horizontal": "common-tooltip--horizontal-Hp4KzOJw",
        "common-tooltip--farther": "common-tooltip--farther-Hp4KzOJw",
        "common-tooltip--vertical": "common-tooltip--vertical-Hp4KzOJw",
        "common-tooltip-farther": "common-tooltip-farther-Hp4KzOJw",
        "common-tooltip--direction_normal":
          "common-tooltip--direction_normal-Hp4KzOJw",
        "common-tooltip__body": "common-tooltip__body-Hp4KzOJw",
        "common-tooltip__button-container":
          "common-tooltip__button-container-Hp4KzOJw",
        "common-tooltip__body--no-buttons":
          "common-tooltip__body--no-buttons-Hp4KzOJw",
        "common-tooltip__button": "common-tooltip__button-Hp4KzOJw",
        "common-tooltip--direction_reversed":
          "common-tooltip--direction_reversed-Hp4KzOJw",
        "common-tooltip__ear-holder": "common-tooltip__ear-holder-Hp4KzOJw",
        "common-tooltip__ear-holder--below":
          "common-tooltip__ear-holder--below-Hp4KzOJw",
        "common-tooltip__ear-holder--above":
          "common-tooltip__ear-holder--above-Hp4KzOJw",
        "common-tooltip__ear-holder--before":
          "common-tooltip__ear-holder--before-Hp4KzOJw",
        "common-tooltip__ear-holder--after":
          "common-tooltip__ear-holder--after-Hp4KzOJw",
        "common-tooltip__body--with-hotkey":
          "common-tooltip__body--with-hotkey-Hp4KzOJw",
        "common-tooltip__body--width_wide":
          "common-tooltip__body--width_wide-Hp4KzOJw",
        "common-tooltip__body--width_narrow":
          "common-tooltip__body--width_narrow-Hp4KzOJw",
        "common-tooltip__body--no-padding":
          "common-tooltip__body--no-padding-Hp4KzOJw",
        "common-tooltip__hotkey-block": "common-tooltip__hotkey-block-Hp4KzOJw",
        "common-tooltip__hotkey-block--divider":
          "common-tooltip__hotkey-block--divider-Hp4KzOJw",
        "common-tooltip__hotkey-text": "common-tooltip__hotkey-text-Hp4KzOJw",
        "common-tooltip__hotkey-button":
          "common-tooltip__hotkey-button-Hp4KzOJw",
        "common-tooltip__plus-sign": "common-tooltip__plus-sign-Hp4KzOJw",
      };
    },
    556694(t, e, o) {
      "use strict";
      o.d(e, { getTooltipData: () => i, setTooltipData: () => n });
      const s = new WeakMap();
      function i(t, e) {
        const o = s.get(t);
        return o instanceof Function ? o(e) : o && o[e];
      }
      function n(t, e, o) {
        if (o instanceof Function) return void s.set(t, o);
        const i = s.get(t),
          n = void 0 === i || i instanceof Function ? {} : i;
        (n[e] = o), s.set(t, n);
      }
    },
    505513(t, e, o) {
      "use strict";
      o.d(e, { hotKeyDeserialize: () => i });
      var s = o(246759);
      function i(t) {
        return JSON.parse((0, s.decodeHTMLEntities)(t));
      }
    },
    356706(t, e, o) {
      "use strict";
      o.d(e, { empty: () => r, setTooltip: () => d });
      const s = "tooltip-root-element";
      let i;
      function n() {
        const t = document.getElementById(s);
        t
          ? (i = t)
          : ((i = document.createElement("div")),
            (i.id = s),
            document.body.appendChild(i));
      }
      function r() {
        i && (i.innerHTML = "");
      }
      function d(t) {
        r(), i || n(), i.appendChild(t);
      }
      "interactive" === document.readyState
        ? n()
        : document.addEventListener("DOMContentLoaded", n);
    },
    354701(t, e, o) {
      "use strict";
      o.d(e, {
        clearSchedule: () => r,
        scheduleHide: () => c,
        scheduleRemove: () => d,
        scheduleRender: () => a,
      });
      let s = 0,
        i = 0,
        n = 0;
      function r() {
        clearTimeout(s), clearTimeout(i), clearTimeout(n);
      }
      function d(t, e) {
        n = setTimeout(t, e);
      }
      function c(t, e) {
        i = setTimeout(t, e);
      }
      function a(t, e) {
        s = setTimeout(t, e);
      }
    },
    250280(t, e, o) {
      "use strict";
      o.d(e, { setTooltipColorTheme: () => n });
      const s = {
          default: "",
          white: "theme-white",
          chart: "theme-chart",
          news: "theme-news",
          "round-shadow": "theme-round-shadow",
        },
        i = Object.keys(s);
      function n(t, e) {
        const o = i.includes(e) ? s[e] : "";
        t.classList.remove(...i.map((t) => s[t]).filter((t) => !!t)),
          o && !t.classList.contains(o) && t.classList.add(o);
      }
    },
    272607(t, e, o) {
      "use strict";
      o.d(e, { ActionGroup: () => i });
      var s = o(517913);
      class i {
        add(t) {
          let e = this._actions.get(t.hotkey);
          e || ((e = []), this._actions.set(t.hotkey, e));
          const o = new s.Action(this, t);
          return e.push(o), o;
        }
        remove(t) {
          const e = this._actions.get(t.hotkey);
          if (!e) return;
          const o = e.findIndex((e) => e === t);
          o >= 0 &&
            (1 === e.length ? this._actions.delete(t.hotkey) : e.splice(o, 1));
        }
        handleHotkey(t, e) {
          const o = this._actions.get(t);
          if (!o) return !1;
          for (const s of o)
            if (
              (!s.element || (e.target && s.element.contains(e.target))) &&
              !s.isDisabled(e)
            )
              return (
                (e.repeat && !s.isRepeatAccepted) ||
                  (s.handler(e), this._callMatchedHotkeyHandler(t)),
                e.preventDefault(),
                !0
              );
          return !1;
        }
        promote() {
          this._manager.promoteGroup(this);
        }
        destroy() {
          for (const [, t] of this._actions) for (const e of t) e.destroy();
          this._actions.clear(), this._manager.unregisterGroup(this);
        }
        static setMatchedHotkeyHandler(t) {
          i._matchedHotkeyHandler = t;
        }
        _callMatchedHotkeyHandler(t) {
          i._matchedHotkeyHandler && i._matchedHotkeyHandler(t);
        }
        constructor(t, e) {
          (this._actions = new Map()),
            (this._manager = t),
            (this.order = e?.order ?? 0),
            (this.modal = !(!e || !e.modal)),
            e && (this.desc = e.desc),
            e && e.isDisabled
              ? "function" == typeof e.isDisabled
                ? (this.isDisabled = e.isDisabled)
                : (this.isDisabled = () => !0)
              : (this.isDisabled = () => !1),
            this._manager.registerGroup(this);
        }
      }
    },
    419087(t, e, o) {
      "use strict";
      o.d(e, { ActionManager: () => c });
      var s = o(140136),
        i = o(499490),
        n = o(201891),
        r = o(242206);
      class d extends s.WatchedValue {
        setValue(t, e) {
          const o = this.value();
          (e ||
            void 0 === o ||
            o.code !== t.code ||
            o.modifiers !== t.modifiers) &&
            super.setValue(t);
        }
      }
      class c {
        listen(t) {
          t.addEventListener("keydown", this._keyDownListener),
            t.addEventListener("keyup", this._keyUpListener),
            t.addEventListener("blur", this._blurEvent),
            t.addEventListener("mousemove", this._mouseEvent);
        }
        unlisten(t) {
          t.removeEventListener("keydown", this._keyDownListener),
            t.removeEventListener("keyup", this._keyUpListener),
            t.removeEventListener("blur", this._blurEvent),
            t.removeEventListener("mousemove", this._mouseEvent);
        }
        registerGroup(t) {
          this._groups.push(t), this.sortGroups();
        }
        unregisterGroup(t) {
          for (let e = this._groups.length; e--; )
            this._groups[e] === t && this._groups.splice(e, 1);
        }
        promoteGroup(t) {
          const e = this._getModalOrderEpoch(),
            o = a(t, e);
          let s = this._groups.findIndex((t) => a(t, e) === o),
            i = 0;
          for (; s < this._groups.length && a(this._groups[s], e) === o; ) {
            const n = this._groups[s];
            n === t ? (i = 1) : a(n, e) === o && (this._groups[s - i] = n), s++;
          }
          this._groups[s - i] = t;
        }
        pressedKeys() {
          return this._pressedKeys.readonly();
        }
        keyboardPressedKeysState() {
          return this._keyboardPressedKeysState.readonly();
        }
        sortGroups() {
          const t = this._getModalOrderEpoch();
          this._groups.sort((e, o) => a(o, t) - a(e, t));
        }
        _getMinOrder() {
          return this._groups.reduce((t, e) => Math.min(t, e.order), 0);
        }
        _getModalOrderEpoch() {
          return -2 * (Math.abs(this._getMinOrder()) - 1);
        }
        constructor() {
          (this._groups = []),
            (this._pressedKeys = new s.WatchedValue(0)),
            (this._keyboardPressedKeysState = new d(
              new r.KeyboardPressedKeysState(0)
            )),
            (this._keyDownListener = (t) => {
              if (t.defaultPrevented) return;
              const e = (0, i.hashFromEvent)(t);
              if (
                (this._pressedKeys.setValue(e),
                this._keyboardPressedKeysState.setValue(
                  new r.KeyboardPressedKeysState(
                    (0, i.modifiersFromEvent)(t),
                    t.code
                  )
                ),
                !(0, n.isNativeUIInteraction)(e, t.target))
              )
                for (let o = this._groups.length; o-- > 0; ) {
                  const s = this._groups[o];
                  if (!s.isDisabled()) {
                    if (s.handleHotkey(e, t)) return;
                    if (s.modal) return;
                  }
                }
            }),
            (this._keyUpListener = (t) => {
              const e = (0, i.hashFromEvent)(t);
              this._pressedKeys.setValue(e),
                this._keyboardPressedKeysState.setValue(
                  new r.KeyboardPressedKeysState(
                    (0, i.modifiersFromEvent)(t),
                    ""
                  )
                );
            }),
            (this._blurEvent = () => {
              this._pressedKeys.setValue(0),
                this._keyboardPressedKeysState.setValue(
                  new r.KeyboardPressedKeysState(0, "")
                );
            }),
            (this._mouseEvent = (t) => {
              const e = (0, i.modifiersFromEvent)(t),
                o = (this._pressedKeys.value() ?? 0) & i.Hardcode.KeyCode;
              this._pressedKeys.setValue(e | o);
            });
        }
      }
      function a(t, e) {
        return t.order + (t.modal ? e : 0);
      }
    },
    517913(t, e, o) {
      "use strict";
      o.d(e, { Action: () => s });
      class s {
        destroy() {
          this._group && (this._group.remove(this), (this._group = null));
        }
        constructor(t, e) {
          this._group = t;
          const {
            hotkey: o,
            handler: s,
            desc: i,
            isDisabled: n,
            element: r = null,
            isRepeatAccepted: d = !1,
          } = e;
          (this.hotkey = o),
            (this.handler = s),
            (this.desc = i),
            (this.element = r),
            (this.isRepeatAccepted = d),
            (this.isDisabled = n
              ? "function" == typeof n
                ? n
                : () => !0
              : () => !1);
        }
      }
    },
    52407(t, e, o) {
      "use strict";
      o.d(e, { createGroup: () => r });
      var s = o(419087),
        i = o(272607);
      const n = new s.ActionManager();
      n.pressedKeys(), n.keyboardPressedKeysState();
      function r(t) {
        return new i.ActionGroup(n, t);
      }
    },
    499490(t, e, o) {
      "use strict";
      o.d(e, {
        Hardcode: () => i,
        Modifiers: () => r,
        hashFromEvent: () => c,
        isMacKeyboard: () => n,
        modifiersFromEvent: () => d,
      });
      var s = o(467242),
        i = (function (t) {
          return (
            (t[(t.KeyCode = 255)] = "KeyCode"),
            (t[(t.Control = 256)] = "Control"),
            (t[(t.Alt = 512)] = "Alt"),
            (t[(t.Shift = 1024)] = "Shift"),
            (t[(t.Meta = 2048)] = "Meta"),
            t
          );
        })({});
      const n = s.isMac || s.isIOS;
      var r = (function (t) {
        return (
          (t[(t.None = 0)] = "None"),
          (t[(t.Alt = 512)] = "Alt"),
          (t[(t.Shift = 1024)] = "Shift"),
          (t[(t.Mod = n ? 2048 : 256)] = "Mod"),
          (t[(t.Control = 256)] = "Control"),
          (t[(t.Meta = 2048)] = "Meta"),
          t
        );
      })({});
      function d(t) {
        let e = 0;
        return (
          t.shiftKey && (e += 1024),
          t.altKey && (e += 512),
          t.ctrlKey && (e += 256),
          t.metaKey && (e += 2048),
          e
        );
      }
      function c(t) {
        return d(t) | t.keyCode;
      }
      const a = {
          9: "⇥",
          13: "↵",
          27: "Esc",
          8: n ? "⌫" : "Backspace",
          32: "Space",
          35: "End",
          36: "Home",
          37: "←",
          38: "↑",
          39: "→",
          40: "↓",
          45: "Ins",
          46: "Del",
          188: ",",
          190: "Dot",
          191: "/",
        },
        l = {
          9: "Tab",
          13: "Enter",
          27: "Esc",
          8: "Backspace",
          32: "Space",
          35: "End",
          36: "Home",
          37: "ArrowLeft",
          38: "ArrowUp",
          39: "ArrowRight",
          40: "ArrowDown",
          45: "Ins",
          46: "Del",
          188: ",",
          190: ".",
          191: "/",
        };
      for (let t = 1; t <= 16; t++)
        (a[t + 111] = `F${t}`), (l[t + 111] = `F${t}`);
    },
    242206(t, e, o) {
      "use strict";
      o.d(e, { KeyboardPressedKeysState: () => i });
      var s = o(499490);
      class i {
        altOrOptionCode() {
          return "AltLeft" === this.code || "AltRight" === this.code;
        }
        controlOrMetaCode() {
          return s.isMacKeyboard
            ? "MetaLeft" === this.code ||
                "MetaRight" === this.code ||
                "OSLeft" === this.code ||
                "OSRight" === this.code
            : "ControlLeft" === this.code || "ControlRight" === this.code;
        }
        constructor(t, e) {
          (this.modifiers = t), (this.code = e);
        }
      }
    },
  },
]);
