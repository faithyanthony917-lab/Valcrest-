(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [13870],
  {
    543404(e) {
      e.exports = {
        "css-value-copyright-transition-params":
          ".6s 0s cubic-bezier(.4, .01, .22, 1)",
        "css-value-copyright-transition-params-half-time":
          ".3s 0s cubic-bezier(.4, .01, .22, 1)",
        label: "label-rxNlaGOo",
        logoWrap: "logoWrap-rxNlaGOo",
        expandedWithTransition: "expandedWithTransition-rxNlaGOo",
        expandedByClick: "expandedByClick-rxNlaGOo",
        start: "start-rxNlaGOo",
        end: "end-rxNlaGOo",
        snap: "snap-rxNlaGOo",
        top: "top-rxNlaGOo",
        bottom: "bottom-rxNlaGOo",
        large: "large-rxNlaGOo",
        expanded: "expanded-rxNlaGOo",
        label__link: "label__link-rxNlaGOo",
      };
    },
    826406(e) {
      e.exports = {};
    },
    627293(e) {
      e.exports = {
        "css-value-ticker-widget-height": "94px",
        "css-value-ticker-widget-min-height": "150px",
      };
    },
    459986(e) {
      e.exports = {};
    },
    500542(e) {
      e.exports = {
        "tv-widget-single-ticker-loader":
          "tv-widget-single-ticker-loader-eSssuvfh",
      };
    },
    512243(e, t, n) {
      "use strict";
      var o = n(202580);
      n(940485), n(507553);
      function r(e) {
        return { status: "fulfilled", value: e };
      }
      function s(e) {
        return { status: "rejected", reason: e };
      }
      var i = n(771405),
        a = n(819511);
      const l = {
        whitelabel: !0,
        permissionOverrides: !0,
        linkCapturingAllowed: !0,
        symbol_search_default_exchange: !0,
        symbol_search_allowed_exchanges: !0,
      };
      function c(e, t = [], n) {
        return (function (e, t, n, o = [], r) {
          const s = n.slice(1),
            i = decodeURIComponent(s);
          let a = {};
          try {
            "" !== i &&
              ((a = JSON.parse(i)),
              void 0 !== r && r(e, a),
              Object.keys(a).forEach((e) => {
                (l[e] || o.includes(e)) && delete a[e];
              }));
          } catch (e) {
            (a = {}),
              console.warn("Hash params parsing error! Hash params ignored.");
          }
          const c = t.slice(1),
            u = t.includes("%") ? decodeURIComponent(c) : t,
            d = new URLSearchParams(u);
          let m = {};
          try {
            d.forEach((e, t) => {
              o.includes(t) || (m[t] = e);
            }),
              void 0 !== r && r(e, m);
          } catch (e) {
            (m = {}),
              console.warn(
                "Search query params parsing error! Search query params ignored."
              );
          }
          return Object.assign({}, e, a, m);
        })(e, location.search, location.hash, t, n);
      }
      var u = n(986061),
        d = n(383636),
        m = n(527323),
        h = n.n(m),
        p = n(146961),
        y = n(80365),
        g = n(933142),
        f = n(304635),
        v = n(714945),
        _ = n(430580),
        b = n(778738),
        S = n(517615);
      function w(e, t = "x") {
        let n = !1;
        return (
          ("x" !== t && "both" !== t) ||
            (n = n || e.offsetWidth < e.scrollWidth),
          ("y" !== t && "both" !== t) ||
            (n = n || e.offsetHeight < e.scrollHeight),
          n
        );
      }
      function C(e, t = "x") {
        for (const n of Array.from(e.children))
          if (n instanceof HTMLElement && (w(n, t) || C(n, t))) return !0;
        return !1;
      }
      function k(e) {
        let t = "x";
        return (
          e.matches(".apply-overflow-tooltip--direction_both")
            ? (t = "both")
            : e.matches(".apply-overflow-tooltip--direction_y") && (t = "y"),
          t
        );
      }
      function N(e) {
        const t = e.getAttribute("data-overflow-tooltip-html");
        if (t) return { type: "html", data: t };
        const n = e.getAttribute("data-overflow-tooltip-text");
        if (n) return { type: "text", data: n };
        if (e.matches?.(".apply-overflow-tooltip--allow-text")) {
          return { type: "text", data: e.textContent || "" };
        }
        const o = Array.from(e.childNodes)
          .reduce(
            (e, t) => (
              t.nodeType === Node.TEXT_NODE && e.push(t.textContent || ""), e
            ),
            []
          )
          .join("")
          .trim();
        return o ? { type: "text", data: o } : { type: "none" };
      }
      function E(e, t) {
        let n = !1;
        const o = e.children;
        for (let e = 0; e < o.length; e++) {
          const r = o[e];
          if (r instanceof HTMLElement && w(r, t)) {
            n = !0;
            break;
          }
        }
        return n;
      }
      function x(e) {
        const t = e.target;
        if (
          t instanceof HTMLElement &&
          (t.matches(".apply-overflow-tooltip-focus") ||
            t.querySelector(".apply-overflow-tooltip-focus"))
        ) {
          const e = t.matches(".apply-overflow-tooltip")
              ? t
              : t.querySelector(".apply-overflow-tooltip"),
            n = k(e);
          if (
            e.matches(".apply-overflow-tooltip--check-children-recursively")
          ) {
            if (!C(e, n)) return;
          } else if (e.matches(".apply-overflow-tooltip--check-children")) {
            if (!E(e, n)) return;
          } else if (!w(e, n)) return;
          (0, S.showOnElement)(t, { content: N(e) });
          const o = () => {
            (0, S.hide)(),
              t.removeEventListener("blur", o),
              t.removeEventListener("active-descendant-blur", o);
          };
          t.addEventListener("blur", o),
            t.addEventListener("active-descendant-blur", o);
        }
      }
      (0, i.whenDocumentReady)(() => {
        document.addEventListener(
          "mouseenter",
          (e) => {
            const t = e.target;
            if (
              t instanceof HTMLElement &&
              t.matches(".apply-overflow-tooltip")
            ) {
              const e = k(t);
              if (
                t.matches(".apply-overflow-tooltip--check-children-recursively")
              ) {
                if (!C(t, e)) return;
              } else if (t.matches(".apply-overflow-tooltip--check-children")) {
                if (!E(t, e)) return;
              } else if (!w(t, e)) return;
              (0, S.showOnElement)(t, { content: N(t) });
              const n = () => {
                (0, S.hide)(),
                  ["mouseleave", "mousedown"].forEach((e) =>
                    t.removeEventListener(e, n)
                  );
              };
              ["mouseleave", "mousedown"].forEach((e) =>
                t.addEventListener(e, n)
              );
            }
          },
          !0
        ),
          document.addEventListener("focus", x, !0),
          document.addEventListener("active-descendant-focus", x, !0);
      });
      var T = n(570071),
        L = n(334120),
        D = n(951536),
        P = n(805733);
      const I = (0, a.getLogger)("WidgetTicker");
      class M {
        render() {
          this._el.classList.add(this._getClass()),
            (this._el.innerHTML = this._getView()),
            this._setTitle(),
            this._setLink();
        }
        start() {
          this._isRunning || (this._startQuoteTicker(), (this._isRunning = !0));
        }
        stop() {
          this._isRunning && (this._stopQuoteTicker(), (this._isRunning = !1));
        }
        getElement() {
          return this._el;
        }
        changeSymbol(e) {
          const t = e.includes(":") ? { proName: e } : { shortName: e };
          (this._prevQuoteSymbol = this._getSymbolName()),
            (this._symbolData = t),
            this._setTitle(),
            this._setLink(),
            this.stop(),
            this.start();
        }
        quoteTicker() {
          return this._quoteTicker;
        }
        displayPlaceholderLetter() {
          this._renderSymbolLogo([], P.CircleLogoSize.XXXSmall);
        }
        _getElementClass(e) {
          return this._getClass() + "__" + e;
        }
        _getSymbolName() {
          return this._symbolData.proName || this._symbolData.shortName;
        }
        _renderSymbolLogo(e, t) {
          const n = this._el.querySelector(".js-header-icon"),
            o = 0 === e.length ? this._getPlaceholderLetter() : void 0;
          n && this._setSymbolLogoHtml(n, e, t, o);
        }
        _getPlaceholderLetter() {
          const e = this._symbolData.proName,
            t = e && e.split(":")[1];
          return (this._symbolData.title ||
            this._symbolData.description ||
            t ||
            "" ||
            " ")[0];
        }
        _setSymbolLogoHtml(e, t, n, o) {
          if (t.length > 0 || void 0 !== o) {
            const r = (0, D.getCircleLogoAnyHtml)({
              logoUrls: t,
              size: n,
              className: this._getElementClass("icon"),
              placeholderLetter: o,
            });
            e.innerHTML = r;
          } else e.innerHTML = "";
        }
        _setTitle() {
          const e = this._getElTitle();
          if (!e) return;
          const t =
              this._symbolData.title ||
              this._symbolData.description ||
              "" ||
              this._symbolData.shortName ||
              this._symbolData.proName ||
              "",
            n = (0, L.detectAutoDirection)(t);
          n && (e.dir = n), (e.textContent = t);
        }
        _setLink() {
          if (!(this._el instanceof HTMLAnchorElement)) return;
          const e = this._symbolData.linkPage;
          e && (this._el.href = e),
            this._options.isEmbedWidget &&
              ((this._el.target = "_blank"),
              (this._el.rel = "external noopener"));
        }
        _startQuoteTicker() {
          if (!this._quoteTicker) return void this._createQuoteTicker();
          const e = this._getSymbolName();
          this._prevQuoteSymbol !== e
            ? (this._destroyQuoteTicker(), this._createQuoteTicker())
            : this._quoteTicker.enable();
        }
        _stopQuoteTicker() {
          this._quoteTicker &&
            (this._quoteTicker.disable(), (this._quoteTickerComplete = null));
        }
        _createQuoteTicker() {
          const e = this._getSymbolName(),
            t = this._getTickerOptions(),
            n = t.initedHook,
            o = t.setStateHook;
          (this._quoteTickerComplete = null),
            (this._quoteTicker = this._options.createQuoteTicker(e, this._el, {
              noSuchSymbolHook: () => this.onError.fire("no_symbol"),
              permissionDeniedHook: () =>
                this.onError.fire("permission_denied"),
              ...t,
              initedHook: (...e) => {
                n?.(...e), this.onInit.fire(...e);
              },
              setStateHook: (e, t, n) => {
                o?.(e, t, n),
                  n &&
                    null === this._quoteTickerComplete &&
                    ((this._quoteTickerComplete = n), this.onComplete.fire());
              },
            }));
        }
        _destroyQuoteTicker() {
          this._stopQuoteTicker(), delete this._quoteTicker;
        }
        _getElTitle() {
          return this._el.querySelector(`.${this._getElementClass("title")}`);
        }
        constructor(e, t, n) {
          (this.onInit = new T.Delegate()),
            (this.onComplete = new T.Delegate()),
            (this.onError = new T.Delegate()),
            (this._quoteTickerComplete = null),
            (this._isRunning = !1),
            (this._prevQuoteSymbol = null),
            (this._el = t || document.createElement("a")),
            (this._symbolData = e),
            (this._options = n),
            (function (e) {
              const t = e;
              return (
                Boolean(e) &&
                ("string" == typeof t.proName || "string" == typeof t.shortName)
              );
            })(e)
              ? (this.render(), this.start())
              : I.logError("symbolData is not valid");
        }
      }
      var O = n(743618);
      n(459986);
      class R extends M {
        _getClass() {
          return "tv-ticker-item-last";
        }
        _getView() {
          const e = this._getElementClass("header"),
            t =
              (this._getElementClass("icon"),
              this._getElementClass("short-name")),
            n = this._getElementClass("title"),
            o = this._getElementClass("body"),
            r = this._getElementClass("last"),
            s = this._getElementClass("change-wrapper"),
            i =
              (this._getElementClass("change-direction"),
              this._getElementClass("change-percent")),
            a = this._getElementClass("change"),
            l = this._getElementClass("session-status"),
            c = this._getElementClass("update-mode"),
            u = this._getElementClass("range");
          return (
            `<div class="${e}"><div class="js-header-icon"></div><div class="${this._getElementClass(
              "name-wrapper"
            )}"><div class="${t}"><span class="js-symbol-short-name"></span><span class="${l}"><span class="js-symbol-session-status"></span></span></div><div class="${n} js-symbol-description-name"></div></div></div><div class="${o}"><span class="${r} js-symbol-last apply-overflow-tooltip"></span><span class="${c}"><span class="js-data-mode"></span></span><span class="${s} js-symbol-change-direction"><span class="${i} js-symbol-change-pt"></span>&nbsp<span class="${a} js-symbol-change"></span>` +
            (this._options.symbolRange
              ? `<span class="${u} js-symbol-range"></span>`
              : "") +
            "</span></div>"
          );
        }
        _getTickerOptions() {
          return {
            dontDyePrice: !0,
            signPositive: !1,
            signNegative: !1,
            changeInBrackets: !0,
            changeDirectionUpClass: `${this._getElementClass(
              "change-wrapper"
            )}--up`,
            changeDirectionDownClass: `${this._getElementClass(
              "change-wrapper"
            )}--down`,
            lastGrowingClass: this._options.notHighlightLast
              ? ""
              : `${this._getElementClass("last")}--growing`,
            lastFallingClass: this._options.notHighlightLast
              ? ""
              : `${this._getElementClass("last")}--falling`,
            sessionStatusClassSuffix: "--for-ticker-last",
            dataModeClassSuffix: "--for-ticker-last",
            showInvalidSymbolStatus: !0,
            setStateHook: (0, O.getLogoUrlsHook)((e) => {
              this._renderSymbolLogo(e, P.CircleLogoSize.XSmall);
            }),
            initedHook: () => {
              if (this._options.symbolRange) {
                const e = this._el.querySelector(".js-symbol-range");
                e && (e.textContent = this._options.symbolRange);
              }
            },
          };
        }
        _renderSymbolLogo(e, t) {
          const n = this._el.querySelector(".js-header-icon");
          n && this._setSymbolLogoHtml(n, e, t);
        }
        constructor(e, t, n) {
          super(e, t, n);
        }
      }
      var A = n(356656);
      var F = n(980136),
        H = n(444873),
        B = n(907738);
      var W = n(166447),
        j = n(164732);
      function $(e) {
        return (
          new Map([
            ["1D", d.t(null, void 0, n(614450))],
            ["1M", d.t(null, void 0, n(430333))],
            ["3M", d.t(null, void 0, n(44656))],
            ["12M", d.t(null, void 0, n(673523))],
            ["60M", d.t(null, void 0, n(878708))],
            ["120M", d.t(null, void 0, n(670568))],
            ["ALL", d.t(null, void 0, n(290787))],
            ["LASTSESSION", (0, j.daysStringLiteral)(1)],
          ]).get((0, W.getActualTimeFrame)(e)) || ""
        );
      }
      var q = n(425268),
        U = n(68647),
        z = n(511538),
        Q = n(344759),
        G = n(301510);
      let V = 0;
      var X = n(359239);
      class J {
        destroy() {
          this.stop(), this._isConnectedChartSession.destroy();
        }
        start() {
          0 !== this._status && this.stop(),
            (this._sessionDeferredPromise = (0, X.createDeferredPromise)());
          const e = this._seriesDataSource.instanceId();
          null !== e
            ? this._createStudyForSeries(e)
            : this._seriesDataSource
                .dataEvents()
                .created()
                .subscribe(this, this._createStudyForSeries.bind(this), !0),
            (this._status = 1);
        }
        stop() {
          null !== this._instanceID &&
            (this._chartSession.isConnected().value() &&
              this._chartSession.removeStudy(this._instanceID),
            (this._instanceID = null),
            this._sessionDeferredPromise.resolve()),
            this._seriesDataSource.dataEvents().created().unsubscribeAll(this),
            this._isConnectedChartSession.unsubscribe(),
            (this._status = 0);
        }
        completed() {
          return this._sessionDeferredPromise.promise;
        }
        isPostMarket(e) {
          return !!this._sessionsData?.postMarket?.has(e);
        }
        isPreMarket(e) {
          return !!this._sessionsData?.preMarket?.has(e);
        }
        isNightMarket(e) {
          return !!this._sessionsData?.nightMarket?.has(e);
        }
        _createStudyForSeries(e) {
          this._isConnectedChartSession &&
            this._isConnectedChartSession.unsubscribe(),
            this._isConnectedChartSession.when(() => {
              (this._instanceID = (V++, "st" + V)),
                this._chartSession.createStudy(
                  this._instanceID,
                  this._turnaround.next(),
                  e,
                  "Sessions@tv-basicstudies-187!",
                  {},
                  this._onMessage,
                  { id: "Sessions@tv-basicstudies" }
                );
            });
        }
        _onDataUpdate(e) {
          const { indexes: t, d: n } = e;
          if (!n) return;
          const o = JSON.parse(n),
            r =
              !0 === o.indexes_replace
                ? void 0
                : o.graphicsCmds?.create?.backgrounds;
          if (!r || "nochange" === t) return;
          const s = (e) => {
            const n = t[e];
            return n > G.UNPLOTTABLE_TIME_POINT_INDEX ? n : null;
          };
          this._sessionsData = r.reduce((e, { styleId: t, data: n }) => {
            const o = new Set();
            return (
              n.forEach(({ start: e, stop: t }) => {
                let n = s(e),
                  r = s(t);
                if (null !== n || null !== r) {
                  null === n && (n = r + -300), null === r && (r = n + 300);
                  for (let e = n; e <= r; e++) o.add(e);
                }
              }),
              (e[t] = o),
              e
            );
          }, {});
        }
        _checkTurnaround(e) {
          return (
            e === this._turnaround.current() ||
            e === this._seriesDataSource.turnaround() ||
            e ===
              `${this._seriesDataSource.turnaround()}_${this._turnaround.current()}`
          );
        }
        constructor(e, t) {
          (this._turnaround = new Z("st")),
            (this._instanceID = null),
            (this._sessionDeferredPromise = (0, X.createDeferredPromise)()),
            (this._sessionsData = null),
            (this._status = 0),
            (this._onMessage = (e) => {
              switch (e.method) {
                case "data_update": {
                  const { customId: t, turnaround: n, nonseries: o } = e.params;
                  if (t !== this._instanceID || !this._checkTurnaround(n) || !o)
                    return;
                  return void this._onDataUpdate(o);
                }
                case "study_completed":
                case "study_error":
                  return void this._sessionDeferredPromise.resolve();
              }
            }),
            (this._chartSession = e),
            (this._seriesDataSource = t),
            (this._isConnectedChartSession = this._chartSession
              .isConnected()
              .spawn());
        }
      }
      class Z {
        next() {
          return this._counter++, this._value();
        }
        current() {
          return this._value();
        }
        _value() {
          return `${this._prefix}${this._counter}`;
        }
        constructor(e) {
          (this._counter = 0), (this._prefix = e);
        }
      }
      class K extends Q.MiniChartPlot {
        destroy() {
          this._destroySessionStudyProvider(), super.destroy();
        }
        requestData() {
          super.requestData(), this._setupSessionsStudyProviderIfNeeded();
        }
        disconnect() {
          this._destroySessionStudyProvider(), super.disconnect();
        }
        _onSymbolResolved(e) {
          super._onSymbolResolved(e),
            this._isLastSessionInterval.value() &&
              !this._barBuilderLoader &&
              this._initBarBuilder(e);
        }
        async _onData(e, t) {
          await this._waitForReadyToCalculateSession(), super._onData(e, t);
        }
        async _onDataCompleted() {
          await this._waitForReadyToCalculateSession(),
            super._onDataCompleted();
        }
        _barIndexSession(e) {
          if (!this._isLastSessionInterval.value()) return;
          const t = this._barBuilderLoader?.get();
          if (t) {
            const n = this._miniChart.indexToTime(e);
            if (null !== n) return t.session(n);
          }
          return this._sessionsStudyProvider
            ? this._sessionsStudyProvider.isPreMarket(e)
              ? z.SessionPhase.Pre
              : this._sessionsStudyProvider.isPostMarket(e)
              ? z.SessionPhase.Post
              : this._sessionsStudyProvider.isNightMarket(e)
              ? z.SessionPhase.Night
              : z.SessionPhase.Regular
            : void 0;
        }
        _setupSessionsStudyProviderIfNeeded() {
          if (
            (this._destroySessionStudyProvider(),
            this._isLastSessionInterval.value())
          ) {
            const e = this._barBuilderLoader?.get();
            e ||
              ((this._sessionsStudyProvider = new J(
                this.chartSession(),
                this.seriesDataSource()
              )),
              this._sessionsStudyProvider.start());
          }
        }
        async _waitForReadyToCalculateSession() {
          const e = this._barBuilderLoader?.get();
          if (!e && this._isLastSessionInterval.value()) {
            (await Promise.race([
              this._sessionsStudyProvider?.completed(),
              this._initBarBuilder((0, p.ensureNotNull)(this.symbolInfo())),
            ])) === this._barBuilderLoader?.get() &&
              this._destroySessionStudyProvider();
          }
        }
        _destroySessionStudyProvider() {
          this._sessionsStudyProvider?.destroy(),
            (this._sessionsStudyProvider = null);
        }
        constructor(...e) {
          super(...e), (this._sessionsStudyProvider = null);
        }
      }
      class Y extends U.MiniChart {
        _getChartPlotClass() {
          return K;
        }
      }
      n(500542), n(826406);
      var ee = n(627293),
        te = n(969301);
      var ne = n(419082);
      const oe = parseInt(ee["css-value-ticker-widget-min-height"]),
        re = parseInt(ee["css-value-ticker-widget-height"]),
        se = {
          growingLineColor: (0, b.getHexColorByName)("color-minty-green-500"),
          growingTopColor: (0, v.applyAlpha)(
            (0, b.getHexColorByName)("color-minty-green-500"),
            0.1
          ),
          growingBottomColor: (0, v.applyAlpha)(
            (0, b.getHexColorByName)("color-minty-green-500"),
            0
          ),
          fallingLineColor: (0, b.getHexColorByName)("color-ripe-red-500"),
          fallingTopColor: (0, v.applyAlpha)(
            (0, b.getHexColorByName)("color-ripe-red-500"),
            0.1
          ),
          fallingBottomColor: (0, v.applyAlpha)(
            (0, b.getHexColorByName)("color-ripe-red-500"),
            0
          ),
        };
      function ie(e, t, o) {
        const r = `https://www.tradingview.com${(0, F.getSymbolPagePath)({
          proName: e,
        })}?utm_source=www.tradingview.com&utm_medium=widget&utm_campaign=chart&utm_term=${o}:${t}`;
        return d.t(
          null,
          {
            replace: {
              linkStart: `<a target="_blank" href="${r}">`,
              linkEnd: "</a>",
            },
          },
          n(114338)
        );
      }
      function ae(e) {
        switch (e.type) {
          case z.NoDataReason.NoData:
            return { message: d.t(null, void 0, n(5197)) };
          case z.NoDataReason.NoSuchSymbol:
            return { message: d.t(null, void 0, n(732776)) };
          case z.NoDataReason.IntradaySpreadError:
            return { message: d.t(null, void 0, n(751278)) };
          case z.NoDataReason.NoPermission:
            const t = (0, ne.unwrapSimpleSymbol)(
                (0, ne.decodeExtendedSymbol)(e.symbol)
              ),
              [o, r] = t.split(":");
            return { message: ie(t, o, r) };
        }
      }
      class le {
        changeSymbol(e, t) {
          (this._settings.symbol = e),
            (this._settings.subSession = t),
            this._initSignals(),
            this._setContainerLink(),
            this._ticker?.changeSymbol(e),
            this._chart?.changeSymbol({ symbol: e, session: t });
        }
        chart() {
          return this._chart;
        }
        ticker() {
          return this._ticker;
        }
        _initSignals() {
          let e = !1,
            t = Boolean(this._settings.chartOnly);
          const n = () => e && t && this._callbacks.onWidgetReady();
          this._emitter.on("chart-is-ready", () => {
            (e = !0), n();
          }),
            this._emitter.on("ticker-is-ready", () => {
              (t = !0), n();
            });
        }
        _initWidget() {
          const {
              colorTheme: e,
              isTransparent: t,
              height: n,
              autosize: o,
            } = this._settings,
            r = n > re ? n : re;
          if (
            (e && (0, _.setTheme)(e),
            this._setContainerLink(),
            this._initTickerWidget(),
            t
              ? (this._container.style.backgroundColor = "transparent")
              : this._widgetContainer.classList.add(
                  "tv-mini-symbol-overview__link"
                ),
            r >= oe || o || this._settings.chartOnly)
          ) {
            const e = (0, p.ensureNotNull)(
              this._container.querySelector("#mini-symbol-overview-chart")
            );
            this._initChartWidget(e);
          } else this._showWidget();
        }
        _setContainerLink() {
          const { symbol: e, largeChartUrl: t } = this._settings,
            n = c(this._settings),
            o = (function (e) {
              const { customUrl: t, utmInfo: n, path: o, typespecs: r } = e;
              let s,
                i,
                a = e.symbol;
              const l = (0, B.tokenize)(a);
              return (
                (0, B.isSpread)(l) &&
                  (a =
                    l.find((e) => e.type === B.TokenType.Symbol)?.value || a),
                a.includes(":") ? ([i, s] = a.split(":")) : (s = a),
                t
                  ? (0, H.makeTemplateSymbolUrl)(
                      t
                        .replace("{{shortName}}", "{tvsymbol}")
                        .replace("{{proName}}", "{tvprosymbol}")
                        .replace("{{symbol}}", "{tvsymbol}")
                        .replace("{{exchange}}", "{tvexchange}"),
                      { proName: a }
                    )
                  : (0, F.makeSymbolPageUrl)(
                      { shortName: s, exchange: i, typespecs: r },
                      n,
                      void 0,
                      o
                    )
              );
            })({ symbol: e, customUrl: t, utmInfo: (0, A.filterUtmInfo)(n) });
          this._widgetContainer.href = o;
        }
        _initTickerWidget() {
          if (this._settings.chartOnly) return;
          const e = (0, p.ensureNotNull)(
              this._container.querySelector("#mini-symbol-overview-ticker")
            ),
            t = { proName: this._settings.symbol };
          (this._ticker = new R(t, e, {
            createQuoteTicker: this._createQuoteTicker,
            isEmbedWidget: !0,
            notHighlightLast: this._settings.notHighlightLast,
            symbolRange: this._settings.showSymbolRange
              ? $(this._settings.dateRange || "")
              : void 0,
          })),
            this._ticker.onComplete.subscribe(null, () =>
              this._emitter.emit("ticker-is-ready")
            ),
            this._ticker.onError.subscribe(null, () =>
              this._callbacks.onNoData()
            );
        }
        _initChartWidget(e) {
          const {
              dateRange: t,
              trendLineColor: n,
              growingTrendLineColor: o,
              fallingTrendLineColor: r,
              lineWidth: s,
              underLineColor: i,
              underLineBottomColor: a,
              colorTheme: l,
              symbol: c,
              locale: u,
              noTimeScale: d,
              scalePosition: m,
              useLastSession: h = !0,
            } = this._settings,
            f = "dark" === l,
            v = (0, b.getHexColorByName)("color-cold-gray-900"),
            _ = (0, b.getHexColorByName)("color-cold-gray-200");
          let S, w;
          S = w = f
            ? (0, b.getHexColorByName)("color-cold-gray-650")
            : (0, b.getHexColorByName)("color-cold-gray-300");
          const C = {
            rightPriceScale: { visible: !1, entireTextOnly: !0 },
            leftPriceScale: { visible: !1, entireTextOnly: !0 },
          };
          switch (m) {
            case "left": {
              const { leftPriceScale: e } = C;
              e.visible = !0;
              break;
            }
            case "right": {
              const { rightPriceScale: e } = C;
              e.visible = !0;
              break;
            }
          }
          const k = {
            timeframe: {
              visible: !1,
              value: {
                type: y.TimeFrameType.PeriodBack,
                value: (0, W.getActualTimeFrame)(
                  h && "1D" === t ? "LASTSESSION" : t
                ),
              },
              options: (0, q.getMiniTimeFrameOptions)(h),
            },
            chartOptions: {
              chart: {
                grid: {
                  horzLines: { visible: !1 },
                  vertLines: { visible: !1 },
                },
                layout: {
                  fontSize: 12,
                  textColor: f ? _ : v,
                  fontFamily:
                    "-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif",
                  attributionLogo: !1,
                },
                localization: {
                  locale: (0, g.getIsoLanguageCodeFromLanguage)(u),
                },
                timeScale: { visible: !d, minBarSpacing: 0.1 },
                ...C,
              },
              series: {
                chartType: z.ChartType.Area,
                priceLineWidth: 2,
                lineColor: n ?? se.growingLineColor,
                fallingLineColor: r ?? n ?? se.fallingLineColor,
                growingLineColor: o ?? n ?? se.growingLineColor,
                lineWidth: s ?? 2,
                topColor: i ?? se.growingTopColor,
                bottomColor: a ?? se.growingBottomColor,
                growingTopColor: i ?? se.growingTopColor,
                growingBottomColor: a ?? se.growingBottomColor,
                fallingTopColor: i ?? se.fallingTopColor,
                fallingBottomColor: a ?? se.fallingBottomColor,
                premarketLineColor: S,
                postmarketLineColor: w,
                scaleMargins: { top: 0.01, bottom: 0.05 },
              },
              suppressTickMarks: { dayAndTimeTickMarkFixEnabled: !0 },
            },
            onFirstData: () => {
              this._showWidget(), this._emitter.emit("chart-is-ready");
            },
          };
          (this._chart = new Y(c, e, k)),
            this._chart
              .mainPlot()
              .noData()
              .subscribe((e) => {
                let t;
                switch (e) {
                  case z.NoDataReason.NoSuchSymbol:
                    t = { type: z.NoDataReason.NoSuchSymbol };
                    break;
                  case z.NoDataReason.IntradaySpreadError:
                    t = { type: z.NoDataReason.IntradaySpreadError };
                    break;
                  case z.NoDataReason.NoPermission:
                    t = {
                      type: z.NoDataReason.NoPermission,
                      symbol: (0, p.ensureNotNull)(this._chart)
                        .mainPlot()
                        .symbol(),
                    };
                    break;
                  case z.NoDataReason.NoData:
                  case z.NoDataReason.DataError:
                    t = { type: z.NoDataReason.NoData };
                    break;
                  default:
                    return;
                }
                this._showErrorMessage(t);
              });
        }
        _showWidget() {
          this._loader.classList.remove("i-loading"),
            this._widgetContainer.classList.remove(
              "tv-mini-symbol-overview__link--hidden"
            );
        }
        _showErrorMessage(e, t) {
          this._hideChart(),
            this._errorCardRenderer ||
              ((this._errorCardRenderer = new te.AsyncResourceWrapper(
                (async function () {
                  return new (await (async function () {
                    return (
                      await Promise.all([
                        n.e(96212),
                        n.e(20750),
                        n.e(61483),
                        n.e(91951),
                        n.e(28507),
                      ]).then(n.bind(n, 318065))
                    ).ErrorCardRenderer;
                  })())();
                })()
              )),
              this._errorCardRenderer.callFunction((e) => {
                const t = (0, p.ensureNotNull)(
                  this._container.querySelector("#mini-symbol-overview-chart")
                );
                t.appendChild(e.container),
                  t.classList.add("tv-mini-symbol-overview--visible"),
                  this._loader.classList.remove("i-loading"),
                  this._widgetContainer.classList.remove(
                    "tv-mini-symbol-overview__link--hidden"
                  );
              })),
            this._errorCardRenderer.callFunction((t) => {
              t.update({
                ...ae(e),
                icon: "ghost",
                backgroundColor: "transparent",
              });
            });
        }
        _hideChart() {
          (0, p.ensureNotNull)(
            this._container.querySelector("#mini-symbol-overview-chart")
          ).classList.add("tv-mini-symbol-overview--hidden"),
            this._chart?.destroy();
        }
        constructor(e, t, n, o) {
          (this._chart = null),
            (this._ticker = null),
            (this._emitter = new (h())()),
            (this._errorCardRenderer = null),
            (this._container = e),
            (this._settings = t),
            (this._callbacks = n),
            (this._createQuoteTicker = o.createQuoteTicker),
            this._container.appendChild(
              (0, f.parseHtml)(
                `<a class="tv-mini-symbol-overview__link tv-mini-symbol-overview__link--hidden js-link" target="_blank" rel="external noopener">\n\t\t\t${
                  t.chartOnly
                    ? ""
                    : '<div id="mini-symbol-overview-ticker" class="tv-mini-symbol-overview__ticker"></div>'
                }\n\t\t\t<div id="mini-symbol-overview-chart" class="tv-mini-symbol-overview__chart ${
                  t.chartOnly ? "tv-mini-symbol-overview__chartOnly" : ""
                }"></div>\n\t\t</a>`
              )
            ),
            (this._widgetContainer = (0, p.ensureNotNull)(
              this._container.querySelector(".js-link")
            )),
            (this._loader = (0, p.ensureNotNull)(
              this._container.querySelector(".js-loader")
            )),
            this._initSignals(),
            this._initWidget();
        }
      }
      var ce = n(952643),
        ue = n(744024),
        de = n(563946),
        me = n(498728),
        he = n(514154);
      const pe = { host: "_unknown", path: "" };
      function ye(e) {
        if (e)
          try {
            const t = new URL(e);
            return {
              host: t.hostname || t.host || "_unknown",
              path: t.pathname,
            };
          } catch {
            return;
          }
      }
      function ge() {
        return (
          ye(
            (function () {
              const e = (0, he.getInitDataField)("hashSettings")?.["page-uri"];
              if (e) return "https://" + e;
            })()
          ) ||
          ye(document.referrer) ||
          ye(location.ancestorOrigins?.[0]) ||
          pe
        );
      }
      var fe = n(869996);
      function ve(e, t, n) {
        const o = { name: e, frameElementId: t, data: n };
        window.parent.postMessage(o, "*");
      }
      var _e = (function (e) {
          return (
            (e.SetSymbol = "set-symbol"), (e.SetInterval = "set-interval"), e
          );
        })({}),
        be = (function (e) {
          return (
            (e.SymbolClick = "tv-widget-symbol-click"),
            (e.WidgetLoad = "tv-widget-load"),
            (e.WidgetReady = "tv-widget-ready"),
            (e.ResizeIframe = "tv-widget-resize-iframe"),
            (e.NoData = "tv-widget-no-data"),
            e
          );
        })({}),
        Se = n(298441);
      const we = (0, a.getLogger)("EmbedWidget.MiniSymbolOverview"),
        Ce = window.initData.widgetDefaults;
      const ke = c(Ce, [], function (e, t) {
          void 0 === t.underLineBottomColor &&
            void 0 !== t.underLineColor &&
            (t.underLineBottomColor = t.underLineColor);
        }),
        Ne = (0, A.filterUtmInfo)(ke);
      !(async function (e) {
        await new Promise((e) => setTimeout(e, 0)),
          (await (0, me.getUnboundTracker)())?.trackSelfDesc(
            "iglu:com.tradingview/widgets_without_websocket/jsonschema/1-0-0",
            { ...ge(), widget_id: e, event_name: "page_view" }
          );
      })(de.WidgetIdSnowplow.MiniSymbolOverview);
      try {
        (0, Se.trackWidgetLoadMetaInfo)({
          widget_id: de.WidgetId.MiniSymbolOverview,
          symbols: JSON.stringify([ke.symbol]),
          customer: ke.customer,
        });
      } catch {}
      Number.isNaN(Number(ke.height)) && (ke.height = Ce.height);
      const Ee = {
        onNoData: () => ve(be.NoData, ue.frameElementId, void 0),
        onWidgetReady: async () => {
          if (ke.considerImagesAtWidgetReady)
            try {
              await xe();
            } catch (e) {
              we.logError("Images loading error");
            }
          ve(be.WidgetReady, ue.frameElementId, void 0);
        },
      };
      (0, i.whenDocumentReady)(() => {
        const e = (0, p.ensureNotNull)(
            document.getElementById("mini-symbol-overview")
          ),
          t = new le(e, ke, Ee, { createQuoteTicker: u.createQuoteTicker });
        (window._exposed_miniSymbolOverviewWidget = t),
          (function (e, t) {
            function n(n) {
              n.data && n.data.name && n.data.name === e && t(n.data.data);
            }
            window.addEventListener("message", n, !1);
          })(_e.SetSymbol, (e) => t.changeSymbol(e.symbol, e.session)),
          (0, ce.createEmbedWidgetWrapper)(
            e,
            de.WidgetId.MiniSymbolOverview,
            Ne,
            {
              locale: ke.locale,
              customer: (0, o.embedWidgetCustomer)(),
              isWhiteLabel: window.initData.widgetDefaults.whitelabel,
              isSheriffDisabled:
                window.initData.widgetDefaults.isSheriffDisabled,
              copyrightOptions: {
                verticalPosition: fe.CopyrightPosition.Vertical.Top,
                mode: "small_old",
              },
            }
          ),
          ve(be.WidgetLoad, ue.frameElementId, void 0);
      });
      const xe = () =>
          new Promise(async (e, t) => {
            const n = [],
              o = [];
            var i;
            (
              await ((i = Array.from(document.images).map(Te)),
              Promise.all(Array.from(i, (e) => Promise.resolve(e).then(r, s))))
            ).forEach((e) => {
              "rejected" === e.status ? n.push(e.reason) : o.push(e.value);
            }),
              n.length ? t(n) : e(o);
          }),
        Te = (e) =>
          new Promise((t, n) => {
            if (e.complete) return void t(e);
            const o = () => {
                e.removeEventListener("load", r, !0),
                  e.removeEventListener("error", s, !0);
              },
              r = () => {
                o(), t(e);
              },
              s = (e) => {
                o(), n(e);
              };
            e.addEventListener("load", r, !0),
              e.addEventListener("error", s, !0);
          });
    },
    798438(e, t, n) {
      "use strict";
      function o(e, t = window) {
        const n = "theme-" + e,
          o = t.document.documentElement.classList;
        for (const e of Array.from(o))
          e.startsWith("theme-") && e !== n && o.remove(e);
        o.add(n), (t.document.documentElement.dataset.theme = e);
      }
      n.d(t, { applyTheme: () => o });
    },
    798975(e, t, n) {
      "use strict";
    },
    430580(e, t, n) {
      "use strict";
      n.d(t, { setTheme: () => i, watchedTheme: () => s });
      var o = n(140136),
        r = n(798438);
      const s = new o.WatchedValue();
      function i(e) {
        s.setValue(e);
      }
      s.subscribe((e) => {
        (0, r.applyTheme)(e, window);
      });
    },
    907738(e, t, n) {
      "use strict";
      n.d(t, { TokenType: () => s, isSpread: () => u, tokenize: () => l });
      var o = n(920621),
        r = n(39032),
        s = (function (e) {
          return (
            (e.Symbol = "symbol"),
            (e.IncompleteSymbol = "incompleteSymbol"),
            (e.Number = "number"),
            (e.IncompleteNumber = "incompleteNumber"),
            (e.SeparatorPrefix = "separatorPrefix"),
            (e.OpenBrace = "openBrace"),
            (e.CloseBrace = "closeBrace"),
            (e.Plus = "plus"),
            (e.Minus = "minus"),
            (e.Multiply = "multiply"),
            (e.Divide = "divide"),
            (e.Power = "power"),
            (e.Whitespace = "whitespace"),
            (e.Unparsed = "unparsed"),
            e
          );
        })({});
      const i =
          /(?:[^-+\/*^\s]'|[a-zA-Z0-9_\u0370-\u1FFF_\u2E80-\uFFFF])(?:[^-+\/*^\s]'|[a-zA-Z0-9_\u0020\u0370-\u1FFF_\u2E80-\uFFFF_!|:.&])*|'.+?'/,
        a = (
          e = (0, r.isFeatureEnabled)(
            "allow_trailing_whitespace_in_number_token"
          )
        ) => ({
          number: e
            ? /\d+(?:\.\d*|(?![a-zA-Z0-9_!:.&]))(?:\s*(?=\s*$))?|\.\d+(?:\s*(?=\s*$))?/
            : /\d+(?:\.\d*|(?![a-zA-Z0-9_!:.&]))|\.\d+/,
          incompleteNumber: /\./,
          symbol: i,
          incompleteSymbol: /'[^']*/,
          separatorPrefix: o.SEPARATOR_PREFIX,
          openBrace: "(",
          closeBrace: ")",
          plus: "+",
          minus: "-",
          multiply: "*",
          divide: "/",
          power: "^",
          whitespace: /[\0-\x20\s]+/,
          unparsed: null,
        });
      function l(e, t = a()) {
        if (!e) return [];
        const n = [],
          o = Object.keys(t);
        let r;
        const s = ((e = a()) =>
          new RegExp(
            Object.values(e)
              .map((e) => {
                return null === e
                  ? ""
                  : `(${
                      "string" == typeof e
                        ? ((t = e), t.replace(/[\^$()[\]{}*+?|\\]/g, "\\$&"))
                        : e.source
                    })`;
                var t;
              })
              .filter((e) => "" !== e)
              .concat(".")
              .join("|"),
            "g"
          ))(t);
        for (; (r = s.exec(e)); ) {
          let e = !1;
          for (let t = o.length; t--; )
            if (r[t + 1]) {
              o[t] &&
                n.push({
                  value: r[t + 1],
                  type: o[t],
                  precedence: 0,
                  offset: r.index,
                }),
                (e = !0);
              break;
            }
          e ||
            n.push({
              value: r[0],
              type: "unparsed",
              precedence: 0,
              offset: r.index,
            });
        }
        return n;
      }
      function c(e) {
        return (
          "plus" === e ||
          "minus" === e ||
          "multiply" === e ||
          "divide" === e ||
          "power" === e
        );
      }
      function u(e) {
        return e.length > 1 && e.some((e) => c(e.type));
      }
    },
    563946(e, t, n) {
      "use strict";
      n.d(t, { WidgetId: () => o, WidgetIdSnowplow: () => r });
      var o = (function (e) {
          return (
            (e.AdvancedChart = "advanced-chart"),
            (e.TechnicalAnalysis = "technical-analysis"),
            (e.MarketOverview = "market-overview"),
            (e.MarketQuotes = "market-quotes"),
            (e.Hotlists = "hotlists"),
            (e.EconomicCalendar = "events"),
            (e.Ticker = "tickers"),
            (e.TickerTape = "ticker-tape"),
            (e.SingleQuote = "single-quote"),
            (e.MiniSymbolOverview = "mini-symbol-overview"),
            (e.SymbolOverview = "symbol-overview"),
            (e.SymbolInfo = "symbol-info"),
            (e.ForexCrossRates = "forex-cross-rates"),
            (e.ForexHeatMap = "forex-heat-map"),
            (e.Screener = "screener"),
            (e.CryptoMktScreener = "crypto-mkt-screener"),
            (e.Financials = "financials"),
            (e.SymbolProfile = "symbol-profile"),
            (e.TimelineWidget = "timeline"),
            (e.StockHeatmap = "stock-heatmap"),
            (e.CryptoCoinsHeatmap = "crypto-coins-heatmap"),
            (e.EtfHeatmap = "etf-heatmap"),
            e
          );
        })({}),
        r = (function (e) {
          return (
            (e.EconomicCalendar = "events"),
            (e.Screener = "forexscreener"),
            (e.CryptoMktScreener = "cryptomktscreener"),
            (e.SymbolProfile = "symbol-profile"),
            (e.TimelineWidget = "timeline"),
            (e.MiniSymbolOverview = "mini-symbol-overview"),
            e
          );
        })({});
    },
    869996(e, t, n) {
      "use strict";
      n.d(t, { CopyrightPosition: () => o, copyrightLabel: () => u });
      var o,
        r = n(383636),
        s = n(914487),
        i = n.n(s),
        a = n(881014),
        l = n(683325),
        c = n(543404);
      function u({
        svgText: e,
        icon: t,
        theme: s,
        url: u,
        mode: d,
        verticalPosition: m = o.Vertical.Bottom,
        horizontalPosition: h = o.Horizontal.End,
        snapToEdge: p = !0,
        isExpanded: y = !1,
        className: g,
      }) {
        let f;
        switch (d) {
          case "new":
          case "with_border":
          case "large_trade":
            f = (0, a.clone)(s);
            break;
          default:
            f = (0, l.mergeThemes)((0, a.clone)(c), s);
        }
        const v = document.createElement("span");
        let _;
        u &&
          ((_ = document.createElement("a")),
          _.classList.add(...f.label__link.split(/\s/)),
          (_.href = u),
          (_.target = "_blank"),
          (_.rel = "noopener noreferrer"),
          _.setAttribute("data-target-type", "copyright"),
          (_.ariaLabel = r.t(null, void 0, n(517859))),
          v.append(_)),
          (v.className = i()(
            f.label,
            h === o.Horizontal.Start && f.start,
            h === o.Horizontal.End && f.end,
            m === o.Vertical.Top && f.top,
            m === o.Vertical.Bottom && f.bottom,
            p && "large_trade" !== d && f.snap,
            "large_old" === d && f.large,
            (y || "large_trade" === d) && f.expanded,
            g,
            "js-copyright-label"
          )),
          v.addEventListener("click", () => {
            function e() {
              v.classList.remove(f.expandedByClick),
                v.removeEventListener("mouseleave", e);
            }
            v.classList.contains(f.expandedWithTransition) ||
              v.classList.contains(f.expanded) ||
              (v.classList.contains(f.expandedByClick)
                ? u || e()
                : (v.classList.add(f.expandedByClick),
                  v.addEventListener("mouseleave", e)));
          });
        const b = document.createElement("span");
        (b.className = f.logoWrap), (b.innerHTML = t);
        const S = document.createElement("span");
        return (
          (S.className = f.svgTextWrap),
          (S.innerHTML = e),
          v.append(b, S),
          [v, f]
        );
      }
      !(function (e) {
        var t, n;
        ((t = e.Vertical || (e.Vertical = {}))[(t.Bottom = 0)] = "Bottom"),
          (t[(t.Top = 1)] = "Top"),
          ((n = e.Horizontal || (e.Horizontal = {}))[(n.Start = 0)] = "Start"),
          (n[(n.End = 1)] = "End");
      })(o || (o = {}));
    },
    403334(e, t, n) {
      "use strict";
      function o(e) {
        e.preventDefault();
      }
      n.d(t, { preventDefault: () => o });
    },
    517615(e, t, n) {
      "use strict";
      n.d(t, { hide: () => f, showOnElement: () => h });
      var o = n(467242),
        r = n(146961),
        s = n(52407),
        i = n(354701),
        a = n(356706),
        l = n(527048);
      let c = !1,
        u = null,
        d = null;
      o.mobiletouch ||
        (document.addEventListener("mouseover", y, !0),
        document.addEventListener(
          "focus",
          function (e) {
            const t = e.target;
            if (
              !(
                t instanceof HTMLElement &&
                t.closest('[data-tooltip-show-on-focus="true"]') &&
                t.matches(":focus-visible")
              )
            )
              return;
            y(e, !0);
          },
          { capture: !0 }
        ),
        document.addEventListener(
          "active-descendant-focus",
          function (e) {
            e.target instanceof HTMLElement && y(e, !0);
          },
          { capture: !0 }
        ));
      const m = new MutationObserver(() => {
          if (u && u.options.target) {
            let e;
            (e =
              "isConnected" in u.options.target
                ? u.options.target.isConnected
                : document.body.contains(u.options.target)),
              e || f();
          }
        }),
        h = (e, t = {}) => {
          const { content: n, ...o } = b(t),
            r = l.getDataFromTarget(e),
            s = Object.assign(r, o);
          return (
            "none" !== n.type && (s.content = n),
            !("none" === s.content.type && !s.hotkey) &&
              ((s.target = e), p(s), !0)
          );
        },
        p = (e) => {
          const t = b(e),
            n = l.getTooltip(t);
          if (
            ((u = { options: t, element: n }),
            (0, a.setTooltip)(n),
            (0, i.clearSchedule)(),
            !c)
          )
            return (
              l.hideTooltip(n),
              void (0, i.scheduleRender)(
                () => v(n),
                (function (e) {
                  return "number" != typeof e.tooltipDelay ||
                    isNaN(e.tooltipDelay)
                    ? 500
                    : e.tooltipDelay;
                })(t)
              )
            );
          const { tooltipDebounce: o } = e;
          "number" != typeof o || isNaN(o)
            ? v(n)
            : (0, i.scheduleRender)(() => v(n), o);
        };
      function y(e, t) {
        if ("sourceCapabilities" in e && e.sourceCapabilities?.firesTouchEvents)
          return;
        const n = (function (e, t, n) {
          const o = [];
          for (; e && e !== t; )
            e.classList && e.classList.contains(n) && o.push(e),
              (e = e.parentElement || _(e.parentNode));
          return o;
        })(e.target, e.currentTarget, "apply-common-tooltip");
        for (const o of n) {
          if (e instanceof MouseEvent)
            if ("buttons" in e) {
              if (1 & e.buttons) continue;
            } else if (1 === e.which) continue;
          const n = () => h(o);
          if (n()) {
            const e = (e) => r(null, !0),
              r = (s, i = !1) => {
                o.removeEventListener("common-tooltip-update", n),
                  o.removeEventListener("mouseleave", r),
                  o.removeEventListener("mousedown", r),
                  document.removeEventListener("scroll", e, { capture: !0 }),
                  t &&
                    (o.removeEventListener("blur", r),
                    o.removeEventListener("active-descendant-blur", r)),
                  d && (d.destroy(), (d = null)),
                  f(i);
              };
            o.addEventListener("common-tooltip-update", n),
              o.addEventListener("mouseleave", r),
              o.addEventListener("mousedown", r),
              document.addEventListener("scroll", e, { capture: !0 }),
              t &&
                (o.addEventListener("blur", r),
                o.addEventListener("active-descendant-blur", r)),
              null === d &&
                ((d = (0, s.createGroup)({ desc: "Tooltip" })),
                d.add({ desc: "Hide", hotkey: 27, handler: r }));
            break;
          }
        }
      }
      function g() {
        (0, a.empty)(), (c = !1), (u = null);
      }
      const f = (e, t) => {
        if (((0, i.clearSchedule)(), (0, r.ensureNotNull)(m).disconnect(), !u))
          return;
        if (!e && !c) return;
        const { element: n, options: o } = u,
          s = () => {
            n.removeEventListener("mouseleave", s),
              l.hideTooltip(n),
              e
                ? g()
                : (0, i.scheduleRemove)(() => {
                    g();
                  }, 250),
              t?.();
          };
        o.tooltipHideDelay
          ? (0, i.scheduleHide)(() => {
              n.querySelector(":hover")
                ? n.addEventListener("mouseleave", s)
                : s();
            }, o.tooltipHideDelay)
          : s();
      };
      function v(e) {
        const { options: t } = (0, r.ensureNotNull)(u);
        if (
          (l.setStyle(e, t),
          l.showTooltip(e),
          (0, r.ensureNotNull)(m).observe(document, {
            childList: !0,
            subtree: !0,
          }),
          (c = !0),
          t.forceHideOnMove)
        ) {
          const e = () => {
            document.removeEventListener("mousemove", e),
              document.removeEventListener("touchmove", e),
              f();
          };
          document.addEventListener("mousemove", e),
            document.addEventListener("touchmove", e);
        }
      }
      function _(e) {
        return e && (e.nodeType === Node.ELEMENT_NODE ? e : null);
      }
      function b(e) {
        if (
          (function (e) {
            return "content" in e;
          })(e)
        )
          return e;
        const { inner: t, html: n, text: o, ...r } = e;
        let s = { type: "none" };
        return (
          t && (s = { type: "element", data: t }),
          o && (s = { type: n ? "html" : "text", data: o }),
          { content: s, ...r }
        );
      }
    },
    966193(e, t, n) {
      "use strict";
      n.d(t, { guid: () => r, randomHash: () => s });
      const o =
        "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
      function r() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (e) => {
          const t = (16 * Math.random()) | 0;
          return ("x" === e ? t : (3 & t) | 8).toString(16);
        });
      }
      function s() {
        return (function (e) {
          let t = "";
          for (let n = 0; n < e; ++n) {
            const e = Math.floor(62 * Math.random());
            t += o[e];
          }
          return t;
        })(12);
      }
    },
    304635(e, t, n) {
      "use strict";
      n.d(t, { parseHtml: () => r, parseHtmlElement: () => s });
      const o = new WeakMap();
      function r(e, t) {
        let n, r;
        return (
          (n =
            null == t
              ? document.documentElement
              : 9 === t.nodeType
              ? t.documentElement
              : t),
          o && (r = o.get(n)),
          r ||
            ((r = n.ownerDocument.createRange()),
            r.selectNodeContents(n),
            o && o.set(n, r)),
          r.createContextualFragment(e)
        );
      }
      function s(e, t) {
        const n = r(e, t),
          o = n.firstElementChild;
        return null !== o && n.removeChild(o), o;
      }
    },
    334120(e, t, n) {
      "use strict";
      n.d(t, {
        detectAutoDirection: () => h,
        forceLTRStr: () => u,
        isRtl: () => s,
        setDocumentDirGetter: () => r,
        stripLTRMarks: () => c,
      });
      n(320403);
      let o = () => null;
      function r(e) {
        o = e;
      }
      const s = () =>
          "rtl" ===
          (function () {
            const e = o();
            if (null === e)
              throw new Error(
                "Document direction getter is not set, call setDocumentDirGetter to set it"
              );
            return e;
          })(),
        i = "‪",
        a = "‬",
        l = new RegExp("‎|‏|‪|‫|‬", "g");
      function c(e) {
        return "" !== e && s() && null != e ? e.replace(l, "") : e;
      }
      function u(e) {
        return "" !== e && s() && null != e ? i + e + a : e;
      }
      const d =
          /[^\u0000-\u0040\u005B-\u0060\u007B-\u00BF\u00D7\u00F7\u02B9-\u02FF\u2000-\u200E\u2010-\u2029\u202C\u202F-\u2BFF]/,
        m = /[\u0590-\u07FF\u200F\u202B\u202E\uFB1D-\uFDFD\uFE70-\uFEFC]/;
      function h(e) {
        const t = d.exec(e);
        return t ? (m.test(t[0]) ? "rtl" : "ltr") : "";
      }
    },
    881014(e, t, n) {
      "use strict";
      n.d(t, {
        clone: () => r,
        deepEquals: () => l,
        hasProperty: () => i,
        isArray: () => c,
        isInteger: () => d,
        isNaN: () => u,
        isNumber: () => o,
        isObject: () => s,
        isString: () => m,
        notNull: () => h,
      });
      new Set(["__proto__", "prototype", "constructor"]);
      function o(e) {
        return "number" == typeof e && isFinite(e);
      }
      function r(e) {
        if (!e || "object" != typeof e) return e;
        let t;
        t = Array.isArray(e) ? [] : {};
        for (const n in e)
          if (e.hasOwnProperty(n)) {
            const o = e[n];
            t[n] = o && "object" == typeof o ? r(o) : o;
          }
        return t;
      }
      function s(e) {
        return "object" == typeof e && null !== e;
      }
      function i(e, t) {
        return t in e;
      }
      function a(e) {
        return (
          null != e &&
          (e.constructor === Function ||
            "[object Function]" === Object.prototype.toString.call(e))
        );
      }
      function l(e, t, n = "") {
        if (e === t) return [!0, n];
        if (
          (a(e) && (e = void 0), a(t) && (t = void 0), null == e || null == t)
        )
          return [e === t, n];
        if ("object" != typeof e && "object" != typeof t) return [e === t, n];
        if (Array.isArray(e) && Array.isArray(t)) {
          const o = e.length;
          if (o !== t.length) return [!1, n];
          for (let r = 0; r < o; r++) {
            const o = l(e[r], t[r], n + "[" + r + "]");
            if (!o[0]) return o;
          }
          return [!0, n];
        }
        if (Array.isArray(e) || Array.isArray(t)) return [!1, n];
        if (Object.keys(e).length !== Object.keys(t).length) return [!1, n];
        for (const o in e) {
          const r = l(e[o], t[o], n + "[" + o + "]");
          if (!r[0]) return r;
        }
        return [!0, n];
      }
      const c =
        Array.isArray ||
        function (e) {
          return "[object Array]" === Object.prototype.toString.call(e);
        };
      function u(e) {
        return !(e <= 0 || e > 0);
      }
      function d(e) {
        return "number" == typeof e && e % 1 == 0;
      }
      function m(e) {
        return null != e && e.constructor === String;
      }
      function h(e) {
        return null !== e;
      }
      Number.isNaN =
        Number.isNaN ||
        function (e) {
          return e != e;
        };
    },
    714945(e, t, n) {
      "use strict";
      n.d(t, {
        applyAlpha: () => r,
        applyTransparency: () => i,
        resetTransparency: () => a,
      });
      var o = n(378305);
      function r(e, t, n) {
        const r = (0, o.tryParseRgba)(e);
        if (null === r) throw new Error(`Invalid color: ${e}`);
        const [s, i, a, l] = r,
          c = (0, o.normalizeAlphaComponent)(t * (n ? l : 1));
        return (0, o.rgbaToString)((0, o.rgba)([s, i, a], c));
      }
      function s(e) {
        if (e < 0 || e > 100) throw new Error("invalid transparency");
        return 1 - e / 100;
      }
      function i(e, t) {
        if ("transparent" === e) return e;
        const n = (0, o.parseRgba)(e),
          r = n[3];
        return (0, o.rgbaToString)((0, o.rgba)(n[0], n[1], n[2], s(t) * r));
      }
      function a(e) {
        return "transparent" === e
          ? e
          : l(e)
          ? e.slice(0, 7)
          : (0, o.rgbaToString)(
              (0, o.rgba)((0, o.parseRgb)(e), (0, o.normalizeAlphaComponent)(1))
            );
      }
      function l(e) {
        return 0 === e.indexOf("#");
      }
    },
    378305(e, t, n) {
      "use strict";
      n.d(t, {
        normalizeAlphaComponent: () => u,
        parseRgb: () => f,
        parseRgba: () => _,
        rgba: () => d,
        rgbaToString: () => g,
        tryParseRgba: () => v,
      });
      var o = n(881014),
        r = n(358237);
      function s(e, t, n) {
        return (0, o.isNaN)(t) || t < e ? e : t > n ? n : Math.round(t);
      }
      function i(e, t, n) {
        return (0, o.isNaN)(t) || t < e
          ? e
          : t > n
          ? n
          : Math.round(1e4 * t) / 1e4;
      }
      function a(e) {
        return s(0, e, 255);
      }
      function l(e) {
        return s(0, e, 255);
      }
      function c(e) {
        return s(0, e, 255);
      }
      function u(e) {
        return i(0, e, 1);
      }
      function d(e, t, n, o) {
        if (Array.isArray(e)) {
          const n = e;
          return (o = t), [n[0], n[1], n[2], u(o)];
        }
        {
          const r = t;
          return (n = n || 0), (o = o || 0), [a(e), l(r), c(n), u(o)];
        }
      }
      function m(e) {
        const t = b.re.exec(e);
        return null !== t ? b.parse(t) : null;
      }
      function h(e) {
        const t = S.re.exec(e);
        return null !== t ? S.parse(t) : null;
      }
      function p(e) {
        const t = w.re.exec(e);
        return null !== t ? w.parse(t) : null;
      }
      function y(e) {
        const t = C.re.exec(e);
        return null !== t ? C.parse(t) : null;
      }
      function g(e) {
        const [t, n, o, r] = e;
        return `rgba(${t}, ${n}, ${o}, ${r})`;
      }
      function f(e) {
        const t = (function (e) {
          e = e.toLowerCase();
          const t = (0, r.tryParseNamedRgba)(e);
          if (null !== t) {
            const [e, n, o] = t;
            return [e, n, o];
          }
          const n = m(e);
          if (null !== n) return n;
          const o = h(e);
          if (null !== o) return o;
          const s = p(e);
          if (null !== s) return s;
          const i = y(e);
          if (null !== i) {
            const [e, t, n] = i;
            return [e, t, n];
          }
          return null;
        })(e);
        if (null !== t) return t;
        throw new Error(
          "Passed color string does not match any of the known color representations"
        );
      }
      function v(e) {
        e = e.toLowerCase();
        const t = (0, r.tryParseNamedRgba)(e);
        if (null !== t) return t;
        const n = m(e);
        if (null !== n) {
          const [e, t, o] = n;
          return [e, t, o, 1];
        }
        const o = h(e);
        if (null !== o) {
          const [e, t, n] = o;
          return [e, t, n, 1];
        }
        const s = p(e);
        if (null !== s) {
          const [e, t, n] = s;
          return [e, t, n, 1];
        }
        const i = y(e);
        return null !== i ? i : null;
      }
      function _(e) {
        const t = v(e);
        if (null !== t) return t;
        throw new Error(
          "Passed color string does not match any of the known color representations"
        );
      }
      var b, S, w, C;
      !(function (e) {
        (e.re =
          /^rgb\(\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*\)$/),
          (e.parse = function (e) {
            return [
              a(parseInt(e[1], 10)),
              l(parseInt(e[2], 10)),
              c(parseInt(e[3], 10)),
            ];
          });
      })(b || (b = {})),
        (function (e) {
          (e.re = /^#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/),
            (e.parse = function (e) {
              return [
                a(parseInt(e[1], 16)),
                l(parseInt(e[2], 16)),
                c(parseInt(e[3], 16)),
              ];
            });
        })(S || (S = {})),
        (function (e) {
          (e.re = /^#([0-9a-fA-F])([0-9a-fA-F])([0-9a-fA-F])$/),
            (e.parse = function (e) {
              return [
                a(parseInt(e[1] + e[1], 16)),
                l(parseInt(e[2] + e[2], 16)),
                c(parseInt(e[3] + e[3], 16)),
              ];
            });
        })(w || (w = {})),
        (function (e) {
          (e.re =
            /^rgba\(\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?[\d]{0,10}(?:\.\d+)?)\s*\)$/),
            (e.parse = function (e) {
              return [
                a(parseInt(e[1], 10)),
                l(parseInt(e[2], 10)),
                c(parseInt(e[3], 10)),
                u(parseFloat(e[4])),
              ];
            });
        })(C || (C = {}));
    },
    201891(e, t, n) {
      "use strict";
      n.d(t, { isNativeUIInteraction: () => s });
      var o = n(499490);
      function r(e) {
        if ("INPUT" === e.tagName) {
          const t = e.type;
          return (
            "text" === t ||
            "email" === t ||
            "number" === t ||
            "password" === t ||
            "search" === t ||
            "tel" === t ||
            "url" === t
          );
        }
        return "TEXTAREA" === e.tagName || e.isContentEditable;
      }
      function s(e, t) {
        if (!t) return !1;
        const n = 255 & e;
        if (27 === n || n >>> 4 == 7) return !1;
        switch (e ^ n) {
          case o.Modifiers.Alt:
            return ((38 === n || 40 === n) && "SELECT" === t.tagName) || r(t);
          case o.Modifiers.Alt + o.Modifiers.Shift:
            return r(t);
          case o.Modifiers.Mod:
            if (67 === n || (!o.isMacKeyboard && 45 === n)) {
              const e = t.ownerDocument && t.ownerDocument.getSelection();
              if (e && !e.isCollapsed) return !0;
            }
            return r(t);
          case o.Modifiers.Mod + o.Modifiers.Shift:
            return n >= 33 && n <= 40 && r(t);
          case o.Modifiers.Shift:
          case 0:
            return 9 === n
              ? !(
                  !t.ownerDocument ||
                  t === t.ownerDocument.body ||
                  t === t.ownerDocument.documentElement
                )
              : (!(function (e) {
                  if ("BUTTON" === e.tagName) return !0;
                  if ("INPUT" === e.tagName) {
                    const t = e.type;
                    if (
                      "submit" === t ||
                      "button" === t ||
                      "reset" === t ||
                      "checkbox" === t ||
                      "radio" === t
                    )
                      return !0;
                  }
                  return !1;
                })(t) ||
                  13 === n ||
                  32 === n ||
                  9 === n) &&
                  ("form" in t || t.isContentEditable);
        }
        return !1;
      }
    },
    778738(e, t, n) {
      "use strict";
      n.d(t, { colorsPalette: () => d, getHexColorByName: () => m });
      var o = n(317663),
        r = n(867522),
        s = n(146961);
      const i = { ...o, ...r },
        a = {},
        l = Object.keys(i).length,
        c = /^#(([a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i;
      function u(e, t = [], n = i) {
        const o = n[e];
        if (!o) return null;
        if (c.test(o)) return o;
        const r = o;
        return (
          t.push(e),
          -1 !== t.indexOf(r)
            ? (console.warn("Colors definitions cycled"), o)
            : t.length > l
            ? (console.warn(
                "Too many variables-link in HEX-color search: " + t[0]
              ),
              null)
            : u(r, t, n)
        );
      }
      Object.keys(i).forEach((e) => {
        const t = u(e);
        a[e] = (0, s.ensureNotNull)(t);
      });
      const d = a;
      function m(e, t = d) {
        const n = t[e];
        if (!n) {
          if (c.test(e)) return e;
          throw new Error("No such color " + e);
        }
        return n;
      }
    },
    419082(e, t, n) {
      "use strict";
      n.d(t, {
        compareSymbols: () => g,
        decodeExtendedSymbol: () => m,
        encodeExtendedSymbol: () => r,
        encodeExtendedSymbolOrGetSimpleSymbolString: () => u,
        extractExtendedSymbol: () => p,
        isEncodedExtendedSymbol: () => d,
        replaceExtendedSymbol: () => f,
        unwrapSimpleSymbol: () => h,
      });
      var o = n(881014);
      function r(e) {
        return "=" + JSON.stringify(s(e));
      }
      function s(e) {
        return Object.keys(e)
          .sort()
          .reduce(
            (t, n) => (
              "[object Object]" === Object.prototype.toString.call(e[n])
                ? (t[n] = s(e[n]))
                : (t[n] = e[n]),
              t
            ),
            {}
          );
      }
      function i(e) {
        return (0, o.isString)(e);
      }
      function a(e) {
        return !i(e) && "inputs" in e;
      }
      function l(e) {
        return !i(e) && "replay" in e;
      }
      function c(e) {
        return (
          l(e) ||
          (function (e) {
            return !i(e) && l(e.symbol);
          })(e)
        );
      }
      function u(e, t) {
        return t
          ? (function (e) {
              return a(e) ||
                c(e) ||
                e.session ||
                e.adjustment ||
                e["currency-id"] ||
                e["unit-id"] ||
                e.metric
                ? r(e)
                : e.symbol;
            })(e)
          : r(e);
      }
      function d(e) {
        return "=" === e[0];
      }
      function m(e) {
        if (!d(e)) return { symbol: e };
        try {
          return JSON.parse(e.slice(1));
        } catch (t) {
          return { symbol: e };
        }
      }
      function h(e) {
        return i(e) ? e : h(e.symbol);
      }
      function p(e) {
        if (i(e)) return { symbol: e };
        let t = e;
        for (; !i(t.symbol); ) t = t.symbol;
        return t;
      }
      const y = [
        "symbol",
        "session",
        "unit-id",
        "currency-id",
        "metric",
        "adjustment",
        "backadjustment",
        "settlement-as-close",
      ];
      function g(e, t) {
        return y.every((n) => e[n] === t[n]);
      }
      function f(e, t) {
        let n = e;
        for (; !i(n.symbol); ) n = n.symbol;
        n.symbol = t;
      }
    },
    980136(e, t, n) {
      "use strict";
      n.d(t, {
        getSymbolPagePath: () => d,
        makeSymbolInfoWithSymbolInfoPriority: () => h,
        makeSymbolPageUrl: () => f,
        normalizeSpreadSymbol: () => u,
        renderTemplate: () => p,
      });
      var o = n(892449),
        r = n(648143),
        s = n(905436),
        i = n(371774),
        a = n(907738),
        l = n(398871);
      const c = new Set(["SP:SPX", "CBOE:SPX"]);
      function u(e) {
        const t = { ...e };
        if ("spread" === t.type || "expression" === t.type) {
          const e = t.shortName && m(t.shortName),
            n = t.proName && m(t.proName);
          (t.type = void 0), (t.shortName = e), (t.proName = n);
        }
        return t;
      }
      function d(e, t) {
        const n = u(e);
        return p(y(n, t), h(n));
      }
      function m(e) {
        return (0, a.tokenize)(e).find((e) => e.type === a.TokenType.Symbol)
          ?.value;
      }
      function h(e) {
        const t = {
          shortName: e.shortName,
          exchange: e.exchange,
          proName: e.proName,
          type: e.type,
          typespecs: e.typespecs,
          root: e.root,
        };
        return (
          t.proName &&
            t.proName.includes(":") &&
            ([t.exchange, t.shortName] = t.proName.split(":")),
          t
        );
      }
      function p(e, t) {
        const n = encodeURIComponent(t.shortName || ""),
          o = encodeURIComponent(t.exchange || ""),
          r = encodeURIComponent(t.proName || ""),
          s = encodeURIComponent(t.root || "");
        return e
          .replace("{tvexchange}", o)
          .replace("{tvsymbol}", n)
          .replace("{tvprosymbol}", r)
          .replace("{tvroot}", s);
      }
      function y(e, t = r.SymbolSubpath.Empty) {
        const n = h(e),
          {
            type: o,
            typespecs: s,
            shortName: i,
            proName: a,
            exchange: u,
            root: d,
          } = n;
        return void 0 === i && void 0 === a
          ? (console.warn("Params missed"), "/")
          : a && c.has(a)
          ? `/symbols/{tvsymbol}/${t}`
          : o || s
          ? "commodity" === o && s && s.includes("cfd")
            ? "/symbols/{tvsymbol}/?exchange={tvexchange}"
            : !d ||
              !s ||
              "futures" !== o ||
              (s.includes("continuous") && i?.endsWith("1!")) ||
              s.includes("exchange-continuous")
            ? u && ("forex" === o || (s && (0, l.hasCryptoTypespec)(s)))
              ? "/symbols/{tvsymbol}/?exchange={tvexchange}"
              : u
              ? `/symbols/{tvexchange}-{tvsymbol}/${t}`
              : `/symbols/{tvsymbol}/${t}`
            : `/symbols/{tvexchange}-{tvroot}1!/${t}?contract={tvsymbol}`
          : u
          ? `/symbols/{tvexchange}-{tvsymbol}/${t}`
          : `/symbols/{tvsymbol}/${t}`;
      }
      function g(e, t, n, r) {
        const a = (0, o.getEnvValue)("locale_domains"),
          l =
            (a ? (0, i.determineBaseUrl)(a, r) : window.location.origin) +
            p(e, h(u(t)));
        return n ? (0, s.addUtmToUrl)(l, n) : l;
      }
      function f(e, t, n, o) {
        const r = u(e);
        return g(y(r, o), r, t, n);
      }
    },
  },
  (e) => {
    e.O(
      0,
      [
        58667, 12819, 63501, 26830, 81263, 95350, 74916, 11709, 923, 18510,
        63264, 35723, 98550, 13148, 30235, 80580, 79726, 44906, 1068, 33390,
        62851, 92358, 11401, 66708, 12338, 37463, 99702, 85589, 97717, 98587,
        45394,
      ],
      () => {
        return (t = 512243), e((e.s = t));
        var t;
      }
    );
    e.O();
  },
]);
