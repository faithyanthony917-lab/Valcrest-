"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [62851],
  {
    329203(e, t, s) {
      s.d(t, { default: () => o });
      var i = s(383636);
      const o = [
        {
          name: i.t(null, { context: "symbols_type" }, s(350146)),
          value: "",
          search_type: "undefined",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(555510)),
          value: "stocks",
          search_type: "stocks",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(564917)),
          value: "funds",
          search_type: "funds",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(505079)),
          value: "futures",
          search_type: "futures",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(97997)),
          value: "forex",
          search_type: "forex",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(384597)),
          value: "cfd",
          search_type: "cfd",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(655235)),
          value: "bitcoin,crypto",
          search_type: "crypto",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(927411)),
          value: "index",
          search_type: "index",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(765440)),
          value: "bond",
          search_type: "bond",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(548322)),
          value: "economic",
          search_type: "economic",
        },
        {
          name: i.t(null, { context: "symbols_type" }, s(79600)),
          value: "options",
          search_type: "options",
        },
      ];
    },
    507553(e, t, s) {
      var i = s(666746),
        o = s(240680),
        r = s(619909),
        n = s(146961),
        a = s(982738);
      const _ = {
          [r.ChartApiProductFeature.StudyOnStudy]: "child_limit",
          [r.ChartApiProductFeature.FundamentalsOnChart]: "limit",
          [r.ChartApiProductFeature.IndicatorsOnChart]: "limit",
          [r.ChartApiProductFeature.FundamentalsForecast]: "limit",
        },
        l = {
          isFeatureEnabled: (e) => (0, a.enabled)(e),
          featureLimit: (e) => (0, n.ensureNotNull)((0, a.getConfig)(e))[_[e]],
        };
      (0, r.setChartApiEntitlements)(l);
      var d = s(462965);
      const c = JSON.parse(
        '{"adx":"widget_user_token-adx","adxD":"widget_user_token-adxD","aljaziracapitalD":"widget_user_token-aljaziracapitalD","aljaziracapitalRT":"widget_user_token-aljaziracapitalRT","alrajhicapitalcomD":"widget_user_token-alrajhicapitalcomD","alrajhicapitalcomRT":"widget_user_token-alrajhicapitalcomRT","arenaxtro":"widget_user_token-arenaxtro","bankirosru":"widget_user_token-bankirosru","beeksgroup":"widget_user_token-beeksgroup","belugagroupru":"widget_user_token-belugagroupru","bivacom":"widget_user_token-bivacom","bluefield":"widget_user_token-bluefield","bluelinefutures":"widget_user_token-bluelinefutures","bovespa":"widget_user_token-bmfbovespacombr","bvbro":"widget_user_token-bvbro","cboecanada":"widget_user_token-cboecanada","championnatbourse":"widget_user_token-championnatbourse","ceocaD":"widget_user_token-ceocaD","ceocaRT":"widget_user_token-ceocaRT","cmcmarkets":"widget_user_token-cmcmarkets","cselk":"widget_user_token-cselk","dailyfx":"widget_user_token-dailyfx","deepsearch":"widget_user_token-deepsearch","derayahcom":"widget_user_token-derayahcom","dfmaeD":"widget_user_token-dfmaeD","dfmaeRT":"widget_user_token-dfmaeRT","dinarsaD":"widget_user_token-dinarsaD","dinarsaRT":"widget_user_token-dinarsaRT","edaily":"widget_user_token-edaily","elespanolcom":"widget_user_token-elespanolcom","eurex":"widget_user_token-eurex","eurofins":"widget_user_token-eurofins","galiciaar":"widget_user_token-galiciaar","healthitalia":"widget_user_token-healthitalia","hegnarno":"widget_user_token-hegnarno","igcom":"widget_user_token-igcom","investegatecouk":"widget_user_token-investegatecouk","investopedia":"widget_user_token-investopedia","integralyatirim":"widget_user_token-integralyatirim","ivsgroup":"widget_user_token-ivsgroup","jsecoza":"widget_user_token-jsecoza","boersenzeitung":"widget_user_token-boersenzeitung","marcopolocombr":"widget_user_token-marcopolocombr","moex":"widget_user_token-moex","moneytimescombr":"widget_user_token-moneytimescombr","mynetcom":"widget_user_token-mynetcom","NGX":"widget_user_token-NGX","nommoma":"widget_user_token-nommoma","nsecokr":"widget_user_token-nsecokr","panafricanresourcescom":"widget_user_token-panafricanresourcescom","pse":"widget_user_token-pse","pseD":"widget_user_token-pseD","riyadhcapitalD":"widget_user_token-riyadhcapitalD","riyadhcapitalRT":"widget_user_token-riyadhcapitalRT","qecomqa":"widget_user_token-qecomqa","samolet":"widget_user_token-samolet","seeingmachinescom":"widget_user_token-seeingmachinescom","seudinheiro":"widget_user_token-seudinheiro","softwareag":"widget_user_token-softwareag","sogeclair":"widget_user_token-sogeclair","sgcompanyit":"widget_user_token-sgcompanyit","sharejunction":"widget_user_token-sharejunction","smartlab-custom":"widget_user_token-smartlab","smartlab":"widget_user_token-smartlab","stonexwdg":"widget_user_token-stonex£-!www.stonex.com","stoxio":"widget_user_token-stoxio","stonex":"widget_user_token-stonex","toroinvestimentoscom":"widget_user_token-toroinvestimentoscom","thecsecom":"widget_user_token-thecsecom","tonnerdronescom":"widget_user_token-tonnerdronescom","tradersclubbrasil":"widget_user_token-tradersclubbrasil","tradingview":"widget_user_token-tradingview","xtools":"widget_user_token-xtools","twitter":"widget_user_token-twitter","uaestocktalks":"widget_user_token-uaestocktalks","velocitycompositescom":"widget_user_token-velocitycompositescom","wealthsimple":"widget_user_token-wealthsimple£-!my.wealthsimple.com","worldchesscom":"widget_user_token-worldchesscom","xCrtyJksp":"widget_user_token-xCrtyJksp"}'
      );
      var u = s(329203);
      const h = {
        widgetToken: (e) => c[e] || "widget_user_token",
        symbolTypes: () => u.default,
      };
      (0, d.setChartApiSiteConfig)(h),
        (0, i.setChartApi)(
          "site",
          new o.TVChartApi(window.WSBackendConnection)
        );
    },
    619909(e, t, s) {
      s.d(t, {
        ChartApiProductFeature: () => i,
        getChartApiEntitlements: () => n,
        setChartApiEntitlements: () => r,
      });
      var i = (function (e) {
        return (
          (e.StudyOnStudy = "STUDY_ON_STUDY"),
          (e.FundamentalsOnChart = "FUNDAMENTALS_ON_CHART"),
          (e.IndicatorsOnChart = "INDICATORS_ON_CHART"),
          (e.FundamentalsForecast = "FUNDAMENTALS_FORECAST"),
          e
        );
      })({});
      let o = null;
      function r(e) {
        o = e;
      }
      function n() {
        if (null === o)
          throw new Error(
            "Chart API entitlements are not installed on this page."
          );
        return o;
      }
    },
    462965(e, t, s) {
      s.d(t, {
        getChartApiSiteConfig: () => r,
        setChartApiSiteConfig: () => o,
      });
      let i = null;
      function o(e) {
        i = e;
      }
      function r() {
        if (null === i)
          throw new Error(
            "Chart API site config is not installed on this page."
          );
        return i;
      }
    },
    240680(e, t, s) {
      s.d(t, { TVChartApi: () => pe });
      var i = s(202580),
        o = s(203681),
        r = s(547851),
        n = s(206673),
        a = s(304221),
        _ = s(817350),
        l = s(146961),
        d = s(881014),
        c = s(140136),
        u = s(570071),
        h = s(819511),
        m = (function (e) {
          return (
            (e.Connected = "connected"),
            (e.Disconnected = "disconnected"),
            (e.ReconnectBailout = "reconnect_bailout"),
            e
          );
        })({}),
        p = s(80365),
        g = s(554741),
        f = s(478561),
        y = s(384017);
      const b = (0, h.getLogger)("ChartApi.AuthToken", { color: "#173" });
      class S {
        destroy() {
          window.removeEventListener("online", this._onOnline),
            document.removeEventListener(
              "visibilitychange",
              this._onVisibilityChange
            );
        }
        get(e) {
          return window.is_authenticated
            ? !e && this.currentTokenIsValid()
              ? (b.logInfo(`Using cached token ${this._cache.token}`),
                Promise.resolve(this._cache.token))
              : window.navigator.onLine
              ? (this._onGoingAuthTokenRequest ||= this._fetch(Boolean(e), 0)
                  .then((e) => {
                    if (!window.is_authenticated)
                      throw new Error(
                        "User logged out while the request was in flight"
                      );
                    return this._set(e), e;
                  })
                  .catch(
                    (e) => (
                      b.logError(`Error fetching new token: ${e && e.message}`),
                      ""
                    )
                  )
                  .finally(() => {
                    this._onGoingAuthTokenRequest = null;
                  }))
              : (b.logWarn(
                  "Offline, cannot fetch new token, using cached token"
                ),
                Promise.resolve(this._cache.token))
            : Promise.resolve("");
        }
        reset() {
          this._set(void 0), this.invalidated.fire();
        }
        currentTokenIsValid() {
          return (
            !window.is_authenticated ||
            (!!this._cache &&
              performance.now() < this._cache.monoValidThru &&
              Date.now() < this._cache.wallValidThru)
          );
        }
        _set(e) {
          if (window.is_authenticated && void 0 !== e) {
            const t = (function (e) {
              if ("" === e) return 144e5;
              try {
                const t = JSON.parse(
                    atob(e.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))
                  ),
                  s = 1e3 * (t.exp - t.iat);
                if (!isFinite(s)) throw new Error("invalid expiration");
                return Math.max(s - 3e5, 3e5);
              } catch (t) {
                return b.logError(`${e} is invalid: ${t.message}`), 144e5;
              }
            })(e);
            (this._cache = {
              token: e,
              monoValidThru: performance.now() + t,
              wallValidThru: Date.now() + t,
            }),
              clearTimeout(this._tid),
              (this._tid = setTimeout(() => {
                window.navigator.onLine
                  ? this.reset()
                  : b.logInfo("Offline, cache will not be invalidated");
              }, t)),
              b.logInfo(`Cached for ${t} ms: ${e}`);
          } else
            (this._cache = {
              token: "",
              monoValidThru: -1 / 0,
              wallValidThru: -1 / 0,
            }),
              clearTimeout(this._tid),
              b.logInfo("Cache dropped");
        }
        _fetch(e, t) {
          return (
            b.logNormal(`Fetching a new token, grabSession=${e}`),
            (0, y.fetch)("/quote_token/", {
              method: "POST",
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              body: e ? "grabSession=true" : "",
            }).then(
              (e) => {
                if (!e.ok)
                  throw new Error(`Response status is not ok: ${e.status}`);
                return e.json().then(String);
              },
              (s) => {
                if (t >= 3) throw s;
                return (
                  b.logWarn("Request failed, will retry"),
                  (function (e) {
                    return new Promise((t) => setTimeout(t, 1e3 * e));
                  })(t).then(() => this._fetch(e, t + 1))
                );
              }
            )
          );
        }
        async _tryToUpdateToken() {
          this._cache.token !== (await this.get()) && this.invalidated.fire();
        }
        constructor() {
          (this.invalidated = new u.Delegate()),
            (this._tid = 0),
            (this._onGoingAuthTokenRequest = null),
            (this._onOnline = () => {
              b.logInfo("Online, new token will be fetched if needed"),
                this._tryToUpdateToken();
            }),
            (this._onVisibilityChange = () => {
              "visible" === document.visibilityState &&
                (b.logInfo("Page visible, new token should be fetched"),
                this._tryToUpdateToken());
            }),
            window.loginStateChange ||
              (window.loginStateChange = new u.Delegate()),
            window.loginStateChange.subscribe(this, (e) => {
              e || (this._set(window.user.auth_token), this.invalidated.fire());
            }),
            this._set(window.user.auth_token),
            window.addEventListener("online", this._onOnline),
            document.addEventListener(
              "visibilitychange",
              this._onVisibilityChange
            );
        }
      }
      var T = s(695807),
        w = s(179594),
        C = s(619909),
        R = s(462965),
        v = s(83019),
        k = s(359239),
        E = s(415100);
      class A {
        async getValue(e) {
          const t = await this._cache.match(e);
          if (!t) return null;
          return "application/json" ===
            (0, l.ensureNotNull)(t.headers.get("Content-Type"))
            ? t.json()
            : t.text();
        }
        async setValue(e, t) {
          return "string" == typeof t
            ? this._cache.put(
                e,
                new Response(t, { headers: { "content-type": "text/plain" } })
              )
            : this._cache.put(
                e,
                new Response(JSON.stringify(t), {
                  headers: { "content-type": "application/json" },
                })
              );
        }
        async migrateValue(e, t) {
          const s = await this.getValue(e);
          s && (await this.setValue(t, s), await this._cache.delete(e));
        }
        async deleteValue(e) {
          return this._cache.delete(e);
        }
        constructor(e) {
          this._cache = e;
        }
      }
      class I {
        async getValue(e) {
          return this._data.get(e) ?? null;
        }
        async setValue(e, t) {
          this._data.set(e, t);
        }
        async migrateValue(e, t) {
          this._data.has(e) &&
            (this._data.set(t, this._data.get(e)), this._data.delete(e));
        }
        async deleteValue(e) {
          return this._data.delete(e);
        }
        constructor() {
          this._data = new Map();
        }
      }
      var O = s(39032),
        N = s(137139),
        D = s(712859),
        P = s(197052),
        L = s(514154),
        x = s(715471),
        M = (function (e) {
          return (
            (e.RequestDataProblems = "request_data_problems"),
            (e.ProtocolError = "protocol_error"),
            (e.ProtocolSwitched = "protocol_switched"),
            (e.CriticalError = "critical_error"),
            e
          );
        })({}),
        q = (function (e) {
          return (
            (e.StudiesMetadata = "studies_metadata"),
            (e.TimeScaleUpdate = "timescale_update"),
            (e.TickMarkUpdate = "tickmark_update"),
            (e.DU = "du"),
            (e.DataUpdate = "data_update"),
            (e.IndexUpdate = "index_update"),
            (e.TimeScaleCompleted = "timescale_completed"),
            (e.QSD = "qsd"),
            (e.QuoteListField = "quote_list_fields"),
            (e.QuoteSymbolData = "quote_symbol_data"),
            (e.QuoteCompleted = "quote_completed"),
            (e.DepthSymbolError = "depth_symbol_error"),
            (e.DepthSymbolSuccess = "depth_symbol_success"),
            (e.DepthData = "dd"),
            (e.DepthDataUpdate = "dpu"),
            (e.DepthBarLastValue = "depth_bar_last_value"),
            (e.ClearData = "clear_data"),
            (e.SeriesTimeFrame = "series_timeframe"),
            (e.SymbolResolved = "symbol_resolved"),
            (e.SeriesError = "series_error"),
            (e.SeriesCompleted = "series_completed"),
            (e.StudyLoading = "study_loading"),
            e
          );
        })({}),
        U = (function (e) {
          return (
            (e.ReplayError = "replay_error"),
            (e.ReplayPoint = "replay_point"),
            (e.ReplayOk = "replay_ok"),
            (e.ReplayResolutions = "replay_resolutions"),
            (e.ReplayDataEnd = "replay_data_end"),
            (e.ReplayInstanceId = "replay_instance_id"),
            (e.ReplayDepth = "replay_depth"),
            e
          );
        })({});
      function F(e) {
        return { index: e.i, value: e.v };
      }
      function H(e) {
        for (const t of Object.keys(e)) {
          const s = e[t];
          s.t && (s.turnaround = e[t].t),
            "s" in e[t] && e[t].s && !s.series && (s.series = e[t].s.map(F)),
            "st" in e[t] && e[t].st && !s.series && (s.series = e[t].st.map(F));
        }
      }
      class B {
        set_broker(e) {
          return [e];
        }
        set_data_quality() {
          return ["low"];
        }
        quote_create_session(e) {
          return [e];
        }
        quote_delete_session(e) {
          return [e];
        }
        quote_set_fields(e, t) {
          return [e].concat(t);
        }
        quote_add_symbols(e, t) {
          return [e].concat(t);
        }
        quote_remove_symbols(e, t) {
          return [e].concat(t);
        }
        quote_fast_symbols(e, t) {
          return [e].concat(t);
        }
        quote_hibernate_all(e) {
          return [e];
        }
        depth_create_session(e, t, s) {
          return [e, t, s];
        }
        depth_delete_session(e) {
          return [e];
        }
        depth_set_symbol(e, t) {
          return [e, t];
        }
        depth_clear_symbol(e) {
          return [e];
        }
        depth_set_scale(e, t) {
          return [e, t];
        }
        chart_create_session(e, t) {
          return [e, t ? "disable_statistics" : ""];
        }
        chart_delete_session(e) {
          return [e];
        }
        set_auth_token(e) {
          return [e];
        }
        set_locale(e, t) {
          return [e, t];
        }
        switch_timezone(e, t) {
          return [e, t];
        }
        resolve_symbol(e, t, s) {
          return [e, t, s];
        }
        create_series(e, t, s, i, o, r, n) {
          return [e, t, (s = s || ""), i, o, r, n];
        }
        remove_series(e, t) {
          return [e, t];
        }
        modify_series(e, t, s, i, o, r) {
          return [e, t, (s = s || ""), i, o, r];
        }
        request_more_data(e, t, s) {
          return [e, t, s];
        }
        set_future_tickmarks_mode(e, t) {
          return [e, t];
        }
        request_studies_metadata(e) {
          return [e];
        }
        create_study(e, t, s, i, o, r) {
          return [e, t, (s = s || ""), i, o].concat(r);
        }
        create_child_study(e, t, s, i, o, r) {
          return this.create_study(e, t, s, i, o, r);
        }
        remove_study(e, t) {
          return [e, t];
        }
        modify_study(e, t, s, i) {
          return [e, t, (s = s || "")].concat(i);
        }
        notify_study(e, t, s, i) {
          return [e, t, (s = s || ""), i];
        }
        create_pointset(e, t, s, i, o, r) {
          return [e, t, (s = s || ""), i, o].concat(r);
        }
        modify_pointset(e, t, s, i) {
          return [e, t, (s = s || "")].concat(i);
        }
        remove_pointset(e, t) {
          return [e, t];
        }
        request_more_tickmarks(e, t, s) {
          return [e, t, s];
        }
        get_first_bar_time(e, t, s) {
          return [e, t, s];
        }
        replay_create_session(e) {
          return [e];
        }
        replay_delete_session(e) {
          return [e];
        }
        replay_reset(e, t, s) {
          return [e, t, s];
        }
        replay_start(e, t, s) {
          return [e, t, s];
        }
        replay_stop(e, t) {
          return [e, t];
        }
        replay_step(e, t, s) {
          return [e, t, s];
        }
        replay_add_series(e, t, s, i) {
          return [e, t, s, i];
        }
        replay_remove_series(e, t, s, i) {
          return [e, t, s, i];
        }
        replay_set_resolution(e, t, s) {
          return [e, t, s];
        }
        replay_get_depth(e, t, s, i) {
          return [e, t, s, i];
        }
        convertTimescaleResponse(e) {
          const t = e.marks.map((e) => ({
              span: e[0],
              time: e[1],
              index: e[2],
            })),
            s =
              void 0 === e.index_diff
                ? []
                : e.index_diff.map((e) => ({ old: e[0], new: e[1] }));
          return {
            ...e,
            marks: t,
            index_diff: s,
            clear: 0 === e.changes.length && 0 === s.length && 0 === t.length,
          };
        }
        getDataUpdateObjects(e) {
          return e.params[0];
        }
        getTimescaleObjects(e) {
          return e.params[0];
        }
        getTimescaleChangeset(e) {
          return e.params[1];
        }
        prepareDataUpdateObjects(e, t, s) {
          for (const [i, o] of Object.entries(t)) {
            const t = "plots" in o ? o.plots : o.series,
              r = { customId: i, turnaround: o.turnaround, plots: t };
            "ns" in o && o.ns && (r.nonseries = o.ns),
              "lbs" in o &&
                o.lbs &&
                (r.lastBar = { closeTime: o.lbs.bar_close_time });
            for (const e of r.plots)
              for (const [t, s] of Object.entries(e.value))
                s && Math.abs(s) >= 1e100 && (e.value[+t] = void 0);
            s(e, i, { method: q.DataUpdate, params: r });
          }
        }
        unpack(e) {
          const t = JSON.parse(e);
          t.m && t.p && ((t.method = t.m), (t.params = t.p), (t.time = t.t));
          const s = t.params[1];
          switch (t.method) {
            case "qsd":
              (t.method = "quote_symbol_data"),
                (s.symbolname = s.n),
                (s.status = s.s),
                (s.values = s.v),
                (s.values.change = s.v.ch),
                (s.values.last_price = s.v.lp),
                (s.values.change_percent = s.v.chp),
                delete s.n,
                delete s.s,
                delete s.v,
                delete s.values.ch,
                delete s.values.lp,
                delete s.values.chp;
              break;
            case "du":
              (t.method = "data_update"), H(s);
              break;
            case "clear_data":
              for (const e of Object.keys(s)) s[e].turnaround = s[e].t;
              break;
            case "timescale_update":
              H(s);
          }
          return t;
        }
        prepareEncodeMessage(e, t) {
          return JSON.stringify({ m: e, p: t });
        }
        request_data_problems() {
          return [];
        }
      }
      class V {
        constructor(e, t, s) {
          (this.handler = e), (this.customId = t), (this.singleShot = s);
        }
      }
      const j = (0, h.getLogger)("Chart.Studies.StudyMetaInfoRepository", {
          color: "#606",
        }),
        Y = (0, h.getLogger)("ChartApi.TrafficMeter", {
          maxCount: 20,
          color: "#268",
        }),
        $ = (0, h.getLogger)("ChartApi.Core", { color: "#706" }),
        G = (0, h.getLogger)("ChartApi.ChartSession", { color: "#706" }),
        W = (0, h.getLogger)("ChartApi.ChartSession", {
          highRate: !0,
          maxCount: 100,
          color: "#706",
        }),
        z = (0, h.getLogger)("ChartApi.ChartSession", {
          maxCount: 0,
          color: "#706",
        }),
        Q = (0, h.getLogger)("ChartApi.ChartSession", {
          maxCount: 50,
          color: "#706",
        }),
        K = (0, h.getLogger)("ChartApi.QuoteSession", {
          maxCount: 50,
          color: "#660",
        }),
        X = (0, h.getLogger)("ChartApi.QuoteSession", {
          highRate: !0,
          maxCount: 10,
          color: "#660",
        }),
        J = !(0, D.isOnMobileAppPage)("any"),
        Z = (0, O.isFeatureEnabled)("broker_id_session");
      let ee = !1,
        te = !1,
        se = !1;
      const ie = ["", "KB", "MB", "GB", "TB"];
      function oe(e) {
        if (0 === e) return "0";
        const t = (0, x.toInt)(Math.floor(Math.log(e) / Math.log(1024)));
        return (e / Math.pow(1024, t)).toFixed(2) + ie[t];
      }
      function re(e, t) {
        return `${e}__${t}`;
      }
      function ne(e, t, s) {
        const i = t[s] ?? 0;
        t[s] = i + e;
      }
      const ae = ne.bind(null, 1),
        _e = ne.bind(null, -1),
        le = (0, f.isFeaturesetEnabled)("widget")
          ? "studies_metadata_widget"
          : "studies_metadata",
        de = "/chart-api/pro_hash",
        ce = (0, f.isFeaturesetEnabled)("widget")
          ? "/chart-api/studies_metadata_widget"
          : "/chart-api/studies_metadata";
      let ue = null;
      function he() {
        if (null === ue) {
          const e = document.querySelector('link[rel~="conversions-config"]'),
            t = new URL((0, l.ensureNotNull)(e).href);
          ue = (0, y.fetch)(t.toString(), { method: "GET" })
            .then((e) => {
              if (!e.ok)
                throw new Error(
                  `Failed to load conversions config from ${e.url} with status ${e.status} and statusText ${e.statusText}.`
                );
              return e.json();
            })
            .then((e) => {
              const t = (0, N.getLogoUrlResolver)();
              return (
                e.currencies.forEach((e) => {
                  void 0 !== e.logoid &&
                    (e.logoUrl = t.getSymbolLogoUrl(
                      e.logoid,
                      N.LogoSize.Medium
                    ));
                }),
                e
              );
            });
        }
        return ue;
      }
      let me = null;
      class pe {
        connect(e) {
          this._planUpgradeRequired.value()
            ? $.logInfo(
                "Connect skipped: the backend requires a plan upgrade for this account."
              )
            : ((this._connectOnlyOptions = e),
              this._wsBackendConnection.isConnected() ||
                this._wsBackendConnection.isConnecting() ||
                this._wsBackendConnection.connect());
        }
        disconnect() {
          this._wsBackendConnection.disconnect();
        }
        sentMethodsCounters() {
          return this._sentMethodsCounters;
        }
        receivedMethodsCounters() {
          return this._receivedMethodsCounters;
        }
        defaultResolutions() {
          return (0, w.getDefaultResolutions)();
        }
        availableCurrencies() {
          return he().then((e) => e.currencies);
        }
        availableUnits() {
          return he().then((e) => {
            const t = {};
            for (const s of e.units)
              t[s.type] || (t[s.type] = []), t[s.type].push(s);
            return t;
          });
        }
        async availableMetrics() {
          return (function () {
            if (null === me) {
              const e = document.querySelector('link[rel~="metrics-config"]'),
                t = new URL((0, l.ensureNotNull)(e).href);
              me = (0, y.fetch)(t.toString(), { method: "GET" }).then(
                async (e) => {
                  if (!e.ok)
                    throw new Error(
                      `Failed to load metrics config from ${e.url} with status ${e.status} and statusText ${e.statusText}.`
                    );
                  const t = await e.json();
                  return (
                    t.metrics_full_name?.forEach((e) => {
                      const s = t.metrics.find((t) => t.id === e.id);
                      s && (s.description = e.name);
                    }),
                    t
                  );
                }
              );
            }
            return me;
          })().then((e) => e.metrics);
        }
        availablePriceSources() {
          return Promise.resolve([]);
        }
        supportedSymbolsTypes() {
          const e = (0, i.embedWidgetCustomer)() ?? "",
            t = (0, R.getChartApiSiteConfig)().symbolTypes();
          return "bovespa" === e
            ? t.filter((e) =>
                ["", "stock", "futures", "index"].includes(e.value)
              )
            : "cme" === e
            ? t.filter((e) => "quandl" !== e.value)
            : t;
        }
        symbolsGrouping() {
          return { futures: /^(.+?)([12]!|\w\d{4})?$/ };
        }
        connected() {
          return !!this._isConnected;
        }
        authTokenManager() {
          return (0, l.ensureDefined)(this._authTokenManager);
        }
        createSession(e, t) {
          (this._sessions[e] = t),
            (this._notificationHandlers[e] = {}),
            this.connected() &&
              this._isAuthTokenLoaded &&
              t.onMessage({ method: m.Connected, params: [] });
        }
        removeSession(e) {
          delete this._sessions[e], delete this._notificationHandlers[e];
        }
        disconnectCount() {
          return this._disconnectCount || 0;
        }
        getPingInfo() {
          return this._wsBackendConnection.getPingInfo();
        }
        connectionBanInfo() {
          return this._banInfo.readonly();
        }
        connectionsLimitReached() {
          return this._connectionsLimitReached.readonly();
        }
        connectionPlanUpgradeRequired() {
          return this._planUpgradeRequired.readonly();
        }
        protocolError() {
          return this._protocolError;
        }
        serverTime() {
          return Math.round(this._serverTimeBasePoint + performance.now());
        }
        compensateConnectionLag(e) {
          const t = this.serverTime(),
            s = Math.floor(e - t);
          s > 0 && (this._serverTimeBasePoint += s);
        }
        setBroker(e) {
          return (
            e === this._brokerId ||
            ((this._brokerId = e), this._sendBrokerIdToSession(this._brokerId))
          );
        }
        chartCreateSession(e, t) {
          return this._sendRequest("chart_create_session", [e, t]);
        }
        chartDeleteSession(e) {
          return this._sendRequest("chart_delete_session", [e]);
        }
        switchTimezone(e, t) {
          return this._sendRequest("switch_timezone", [e, t]);
        }
        resolveSymbol(e, t, s, i) {
          return (
            (P.telemetry.timeCounters.series["resolve_symbol_" + e] =
              window.performance.now()),
            (this._notificationHandlers[e][t] = new V(i, t, !0)),
            this._sendRequest("resolve_symbol", [e, t, s])
          );
        }
        requestFirstBarTime(e, t, s, i) {
          return (
            (this._notificationHandlers[e][t] = new V(i, t, !0)),
            this._sendRequest("get_first_bar_time", [e, t, s])
          );
        }
        createSeries(e, t, s, i, o, r, n, a) {
          P.telemetry.timeCounters.series.marks.push("create_series_" + e),
            (this._notificationHandlers[e][t] = new V(a, t));
          const _ = null === n ? "" : (0, p.convertTimeFrameToStr)(n, !0);
          return this._sendRequest("create_series", [e, t, s, i, o, r, _]);
        }
        removeSeries(e, t) {
          return (
            delete this._notificationHandlers[e][t],
            this._sendRequest("remove_series", [e, t])
          );
        }
        modifySeries(e, t, s, i, o, r, n, a) {
          this._notificationHandlers[e][t] = new V(a, t);
          const _ = null === n ? "" : (0, p.convertTimeFrameToStr)(n, !0);
          return this._sendRequest("modify_series", [e, t, s, i, o, _]);
        }
        getStudyCounter(e) {
          return this._studyCounter[e] ?? 0;
        }
        getFundamentalCounter(e) {
          return this._fundamentalCounter[e] ?? 0;
        }
        getChildStudyCounter(e) {
          return this._childStudyCounter[e] ?? 0;
        }
        requestMoreData(e, t, s, i) {
          if (void 0 === s || void 0 === i)
            throw new Error("unsupported request to load more data, bars=" + s);
          const o = t;
          return (
            (this._notificationHandlers[e][o] = new V(i, o)),
            this._sendRequest("request_more_data", [e, o, s])
          );
        }
        requestMoreTickmarks(e, t, s, i) {
          return (
            i && (this._notificationHandlers[e][t] = new V(i, t)),
            this._sendRequest("request_more_tickmarks", [e, t, s])
          );
        }
        setFutureTickmarksMode(e, t) {
          this._sendRequest("set_future_tickmarks_mode", [e, t]);
        }
        requestDataProblems() {
          return (
            this._requestDataProblemsPromise ||
              (this._requestDataProblemsPromise = this.connectDfd
                .then(
                  () =>
                    new Promise((e, t) => {
                      (this._onDataProblemsPromiseErrback = t),
                        this._sendRequest("request_data_problems", [])
                          ? (this._onDataProblemsPromiseCb = e)
                          : t();
                    })
                )
                .finally(() => {
                  this._requestDataProblemsPromise = null;
                })),
            this._requestDataProblemsPromise
          );
        }
        async requestMetadata() {
          return (
            null === this._metadataDeferredPromise &&
              ((this._metadataDeferredPromise = (0, k.createDeferredPromise)()),
              this._metadataDeferredPromise.promise.finally(() => {
                this._metadataDeferredPromise = null;
              }),
              this._requestMetadata()),
            this._metadataDeferredPromise.promise
          );
        }
        allStudiesMetadata() {
          throw new Error("This method is not implemented");
        }
        setLoadNew(e) {
          this._loadNewBars = !!e;
        }
        setIsNonCountedStudyFn(e) {
          this._isNonCountedStudy = e;
        }
        canCreateStudy(e, t, s) {
          const {
              id: i,
              child: o,
              fundamental: r,
              forecast: n,
              stubTitle: a,
            } = t,
            _ = (0, C.getChartApiEntitlements)(),
            l = _.featureLimit(C.ChartApiProductFeature.StudyOnStudy);
          if (
            o &&
            (!_.isFeatureEnabled(C.ChartApiProductFeature.StudyOnStudy) ||
              (this._childStudyCounter[e] ?? 0) >= l)
          )
            return { success: !1, reason: "child", limitValue: l };
          if (s) return { success: !0 };
          if (
            n &&
            !_.isFeatureEnabled(C.ChartApiProductFeature.FundamentalsForecast)
          )
            return { success: !1, reason: "forecast", scriptName: a };
          const d = _.featureLimit(
            C.ChartApiProductFeature.FundamentalsOnChart
          );
          if (
            r &&
            (!_.isFeatureEnabled(
              C.ChartApiProductFeature.FundamentalsOnChart
            ) ||
              this.getFundamentalCounter(e) >= d)
          )
            return { success: !1, reason: "fundamental", limitValue: d };
          const c = _.featureLimit(C.ChartApiProductFeature.IndicatorsOnChart);
          return r ||
            this._isNonCountedStudy(i) ||
            (_.isFeatureEnabled(C.ChartApiProductFeature.IndicatorsOnChart) &&
              !(this.getStudyCounter(e) >= c))
            ? { success: !0 }
            : { success: !1, reason: "general", limitValue: c };
        }
        createStudy(e, t, s, i, o, r, n, a) {
          const _ = this.canCreateStudy(e, a);
          return (
            !(!_.success && "child" === _.reason) &&
            ((this._notificationHandlers[e][t] = new V(n, t)),
            this._sendRequest("create_study", [e, t, s, i, o, r]),
            a.fundamental
              ? ae(this._fundamentalCounter, e)
              : this._isNonCountedStudy(a.id) || ae(this._studyCounter, e),
            a.child && ae(this._childStudyCounter, e),
            this._studySpecs.set(re(e, t), a),
            !0)
          );
        }
        modifyStudy(e, t, s, i, o, n) {
          ne((n = n ?? 0), this._childStudyCounter, e),
            0 !== n &&
              ((0, l.ensureDefined)(this._studySpecs.get(re(e, t))).child =
                n > 0),
            (this._notificationHandlers[e][t] = new V(o, t));
          const a = e + t;
          if (this._modifyStudyMap.has(a)) {
            return (
              (0, l.ensureDefined)(this._modifyStudyMap.get(a))(e, t, s, i) ??
              !0
            );
          }
          {
            const o = (0, r.default)(
              (e, t, s, i) => this._sendRequest("modify_study", [e, t, s, i]),
              500,
              { maxWait: 550 }
            );
            return this._modifyStudyMap.set(a, o), o(e, t, s, i) ?? !0;
          }
        }
        notifyStudy(e, t, s, i) {
          return (
            $.logNormal(
              `Send notify_study, [${e}, ${t}, ${s}, ${JSON.stringify(i)}]`
            ),
            this._sendRequest("notify_study", [e, t, s, JSON.stringify(i)])
          );
        }
        removeStudy(e, t) {
          const s = e + t;
          delete this._notificationHandlers[e][t],
            this._modifyStudyMap.get(s)?.flush();
          const i = this._sendRequest("remove_study", [e, t]);
          if (!1 === i) return !1;
          this._modifyStudyMap.delete(s);
          const o = re(e, t),
            r = (0, l.ensureDefined)(this._studySpecs.get(o));
          return (
            this._studySpecs.delete(o),
            r.fundamental
              ? _e(this._fundamentalCounter, e)
              : this._isNonCountedStudy(r.id) || _e(this._studyCounter, e),
            r.child && _e(this._childStudyCounter, e),
            i
          );
        }
        createPointset(e, t, s, i, o, r, n) {
          return (
            (this._notificationHandlers[e][t] = new V(n, t)),
            this._sendRequest("create_pointset", [e, t, s, i, o, r])
          );
        }
        modifyPointset(e, t, s, i, o) {
          return (
            (this._notificationHandlers[e][t] = new V(o, t)),
            this._sendRequest("modify_pointset", [e, t, s, i])
          );
        }
        removePointset(e, t) {
          return (
            delete this._notificationHandlers[e][t],
            this._sendRequest("remove_pointset", [e, t])
          );
        }
        getMarks(e, t, s, i, o) {
          throw Error("This method is not implemented");
        }
        getTimescaleMarks(e, t, s, i, o) {
          throw Error("This method is not implemented");
        }
        quoteCreateSession(e) {
          return this._sendRequest("quote_create_session", [e]);
        }
        quoteDeleteSession(e) {
          return this._sendRequest("quote_delete_session", [e]);
        }
        quoteAddSymbols(e, t) {
          return this._sendRequest("quote_add_symbols", [e, t]);
        }
        quoteRemoveSymbols(e, t) {
          return this._sendRequest("quote_remove_symbols", [e, t]);
        }
        quoteFastSymbols(e, t) {
          return this._sendRequest("quote_fast_symbols", [e, t]);
        }
        quoteSetFields(e, t) {
          return this._sendRequest("quote_set_fields", [e, t]);
        }
        quoteHibernateAll(e) {
          return this._sendRequest("quote_hibernate_all", [e]);
        }
        depthCreateSession(e, t, s) {
          return this._sendRequest("depth_create_session", [e, t, s]);
        }
        depthDeleteSession(e) {
          return this._sendRequest("depth_delete_session", [e]);
        }
        depthSetSymbol(e, t) {
          return this._sendRequest("depth_set_symbol", [e, t]);
        }
        depthClearSymbol(e) {
          return this._sendRequest("depth_clear_symbol", [e]);
        }
        depthSetScale(e, t) {
          return this._sendRequest("depth_set_scale", [e, t]);
        }
        unpack(e) {
          return this._dataHandleModule.unpack(e);
        }
        sendRequest(e, t) {
          return this._sendRequest(e, t);
        }
        setVisibleTimeRange() {
          throw new Error(
            "setVisibleTimeRange is deprecated and should not be used"
          );
        }
        _init() {
          (this._notificationHandlers = {}),
            (this._studyCounter = {}),
            (this._childStudyCounter = {}),
            (this._fundamentalCounter = {}),
            (this._modifyStudyMap = new Map());
        }
        _checkAuthTokenExpiration(e) {
          0 === this._sendingQueuedRequestsCount &&
            this._authTokenManager &&
            !this._authTokenManager.currentTokenIsValid() &&
            ($.logInfo(e), this._authTokenManager.reset());
        }
        _sendRequest(e, t) {
          return (
            this._checkAuthTokenExpiration(
              "AuthToken invalidation detected on sending a message, requesting new token"
            ),
            0 !== this._sendingQueuedRequestsCount
              ? (this._pendingMessagesQueue.push({ method: e, args: t }), !0)
              : this._sendRequestImpl(e, t)
          );
        }
        _sendRequestImpl(e, t) {
          const s = this._sentMethodsCounters.get(e) ?? 0;
          this._sentMethodsCounters.set(e, s + 1);
          const i = this._dataHandleModule[e].apply(this._dataHandleModule, t),
            r = { m: e, p: (0, o.default)(i) },
            l = r.m.includes("study") && r.p[5];
          l &&
            (function (e) {
              if (!(0, d.isObject)(e)) return !1;
              for (const t of Object.keys(e)) {
                const s = e[t];
                if (
                  !(
                    (0, d.isObject)(s) ||
                    (0, a.default)(s) ||
                    (0, n.default)(s) ||
                    (0, _.default)(s)
                  )
                )
                  return !1;
              }
              return !0;
            })(l) &&
            "text" in l &&
            (l.text = l.text.slice(0, 10));
          const c = JSON.stringify(r);
          if (i.length > 0) {
            const e = i[0];
            e.startsWith("qs_")
              ? K.logNormal("send: " + c)
              : e.startsWith("cs_") && G.logNormal("send: " + c, 4096);
          } else $.logNormal("send: " + c);
          const u = this._dataHandleModule.prepareEncodeMessage(e, i);
          return this._wsBackendConnection.send(u);
        }
        _onConnect() {
          if (this.connected()) return;
          if (
            ((this._trafficStats.sinceConnect = 0),
            (this._isAuthTokenLoaded = !1),
            (this._connectOnlyOptions = this._connectOnlyOptions || {}),
            (this._authTokenDfd = this._getAuthTokenDfd(
              this._connectOnlyOptions.tokenGrabSession
            )),
            (this._connectOnlyOptions = {}),
            (this.sessionid = this._wsBackendConnection.getSessionId()),
            !this.sessionid || this._isConnected)
          )
            return;
          (this._pendingMessagesQueue = []),
            (this._sendingQueuedRequestsCount = 0),
            (this._studyCounter = {}),
            (this._childStudyCounter = {}),
            (this._fundamentalCounter = {}),
            this._studySpecs.clear(),
            (this._isConnected = !0),
            this._banInfo.setValue(null),
            this._connectionsLimitReached.setValue(!1);
          const e = JSON.parse(this.sessionid);
          this._sendLowQualityModeIfEnabled(),
            (this._metadataServerHash = e.studies_metadata_hash || null);
          const t = this._wsBackendConnection.getConnectionEstablished();
          try {
            this._serverTimeBasePoint = Math.round(e.timestampMs - t);
          } catch (e) {
            this._serverTimeBasePoint = Date.now() - performance.now();
          }
          if (
            ($.logInfo(
              "Time shift with server: " +
                this._formatTime(this.serverTime() - Date.now())
            ),
            this._authTokenDfd)
          ) {
            (this._sendingQueuedRequestsCount += 1),
              $.logInfo("Wait for auth token before send messages");
            const e = this._authTokenDfd;
            e.then((t) => {
              if (null !== this._authTokenDfd && this._authTokenDfd === e) {
                if (
                  ($.logNormal(
                    "Auth token request is finished, token: " + Boolean(t)
                  ),
                  (this._authTokenDfd = null),
                  t)
                ) {
                  const e = [{ method: "set_auth_token", args: [t] }];
                  if (J) {
                    const t = (0, L.getInitDataField)("currentLocaleInfo");
                    t &&
                      e.push({
                        method: "set_locale",
                        args: [t.iso, t.flag.toUpperCase()],
                      });
                  }
                  this._pendingMessagesQueue.unshift(...e);
                }
                this._onSendingQueueRequestFinished(),
                  (this._isAuthTokenLoaded = !0),
                  this._notifySessions({ method: m.Connected, params: [] });
              } else
                $.logNormal(
                  "Comes auth token after requesting new token or after socket disconnected"
                );
            }).catch((e) => {
              $.logNormal((0, E.errorToString)(e));
            });
          } else
            $.logWarn("Deferred auth token object is not valid"),
              (this._isAuthTokenLoaded = !0);
          "" !== this._brokerId && this._sendBrokerIdToSession(this._brokerId);
          const s = this._wsBackendConnection.getConnectionStart();
          P.telemetry.setSessionInfo(this.sessionid),
            P.telemetry.sendChartReport("websocket_connected"),
            P.telemetry.sendChartReport("websocket_connection_time_frame", {
              value: t - s,
            }),
            P.telemetry.sendChartReport("reconnect_count_frame", {
              value: this._wsBackendConnection.getReconnectCount(),
            }),
            P.telemetry.sendChartReport("redirect_count_frame", {
              value: this._wsBackendConnection.getRedirectCount(),
            }),
            ee ||
              ((ee = !0),
              P.telemetry.sendChartReport(
                "before_websocket_connection_time_frame",
                { value: s }
              )),
            this._wsBackendConnection.resetCounters(),
            clearTimeout(this._telemetryDisconnectTimeout);
        }
        _formatTime(e) {
          return `${(e / 1e3).toFixed(2)} seconds.`;
        }
        _dispatchNotification(e, t) {
          if (
            "request_data_problems" === e.method &&
            this._onDataProblemsPromiseCb
          )
            return void this._onDataProblemsPromiseCb(e.params);
          if (
            e.method === q.StudiesMetadata &&
            null !== this._metadataDeferredPromise
          )
            return void this._processedMetadata(e);
          const s = e.params.shift();
          if (!this._notificationHandlers[s]) return;
          if ("symbol_resolved" === e.method) {
            const t = e.params[1].full_name;
            P.telemetry.sendChartReport("symbol_resolved", {
              count: 1,
              additional: { symbol: t },
            });
            const i = P.telemetry.timeCounters.series["resolve_symbol_" + s];
            "number" == typeof i &&
              P.telemetry.sendChartReport("symbol_resolve_time_frame", {
                value: window.performance.now() - i,
                additional: { symbol: t },
              });
          }
          if (
            ["series_error", "series_completed"].includes(e.method) &&
            P.telemetry.timeCounters.series.marks.length > 0
          ) {
            const e = "create_series_" + s,
              t = P.telemetry.timeCounters.series.marks.indexOf(e);
            t >= 0 && P.telemetry.timeCounters.series.marks.splice(t, 1);
          }
          se || "series_error" !== e.method || (se = !0);
          const i = this._wsBackendConnection.getConnectionEstablished();
          if (
            (null !== i &&
              "series_completed" === e.method &&
              (se ||
                ((se = !0),
                P.telemetry.sendChartReport("first_series_full_time_frame", {
                  value: window.performance.now() - i,
                }),
                (P.telemetry.timeCounters.series.marks = [])),
              te ||
                ((te = !0),
                P.telemetry.sendChartReport("page_full_load_time_frame", {
                  value: window.performance.now(),
                }))),
            s.startsWith("cs_"))
          ) {
            let s = "recv: " + t;
            "data_update" === e.method
              ? ((s = (0, h.isHighRateEnabled)() ? s : s.slice(0, 500)),
                W.logNormal(this._appendDuration(s, e.time)))
              : "study_loading" === e.method
              ? z.logNormal(this._appendDuration(s, e.time))
              : "tickmark_update" === e.method
              ? Q.logNormal(this._appendDuration(s, e.time))
              : G.logNormal(this._appendDuration(s, e.time));
          }
          if (s.startsWith("qs_")) {
            ("quote_symbol_data" === e.method ? X.logNormal : K.logNormal)(
              "recv: " + t
            );
          }
          switch (e.method) {
            case q.TimeScaleUpdate: {
              const t = this._dataHandleModule.getTimescaleObjects(e),
                i = this._dataHandleModule.getTimescaleChangeset(e),
                o = this._convertTimescaleResponse(i);
              this._sessions[s].onMessage({
                method: q.TimeScaleUpdate,
                params: o,
              }),
                this._dataHandleModule.prepareDataUpdateObjects(
                  s,
                  t,
                  (e, t, s) => {
                    this._invokeNotificationHandler(e, t, s);
                  }
                );
              break;
            }
            case "tickmark_update":
              const t = {
                ...this._convertTimescaleResponse(e.params[0]),
                changes: [],
              };
              this._sessions[s].onMessage({
                method: q.TimeScaleUpdate,
                params: t,
              });
              break;
            case q.DataUpdate: {
              const t = this._dataHandleModule.getDataUpdateObjects(e);
              this._dataHandleModule.prepareDataUpdateObjects(
                s,
                t,
                (e, t, s) => {
                  this._invokeNotificationHandler(e, t, s);
                }
              );
              break;
            }
            case "index_update":
              for (const t in e.params[0])
                if (e.params[0].hasOwnProperty(t)) {
                  const i = { method: "index_update", params: e.params[0][t] };
                  this._invokeNotificationHandler(s, t, i);
                }
              break;
            case M.CriticalError:
              $.logInfo(
                new Date() +
                  " critical_error session:" +
                  this.sessionid +
                  " reason:" +
                  e.params[0]
              ),
                P.telemetry.sendChartReport("critical_error"),
                this._sessions[s].onMessage({
                  method: M.CriticalError,
                  params: e.params,
                });
              break;
            case "timescale_completed":
            case "quote_symbol_data":
            case "quote_list_fields":
            case "quote_completed":
            case "depth_symbol_error":
            case "depth_symbol_success":
            case "dd":
            case "dpu":
            case "depth_bar_last_value":
              this._sessions[s].onMessage({
                method: e.method,
                params: e.params,
              });
              break;
            case "clear_data":
              for (const t in e.params[0])
                e.params[0].hasOwnProperty(t) &&
                  this._invokeNotificationHandler(s, t, {
                    method: q.ClearData,
                    params: e.params[0][t],
                  });
              break;
            case U.ReplayPoint:
            case U.ReplayResolutions:
            case U.ReplayDataEnd:
            case U.ReplayInstanceId:
            case U.ReplayDepth:
            case U.ReplayError:
            case U.ReplayOk:
              this._sessions[s].onMessage(e);
              break;
            case "series_timeframe":
              const i = e.params[4];
              (e.params[4] =
                null == i ? null : (0, p.convertStrToTimeFrame)(i)),
                this._invokeNotificationHandler(s, e.params[0], e);
              break;
            case "symbol_resolved":
              !(function (e) {
                if (void 0 === e.corrections) {
                  const t = (e.subsessions ?? []).find(
                    (t) => t.id === e.subsession_id
                  );
                  void 0 !== t && (e.corrections = t["session-correction"]);
                }
              })(e.params[1]),
                this._invokeNotificationHandler(s, e.params[0], e);
              break;
            default:
              this._invokeNotificationHandler(s, e.params[0], e);
          }
        }
        _notifySessions(e) {
          for (const t in this._sessions)
            if (this._sessions.hasOwnProperty(t)) {
              const s = this._sessions[t];
              "function" == typeof s.onMessage && s.onMessage(e);
            }
        }
        _onMessage(e) {
          this._checkAuthTokenExpiration(
            "AuthToken invalidation detected on receiving a message, requesting new token"
          ),
            this._calcTrafficStats(e);
          const t = this.unpack(e);
          this._receivedMethodsCounters.set(
            t.method,
            (this._receivedMethodsCounters.get(t.method) ?? 0) + 1
          ),
            "t_ms" in t &&
              (0, n.default)(t.t_ms) &&
              this.compensateConnectionLag(t.t_ms),
            "protocol_switched" !== t.method
              ? "protocol_error" !== t.method
                ? this._dispatchNotification(t, e)
                : this._processProtocolError(t)
              : $.logError(
                  "Unexpected protocol changing request, try skipping. Requested protocol:" +
                    t.params[0]
                );
        }
        async _processedMetadata(e) {
          const t = (0, l.ensureNotNull)(this._metadataDeferredPromise),
            s = await this._initCachePromise,
            i = v.shopConfService.hash(),
            r = (0, f.isFeaturesetEnabled)("widget");
          try {
            await s.setValue(ce, (0, o.default)(e));
            const n = Array.from(
              new Set(
                e.params[1].metainfo.map((e) => {
                  return `${(t = (0, T.parseIdString)(e.id)).packageId}-${
                    t.version
                  }`;
                  var t;
                })
              )
            );
            if (
              ($.logNormal(
                `Updated studies_metadata cache, unique package ids: ${n.join(
                  ", "
                )}`
              ),
              !r)
            )
              try {
                await s.setValue(de, (0, o.default)(i)),
                  $.logNormal("Updated pro_hash cache");
              } catch (e) {
                t.reject(),
                  $.logError("Cannot update pro_hash cache, reason: " + e);
              }
          } catch (e) {
            t.reject(),
              $.logError("Cannot update studies_metadata cache, reason: " + e);
          }
          t.resolve((0, o.default)(e));
        }
        _invokeNotificationHandler(e, t, s) {
          if (void 0 === t) return;
          const i = this._notificationHandlers[e][t];
          void 0 !== i &&
            (i.singleShot && delete this._notificationHandlers[e][t],
            i.handler?.(s));
        }
        _convertTimescaleResponse(e) {
          return this._dataHandleModule.convertTimescaleResponse(e);
        }
        _appendDuration(e, t) {
          return t
            ? `${e}, duration: ${this._formatTime(this.serverTime() - 1e3 * t)}`
            : e;
        }
        async _requestMetadata() {
          const e = this._makeNextRequestId();
          j.logNormal(`Requesting metainfo #${e}`);
          const t = (0, l.ensureNotNull)(this._metadataDeferredPromise),
            s = v.shopConfService.hash(),
            i = (0, f.isFeaturesetEnabled)("widget");
          $.logNormal("Requesting pro hash");
          try {
            const r = await this._initCachePromise;
            await r.migrateValue("pro_hash", de), await r.migrateValue(le, ce);
            const n = await r.getValue(de);
            if ((null !== n && n === s) || i) {
              $.logNormal("Pro hash has not changed, requesting from local");
              const i = await r.getValue(ce),
                n = (null !== i && i.params[1].hash) || null;
              if (
                null === n ||
                null === this._metadataServerHash ||
                this._metadataServerHash !== n
              )
                $.logNormal(
                  `Metadata hash has changed (cached: '${n}', server: '${this._metadataServerHash}')`
                ),
                  this._requestMetadataFromServer(e);
              else {
                if (
                  !v.shopConfService.hasPackage("tv-volumebyprice") ||
                  void 0 !==
                    i.params[1].metainfo.find((e) =>
                      e.id.includes("@tv-volumebyprice")
                    )
                )
                  return (
                    $.logNormal("Using studies_metadata from browser cache"),
                    void t.resolve((0, o.default)(i))
                  );
                $.logNormal(
                  `De-sync detected! pro.hash contains VbPR studies, but data from cache doesn't and pro.hash isn't changed, pro.hash=${s}`
                ),
                  this._requestMetadataFromServer(e);
              }
            } else
              $.logNormal(
                `Pro hash has changed (cached: '${n}', current: '${s}')`
              ),
                this._requestMetadataFromServer(e);
          } catch (t) {
            $.logError("Cannot get studies_metadata, reason: " + t),
              this._requestMetadataFromServer(e);
          } finally {
            j.logNormal(`Requesting studies metadata #${e} finished`);
          }
        }
        _makeNextRequestId() {
          return "metadata_" + this._metadataRequestNextNumber++;
        }
        _processProtocolError(e) {
          const t = e.params[0];
          $.logError(`Protocol error. Reason=${t}.`);
          const s =
            t === g.BanReason.General ||
            t === g.BanReason.ByUserId ||
            t === g.BanReason.ByIP;
          s && (this._banInfo.setValue({ reason: t }), this.disconnect());
          const i = "invalid_plan_for_pro_user" === t;
          i && (this._planUpgradeRequired.setValue(!0), this.disconnect());
          const o = "user connections limit reached" === t;
          this._connectionsLimitReached.setValue(o),
            s ||
              o ||
              i ||
              (P.telemetry.sendChartReport("protocol_error"),
              this._protocolError.fire(t));
        }
        _requestMetadataFromServer(e) {
          return (
            $.logNormal("Request studies_metadata from server"),
            this._sendRequest("request_studies_metadata", [e])
          );
        }
        _bindSocketEvents() {
          this.connectDfd = new Promise((e, t) => {
            this._wsBackendConnection.on("connect", () => {
              this._onConnect(), e();
            }),
              this._wsBackendConnection.on(
                "message",
                this._onMessage.bind(this)
              ),
              this._wsBackendConnection.on("disconnect", () => {
                this._authTokenDfd && (this._authTokenDfd = null),
                  this._onDataProblemsPromiseErrback &&
                    this._onDataProblemsPromiseErrback(),
                  (this._isConnected = !1),
                  this._notifySessions({ method: m.Disconnected, params: [] }),
                  this._banInfo.value() ||
                    (this._metadataDeferredPromise = null),
                  (this._disconnectCount = (this._disconnectCount || 0) + 1),
                  this._wsBackendConnection.isConnected() &&
                    ((this._telemetryDisconnectTimeout = setTimeout(() => {
                      P.telemetry.sendChartReport("disconnect");
                    }, 5e3)),
                    this._wsBackendConnection.isMaxReconnects() &&
                      (this._notifySessions({
                        method: m.ReconnectBailout,
                        params: [],
                      }),
                      t(),
                      P.telemetry.sendChartReport("reconnect_bailout")));
              });
          });
        }
        _calcTrafficStats(e) {
          const t = e.length;
          (this._trafficStats.total += t),
            (this._trafficStats.sinceConnect += t),
            (this._trafficStats.lastChunk += t);
        }
        _sendBrokerIdToSession(e) {
          return !Z || this._sendRequest("set_broker", [e]);
        }
        _enableLowQualityMode() {
          $.logNormal("low quality mode is enabled"),
            (this._lowQualityEnabled = !0),
            this._sendLowQualityModeIfEnabled();
        }
        _sendLowQualityModeIfEnabled() {
          this._lowQualityEnabled &&
            this.connected() &&
            this._sendRequest("set_data_quality", []);
        }
        _getAuthTokenDfd(e) {
          if (this._loadNewBars) return Promise.resolve("load_new_token");
          if (
            (0, f.isFeaturesetEnabled)("widget") ||
            -1 !== window.location.search.indexOf("widget_token") ||
            -1 !== window.location.hash.indexOf("widget_token")
          ) {
            const e = (0, i.embedWidgetCustomer)() ?? "";
            return Promise.resolve(
              (0, R.getChartApiSiteConfig)().widgetToken(e)
            );
          }
          if (!window.is_authenticated)
            return Promise.resolve("unauthorized_user_token");
          if (!this._authTokenManager) {
            const e = (this._authTokenManager = new S());
            e.invalidated.subscribe(null, async () => {
              try {
                this._sendingQueuedRequestsCount += 1;
                const t = await e.get();
                if (!t)
                  return void $.logInfo(
                    "AuthToken invalidated, but new token is empty"
                  );
                if (!this.connected())
                  return void $.logInfo(
                    `AuthToken invalidated, but socket is not connected. Token: ${t}`
                  );
                $.logInfo(
                  "AuthToken invalidated, refreshing token and resending to session"
                ),
                  this._sendRequestImpl("set_auth_token", [t]);
              } catch (e) {
                throw (
                  ($.logError(
                    `Failed to refresh auth token after invalidation: ${(0,
                    E.errorToString)(e)}`
                  ),
                  e)
                );
              } finally {
                (this._sendingQueuedRequestsCount -= 1),
                  0 === this._sendingQueuedRequestsCount &&
                    e.currentTokenIsValid() &&
                    this._flushPendingMessages();
              }
            });
          }
          return this._authTokenManager.get(e);
        }
        _onSendingQueueRequestFinished() {
          (this._sendingQueuedRequestsCount -= 1),
            $.logInfo(
              `Sending queue request finished. Remaining pending requests=${this._sendingQueuedRequestsCount}`
            ),
            this._sendingQueuedRequestsCount < 0 &&
              $.logError(
                `Invalid queue state=${this._sendingQueuedRequestsCount}`
              ),
            0 === this._sendingQueuedRequestsCount &&
              this._flushPendingMessages();
        }
        _flushPendingMessages() {
          $.logInfo(
            `Flush pending messages. Count=${this._pendingMessagesQueue.length}`
          ),
            this._pendingMessagesQueue.forEach((e) =>
              this._sendRequest(e.method, e.args)
            ),
            (this._pendingMessagesQueue = []);
        }
        constructor(e) {
          (this.sessionid = null),
            (this._banInfo = new c.WatchedValue(null)),
            (this._isAuthTokenLoaded = !1),
            (this._authTokenDfd = null),
            (this._serverTimeBasePoint = Date.now() - performance.now()),
            (this._initCachePromise = (async function (e) {
              try {
                const t = await caches.open(e);
                return new A(t);
              } catch {
                return new I();
              }
            })("TVChartApi")),
            (this._trafficStats = { total: 0, sinceConnect: 0, lastChunk: 0 }),
            (this._lowQualityEnabled = !1),
            (this._brokerId = ""),
            (this._sendingQueuedRequestsCount = 0),
            (this._modifyStudyMap = new Map()),
            (this._disconnectCount = 0),
            (this._isConnected = !1),
            (this._metadataDeferredPromise = null),
            (this._dataHandleModule = new B()),
            (this._sessions = {}),
            (this._notificationHandlers = {}),
            (this._pendingMessagesQueue = []),
            (this._loadNewBars = !1),
            (this._metadataRequestNextNumber = 1),
            (this._fundamentalCounter = {}),
            (this._studyCounter = {}),
            (this._childStudyCounter = {}),
            (this._studySpecs = new Map()),
            (this._connectionsLimitReached = new c.WatchedValue(!1)),
            (this._planUpgradeRequired = new c.WatchedValue(!1)),
            (this._protocolError = new u.Delegate()),
            (this._sentMethodsCounters = new Map()),
            (this._receivedMethodsCounters = new Map()),
            (this._requestDataProblemsPromise = null),
            (this._wsBackendConnection = e),
            this._wsBackendConnection.onReconnect(
              this._bindSocketEvents.bind(this)
            ),
            this._wsBackendConnection.setLogger($, h.getLogHistory),
            this._wsBackendConnection.setTelemetry(P.telemetry),
            this._bindSocketEvents(),
            (this._isNonCountedStudy = () => !0),
            window?.TradingView?.onChartPage || this._enableLowQualityMode(),
            setInterval(() => {
              Y.logNormal(
                "Last 30 seconds:" +
                  oe(this._trafficStats.lastChunk) +
                  " Since last connect:" +
                  oe(this._trafficStats.sinceConnect) +
                  " Total traffic:" +
                  oe(this._trafficStats.total)
              ),
                (this._trafficStats.lastChunk = 0);
            }, 3e4),
            this._connectionsLimitReached.subscribe((e) => {
              e && this.disconnect();
            });
        }
      }
    },
    179594(e, t, s) {
      s.d(t, { getDefaultResolutions: () => r });
      var i = s(478561),
        o = s(549282);
      function r() {
        const e = [
          "1",
          "3",
          "5",
          "15",
          "30",
          "45",
          "60",
          "120",
          "180",
          "240",
          "1D",
          "1W",
          "1M",
          "3M",
          "6M",
          "12M",
          "1R",
          "10R",
          "100R",
          "1000R",
        ];
        if (!(0, i.isFeaturesetEnabled)("widget")) {
          let t = ["1S", "5S", "10S", "15S", "30S", "45s"];
          return (
            (0, o.isTicksEnabled)() &&
              (t = ["1T", "10T", "100T", "1000T"].concat(t)),
            t.concat(e)
          );
        }
        return e;
      }
    },
    202580(e, t, s) {
      function i() {
        return window.TradingView?.widgetCustomer;
      }
      s.d(t, { embedWidgetCustomer: () => i });
    },
    137139(e, t, s) {
      s.d(t, { LogoSize: () => r.LogoSize, getLogoUrlResolver: () => a });
      var i = s(514154),
        o = s(441992),
        r = s(27631);
      let n;
      function a() {
        if (!n) {
          const e = (0, i.getInitDataField)("settings");
          n = new o.LogoUrlResolver(e?.S3_LOGO_SERVICE_BASE_URL ?? "");
        }
        return n;
      }
    },
    284656(e, t, s) {
      s.d(t, { qaGlobals: () => i });
      const i =
        "undefined" != typeof window
          ? new (class {
              provide(e, t) {
                this._test[e] = t;
              }
              constructor(e, t) {
                this._test = e[t] = {};
              }
            })(window, "qaGlobals")
          : { provide() {} };
    },
    956293(e, t, s) {
      s.d(t, { ProductType: () => i });
      var i = (function (e) {
        return (
          (e[(e.ProPlan = 1)] = "ProPlan"),
          (e[(e.NewsFeed = 3)] = "NewsFeed"),
          (e[(e.Exchange = 4)] = "Exchange"),
          (e[(e.Connection = 6)] = "Connection"),
          (e[(e.Coins = 8)] = "Coins"),
          (e[(e.ScriptPackage = 9)] = "ScriptPackage"),
          (e[(e.AIAddon = 10)] = "AIAddon"),
          e
        );
      })({});
    },
    815414(e, t, s) {
      s.d(t, { ShopConfCatalog: () => o });
      var i = s(956293);
      class o {
        isDiscountProductId(e) {
          return e in this._discounts;
        }
        getProduct(e) {
          if (e in this._products) return this._products[e];
          if (this.isDiscountProductId(e)) {
            const t = this._discounts[e],
              s = { discount_text_id: e, ...this._products[t.product] };
            return this._applyDiscountOverrides(s, t), s;
          }
          return {};
        }
        getDiscountProduct(e) {
          return this._discounts[e] ?? {};
        }
        isOffer(e, t) {
          return Object.keys(this._discounts)
            .filter(
              (e) =>
                !this._discounts[e].expired &&
                this._discounts[e].offer_type === t
            )
            .includes(e);
        }
        getProductsByType(e) {
          return Object.keys(this._products)
            .filter((t) => this._products[t].type === e)
            .map((e) => this.getProduct(e));
        }
        getProPlanProducts() {
          return this.getProductsByType(i.ProductType.ProPlan).filter(
            (e) => !e.is_expert
          );
        }
        getExpertPlanProducts() {
          return this.getProductsByType(i.ProductType.ProPlan).filter(
            (e) => e.is_expert
          );
        }
        getProPlanProductsList() {
          return this.getProPlanProducts().map((e) => e.text_id);
        }
        getExpertPlanProductsList() {
          return this.getExpertPlanProducts().map((e) => e.text_id);
        }
        isExpertProduct(e) {
          return this.getExpertPlanProductsList().includes(e);
        }
        discounts() {
          return this._discounts;
        }
        constructor() {
          (this._products = {}), (this._discounts = {});
        }
      }
    },
    83019(e, t, s) {
      s.d(t, {
        shopConfService: () => c,
      });
      var i = s(570071),
        o = s(819511),
        r = s(384017),
        n = s(514154),
        a = s(956293),
        _ = s(815414);
      const l = [
        "tv-scripting",
        "tv-basicstudies",
        "tv-prostudies",
        "Script$USER",
        "Script$EDGR",
        "ESD$TV",
      ];
      class d extends _.ShopConfCatalog {
        init(e) {
          return this._initialized
            ? (this._logger.logWarn(
                "ShopConfService.init called more than once; keeping the existing state"
              ),
              this)
            : ((this._initialized = !0),
              e
                ? ((this._offers = e.offers ?? []),
                  (this._paidExchanges = e.paid_exchanges ?? []),
                  (this._invalidShopConf = !0),
                  this._deps.subscribeLoginStateChange((e) =>
                    this.onLoginStateChange(e)
                  ),
                  this)
                : this);
        }
        isInitialized() {
          return this._initialized;
        }
        hasPackage(e) {
          return this._offers.includes(e) || l.includes(e);
        }
        async updateShopConf(e = !1) {
          return (
            void 0 !== this._shopConfPromise ||
              (this._shopConfPromise = (0, r.fetch)("/market/shopconf/", {
                credentials: "include",
              })
                .then(async (t) => {
                  const s = await t.json();
                  return (
                    (this._products =
                      (s.all_products && JSON.parse(s.all_products)) || {}),
                    (this._discounts =
                      (s.discounts && JSON.parse(s.discounts)) || {}),
                    (this._offers = (s.offers && JSON.parse(s.offers)) || []),
                    (this._paidExchanges =
                      (s.paid_exchanges && JSON.parse(s.paid_exchanges)) || []),
                    (this._invalidShopConf = !1),
                    (this._shopConfPromise = void 0),
                    e || this.packagesUpdated.fire(),
                    s
                  );
                })
                .catch(() => {
                  throw (
                    (this._logger.logError("Update shopconf error"),
                    (this._shopConfPromise = void 0),
                    Error("Update shopconf error"))
                  );
                })),
            this._shopConfPromise
          );
        }
        invalidateShopConf() {
          this._invalidShopConf = !0;
        }
        isInvalidShopConf() {
          return this._invalidShopConf;
        }
        ensureValidShopConf() {
          return new Promise((e) => this.runOrUpdate(e));
        }
        onLoginStateChange(e) {
          e || this.updateShopConf();
        }
        runOrUpdate(e, t) {
          this.isInvalidShopConf() ? this.updateShopConf(t).then(e) : e();
        }
        getIDCExchanges(e) {
          const t = this._getInitData();
          if (e) {
            if (t.idc_delay_exchanges_list) return t.idc_delay_exchanges_list;
          } else if (t.idc_exchanges_list) return t.idc_exchanges_list;
          return Object.keys(this._products)
            .filter((t) => {
              const s = this._products[t];
              return (
                s.type === a.ProductType.Exchange &&
                (e ? s.idc_service_codes_delay : s.idc_service_codes)
              );
            })
            .map((e) => this._products[e].exchange);
        }
        async findProduct(e) {
          if (this.isInvalidShopConf())
            try {
              await this.updateShopConf();
            } catch {}
          return this.getProduct(e);
        }
        getUserExchanges() {
          return this._offers
            .map((e) => this.getProduct(e))
            .filter((e) => e.type === a.ProductType.Exchange);
        }
        getUserPaidExchanges() {
          return this._paidExchanges.map((e) => this.getProduct(e));
        }
        getUserExchangeByPerm(e) {
          return this.getUserExchanges().find((t) => t.exchange === e);
        }
        getExchange(e) {
          const t = this.getProductsByType(a.ProductType.Exchange);
          let s;
          for (let i = 0; i < t.length; i += 1)
            if (
              ((s = t[i]),
              s.exchange === e ||
                (s.included_exchanges && s.included_exchanges.includes(e)))
            )
              return s;
          return {};
        }
        getPaidExchangesForProfessional() {
          return this.getProductsByType(a.ProductType.Exchange).filter(
            (e) => e.paid_for_expert
          );
        }
        offers() {
          return this._offers;
        }
        paidExchanges() {
          return this._paidExchanges;
        }
        hash() {
          const e = this._offers.slice(0);
          return e.sort(), JSON.stringify({ offers: e });
        }
        _applyDiscountOverrides(e, t) {
          void 0 !== t.fixed_cost && (e.fixed_cost = t.fixed_cost),
            void 0 !== t.extra_days && (e.extra_days = t.extra_days),
            void 0 !== t.billing_cycle && (e.billing_cycle = t.billing_cycle),
            void 0 !== t.next_billing_cycle &&
              (e.next_billing_cycle = t.next_billing_cycle);
        }
        _getInitData() {
          return (
            void 0 === this._initDataCache &&
              (this._initDataCache = {
                idc_exchanges_list: (0, n.getInitDataField)(
                  "idc_exchanges_list"
                ),
                idc_delay_exchanges_list: (0, n.getInitDataField)(
                  "idc_delay_exchanges_list"
                ),
              }),
            this._initDataCache
          );
        }
        constructor(e) {
          super(),
            (this.packagesUpdated = new i.Delegate()),
            (this.PRODUCT_TYPES = {
              pro_plan: a.ProductType.ProPlan,
              exchange: a.ProductType.Exchange,
              connection: a.ProductType.Connection,
              coins: a.ProductType.Coins,
            }),
            (this._logger = (0, o.getLogger)("Platform.ShopConf")),
            (this._offers = []),
            (this._paidExchanges = []),
            (this._invalidShopConf = !1),
            (this._initialized = !1),
            (this._deps = e);
        }
      }
      const c = new d({
        subscribeLoginStateChange: (e) => {
          window.loginStateChange.subscribe(null, e);
        },
      });
    },
    910327(e, t, s) {
      s.d(t, { getProductForTrial: () => o, isTrialProduct: () => r });
      var i = s(389086);
      function o(e) {
        return e.split(i.TRIAL_SUFFIX)[0];
      }
      function r(e) {
        return new RegExp(i.TRIAL_SUFFIX + "$").test(e);
      }
    },
    489489(e, t, s) {
      function i(e, t, s, i, o) {
        let r = "";
        if (((i = i ? "; path=" + i : ""), (o = o ? "; domain=" + o : ""), s)) {
          const e = new Date();
          e.setTime(e.getTime() + 24 * s * 60 * 60 * 1e3),
            (r = "; expires=" + e.toUTCString());
        } else r = "";
        document.cookie = e + "=" + t + r + o + i;
      }
      function o(e) {
        const t = e + "=",
          s = document.cookie.split(";");
        for (let e = 0; e < s.length; e++) {
          let i = s[e];
          for (; " " === i.charAt(0); ) i = i.substring(1, i.length);
          if (0 === i.indexOf(t)) return i.substring(t.length, i.length);
        }
        return null;
      }
      s.d(t, { get: () => o, set: () => i });
    },
    359239(e, t, s) {
      function i() {
        let e, t;
        return {
          promise: new Promise((s, i) => {
            (e = s), (t = i);
          }),
          reject: t,
          resolve: e,
        };
      }
      s.d(t, { createDeferredPromise: () => i });
    },
    771405(e, t, s) {
      function i(e, t = !1) {
        "loading" !== document.readyState
          ? t
            ? setTimeout(() => e(), 1)
            : e()
          : document.addEventListener("DOMContentLoaded", () => e());
      }
      s.d(t, { whenDocumentReady: () => i });
      new Promise((e) => {
        i(e);
      });
    },
    415100(e, t, s) {
      function i(e) {
        if (void 0 === e) return "";
        if (e instanceof Error) {
          let t = e.message;
          return e.stack && (t += " " + e.stack), t;
        }
        return "string" == typeof e ? e.toString() : JSON.stringify(e);
      }
      s.d(t, { errorToString: () => i });
    },
    27631(e, t, s) {
      s.d(t, { LogoSize: () => i });
      var i = (function (e) {
        return (e[(e.Medium = 0)] = "Medium"), (e[(e.Large = 1)] = "Large"), e;
      })({});
    },
    441992(e, t, s) {
      s.d(t, { LogoUrlResolver: () => a });
      var i = s(819511),
        o = s(146961),
        r = s(27631);
      const n = (0, i.getLogger)("LogoUrlResolver");
      class a {
        getSymbolLogoUrl(e, t) {
          if ("" === e)
            return n.logWarn("logo id must be a non-empty string"), "";
          switch (t) {
            case r.LogoSize.Medium:
              return this._baseUrl + `${e}.svg`;
            case r.LogoSize.Large:
              return this._baseUrl + `${e}--big.svg`;
          }
        }
        getCountryFlagUrl(e, t) {
          return this.getSymbolLogoUrl("country/" + e, t);
        }
        getProviderLogoUrl(e, t) {
          return this.getSymbolLogoUrl("provider/" + e, t);
        }
        getSourceLogoUrl(e, t) {
          return this.getSymbolLogoUrl("source/" + e, t);
        }
        getBlockchainContractLogoUrl(e, t) {
          return this.getSymbolLogoUrl("blockchain/" + e, t);
        }
        getCandlestickPatternLogoUrl(e, t = "light") {
          return this.getSymbolLogoUrl(
            `candlepattern/${e}-${t}`,
            r.LogoSize.Medium
          );
        }
        constructor(e) {
          (0, o.assert)("" !== e, "S3 base url must be a non-empty string"),
            (this._baseUrl = e);
        }
      }
    },
    863150(e, t, s) {
      function i(e, t, s) {
        if (t(e.value())) return void s();
        const i = (o) => {
          t(o) && (e.unsubscribe(i), s());
        };
        e.subscribe(i, {
          callWithLast: !0,
        });
      }
      s.d(t, { callWhen: () => i });
    },
    933142(e, t, s) {
      s.d(t, { getIsoLanguageCodeFromLanguage: () => o });
      const i = {
        ar_AE: "ar",
        br: "pt",
        de_DE: "de",
        ca_ES: "ca",
        he_IL: "he",
        id_ID: "id",
        in: "en",
        kr: "ko",
        ms_MY: "ms",
        sv_SE: "sv",
        th_TH: "th",
        uk: "en",
        vi_VN: "vi",
        zh_CN: "zh-Hans",
        zh_TW: "zh-Hant",
        zh: "zh-Hans",
        hu_HU: "hu-HU",
      };
      function o(e) {
        return i[e] || e;
      }
    },
    554741(e, t, s) {
      s.d(t, { BanReason: () => i });
      var i = (function (e) {
        return (
          (e.General = "banned"),
          (e.ByUserId = "banned by user_id"),
          (e.ByIP = "banned by ip"),
          e
        );
      })({});
    },
    695807(e, t, s) {
      function i(e) {
        const t = {};
        if (-1 === e.indexOf("@"))
          (t.shortId = e),
            (t.packageId = "tv-basicstudies"),
            (t.id = e + "@" + t.packageId),
            (t.version = 1);
        else {
          const s = e.split("@");
          t.shortId = s[0];
          const i = s[1].split("-");
          if (3 === i.length)
            (t.packageId = i.slice(0, 2).join("-")),
              (t.id = t.shortId + "@" + t.packageId),
              (t.version = parseInt(i[2]));
          else if (1 === i.length && "decisionbar" === i[0])
            (t.packageId = "les-" + i[0]),
              (t.id = t.shortId + "@" + t.packageId),
              (t.version = 1);
          else {
            if (1 !== i.length) throw new Error("unexpected study id:" + e);
            (t.packageId = "tv-" + i[0]),
              (t.id = t.shortId + "@" + t.packageId),
              (t.version = 1);
          }
        }
        if (
          ((t.fullId = t.id + "-" + t.version), "tv-scripting" === t.packageId)
        ) {
          const e = t.shortId;
          if (
            0 === e.indexOf("Script$") ||
            0 === e.indexOf("StrategyScript$")
          ) {
            const s = e.indexOf("_");
            t.productId = s >= 0 ? e.substring(0, s) : t.packageId;
          } else t.productId = t.packageId;
        } else t.productId = t.packageId;
        return t;
      }
      s.d(t, { parseIdString: () => i });
    },
    558948(e) {
      e.exports = JSON.parse(
        '{"14851":{},"custom_items_in_context_menu":{},"countdown":{},"symbol_search_parser_mixin":{},"pay_attention_to_ticker_not_symbol":{},"graying_disabled_tools_enabled":{},"update_study_formatter_on_symbol_resolve":{},"constraint_dialogs_movement":{},"phone_verification":{},"native_sse_private":{},"show_trading_notifications_history":{},"show_interval_dialog_on_key_press":{},"header_interval_dialog_button":{"subsets":["show_interval_dialog_on_key_press"]},"header_fullscreen_button":{},"header_symbol_search":{},"symbol_search_hot_key":{},"header_resolutions":{"subsets":["header_interval_dialog_button"]},"header_chart_type":{},"header_settings":{},"header_indicators":{},"header_compare":{},"header_undo_redo":{},"header_quick_search":{},"header_screenshot":{},"header_saveload":{},"study_on_study":{},"scales_date_format":{},"scales_time_hours_format":{},"header_widget":{"subsets":["header_widget_dom_node","header_symbol_search","header_resolutions","header_chart_type","header_settings","header_indicators","header_compare","header_undo_redo","header_quick_search","header_fullscreen_button","compare_symbol","header_screenshot"]},"legend_widget":{},"compare_symbol":{"subsets":["header_compare"]},"property_pages":{"subsets":["show_chart_property_page","chart_property_page"]},"show_chart_property_page":{},"chart_property_page":{"subsets":["chart_property_page_scales","chart_property_page_trading","chart_property_page_right_margin_editor"]},"left_toolbar":{},"right_toolbar":{},"hide_left_toolbar_by_default":{},"control_bar":{},"widget_logo":{},"timeframes_toolbar":{},"edit_buttons_in_legend":{"subsets":["show_hide_button_in_legend","format_button_in_legend","study_buttons_in_legend","delete_button_in_legend","legend_inplace_edit"]},"show_hide_button_in_legend":{},"object_tree_legend_mode":{},"format_button_in_legend":{},"study_buttons_in_legend":{},"delete_button_in_legend":{},"legend_inplace_edit":{},"broker_button":{},"buy_sell_buttons":{"subsets":["broker_button"]},"show_buy_sell_buttons_on_unsupported_resolution":{},"always_require_order_confirmation":{},"pane_context_menu":{},"scales_context_menu":{},"legend_context_menu":{},"context_menus":{"subsets":["pane_context_menu","scales_context_menu","legend_context_menu","objects_tree_context_menu"]},"items_favoriting":{},"save_chart_properties_to_local_storage":{},"use_localstorage_for_settings":{"subsets":["items_favoriting","save_chart_properties_to_local_storage"]},"handle_scale":{"subsets":["mouse_wheel_scale","pinch_scale","axis_pressed_mouse_move_scale"]},"handle_scroll":{"subsets":["mouse_wheel_scroll","pressed_mouse_move_scroll","horz_touch_drag_scroll","vert_touch_drag_scroll"]},"plain_studymarket":{},"disable_resolution_rebuild":{},"border_around_the_chart":{},"charting_library_debug_mode":{},"saveload_requires_authentication":{},"saveload_storage_customization":{},"volume_force_overlay":{},"create_volume_indicator_by_default":{},"create_volume_indicator_by_default_once":{},"saved_charts_count_restriction":{},"lean_chart_load":{},"stop_study_on_restart":{},"star_some_intervals_by_default":{},"move_logo_to_main_pane":{},"show_animated_logo":{},"link_to_tradingview":{},"logo_without_link":{},"logo_always_maximized":{},"right_bar_stays_on_scroll":{},"chart_content_overrides_by_defaults":{},"snapshot_trading_drawings":{},"allow_supported_resolutions_set_only":{},"widgetbar_tabs":{"subsets":["right_toolbar"]},"show_object_tree":{"subsets":["right_toolbar"]},"dom_widget":{"subsets":["right_toolbar"]},"dom_raw_volume_values":{},"collapsible_header":{},"study_templates":{},"keep_selected_group_on_tool_creation":{},"side_toolbar_in_fullscreen_mode":{},"header_in_fullscreen_mode":{},"remove_library_container_border":{},"whotrades_auth_only":{},"support_multicharts":{},"display_market_status":{},"display_data_mode":{},"datasource_copypaste":{},"drawing_templates":{"subsets":["linetoolpropertieswidget_template_button"]},"expand_symbolsearch_items":{},"symbol_search_three_columns_exchanges":{},"symbol_search_flags":{},"symbol_search_limited_exchanges":{},"bugreport_button":{"subsets":["right_toolbar"]},"header_trade_button":{},"symbol_search_highlight_active_symbol":{},"footer_publish_idea_button":{},"text_notes":{},"show_source_code":{},"symbol_info":{},"no_bars_status":{},"clear_bars_on_series_error":{},"hide_loading_screen_on_series_error":{},"seconds_resolution":{},"dont_show_boolean_study_arguments":{},"hide_last_na_study_output":{},"price_scale_always_last_bar_value":{},"study_dialog_fundamentals_economy_addons":{},"uppercase_instrument_names":{},"trading_notifications":{},"chart_crosshair_menu":{},"japanese_chart_styles":{},"hide_series_legend_item":{},"hide_study_overlay_legend_item":{},"hide_study_compare_legend_item":{},"linetoolpropertieswidget_template_button":{},"use_overrides_for_overlay":{},"timezone_menu":{},"main_series_scale_menu":{},"show_login_dialog":{},"remove_img_from_rss":{},"bars_marks":{},"chart_scroll":{},"chart_zoom":{},"source_selection_markers":{},"low_density_bars":{},"end_of_period_timescale_marks":{},"open_account_manager":{},"show_order_panel_on_start":{},"order_panel":{"subsets":["order_panel_close_button","order_panel_undock","right_toolbar","order_info"]},"multiple_watchlists":{},"watchlist_import_export":{},"study_overlay_compare_legend_option":{},"mobile_app_action_open_details_webview":{},"custom_resolutions":{},"referral_program_for_widget_owners":{},"mobile_trading":{},"real_brokers":{},"quick_trading_panel":{},"native_mobile_brokers_list":{},"no_min_chart_width":{},"lock_visible_time_range_on_resize":{},"pricescale_currency":{},"cropped_tick_marks":{},"trading_account_manager":{},"disable_sameinterval_aligning":{},"display_legend_on_all_charts":{},"chart_style_hilo":{},"chart_style_hilo_last_price":{},"pricescale_unit":{},"show_spread_operators":{},"hide_exponentiation_spread_operator":{},"hide_reciprocal_spread_operator":{},"compare_symbol_search_spread_operators":{},"studies_symbol_search_spread_operators":{},"hide_resolution_in_legend":{},"hide_unresolved_symbols_in_legend":{},"fix_left_edge":{},"study_symbol_ticker_description":{},"two_character_bar_marks_labels":{},"pin_bar_mark_tooltips_on_click":{},"tick_resolution":{},"secondary_series_extend_time_scale":{},"hide_volume_ma":{},"small_no_display":{},"charting_library_single_symbol_request":{},"use_ticker_on_symbol_info_update":{},"show_zoom_and_move_buttons_on_touch":{},"hide_main_series_symbol_from_indicator_legend":{},"chart_hide_close_position_button":{},"chart_hide_close_order_button":{},"hide_price_scale_global_last_bar_value":{"subsets":["use_last_visible_bar_value_in_legend"]},"keep_object_tree_widget_in_right_toolbar":{},"show_average_close_price_line_and_label":{},"hide_image_invalid_symbol":{},"hide_object_tree_and_price_scale_exchange_label":{},"confirm_overwrite_if_chart_layout_with_name_exists":{},"determine_first_data_request_size_using_visible_range":{},"use_na_string_for_not_available_values":{},"show_last_price_and_change_only_in_series_legend":{},"legend_last_day_change":{},"iframe_loading_compatibility_mode":{},"show_percent_option_for_right_margin":{},"watchlist_context_menu":{},"accessible_keyboard_shortcuts":{},"advanced_emoji_in_titles":{},"app_phone":{},"app_tablet":{},"mobile_app_hide_replay_toolbar":{},"symbol_search_option_chain_selector":{},"show_native_symbol_search_on_tap_in_legend":{},"show_native_symbol_search_on_non_tradable":{},"show_new_menu_items_in_chart_menus":{},"pre_post_market_price_line":{},"pre_post_market_sessions":{},"studies_extend_time_scale":{},"inactivity_gaps":{},"align_dwm_bars_to_main_series":{},"request_only_visible_range_on_reset":{},"extended_extrapolation_limit":{},"tv_production":{"subsets":["watchlist_sections","advanced_emoji_in_titles","auto_enable_symbol_labels","symbol_search_parser_mixin","header_fullscreen_button","header_widget","dont_show_boolean_study_arguments","left_toolbar","right_toolbar","buy_sell_buttons","control_bar","symbol_search_hot_key","context_menus","edit_buttons_in_legend","object_tree_legend_mode","uppercase_instrument_names","use_localstorage_for_settings","saveload_requires_authentication","volume_force_overlay","saved_charts_count_restriction","create_volume_indicator_by_default","create_volume_indicator_by_default_once","charts_auto_save","save_old_chart_before_save_as","chart_content_overrides_by_defaults","alerts","header_saveload","header_layouttoggle","datasource_copypaste","show_saved_watchlists","watchlists_from_to_file","add_to_watchlist","property_pages","support_multicharts","display_market_status","display_data_mode","show_chart_warn_message","support_manage_drawings","widgetbar_tabs","study_templates","collapsible_header","drawing_templates","header_trade_button","symbol_search_highlight_active_symbol","footer_publish_idea_button","text_notes","show_source_code","symbol_info","linetoolpropertieswidget_template_button","trading_notifications","symbol_search_three_columns_exchanges","symbol_search_flags","symbol_search_limited_exchanges","phone_verification","custom_resolutions","compare_symbol","study_on_study","japanese_chart_styles","show_login_dialog","dom_widget","bars_marks","chart_scroll","chart_zoom","show_trading_notifications_history","source_selection_markers","study_dialog_fundamentals_economy_addons","multiple_watchlists","marked_symbols","order_panel","pricescale_currency","show_animated_logo","pricescale_currency","show_object_tree","watchlist_import_export","scales_date_format","scales_time_hours_format","popup_hints","show_right_widgets_panel_by_default","compare_recent_symbols_enabled","chart_style_hilo_last_price","symbol_search_option_chain_selector","show_new_menu_items_in_chart_menus","keep_selected_group_on_tool_creation"]},"widget":{"subsets":["auto_enable_symbol_labels","symbol_search_parser_mixin","uppercase_instrument_names","left_toolbar","right_toolbar","control_bar","symbol_search_hot_key","context_menus","edit_buttons_in_legend","object_tree_legend_mode","use_localstorage_for_settings","saveload_requires_authentication","volume_force_overlay","create_volume_indicator_by_default","create_volume_indicator_by_default_once","dont_show_boolean_study_arguments","header_widget_dom_node","header_symbol_search","header_resolutions","header_chart_type","header_compare","header_indicators","star_some_intervals_by_default","display_market_status","display_data_mode","show_chart_warn_message","symbol_info","linetoolpropertieswidget_template_button","symbol_search_three_columns_exchanges","symbol_search_flags","symbol_search_limited_exchanges","widgetbar_tabs","compare_symbol","show_login_dialog","plain_studymarket","japanese_chart_styles","bars_marks","chart_scroll","chart_zoom","source_selection_markers","property_pages","show_right_widgets_panel_by_default","chart_style_hilo_last_price","symbol_search_highlight_active_symbol"]},"bovespa_widget":{"subsets":["widget","header_settings","linetoolpropertieswidget_template_button","compare_recent_symbols_enabled"]},"charting_library_base":{"subsets":["14851","allow_supported_resolutions_set_only","auto_enable_symbol_labels","border_around_the_chart","collapsible_header","constraint_dialogs_movement","context_menus","control_bar","create_volume_indicator_by_default","custom_items_in_context_menu","datasource_copypaste","uppercase_instrument_names","display_market_status","edit_buttons_in_legend","object_tree_legend_mode","graying_disabled_tools_enabled","header_widget","legend_widget","header_saveload","dont_show_boolean_study_arguments","lean_chart_load","left_toolbar","right_toolbar","link_to_tradingview","pay_attention_to_ticker_not_symbol","plain_studymarket","refresh_saved_charts_list_on_dialog_show","right_bar_stays_on_scroll","saveload_storage_customization","stop_study_on_restart","timeframes_toolbar","symbol_search_hot_key","update_study_formatter_on_symbol_resolve","update_timeframes_set_on_symbol_resolve","use_localstorage_for_settings","volume_force_overlay","widget_logo","countdown","use_overrides_for_overlay","trading_notifications","compare_symbol","symbol_info","timezone_menu","main_series_scale_menu","create_volume_indicator_by_default_once","bars_marks","chart_scroll","chart_zoom","source_selection_markers","property_pages","go_to_date","adaptive_logo","show_animated_logo","handle_scale","handle_scroll","shift_visible_range_on_new_bar","chart_content_overrides_by_defaults","cropped_tick_marks","scales_date_format","scales_time_hours_format","popup_hints","save_shortcut","show_right_widgets_panel_by_default","show_object_tree","insert_indicator_dialog_shortcut","compare_recent_symbols_enabled","hide_main_series_symbol_from_indicator_legend","chart_style_hilo","request_only_visible_range_on_reset","clear_price_scale_on_error_or_empty_bars","show_symbol_logo_in_legend","show_symbol_logo_for_compare_studies","library_custom_color_themes","long_press_floating_tooltip","symbol_search_highlight_active_symbol"]},"charting_library":{"subsets":["charting_library_base"]},"static_charts_service":{"subsets":["charting_library","disable_resolution_rebuild"]},"trading_terminal":{"subsets":["charting_library_base","support_multicharts","header_layouttoggle","japanese_chart_styles","chart_property_page_trading","add_to_watchlist","open_account_manager","show_dom_first_time","order_panel","buy_sell_buttons","multiple_watchlists","show_trading_notifications_history","always_pass_called_order_to_modify","show_object_tree","watchlist_import_export","drawing_templates","trading_account_manager","chart_crosshair_menu","compare_recent_symbols_enabled","watchlist_context_menu","show_symbol_logo_in_account_manager","show_symbol_logo_in_close_position_dialog","show_symbol_logo_in_cancel_order_dialog","watchlist_sections","prefer_quote_short_name","enable_dom_data_for_untradable_symbols","prefer_symbol_name_over_fullname","watchlist_cross_tab_sync"]}}'
      );
    },
    127711(e) {
      e.exports = JSON.parse(
        '{"cme":{"INDICATORS_ON_CHART":{"limit":99999}},"bovespa":{"INDICATORS_ON_CHART":{"limit":99999}},"qecomqa":{"INDICATORS_ON_CHART":{"limit":99999}},"santandercomar":{"INDICATORS_ON_CHART":{"limit":99999}}}'
      );
    },
    502587(e) {
      e.exports = JSON.parse(
        '{"free":{"SAVED_PINE_SCRIPTS":{"limit":1},"CHAT_ASSISTANT":{"limit":5,"disable_on_trial":true},"CHART_STORAGE":{"limit":1},"MULTIPLE_CHARTS":{"limit":1},"INDICATORS_ON_CHART":{"limit":2},"FUNDAMENTALS_ON_CHART":{"limit":1},"HISTORICAL_BARS":{"limit":5},"STUDY_ON_STUDY":{"limit":800,"child_limit":1},"SERVER_SIDE_ALERTS":{"overall_limit":50,"limit":3,"complex_limit":0,"primitive_limit":3},"SCREENER_INTERVALS":{"interval":["1D","1W","1M"]},"STUDY_TEMPLATES":{"limit":1},"TV_OPTIONSTUDIES":{"study_packages":["tv-optionstudies"]},"SIMULTANEOUS_CONNECTIONS":{"limit":1},"BACKEND_CONNECTIONS":{"limit":2},"IDEA_SOCIAL_LINKS":{"socials":["Twitter","Youtube"]},"MULTICOLOR_FLAGGED_SYMBOLS":{"limit":1},"WATCHLIST_SYMBOLS":{"limit":30},"VIDEO_IDEAS_LENGTH":{"limit":20},"CREATE_MORE_PORTFOLIOS":{"limit":1},"PORTFOLIO_TRANSACTIONS":{"limit":2000},"PORTFOLIO_HOLDINGS":{"limit":20}},"pro":{"SAVED_PINE_SCRIPTS":{"limit":99999},"DRAWINGS":{},"BACKTESTING_CHART_EXPAND":{},"BACKTESTING_EXTENDED_METRICS":{},"BACKTESTING_EXPORT_XLSX":{},"BACKTESTING_EXPORT_CSV":{},"CHAT_ASSISTANT":{"limit":5,"disable_on_trial":true},"PERSONAL_SUPPORT":{"disable_on_trial":true},"CHART_STORAGE":{"limit":5},"MULTIPLE_CHARTS":{"limit":2},"MARKET_DATA_LIMITS":{"limit":2,"primitive_limit":2},"CUSTOM_INTERVALS":{},"MULTIPLE_WATCHLISTS":{},"IMPORT_WATCHLISTS":{},"EXPORT_WATCHLISTS":{},"INDICATORS_ON_CHART":{"limit":5},"FUNDAMENTALS_FORECAST":{},"FUNDAMENTALS_ON_CHART":{"limit":4},"TV_PROSTUDIES":{"study_packages":["tv-chartpatterns"]},"HISTORICAL_BARS":{"limit":10},"TV_VOLUMEBYPRICE":{"study_packages":["tv-volumebyprice"]},"TV_OPTIONSTUDIES":{"study_packages":["tv-optionstudies"]},"STUDY_ON_STUDY":{"limit":800,"child_limit":1},"TICK_BY_TICK_PUSH_DATA":{},"SERVER_SIDE_ALERTS":{"overall_limit":2000,"limit":20,"complex_limit":20,"primitive_limit":20},"SCREENER_AUTO_REFRESH":{},"SCREENER_NEW_AUTO_REFRESH":{},"SCREENER_NEW_EXPORT_CSV_DATA":{},"SCREENER_NEW_SHOW_RESTRICTED_DATA":{},"SCREENER_CHART_INDICATORS":{},"SCREENER_AI_FILTER":{},"SCREENER_ADD_NEW_COLUMN":{},"SCREENER_SCREEN_OWNER_EMPTY_STATE":{},"SCREENER_SHARED_SCREEN":{},"SHOW_BONDS_RESTRICTED_DATA":{},"PORTFOLIO_DATA_LIMIT":{},"CREATE_MORE_PORTFOLIOS":{"limit":3},"PORTFOLIO_TRANSACTIONS":{"limit":5000},"PORTFOLIO_HOLDINGS":{"limit":50},"SCREENER_INTERVALS":{"interval":["1m","5m","15m","30m","1h","2h","4h","1D","1W","1M"]},"NO_SPONSORED_ADS":{"disable_on_lite_plan":"exclude_mobile"},"STUDY_TEMPLATES":{"limit":99999},"SIMULTANEOUS_CONNECTIONS":{"limit":1},"BACKEND_CONNECTIONS":{"limit":10},"IDC_AVAILABLE_DELAY":{},"STATUS":{"disable_on_trial":true},"BAR_REPLAY_INTRADAY":{"limit":1},"MULTIFLAGGED_SYMBOLS_LISTS":{},"SHOWS":{"disable_on_trial":true},"ALERTS_WEBHOOK":{},"ALERTS_ON_EARNINGS":{},"ALERTS_ON_FUNDAMENTAL_METRICS":{},"DEEP_FUNDAMENTALS_HISTORY":{},"FINANCIALS_DOCUMENTS_SUMMARY":{},"PUBLISH_PROTECTED_SCRIPTS":{"disable_on_trial":true},"IO_SCRIPTS":{},"PRIVATE_IO_SCRIPTS":{},"IDEA_SOCIAL_LINKS":{"socials":["Twitter","Youtube"]},"EXTENDED_SOCIAL_LINKS":{"socials":["Facebook","Instagram"],"disable_on_trial":true},"MULTI_MONITOR":{},"MULTICOLOR_FLAGGED_SYMBOLS":{"limit":7},"INTRADAY_EXCHANGE":{},"VOLUME_PROFILE":{},"STREAMS_ACCESS":{"followers":10},"SMS_2FA_VERIFICATION":{"disable_on_trial":true},"SOCIAL_ACTIVITY":{"disable_on_trial":true},"WATCHLIST_SYMBOLS":{"limit":1000},"FIELDS_PERMISSIONS":{"items":["refbonds"]},"CUSTOM_RANGE_BARS":{},"FASTEST_DATA_FLOW":{},"SESSION_VOLUME_PROFILE":{},"SHOW_ETF_HOLDINGS_DATA":{},"MACRO_MAPS":{}},"pro_realtime":{"extends":"pro","CHART_STORAGE":{"limit":10},"MULTIPLE_CHARTS":{"limit":4},"MARKET_DATA_LIMITS":{"limit":4,"primitive_limit":4},"INDICATORS_ON_CHART":{"limit":10},"FUNDAMENTALS_ON_CHART":{"limit":7},"TV_PROSTUDIES":{"study_packages":["tv-prostudies","tv-chartpatterns"]},"STUDY_ON_STUDY":{"limit":800,"child_limit":9},"SERVER_SIDE_ALERTS":{"overall_limit":2000,"limit":100,"complex_limit":100,"primitive_limit":100},"ALERTS_MULTICONDITIONS":{"condition_limit":5},"CHAT_ASSISTANT":{"limit":5,"disable_on_trial":true},"CAN_EDIT_PUBLIC_CHATS":{"disable_on_trial":true},"BACKEND_CONNECTIONS":{"limit":20},"EXPORT_CHART_DATA":{},"CUSTOM_FORMULAS":{},"INTRADAY_EXOTIC_CHARTS":{},"KAGI_RENKO":{},"INTRADAY_SPREAD":{},"CUSTOM_CHATS":{},"CREATE_MORE_PORTFOLIOS":{"limit":4},"PORTFOLIO_HOLDINGS":{"limit":75}},"pro_premium":{"extends":"pro_realtime","BAR_DETALIZATION":{},"SCRIPT_EXECUTION_ON_HISTORY_BARS":{},"CHART_STORAGE":{"limit":99999},"MULTIPLE_CHARTS":{"limit":8},"MARKET_DATA_LIMITS":{"limit":6,"primitive_limit":6},"INDICATORS_ON_CHART":{"limit":25},"FUNDAMENTALS_ON_CHART":{"limit":10},"FUNDAMENTAL_GRAPHS_LARGE_TIME_RANGE":{},"CHAT_ASSISTANT":{"limit":99999,"disable_on_trial":true},"CHART_PATTERNS":{"study_packages":["tv-chartpatterns","tv-chart_patterns"]},"HISTORICAL_BARS":{"limit":20},"STUDY_ON_STUDY":{"limit":800,"child_limit":24},"SERVER_SIDE_ALERTS":{"overall_limit":2000,"limit":400,"complex_limit":400,"primitive_limit":400,"watchlist_limit":2,"overall_watchlist_limit":5},"SIMULTANEOUS_CONNECTIONS":{"limit":2},"BACKEND_CONNECTIONS":{"limit":50},"IDEA_SIGNATURE":{"disable_on_trial":true},"PROFILE_WEBSITE_FIELD":{"disable_on_trial":true},"BAR_REPLAY_INTRADAY":{"limit":4},"BAR_REPLAY_1S":{},"ALERTS_NO_EXPIRATION":{},"PUBLISH_INVITE_ONLY_SCRIPTS":{"disable_on_trial":true},"EXPORT_CHART_DATA":{},"DEEP_HISTORY_BACKTEST":{},"ALERTS_ON_SECONDS":{},"PERMANENT_STREAM_RECORDS":{},"EXTENDED_SOCIAL_LINKS":{"socials":["Facebook","Instagram","Website"],"disable_on_trial":true},"SECONDS_INTERVALS":{},"TPO_PERIODIC":{"study_packages":["tv-volumebyprice"]},"TPO_CHART_STYLE":{},"VOLUME_CANDLES":{},"VIDEO_IDEAS_LENGTH":{"limit":60},"VOLUME_FOOTPRINT":{},"PINE_SCREENER":{},"CREATE_MORE_PORTFOLIOS":{"limit":5},"PORTFOLIO_HOLDINGS":{"limit":100},"SOCIAL_TRUSTED_USER":{"disable_on_trial":true},"FOLLOWERS_ONLY_MINDS":{"disable_on_trial":true}},"pro_expert":{"extends":"pro_premium","INDICATORS_ON_CHART":{"limit":30},"FUNDAMENTALS_ON_CHART":{"limit":15},"STUDY_ON_STUDY":{"limit":800,"child_limit":29},"MULTIPLE_CHARTS":{"limit":10},"MARKET_DATA_LIMITS":{"limit":12,"primitive_limit":12},"HISTORICAL_BARS":{"limit":25},"SERVER_SIDE_ALERTS":{"overall_limit":2000,"limit":600,"complex_limit":600,"primitive_limit":600,"watchlist_limit":10,"overall_watchlist_limit":20},"BACKEND_CONNECTIONS":{"limit":80},"BAR_REPLAY_INTRADAY":{"limit":6},"BAR_REPLAY_1S":{},"BAR_REPLAY_1T":{},"EXPORT_FINANCIALS_DATA":{},"TICK_INTERVALS":{},"FIRST_PRIORITY_SUPPORT":{},"BUY_PRO_DATA":{},"CREATE_MORE_PORTFOLIOS":{"limit":6},"PORTFOLIO_HOLDINGS":{"limit":125}},"pro_premium_expert":{"extends":"pro_expert","INDICATORS_ON_CHART":{"limit":50},"FUNDAMENTALS_ON_CHART":{"limit":25},"STUDY_ON_STUDY":{"limit":800,"child_limit":49},"MULTIPLE_CHARTS":{"limit":16},"MARKET_DATA_LIMITS":{"limit":99999,"primitive_limit":25},"HISTORICAL_BARS":{"limit":40},"SERVER_SIDE_ALERTS":{"overall_limit":4000,"limit":1000,"complex_limit":1000,"primitive_limit":1000,"watchlist_limit":15,"overall_watchlist_limit":30},"BACKEND_CONNECTIONS":{"limit":200},"BAR_REPLAY_INTRADAY":{"limit":10},"CREATE_MORE_PORTFOLIOS":{"limit":7},"PORTFOLIO_HOLDINGS":{"limit":150}}}'
      );
    },
  },
]);
