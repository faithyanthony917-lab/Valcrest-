"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [44906],
  {
    743451(t, e, n) {
      n.d(e, { createObservable: () => u });
      var r = (function () {
        function t(t) {
          var e = this;
          (this._resolutionListener = function () {
            return e._onResolutionChanged();
          }),
            (this._resolutionMediaQueryList = null),
            (this._observers = []),
            (this._window = t),
            this._installResolutionListener();
        }
        return (
          (t.prototype.dispose = function () {
            this._uninstallResolutionListener(), (this._window = null);
          }),
          Object.defineProperty(t.prototype, "value", {
            get: function () {
              return this._window.devicePixelRatio;
            },
            enumerable: !1,
            configurable: !0,
          }),
          (t.prototype.subscribe = function (t) {
            var e = this,
              n = { next: t };
            return (
              this._observers.push(n),
              {
                unsubscribe: function () {
                  e._observers = e._observers.filter(function (t) {
                    return t !== n;
                  });
                },
              }
            );
          }),
          (t.prototype._installResolutionListener = function () {
            if (null !== this._resolutionMediaQueryList)
              throw new Error("Resolution listener is already installed");
            var t = this._window.devicePixelRatio;
            (this._resolutionMediaQueryList = this._window.matchMedia(
              "all and (resolution: ".concat(t, "dppx)")
            )),
              this._resolutionMediaQueryList.addListener(
                this._resolutionListener
              );
          }),
          (t.prototype._uninstallResolutionListener = function () {
            null !== this._resolutionMediaQueryList &&
              (this._resolutionMediaQueryList.removeListener(
                this._resolutionListener
              ),
              (this._resolutionMediaQueryList = null));
          }),
          (t.prototype._reinstallResolutionListener = function () {
            this._uninstallResolutionListener(),
              this._installResolutionListener();
          }),
          (t.prototype._onResolutionChanged = function () {
            var t = this;
            this._observers.forEach(function (e) {
              return e.next(t._window.devicePixelRatio);
            }),
              this._reinstallResolutionListener();
          }),
          t
        );
      })();
      function u(t) {
        return new r(t);
      }
    },
    74279(t, e, n) {
      function r(t) {
        var e = t.width,
          n = t.height;
        if (e < 0) throw new Error("Negative width is not allowed for Size");
        if (n < 0) throw new Error("Negative height is not allowed for Size");
        return { width: e, height: n };
      }
      function u(t, e) {
        return t.width === e.width && t.height === e.height;
      }
      n.d(e, { equalSizes: () => u, size: () => r });
    },
    269366(t, e, n) {
      n.d(e, { default: () => a });
      var r = n(713148);
      const u = function (t) {
        return this.__data__.set(t, "__lodash_hash_undefined__"), this;
      };
      const i = function (t) {
        return this.__data__.has(t);
      };
      function o(t) {
        var e = -1,
          n = null == t ? 0 : t.length;
        for (this.__data__ = new r.default(); ++e < n; ) this.add(t[e]);
      }
      (o.prototype.add = o.prototype.push = u), (o.prototype.has = i);
      const a = o;
    },
    789287(t, e, n) {
      n.d(e, { default: () => r });
      const r = function (t, e, n) {
        switch (n.length) {
          case 0:
            return t.call(e);
          case 1:
            return t.call(e, n[0]);
          case 2:
            return t.call(e, n[0], n[1]);
          case 3:
            return t.call(e, n[0], n[1], n[2]);
        }
        return t.apply(e, n);
      };
    },
    224416(t, e, n) {
      n.d(e, { default: () => a });
      var r = n(688965);
      const u = function (t) {
        return t != t;
      };
      const i = function (t, e, n) {
        for (var r = n - 1, u = t.length; ++r < u; ) if (t[r] === e) return r;
        return -1;
      };
      const o = function (t, e, n) {
        return e == e ? i(t, e, n) : (0, r.default)(t, u, n);
      };
      const a = function (t, e) {
        return !!(null == t ? 0 : t.length) && o(t, e, 0) > -1;
      };
    },
    825039(t, e, n) {
      n.d(e, { default: () => r });
      const r = function (t, e, n) {
        for (var r = -1, u = null == t ? 0 : t.length; ++r < u; )
          if (n(e, t[r])) return !0;
        return !1;
      };
    },
    688965(t, e, n) {
      n.d(e, { default: () => r });
      const r = function (t, e, n, r) {
        for (var u = t.length, i = n + (r ? 1 : -1); r ? i-- : ++i < u; )
          if (e(t[i], i, t)) return i;
        return -1;
      };
    },
    25826(t, e, n) {
      n.d(e, { default: () => r });
      const r = (function (t) {
        return function (e, n, r) {
          for (var u = -1, i = Object(e), o = r(e), a = o.length; a--; ) {
            var l = o[t ? a : ++u];
            if (!1 === n(i[l], l, i)) break;
          }
          return e;
        };
      })();
    },
    48262(t, e, n) {
      n.d(e, { default: () => j });
      var r = n(886514),
        u = n(254738),
        i = n(910778);
      const o = function (t, e, n) {
        ((void 0 !== n && !(0, i.default)(t[e], n)) ||
          (void 0 === n && !(e in t))) &&
          (0, u.default)(t, e, n);
      };
      var a = n(25826),
        l = n(487060),
        f = n(13907),
        s = n(705749),
        d = n(807575),
        c = n(531557),
        h = n(295635),
        v = n(23963),
        _ = n(659018),
        p = n(928132),
        w = n(880115),
        g = n(931433),
        y = n(165267);
      const b = function (t, e) {
        if (
          ("constructor" !== e || "function" != typeof t[e]) &&
          "__proto__" != e
        )
          return t[e];
      };
      var L = n(61857),
        R = n(217457);
      const M = function (t) {
        return (0, L.default)(t, (0, R.default)(t));
      };
      const O = function (t, e, n, r, u, i, a) {
        var L = b(t, n),
          R = b(e, n),
          O = a.get(R);
        if (O) o(t, n, O);
        else {
          var j = i ? i(L, R, n + "", t, e, a) : void 0,
            x = void 0 === j;
          if (x) {
            var Q = (0, h.default)(R),
              m = !Q && (0, _.default)(R),
              k = !Q && !m && (0, y.default)(R);
            (j = R),
              Q || m || k
                ? (0, h.default)(L)
                  ? (j = L)
                  : (0, v.default)(L)
                  ? (j = (0, s.default)(L))
                  : m
                  ? ((x = !1), (j = (0, l.default)(R, !0)))
                  : k
                  ? ((x = !1), (j = (0, f.default)(R, !0)))
                  : (j = [])
                : (0, g.default)(R) || (0, c.default)(R)
                ? ((j = L),
                  (0, c.default)(L)
                    ? (j = M(L))
                    : ((0, w.default)(L) && !(0, p.default)(L)) ||
                      (j = (0, d.default)(R)))
                : (x = !1);
          }
          x && (a.set(R, j), u(j, R, r, i, a), a.delete(R)), o(t, n, j);
        }
      };
      const j = function t(e, n, u, i, l) {
        e !== n &&
          (0, a.default)(
            n,
            function (a, f) {
              if ((l || (l = new r.default()), (0, w.default)(a)))
                O(e, n, f, u, t, i, l);
              else {
                var s = i ? i(b(e, f), a, f + "", e, n, l) : void 0;
                void 0 === s && (s = a), o(e, f, s);
              }
            },
            R.default
          );
      };
    },
    645376(t, e, n) {
      n.d(e, { default: () => o });
      var r = n(232854),
        u = n(372035),
        i = n(709051);
      const o = function (t, e) {
        return (0, i.default)((0, u.default)(t, e, r.default), t + "");
      };
    },
    431053(t, e, n) {
      n.d(e, { default: () => d });
      var r = n(269366),
        u = n(224416),
        i = n(825039),
        o = n(712801),
        a = n(414123),
        l = n(862388),
        f = n(972017);
      const s =
        a.default && 1 / (0, f.default)(new a.default([, -0]))[1] == 1 / 0
          ? function (t) {
              return new a.default(t);
            }
          : l.default;
      const d = function (t, e, n) {
        var a = -1,
          l = u.default,
          d = t.length,
          c = !0,
          h = [],
          v = h;
        if (n) (c = !1), (l = i.default);
        else if (d >= 200) {
          var _ = e ? null : s(t);
          if (_) return (0, f.default)(_);
          (c = !1), (l = o.default), (v = new r.default());
        } else v = e ? [] : h;
        t: for (; ++a < d; ) {
          var p = t[a],
            w = e ? e(p) : p;
          if (((p = n || 0 !== p ? p : 0), c && w == w)) {
            for (var g = v.length; g--; ) if (v[g] === w) continue t;
            e && v.push(w), h.push(p);
          } else l(v, w, n) || (v !== h && v.push(w), h.push(p));
        }
        return h;
      };
    },
    712801(t, e, n) {
      n.d(e, { default: () => r });
      const r = function (t, e) {
        return t.has(e);
      };
    },
    574669(t, e, n) {
      n.d(e, { default: () => i });
      var r = n(645376),
        u = n(854894);
      const i = function (t) {
        return (0, r.default)(function (e, n) {
          var r = -1,
            i = n.length,
            o = i > 1 ? n[i - 1] : void 0,
            a = i > 2 ? n[2] : void 0;
          for (
            o = t.length > 3 && "function" == typeof o ? (i--, o) : void 0,
              a &&
                (0, u.default)(n[0], n[1], a) &&
                ((o = i < 3 ? void 0 : o), (i = 1)),
              e = Object(e);
            ++r < i;

          ) {
            var l = n[r];
            l && t(e, l, r, o);
          }
          return e;
        });
      };
    },
    854894(t, e, n) {
      n.d(e, { default: () => a });
      var r = n(910778),
        u = n(392908),
        i = n(921143),
        o = n(880115);
      const a = function (t, e, n) {
        if (!(0, o.default)(n)) return !1;
        var a = typeof e;
        return (
          !!("number" == a
            ? (0, u.default)(n) && (0, i.default)(e, n.length)
            : "string" == a && e in n) && (0, r.default)(n[e], t)
        );
      };
    },
    372035(t, e, n) {
      n.d(e, { default: () => i });
      var r = n(789287),
        u = Math.max;
      const i = function (t, e, n) {
        return (
          (e = u(void 0 === e ? t.length - 1 : e, 0)),
          function () {
            for (
              var i = arguments, o = -1, a = u(i.length - e, 0), l = Array(a);
              ++o < a;

            )
              l[o] = i[e + o];
            o = -1;
            for (var f = Array(e + 1); ++o < e; ) f[o] = i[o];
            return (f[e] = n(l)), (0, r.default)(t, this, f);
          }
        );
      };
    },
    972017(t, e, n) {
      n.d(e, { default: () => r });
      const r = function (t) {
        var e = -1,
          n = Array(t.size);
        return (
          t.forEach(function (t) {
            n[++e] = t;
          }),
          n
        );
      };
    },
    709051(t, e, n) {
      n.d(e, { default: () => a });
      var r = n(128076),
        u = n(36049),
        i = n(232854);
      const o = u.default
        ? function (t, e) {
            return (0, u.default)(t, "toString", {
              configurable: !0,
              enumerable: !1,
              value: (0, r.default)(e),
              writable: !0,
            });
          }
        : i.default;
      const a = (0, n(948573).default)(o);
    },
    948573(t, e, n) {
      n.d(e, { default: () => u });
      var r = Date.now;
      const u = function (t) {
        var e = 0,
          n = 0;
        return function () {
          var u = r(),
            i = 16 - (u - n);
          if (((n = u), i > 0)) {
            if (++e >= 800) return arguments[0];
          } else e = 0;
          return t.apply(void 0, arguments);
        };
      };
    },
    128076(t, e, n) {
      n.d(e, { default: () => r });
      const r = function (t) {
        return function () {
          return t;
        };
      };
    },
    232854(t, e, n) {
      n.d(e, { default: () => r });
      const r = function (t) {
        return t;
      };
    },
    23963(t, e, n) {
      n.d(e, { default: () => i });
      var r = n(392908),
        u = n(360620);
      const i = function (t) {
        return (0, u.default)(t) && (0, r.default)(t);
      };
    },
    931433(t, e, n) {
      n.d(e, { default: () => d });
      var r = n(178497),
        u = n(392545),
        i = n(360620),
        o = Function.prototype,
        a = Object.prototype,
        l = o.toString,
        f = a.hasOwnProperty,
        s = l.call(Object);
      const d = function (t) {
        if (!(0, i.default)(t) || "[object Object]" != (0, r.default)(t))
          return !1;
        var e = (0, u.default)(t);
        if (null === e) return !0;
        var n = f.call(e, "constructor") && e.constructor;
        return "function" == typeof n && n instanceof n && l.call(n) == s;
      };
    },
    740162(t, e, n) {
      n.d(e, { default: () => u });
      var r = n(48262);
      const u = (0, n(574669).default)(function (t, e, n) {
        (0, r.default)(t, e, n);
      });
    },
    862388(t, e, n) {
      n.d(e, { default: () => r });
      const r = function () {};
    },
    448245(t, e, n) {
      n.d(e, { default: () => u });
      var r = n(431053);
      const u = function (t) {
        return t && t.length ? (0, r.default)(t) : [];
      };
    },
  },
]);
