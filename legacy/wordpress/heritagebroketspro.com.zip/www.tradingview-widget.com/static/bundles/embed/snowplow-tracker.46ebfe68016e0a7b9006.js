"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [66399],
  {
    932365(e, t, n) {
      n.d(t, { TVLocalStorage: () => r });
      const i = (0, n(819511).getLogger)("TVLocalStorage");
      var o = function () {
        try {
          (this.isAvailable = !0),
            (this.localStorage = window.localStorage),
            this.localStorage.setItem("tvlocalstorage.available", "true");
        } catch (e) {
          delete this.isAvailable, delete this.localStorage;
        }
        this._updateLength();
        try {
          this._report();
        } catch (e) {}
      };
      (o.prototype._report = function () {
        if (this.isAvailable) {
          const e = 10,
            t = [];
          for (let e = 0; e < this.localStorage.length; e++) {
            const n = this.key(e);
            t.push({ key: n, length: String(this.getItem(n)).length });
          }
          t.sort((e, t) => t.length - e.length);
          const n = t.slice(0, e);
          t.sort((e, t) => t.key.length - e.key.length);
          const o = t.slice(0, e);
          i.logNormal(`Total amount of keys in Local Storage: ${this.length}`),
            i.logNormal(
              `Top ${e} keys with longest values: ${JSON.stringify(n)}`
            ),
            i.logNormal(`Top ${e} longest key names: ${JSON.stringify(o)}`);
          try {
            navigator.storage.estimate().then((e) => {
              i.logNormal(`Storage estimate: ${JSON.stringify(e)}`);
            });
          } catch (e) {}
        }
      }),
        (o.prototype.length = 0),
        (o.prototype.isAvailable = !1),
        (o.prototype.localStorage = { "tvlocalstorage.available": "false" }),
        (o.prototype._updateLength = function () {
          if (this.isAvailable) this.length = this.localStorage.length;
          else {
            var e,
              t = 0;
            for (e in this.localStorage)
              this.localStorage.hasOwnProperty(e) && t++;
            this.length = t;
          }
        }),
        (o.prototype.key = function (e) {
          return this.isAvailable
            ? this.localStorage.key(e)
            : Object.keys(this.localStorage)[e];
        }),
        (o.prototype.getItem = function (e) {
          return this.isAvailable
            ? this.localStorage.getItem(e)
            : void 0 === this.localStorage[e]
            ? null
            : this.localStorage[e];
        }),
        (o.prototype.setItem = function (e, t) {
          this.isAvailable
            ? this.localStorage.setItem(e, t)
            : (this.localStorage[e] = t),
            this._updateLength();
        }),
        (o.prototype.removeItem = function (e) {
          this.isAvailable
            ? this.localStorage.removeItem(e)
            : delete this.localStorage[e],
            this._updateLength();
        }),
        (o.prototype.clear = function () {
          this.isAvailable
            ? this.localStorage.clear()
            : (this.localStorage = {}),
            this._updateLength();
        });
      const r = new o();
      window.TVLocalStorage = r;
    },
    858443(e, t, n) {
      n.d(t, { CookieSettings: () => i });
      var i = (function (e) {
        return (e.Analytics = "analytics"), (e.Advertising = "advertising"), e;
      })({});
    },
    784844(e, t, n) {
      n.d(t, {
        CookieSettings: () => i.CookieSettings,
        bannerPrivacyPreferenceKey: () => h,
        checkBannerPrivacyPreferenceKey: () => A,
        cookieSettingsChangeEvent: () => l,
        getCookieSetting: () => L,
        hideBanner: () => I,
        rejectBanner: () => _,
        setCookieSetting: () => $,
      });
      var i = n(858443),
        o = n(643553),
        r = n(359239),
        a = n(932365),
        s = n(457106),
        c = n(489489);
      const l = "cookie_settings_changed",
        g =
          ((0, r.createDeferredPromise)(), window.location.hostname.split(".")),
        u = (0, s.isLocal)() ? "" : "." + g.slice(1, g.length).join("."),
        d = "cookieBanner",
        h = (0, s.isProd)()
          ? "cookiePrivacyPreferenceBannerProduction"
          : "cookiePrivacyPreferenceBannerLocal",
        m = "accepted",
        p = "notApplicable",
        f = "reject",
        w = "cookiesSettings",
        b = "localCookiesSettings",
        S = "cookiePrivacyPreferenceBanner",
        k = {
          [i.CookieSettings.Analytics]: !1,
          [i.CookieSettings.Advertising]: !1,
        };
      function v() {
        return a.TVLocalStorage.removeItem(d);
      }
      function y(e) {
        return [m, p, f].includes(a.TVLocalStorage.getItem(e) ?? "");
      }
      function A() {
        return (e = h), [m, p, f].includes(c.get(e) ?? "");
        var e;
      }
      function I() {
        T(m);
      }
      function _() {
        T(f);
      }
      function T(e) {
        c.set(h, e, 3653, "/", u);
      }
      function $(e, t) {
        (k[e] = t),
          c.set((0, s.isProd)() ? w : b, JSON.stringify(k), 3653, "/", u),
          o.emit(l, e, t);
      }
      function L(e) {
        return k[e];
      }
      function C() {
        return a.TVLocalStorage.removeItem(S);
      }
      !(function () {
        const e = c.get((0, s.isProd)() ? w : b),
          t = a.TVLocalStorage.getItem(S),
          n = a.TVLocalStorage.getItem(w);
        if (e) {
          t && n && (C(), a.TVLocalStorage.removeItem(w)), y(d) && v();
          try {
            const t = JSON.parse(e);
            (k[i.CookieSettings.Analytics] =
              t?.[i.CookieSettings.Analytics] || !1),
              (k[i.CookieSettings.Advertising] =
                t?.[i.CookieSettings.Advertising] || !1);
          } catch {}
        } else if (
          (y(d) &&
            ($(i.CookieSettings.Analytics, !0),
            $(i.CookieSettings.Advertising, !0),
            I(),
            v()),
          t && n)
        ) {
          const e = JSON.parse(n);
          T(t),
            $(i.CookieSettings.Analytics, e?.[i.CookieSettings.Analytics]),
            $(i.CookieSettings.Advertising, e?.[i.CookieSettings.Advertising]),
            C(),
            a.TVLocalStorage.removeItem(w);
        }
      })();
    },
    809233(e, t, n) {
      function i() {
        return /TVDesktop/i.test(navigator.userAgent);
      }
      function o() {
        const e = navigator.userAgent.match(/TVDesktop\/([^\s]+)/);
        return e && e[1];
      }
      n.d(t, { desktopAppVersion: () => o, isDesktopApp: () => i });
    },
    457106(e, t, n) {
      n.d(t, {
        environment: () => o,
        isDebug: () => s,
        isLocal: () => r,
        isProd: () => a,
      });
      const i = new Set(["battle", "staging", "test", "local"]);
      function o() {
        const e = globalThis.environment;
        return (
          (function (e) {
            i.has(e) || console.warn("Invalid environment " + e);
          })(e),
          e
        );
      }
      function r() {
        return "local" === o();
      }
      function a() {
        return "battle" === o();
      }
      function s() {
        return !a();
      }
    },
    39032(e, t, n) {
      n.d(t, { isFeatureEnabled: () => d, onFeaturesStateChanged: () => c });
      var i = n(570071),
        o = n(503617),
        r = n(739722),
        a = n(932365);
      const s = new i.Delegate(),
        c = () => s,
        l = "forcefeaturetoggle.";
      const g = new (class {
        enableFeature(e) {
          a.TVLocalStorage.setItem(l + e, "true"), s.fire(e);
        }
        disableFeature(e) {
          a.TVLocalStorage.setItem(l + e, "false"), s.fire(e);
        }
        resetFeature(e) {
          a.TVLocalStorage.removeItem(l + e), s.fire(e);
        }
        onFeaturesStateChanged() {
          return s;
        }
      })();
      function u(e, t) {
        return (
          (!e[t] || -1 !== e[t]) &&
          (!!(
            "true" === a.TVLocalStorage.getItem(l + t) ||
            (window.is_authenticated &&
              "true" === window.user?.settings?.[l + t])
          ) ||
            (!(
              "false" === a.TVLocalStorage.getItem(l + t) ||
              (window.is_authenticated &&
                "false" === window.user?.settings?.[l + t])
            ) &&
              !!e[t] &&
              (1 === e[t] || (0, r.shouldAffectUser)(t, e[t]))))
        );
      }
      (window.TradingView = window.TradingView || {}),
        (window.TradingView.FeatureToggle = g);
      const d =
        ((h = window.featureToggleState || {}),
        (0, o.onWidget)() ||
          Promise.all([n.e(50488), n.e(13993)])
            .then(n.bind(n, 250488))
            .then((e) => {
              e.pushStreamMultiplexer.on("featuretoggle", (e) => {
                const t = u(h, e.name);
                (h[e.name] = e.state), t !== u(h, e.name) && s.fire(e.name);
              });
            }),
        u.bind(null, h));
      var h;
      window.TradingView.isFeatureEnabled = d;
    },
    643553(e, t, n) {
      n.d(t, {
        emit: () => g,
        emitOnce: () => u,
        on: () => c,
        subscribe: () => l,
        unsubscribe: () => s,
      });
      var i = n(570071);
      const o = {},
        r = [],
        a = {};
      function s(e, t, n) {
        o[e].unsubscribe(n, t);
      }
      function c(e, t, n) {
        l(e, t, n);
      }
      function l(e, t, n, r) {
        o.hasOwnProperty(e) || (o[e] = new i.Delegate()),
          a[e] ? t.call(n) : o[e].subscribe(n, t, r);
      }
      function g(e, ...t) {
        const n = [e].concat(t);
        r.forEach((e) => {
          e.apply(null, n);
        }),
          o.hasOwnProperty(e) && o[e].fire.apply(o[e], t);
      }
      function u(e) {
        a[e] &&
          console.warn(
            `Something went wrong: emitOnce called multiple times with same event (${e})`
          ),
          (a[e] = !0),
          g.apply(null, arguments);
      }
    },
    514154(e, t, n) {
      n.d(t, {
        getCurrentLocaleInfoCountry: () => g,
        getFreshInitData: () => c,
        getInitData: () => s,
        getInitDataField: () => l,
      });
      var i = n(146961);
      const o = (0, n(819511).getLogger)("Common.InitData"),
        r = "undefined" == typeof window ? {} : window.initData || {};
      function a() {
        !(function () {
          const e = window;
          e.initData &&
            e.initData !== r &&
            (Object.assign(r, e.initData), (e.initData = r));
        })();
        const e = document.querySelectorAll(
          'script[type="application/prs.init-data+json"]'
        );
        for (let t = 0; t < e.length; t++) {
          const n = e[t];
          try {
            const e = JSON.parse((0, i.ensureNotNull)(n.textContent));
            Object.assign(r, e);
          } catch (e) {
            o.logWarn(`Failed to parse initData element. ${e}`);
          } finally {
            (0, i.ensureNotNull)(n.parentNode).removeChild(n);
          }
        }
        const t = r.content;
        t &&
          r.study_meta_info_map &&
          (t.studyMetaInfoMap = {
            ...t.studyMetaInfoMap,
            ...r.study_meta_info_map,
          });
      }
      function s() {
        return r;
      }
      function c() {
        return a(), r;
      }
      function l(e) {
        return a(), r[e];
      }
      function g() {
        const e = l("currentLocaleInfo");
        return e?.flag.toUpperCase();
      }
    },
    712859(e, t, n) {
      n.d(t, {
        appVersion: () => a,
        isMobile: () => c,
        isOnMobileAppPage: () => r,
        isPlatformMobile: () => l,
        urlWithMobileAppParams: () => s,
      });
      var i = n(489489);
      if (/^(79795|94389)$/.test(n.j)) var o = n(467242);
      function r(e, t = !1) {
        const { searchParams: n } = new URL(String(location));
        let o = "true" === n.get("mobileapp_new"),
          r = "true" === n.get("mobileapp");
        if (!t) {
          const e = i.get("tv_app") || "";
          (o ||= ["android", "android_nps"].includes(e)), (r ||= "ios" === e);
        }
        return !(("new" !== e && "any" !== e) || !o) || !("new" === e || !r);
      }
      function a() {
        const e = navigator.userAgent.match(/TradingView\/([^\s]+)/);
        return e && e[1];
      }
      function s(e, t = !1) {
        if (r("new", t)) {
          const t = new URL(e, location.href);
          t.searchParams.set("mobileapp_new", "true"), (e = t.toString());
        }
        if (r("old", t)) {
          const t = new URL(e, location.href);
          t.searchParams.set("mobileapp", "true"), (e = t.toString());
        }
        return e;
      }
      function c() {
        const e = window.matchMedia(
          "(min-width: 602px) and (min-height: 445px)"
        ).matches;
        return o.isAnyMobile && !e;
      }
      function l() {
        return !r("any") && c();
      }
    },
    503617(e, t, n) {
      n.d(t, { checkPageType: () => r, onGoPro: () => a, onWidget: () => o });
      const i = new Map();
      function o() {
        const e = window.location.pathname,
          t = window.location.host,
          n = `${t}${e}`;
        return (
          i.has(n) ||
            i.set(
              n,
              (function (e, t) {
                const n = ["^widget-docs"];
                for (const e of n) if (new RegExp(e).test(t)) return !0;
                const i = [
                    "^widgetembed/?$",
                    "^cmewidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/widgetembed/?$",
                    "^([0-9a-zA-Z-]+)/widgetstatic/?$",
                    "^([0-9a-zA-Z-]+)?/?mediumwidgetembed/?$",
                    "^twitter-chart/?$",
                    "^telegram/chart/?$",
                    "^embed/([0-9a-zA-Z]{8})/?$",
                    "^widgetpopup/?$",
                    "^extension/?$",
                    "^idea-popup/?$",
                    "^hotlistswidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/hotlistswidgetembed/?$",
                    "^marketoverviewwidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/marketoverviewwidgetembed/?$",
                    "^eventswidgetembed/?$",
                    "^tickerswidgetembed/?$",
                    "^forexcrossrateswidgetembed/?$",
                    "^forexheatmapwidgetembed/?$",
                    "^marketquoteswidgetembed/?$",
                    "^screenerwidget/?$",
                    "^cryptomktscreenerwidget/?$",
                    "^([0-9a-zA-Z-]+)/cryptomktscreenerwidget/?$",
                    "^([0-9a-zA-Z-]+)/marketquoteswidgetembed/?$",
                    "^technical-analysis-widget-embed/$",
                    "^singlequotewidgetembed/?$",
                    "^([0-9a-zA-Z-]+)/singlequotewidgetembed/?$",
                    "^embed-widget/([0-9a-zA-Z-]+)/(([0-9a-zA-Z-]+)/)?$",
                    "^widget-docs/([0-9a-zA-Z-]+)/([0-9a-zA-Z-/]+)?$",
                  ],
                  o = e.replace(/^\//, "");
                let r;
                for (let e = i.length - 1; e >= 0; e--)
                  if (((r = new RegExp(i[e])), r.test(o))) return !0;
                return !1;
              })(e, t)
            ),
          i.get(n) ?? !1
        );
      }
      function r(e) {
        return (
          new URLSearchParams(window.location.search).get("page_type") === e
        );
      }
      function a() {
        return "/pricing/" === window.location.pathname;
      }
    },
    654147(e, t, n) {
      n.d(t, {
        getAnonymousTrackerInstance: () => I,
        getTrackerInstance: () => y,
        getUnboundTrackerInstance: () => A,
      });
      var i = n(916726),
        o = n(870644);
      let r = !1;
      class a {
        trackPageView() {
          (0, o.trackPageView)(void 0, [this._collectorId]);
        }
        setUserId(e) {
          const t = !e || (0, i.isSymphonyEmbed)() ? null : `${e}`;
          (0, o.setUserId)(t, [this._collectorId]);
        }
        trackSelfDesc(e, t) {
          r ||
            (0, o.trackSelfDescribingEvent)({ event: { schema: e, data: t } }, [
              this._collectorId,
            ]);
        }
        trackPageActivityTime(e) {
          const { disableTracking: t, flushTrackingResult: n } =
              this._startActivityWatcher(e),
            i = () => {
              this.trackSelfDesc(
                "iglu:com.tradingview/page_unload/jsonschema/1-0-0",
                { active_seconds: n() }
              );
            },
            o = () => {
              "hidden" === document.visibilityState && i();
            };
          document.addEventListener("visibilitychange", o);
          return () => {
            i(), t(), document.removeEventListener("visibilitychange", o);
          };
        }
        _setDiscardBrace(e) {
          (0, o.discardBrace)(e, [this._collectorId]);
        }
        _startActivityWatcher(e) {
          let t = 0;
          return (
            (0, o.enableActivityTrackingCallback)(
              {
                minimumVisitLength: e.minimumVisitLength,
                heartbeatDelay: e.heartbeatDelay,
                callback: () => {
                  t++;
                },
              },
              [this._collectorId]
            ),
            {
              disableTracking: o.disableActivityTracking,
              flushTrackingResult: () => {
                const n = t * e.heartbeatDelay;
                return (t = 0), n;
              },
            }
          );
        }
        constructor(e) {
          (0, o.newTracker)(e.collectorId, e.url, e.params),
            (this._collectorId = e.collectorId),
            this._setDiscardBrace(!0);
        }
      }
      var s = n(643553),
        c = n(809233),
        l = n(712859),
        g = n(784844),
        u = n(514154),
        d = (function (e) {
          return (e.Web = "web"), (e.Mobile = "mob"), (e.Desktop = "pc"), e;
        })({}),
        h = (function (e) {
          return (
            (e.Android = "_android"),
            (e.IOS = "_ios"),
            (e.Desktop = "_desktop"),
            e
          );
        })({}),
        m = n(39032);
      let p,
        f = !1;
      function w() {
        return (
          f ||
            ((f = !0),
            (p = (function () {
              const e = (0, u.getInitDataField)("snowplowSettings");
              if (!e || !e.params || !e.enabled) return;
              let t = d.Web,
                n = "";
              (0, c.isDesktopApp)() && ((t = d.Desktop), (n = h.Desktop)),
                (0, l.isOnMobileAppPage)("old")
                  ? ((t = d.Mobile), (n = h.IOS))
                  : (0, l.isOnMobileAppPage)("new") &&
                    ((t = d.Mobile), (n = h.Android));
              const i = !(0, l.isOnMobileAppPage)("any") &&
                  !(0, g.getCookieSetting)(g.CookieSettings.Analytics) && {
                    withSessionTracking: !0,
                  },
                o = {
                  collectorId: e.collectorId,
                  url: e.url,
                  params: {
                    appId: e.params.appId + n,
                    platform: t,
                    discoverRootDomain: !0,
                    contexts: { webPage: !0 },
                    eventMethod: "get",
                    maxLocalStorageQueueSize: 30,
                    anonymousTracking: i,
                    sessionCookieTimeout: (0, g.getCookieSetting)(
                      g.CookieSettings.Analytics
                    )
                      ? 1800
                      : 7776e3,
                  },
                };
              return (
                (0, m.isFeatureEnabled)("snowplow_beacon_feature") &&
                  ((o.params.eventMethod = "beacon"),
                  (o.params.postPath = e.params.postPath)),
                o
              );
            })()),
            s.subscribe(
              g.cookieSettingsChangeEvent,
              (e, t) => {
                e === g.CookieSettings.Analytics &&
                  (t
                    ? (0, o.disableAnonymousTracking)()
                    : (0, o.enableAnonymousTracking)({
                        options: { withSessionTracking: !0 },
                      }));
              },
              null
            )),
          p
        );
      }
      let b = null,
        S = !1,
        k = null;
      function v() {
        if (null === b) {
          const e = w();
          void 0 !== e && (b = new a(e));
        }
        return b;
      }
      function y() {
        const e = v();
        return (
          null === e ||
            S ||
            ((S = !0),
            e.setUserId(window.user.id),
            window.loginStateChange.subscribe(e, () => {
              e.setUserId(window.user.id);
            })),
          e
        );
      }
      function A() {
        return v();
      }
      function I() {
        if (null !== k) return k;
        const e = w();
        return void 0 === e
          ? null
          : ((k = new a({ ...e, userId: void 0, collectorId: "tv_anonymous" })),
            k.setUserId(void 0),
            k);
      }
    },
    581960(e, t, n) {
      function i() {
        return window.is_authenticated
          ? window.user.pro_plan || "free"
          : "visitor";
      }
      function o() {
        return window.locale;
      }
      function r() {
        return window.user.id ? window.user.id.toString() : null;
      }
      function a() {
        return Boolean(window.user.do_not_track);
      }
      n.d(t, {
        getUserId: () => r,
        getUserLocale: () => o,
        getUserPlan: () => i,
        isTrackingDisabled: () => a,
      });
    },
    739722(e, t, n) {
      n.d(t, { shouldAffectUser: () => c });
      var i = n(100595),
        o = n.n(i),
        r = n(932365);
      const a = "featuretoggle_seed";
      function s(e) {
        try {
          const t = o()(
              e +
                (function () {
                  if (window.user && window.user.id) return window.user.id;
                  const e = r.TVLocalStorage.getItem(a);
                  if (null !== e) return e;
                  const t = Math.floor(1e6 * Math.random());
                  return r.TVLocalStorage.setItem(a, `${t}`), t;
                })()
            ),
            n = new DataView(t);
          return n.getUint32(0, !0) / 4294967296;
        } catch (e) {
          return 0.5;
        }
      }
      function c(e, t) {
        return s(e) <= t;
      }
    },
    916726(e, t, n) {
      function i() {
        return Boolean(window.TradingView?.isSymphony);
      }
      n.d(t, { isSymphonyEmbed: () => i });
    },
    237671(e, t, n) {
      if ((n.r(t), n.d(t, { trackChat: () => r }), /^(79795|94389)$/.test(n.j)))
        var i = n(498728);
      if (/^(79795|94389)$/.test(n.j)) var o = n(581960);
      function r(e) {
        (0, i.getTracker)().then((t) => {
          t?.trackSelfDesc("iglu:com.tradingview/chat/jsonschema/1-0-0", {
            ...e,
            locale: (0, o.getUserLocale)(),
          });
        });
      }
    },
    489489(e, t, n) {
      function i(e, t, n, i, o) {
        let r = "";
        if (((i = i ? "; path=" + i : ""), (o = o ? "; domain=" + o : ""), n)) {
          const e = new Date();
          e.setTime(e.getTime() + 24 * n * 60 * 60 * 1e3),
            (r = "; expires=" + e.toUTCString());
        } else r = "";
        document.cookie = e + "=" + t + r + o + i;
      }
      function o(e) {
        const t = e + "=",
          n = document.cookie.split(";");
        for (let e = 0; e < n.length; e++) {
          let i = n[e];
          for (; " " === i.charAt(0); ) i = i.substring(1, i.length);
          if (0 === i.indexOf(t)) return i.substring(t.length, i.length);
        }
        return null;
      }
      n.d(t, { get: () => o, set: () => i });
    },
    359239(e, t, n) {
      function i() {
        let e, t;
        return {
          promise: new Promise((n, i) => {
            (e = n), (t = i);
          }),
          reject: t,
          resolve: e,
        };
      }
      n.d(t, { createDeferredPromise: () => i });
    },
    570071(e, t, n) {
      n.d(t, { Delegate: () => r });
      const i = (0, n(819511).getLogger)("Common.Delegate");
      function o(e) {
        return !e.singleShot;
      }
      class r {
        subscribe(e, t, n) {
          this._listeners.push({
            object: e,
            member: t,
            singleShot: !!n,
            skip: !1,
          });
        }
        unsubscribe(e, t) {
          for (let n = 0; n < this._listeners.length; ++n) {
            const i = this._listeners[n];
            if (i.object === e && i.member === t) {
              (i.skip = !0), this._listeners.splice(n, 1);
              break;
            }
          }
        }
        unsubscribeAll(e) {
          for (let t = this._listeners.length - 1; t >= 0; --t) {
            const n = this._listeners[t];
            n.object === e && ((n.skip = !0), this._listeners.splice(t, 1));
          }
        }
        destroy() {
          this._listeners = [];
        }
        _fireImpl(...e) {
          const t = this._listeners;
          this._listeners = this._listeners.filter(o);
          const n = t.length;
          for (let o = 0; o < n; ++o) {
            const n = t[o];
            if (!n.skip)
              try {
                n.member.apply(n.object || null, e);
              } catch (e) {
                i.logError(`${e && (e.stack || e.message)}`);
              }
          }
        }
        constructor() {
          (this.fire = this._fireImpl.bind(this)), (this._listeners = []);
        }
      }
    },
  },
]);
