(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
  [97717],
  {
    270238(t) {
      t.exports = { fade: "fade-sr9MaOjC", hidden: "hidden-sr9MaOjC" };
    },
    68647(t, e, i) {
      "use strict";
      i.d(e, { MiniChart: () => Z });
      var s = i(678312),
        a = i(740162),
        r = i(511538),
        n = i(246823),
        o = (function (t) {
          return (t.None = "none"), (t.All = "all"), (t.Any = "any"), t;
        })({}),
        h = i(383636),
        l = i(140136),
        c = i(635774),
        d = i(570071),
        m = i(146961),
        u = i(178845),
        _ = i(384229),
        p = i(525912),
        f = i(819511),
        b = i(342288),
        g = i(778738),
        y = i(136035),
        S = i(80365),
        T = i(726115),
        v = i(569531),
        C = i(425268),
        P = i(825280),
        D = i(666746),
        w = i(655044),
        k = i(485393);
      const M = (0, s.defaultHorzScaleBehavior)();
      class I extends M {
        shouldResetTickmarkLabels(t) {
          const e = this.calculateItemsHash(t),
            i = e !== this._lastHash;
          return (this._lastHash = e), i;
        }
        calculateItemsHash(t) {
          return t.reduce((t, e) => t + e.index, "");
        }
        constructor(...t) {
          super(...t), (this._lastHash = "");
        }
      }
      var x = (function (t) {
          return (t[(t.MarginPerLetter = 12)] = "MarginPerLetter"), t;
        })({}),
        F = i(344759),
        O = i(270238);
      const R = (0, f.getLogger)("Chart.MiniChart"),
        V = { value: "12M", type: S.TimeFrameType.PeriodBack },
        B = { top: 0.01, bottom: 0.01 },
        E = {
          chartType: r.ChartType.Area,
          lineWidth: 2,
          priceLineVisible: !1,
          crosshairMarkerVisible: !1,
          lastValueVisible: !1,
          scaleMargins: B,
        },
        z = {
          lineWidth: 2,
          priceLineVisible: !1,
          crosshairMarkerVisible: !1,
          lastValueVisible: !1,
          scaleMargins: B,
        },
        L = { chartType: r.ChartType.Baseline },
        N = { priceLineVisible: !1, lastValueVisible: !1, scaleMargins: B },
        H = { priceLineVisible: !1, lastValueVisible: !1, scaleMargins: B },
        U = { scaleMargins: B },
        W = {
          chartType: r.ChartType.PrettyHistogram,
          scaleMargins: B,
          radius: 2,
          widthPercent: 50,
        },
        A = {
          visible: !1,
          color: g.colorsPalette["color-tv-blue-500"],
          lineWidth: 1,
          length: 9,
          lastValueVisible: !1,
          priceLineVisible: !1,
        },
        q = {
          spinner: {
            visible: !1,
            width: 4,
            color: g.colorsPalette["color-brand"],
          },
          fade: { visible: !1, waitForStudyPlots: o.None },
          clearDataOnSymbolChange: !0,
          clearDataOnTimeframeChange: !0,
        },
        Y = {
          onFirstData: null,
          description: "",
          showDescription: !0,
          noDataTimeout: 15e3,
          timeframe: { visible: !1, value: V },
          chartOptions: {
            minWidth: 0,
            minHeight: 0,
            chart: {
              grid: {
                horzLines: { color: "rgba(120, 123, 134, 0.1)", visible: !1 },
                vertLines: { color: "#ffffff", visible: !1 },
              },
              crosshair: {
                horzLine: {
                  visible: !1,
                  style: 3,
                  width: 1,
                  labelVisible: !1,
                  labelBackgroundColor: "#0f0f0f",
                },
                vertLine: {
                  visible: !1,
                  style: 3,
                  width: 1,
                  labelVisible: !1,
                  labelBackgroundColor: "#0f0f0f",
                },
              },
              layout: {
                fontFamily: "Trebuchet MS",
                fontSize: 10,
                textColor: "#83888D",
                background: { type: s.ColorType.Solid, color: "transparent" },
                attributionLogo: !1,
              },
              rightPriceScale: {
                visible: !0,
                borderVisible: !1,
                entireTextOnly: !0,
                mode: s.PriceScaleMode.Normal,
              },
              leftPriceScale: {
                visible: !1,
                borderVisible: !1,
                entireTextOnly: !0,
                mode: s.PriceScaleMode.Normal,
              },
              timeScale: {
                borderVisible: !1,
                timeVisible: !0,
                secondsVisible: !1,
                lockVisibleTimeRangeOnResize: !0,
              },
              handleScale: !1,
              handleScroll: !1,
            },
            series: E,
            volume: k.defaultVolumeOptions,
            ma: A,
            loading: q,
          },
        },
        G = {
          "1y": { value: "12M", type: S.TimeFrameType.PeriodBack },
          "5y": { value: "60M", type: S.TimeFrameType.PeriodBack },
          max: { value: "ALL", type: S.TimeFrameType.PeriodBack },
        };
      function j(t, e, i, a, r, n) {
        return (
          !!t.dayAndTimeTickMarkFixEnabled &&
          (a === s.TickMarkType.Time
            ? (function (t) {
                return (
                  t.type !== S.TimeFrameType.TimeRange &&
                  (t.value.endsWith("M") ||
                    t.value.endsWith("Y") ||
                    ["YTD", "ALL"].includes(t.value))
                );
              })(e)
            : !(!r || !n || a <= n) &&
              a === s.TickMarkType.DayOfMonth &&
              (i.getMonth() !== r.getMonth() ||
                i.getFullYear() !== r.getFullYear()))
        );
      }
      const $ = (() => {
        let t = null,
          e = null,
          i = null;
        return (a, r, n, o, h, l) => {
          const c = {},
            d = new Date(1e3 * o);
          (i && (0, S.areEqualTimeFrames)(i, n)) ||
            ((t = null), (e = null), (i = n));
          let m = !1;
          if (r) {
            m = (r.suppressFn ?? j)(r, n, d, h, t, e);
          }
          if (((t = d), (e = h), m)) return "";
          switch (h) {
            case s.TickMarkType.Year:
              r?.hideYearsTickMarks
                ? (c.month = "short")
                : (c.year = "numeric");
              break;
            case s.TickMarkType.Month:
              c.month = "short";
              break;
            case s.TickMarkType.DayOfMonth:
              c.day = "numeric";
              break;
            case s.TickMarkType.Time:
              (c.hour12 = a === p.TimeHoursFormat.TwelveHours),
                (c.hour = "2-digit"),
                (c.minute = "2-digit");
              break;
            case s.TickMarkType.TimeWithSeconds:
              (c.hour12 = a === p.TimeHoursFormat.TwelveHours),
                (c.hour = "2-digit"),
                (c.minute = "2-digit"),
                (c.second = "2-digit");
          }
          const u = new Date(
            d.getUTCFullYear(),
            d.getUTCMonth(),
            d.getUTCDate(),
            d.getUTCHours(),
            d.getUTCMinutes(),
            d.getUTCSeconds(),
            d.getUTCMilliseconds()
          );
          return (t = d), (e = h), u.toLocaleString(l, c);
        };
      })();
      function J(t, e) {
        return t.series().seriesOrder() - e.series().seriesOrder();
      }
      "undefined" != typeof window &&
        (window.miniChartInstances = window.miniChartInstances || {});
      const K = "undefined" != typeof window ? window.miniChartInstances : {};
      let Q = 0;
      const X = {
        acquire: () =>
          (0, T.ownership)(new y.ChartSession((0, D.getChartApi)(), !0)),
      };
      class Z {
        screenshotCanvas() {
          return this.widget().takeScreenshot();
        }
        screenshotSymbolInfo() {
          return this.mainPlot().symbolInfo();
        }
        screenshotSymbol() {
          return this.mainPlot().symbol();
        }
        container() {
          return this._container;
        }
        innerContainer() {
          return this._innerContainer;
        }
        getChartContainer() {
          return this._container
            ? (0, w.getChartLayoutContainer)(this._container)
            : null;
        }
        width() {
          return this._width.readonly();
        }
        height() {
          return this._height.readonly();
        }
        status() {
          return this._status.readonly();
        }
        seriesDataSource() {
          return this._mainPlot.seriesDataSource();
        }
        supportRealtimeUpdates() {
          return Boolean(this._options.doNotDisconnectOnDataReady);
        }
        connect(t) {
          const e = (0, S.convertTimeFrameToStr)(this._timeframe.value());
          (0, m.assert)(
            !this._options.cache?.loadData(e),
            "Chart can not to connect if there is an existing cache data"
          ),
            "function" == typeof t && (this._connectCallback = t),
            this._clearReconnectionTimeout(),
            this.connected() ||
              (this._showLoading(),
              this._mainPlot.clearData(),
              this._studyPlots.forEach((t) => t.clearData()),
              this._chartSession ||
                ((this._chartSession = this._chartSessionProvider.acquire()),
                this._chartSession
                  .criticalError()
                  .subscribe(this, this._onChartSessionCriticalError),
                (this._chartSessionConnected = this._chartSession
                  .isConnected()
                  .spawn()),
                this._chartSessionConnected.subscribe(
                  this._onChartSessionIsConnectedChanged.bind(this),
                  { callWithLast: !0 }
                )),
              this._chartSession.connect(this._onData.bind(this)),
              this._chartSession.isConnected().value() && this._requestData(),
              this._clearNoDataTimeout(),
              this._createNoDataTimeout());
        }
        disconnect() {
          this._studyPlots.forEach((t) => t.disconnect()),
            this._mainPlot.disconnect(),
            this._chartSession?.disconnect(),
            (this._connected = !1),
            this._clearNoDataTimeout();
        }
        connected() {
          return Boolean(
            this._connected &&
              this._chartSession &&
              this._chartSession.isConnected().value()
          );
        }
        setTimeframe(t, e, i) {
          const s = this._timeframe.value();
          let a = t;
          const r = a.type === S.TimeFrameType.PeriodBack ? G[a.value] : void 0;
          void 0 !== r && (a = r);
          let n = null;
          if (
            ((n = this._timeframeIsAvailable(a)
              ? a
              : this._timeframeIsAvailable(V)
              ? V
              : this._timeFrameOptions.find((t) =>
                  this._timeframeIsAvailable(t.value)
                )?.value ?? null),
            null === n)
          )
            return void R.logWarn(
              "The current timeframe is not compatible with the timeframes from timeFrameOptions"
            );
          this._options.timeframe.currentTimeframeCallback &&
            this._options.timeframe.currentTimeframeCallback(n),
            this._timeframe.setValue(n);
          const o = (0, S.convertTimeFrameToStr)(this._timeframe.value());
          (this._activeRange = o),
            this._timeframeView &&
              this._options.timeframe.visible &&
              this._timeframeView.update({ activeRange: this._activeRange });
          const h = this._options.cache?.loadData(o);
          if (h)
            return (
              (this._cachedTickmarks = h.tickmarks),
              (this._tickmarks = new Map(this._cachedTickmarks)),
              this._createTooltipDateFormatter(),
              void this._mainPlot.reloadCache(h.mainPlot)
            );
          this._cachedTickmarks.size &&
            ((this._cachedTickmarks = new Map()),
            (this._tickmarks = new Map()),
            this._mainPlot.reloadCache(),
            this._mainPlot.clearData()),
            ((!e && s !== this._timeframe.value()) || i) &&
              this._requestDataOnTimeframeChange();
        }
        chartSession() {
          return (0, m.ensureNotNull)(this._chartSession);
        }
        widget() {
          return this._widget;
        }
        timeframe() {
          return this._timeframe.readonly();
        }
        setTimeFrameOptions(t, e) {
          if (t === this._timeFrameOptions) return;
          const i = this._timeFrameOptions.find((t) =>
              (0, S.areEqualTimeFrames)(t.value, this.timeframe().value())
            ),
            s = i?.targetResolution ?? null;
          (this._timeFrameOptions = t),
            e
              ? this.setTimeframe(e)
              : this.resolution() !== s && this._requestDataOnTimeframeChange(),
            this._initTimeframesRenderer();
        }
        timeFrameOptions() {
          return this._timeFrameOptions;
        }
        resolution() {
          const t = this._timeFrameOptions.find((t) =>
            (0, S.areEqualTimeFrames)(t.value, this.timeframe().value())
          );
          return (0, m.ensureDefined)(t?.targetResolution);
        }
        changeSymbol(t, e) {
          void 0 !== e && this._updateSeriesOptions(e),
            this._options.chartOptions.loading.clearDataOnSymbolChange &&
              (this._mainPlot.clearData(),
              this._mainPlot.deleteView(),
              this._studyPlots.forEach((t) => t.clearData()),
              this._studyPlots.forEach((t) => t.deleteView()));
          this._mainPlot.setSymbol(t, this._options.chartOptions.series) &&
            (this.connected() &&
              (this._mainPlot.requestData(),
              this._studyPlots.forEach((t) => t.requestData())),
            this.connect());
        }
        updateSeriesOptions(t) {
          (this._atomicUpdateIsGoing = !0),
            this._updateSeriesOptions(t),
            this._mainPlot.updateSeriesOptions(t),
            this._updateSeriesUpDownColors(),
            (this._atomicUpdateIsGoing = !1);
        }
        getSeriesOptions() {
          return this._mainPlot.currentSeriesOptions();
        }
        updateVolumeOptions(t) {
          this._mainPlot.updateVolumeOptions(t);
        }
        showMessage(t) {
          this._hideLoading(),
            this._mainPlot.deleteView(),
            this._studyPlots.forEach((t) => t.deleteView()),
            this._textWatermark.applyOptions?.({
              visible: !0,
              lines: [{ color: "#83888D", text: t, fontSize: 12 }],
            });
        }
        hideMessage() {
          this._textWatermark.applyOptions?.({ visible: !1, lines: [] });
        }
        from() {
          const t = this._timeFrameOptions.find((t) =>
            (0, S.areEqualTimeFrames)(t.value, this.timeframe().value())
          );
          return [t?.from];
        }
        enable(t) {
          this.connect(t);
        }
        disable() {
          this.disconnect();
        }
        destroy() {
          this._boundTimeScaleSizeChangedHandler &&
            (this._widget
              .timeScale()
              .unsubscribeSizeChange(this._boundTimeScaleSizeChangedHandler),
            (this._boundTimeScaleSizeChangedHandler = void 0)),
            this._parentResizeObserver.disconnect(),
            this.disconnect(),
            this._widget.remove(),
            this._mainPlot.symbolResolved().unsubscribeAll(null),
            this._mainPlot.timeFrameInvalidated().unsubscribeAll(this),
            this._mainPlot.destroy(),
            this._studyPlots.forEach((t) => t.destroy()),
            this._timeframeView?.destroy(),
            this._chartSessionConnected?.destroy(),
            this._chartSession?.criticalError().unsubscribeAll(this),
            this._chartSession?.release(),
            delete K[this._innerContainer.dataset.miniChartId],
            this._innerContainer.remove(),
            (this._isDestroyed = !0);
        }
        updateAvailableTimeframes() {
          this._mainPlot.symbolInfo()
            ? (this._timeframeView &&
                this._options.timeframe.visible &&
                this._timeframeView.update({
                  ranges: this._getAvailableTimeFrames(),
                }),
              this.setTimeframe(this._timeframe.value()))
            : R.logWarn(
                "Updating available resolutions without full symbol info"
              );
        }
        mainPlot() {
          return this._mainPlot;
        }
        fitContent() {
          this._mainPlot.fitContent();
        }
        hasStudyPlots() {
          return this._studyPlots.length > 0;
        }
        studyPlots() {
          return (
            this._studyPlotsOrderInvalidated &&
              (this._studyPlots.sort(J),
              (this._studyPlotsOrderInvalidated = !1)),
            this._studyPlots
          );
        }
        addStudyPlot(t) {
          return (
            this._addStudyPlot(t),
            {
              noData: t.noData(),
              status: t.status(),
              remove: () => {
                this._removeStudyPlot(t);
              },
              symbol: () => t.symbol(),
              extendedSymbol: () => t.extendedSymbol(),
              options: () => t.currentSeriesOptions(),
            }
          );
        }
        indexToTime(t) {
          const e = this._tickmarks.size
            ? this._tickmarks
            : this._cachedTickmarks;
          return e.get(t)?.time ?? null;
        }
        subscribeCrosshairMove(t) {
          const e = (e) => {
            this._atomicUpdateIsGoing || t(e);
          };
          this._crosshairMoveHandlers.set(t, e),
            this._widget.subscribeCrosshairMove(e);
        }
        unsubscribeCrosshairMove(t) {
          const e = this._crosshairMoveHandlers.get(t);
          e &&
            (this._crosshairMoveHandlers.delete(t),
            this._widget.unsubscribeCrosshairMove(e));
        }
        upDownColors(t) {
          return (
            this._seriesUpDownColors[t] || this._updateSeriesUpDownColorsImpl(),
            this._seriesUpDownColors[t] ?? null
          );
        }
        dateTimeFormatter() {
          return this._dateTimeFormatter;
        }
        isDWMResolution() {
          return this._isDWMResolution;
        }
        updateChartRightMarginAccordingToTitles() {
          const t = this.mainPlot().currentSeriesOptions().horzMargins?.rightPx;
          if (t) this.mainPlot().updateHorzMargins({ rightPx: t });
          else {
            const t = [this.mainPlot(), ...this._studyPlots];
            let e = 0;
            for (const i of t)
              for (const t of i.titles()) e = Math.max(e, t.length);
            this.mainPlot().updateHorzMargins({
              rightPx: x.MarginPerLetter * e,
            });
          }
          this.mainPlot().fitContent();
        }
        activeRange() {
          return this._activeRange;
        }
        timeScaleSizeChanged() {
          return this._timeScaleSizeChanged;
        }
        _getChartPlotClass() {
          return F.MiniChartPlot;
        }
        _createMainPlot(t) {
          const e = (0, S.convertTimeFrameToStr)(this._timeframe.value()),
            i = new (this._getChartPlotClass())(
              this,
              this._options.chartOptions.series,
              this._options.chartOptions.volume,
              () => this._studyPlots,
              this._options.mainPlotOptions,
              this._options.cache?.loadData(e)?.mainPlot
            );
          return (
            i.setSymbol(t),
            i.symbolResolved().subscribe(this, this._onSymbolResolved),
            i
              .timeFrameInvalidated()
              .subscribe(this, this._onTimeFrameInvalidated),
            i.status().subscribe(this._onPlotStatusChanged),
            i
          );
        }
        _onPlotsDataReady() {
          "function" == typeof this._options.onFirstData &&
            (this._options.onFirstData(), (this._options.onFirstData = null)),
            this._hideLoading(),
            this.hideMessage(),
            this._clearNoDataTimeout(),
            this._options.doNotDisconnectOnDataReady || this.disconnect(),
            this._createReconnectionTimeout(),
            this._saveCache();
        }
        _addStudyPlot(t) {
          this._studyPlots.push(t),
            t.status().subscribe(this._onPlotStatusChanged),
            this.connected() ? t.requestData() : this.connect(),
            t.forcePercentageMode() &&
              this._mainPlot.switchToPercentageScaleMode(),
            this._updateStatus(),
            (this._studyPlotsOrderInvalidated = !0);
        }
        _removeStudyPlot(t) {
          const e = this._studyPlots.indexOf(t);
          (0, m.assert)(-1 !== e),
            this._studyPlots.splice(e, 1),
            t.status().unsubscribe(this._onPlotStatusChanged),
            t.deleteView(),
            t.clearData(),
            t.destroy(),
            this._autoRestoreOriginalScaleMode() &&
              this._studyPlots.every((t) => !t.forcePercentageMode()) &&
              this._mainPlot.restoreOriginalScaleMode(),
            (this._studyPlotsOrderInvalidated = !0),
            this._updateStatus();
        }
        _autoRestoreOriginalScaleMode() {
          return !0;
        }
        _updateSeriesUpDownColors() {
          this._seriesUpDownColors = {};
        }
        _updateSeriesUpDownColorsImpl() {
          const t = this._options.chartOptions.series,
            e = this._mainPlot.series().options();
          switch (t.chartType) {
            case r.ChartType.Candlesticks:
              const i = e;
              this._seriesUpDownColors.Candlestick = {
                up:
                  t.borderUpColor ?? t.upColor ?? i.borderUpColor ?? i.upColor,
                down:
                  t.borderDownColor ??
                  t.downColor ??
                  i.borderDownColor ??
                  i.downColor,
              };
              break;
            case r.ChartType.Bars:
              const s = e;
              this._seriesUpDownColors.Bar = {
                up: t.upColor ?? s.upColor,
                down: t.downColor ?? s.downColor,
              };
              break;
            case r.ChartType.Histogram:
              const a = e;
              this._seriesUpDownColors.Histogram = {
                up: t.upColor ?? t.color ?? a.color,
                down: t.downColor ?? t.color ?? a.color,
              };
          }
        }
        _updateSeriesOptions(t) {
          this._options.chartOptions.series = (function (t) {
            let e;
            switch (t.chartType ?? r.ChartType.Area) {
              case r.ChartType.Bars:
                e = N;
                break;
              case r.ChartType.Candlesticks:
                e = H;
                break;
              case r.ChartType.Area:
                e = E;
                break;
              case r.ChartType.Line:
                e = z;
                break;
              case r.ChartType.Histogram:
                e = U;
                break;
              case r.ChartType.PrettyHistogram:
                e = W;
                break;
              case r.ChartType.Baseline:
                e = L;
            }
            return (0, a.default)({}, e, t);
          })(t);
        }
        _saveCache() {
          const { cache: t } = this._options;
          if (!t) return;
          const e = this._prepareCacheData(),
            i = (0, S.convertTimeFrameToStr)(this._timeframe.value());
          e && (t.saveData(i, e), (this._cachedTickmarks = e.tickmarks));
        }
        _prepareCacheData() {
          if (!this._tickmarks.size) return null;
          const t = this._mainPlot.cacheData();
          return t
            ? { mainPlot: t, tickmarks: new Map(this._tickmarks) }
            : null;
        }
        _onMainPlotDataError() {
          this._hideLoading(),
            this.showMessage(h.t(null, void 0, i(87238))),
            this._clearNoDataTimeout(),
            this.disconnect();
        }
        _onMainPlotSymbolResolvingError() {
          this._hideLoading(),
            this.showMessage(h.t(null, void 0, i(146807))),
            this._clearNoDataTimeout(),
            this.disconnect();
        }
        _createReconnectionTimeout() {
          if (this._options.doNotDisconnectOnDataReady) return;
          const t = this._options.updateTimeout;
          void 0 !== t &&
            t > 0 &&
            (this._updateTimerId = setTimeout(() => {
              (this._updateTimerId = null),
                this.connected() ? this._requestData() : this.connect();
            }, t));
        }
        _clearReconnectionTimeout() {
          null !== this._updateTimerId &&
            (clearInterval(this._updateTimerId), (this._updateTimerId = null));
        }
        _createNoDataTimeout() {
          const t = this._options.noDataTimeout;
          void 0 !== t &&
            t > 0 &&
            (this._loadErrorTimeout = setTimeout(() => {
              this.showMessage(h.t(null, void 0, i(146807))),
                "function" == typeof this._options.onFirstData &&
                  (this._options.onFirstData(),
                  (this._options.onFirstData = null));
            }, t));
        }
        _clearNoDataTimeout() {
          this._loadErrorTimeout &&
            (clearTimeout(this._loadErrorTimeout),
            (this._loadErrorTimeout = null));
        }
        _initTimeframesRenderer() {
          if (!this._options.timeframe.visible) return;
          {
            const t = this._timeFrameOptions.length < 2;
            if (
              (this._timeframeView?.update({ hidden: t }),
              (
                this._elTimeframe ?? this._options.timeframe.container
              )?.classList.toggle(O.hidden, t),
              t)
            )
              return;
          }
          if (this._elTimeframe) return;
          this._options.timeframe.container
            ? (this._elTimeframe = this._options.timeframe.container)
            : ((this._elTimeframe = document.createElement("div")),
              this._container.appendChild(this._elTimeframe));
          const t = (t, e) => {
            const i = this._timeFrameOptions.length < 2,
              s = (0, m.ensureNotNull)(this._elTimeframe);
            s.classList.toggle(O.hidden, i),
              (this._timeframeView = new t.TimeFrameViewRenderer(s, {
                name: "minichart_timeframe",
                activeRange: this._activeRange,
                ranges: this._getAvailableTimeFrames(),
                onSelectRange: (t) => {
                  this.setTimeframe({
                    value: t,
                    type: S.TimeFrameType.PeriodBack,
                  });
                },
                size: this._options.timeframe.size,
                hidden: i,
                theme: e,
              }));
          };
          Promise.all([i.e(24827), i.e(84435), i.e(91951), i.e(44162)])
            .then(i.bind(i, 107232))
            .then((e) => {
              (
                this._options.timeframe.getTheme ||
                (() => Promise.resolve(void 0))
              )().then((i) => t(e, i));
            });
        }
        _createLegend() {
          this._options.legend &&
            this._options.legend.visible &&
            Promise.all([
              i.e(16350),
              i.e(76281),
              i.e(98373),
              i.e(91951),
              i.e(1646),
            ])
              .then(i.bind(i, 148460))
              .then((t) =>
                t.createLegend(
                  this._options.legend.container,
                  this._options.legend.items
                )
              );
        }
        _getAvailableTimeFrames() {
          const t = [];
          for (const e of this._timeFrameOptions) {
            if (!this._timeframeIsAvailable(e.value)) continue;
            const i = (0, S.convertTimeFrameToStr)(e.value);
            t.push({ value: i, text: e.text, description: e.description });
          }
          return t;
        }
        _timeframeIsAvailable(t) {
          const e = this._timeFrameOptions.find((e) =>
            (0, S.areEqualTimeFrames)(e.value, t)
          );
          if (!e) return !1;
          const i = this.mainPlot().symbolInfo();
          if (!i || i.pro_name !== this._mainPlot.symbol()) return !0;
          if (i.has_intraday) return !0;
          return !b.Interval.parse(e.targetResolution).isIntraday();
        }
        _onChartSessionIsConnectedChanged(t) {
          t !== this._connected &&
            (t
              ? ((this._connected = !0),
                "function" == typeof this._connectCallback &&
                  this._connectCallback(),
                this._chartSession?.switchTimezone("Etc/UTC"),
                this._requestData())
              : ((this._connected = !1),
                this._mainPlot.disconnect(),
                this._studyPlots.forEach((t) => t.disconnect())));
        }
        _onChartSessionCriticalError() {
          this._connected = !1;
        }
        _createTooltipDateFormatter() {
          const t = b.Interval.parse(this.resolution());
          let e;
          (this._isDWMResolution = t.isDWM()),
            this._widget
              .timeScale()
              .applyOptions({
                timeVisible: !this._isDWMResolution,
                secondsVisible: t.isSeconds(),
              });
          const {
            dateFormat: i = "dd MMM 'yy",
            timeHoursFormat: s = p.TimeHoursFormat.TwentyFourHours,
            suppressTickMarks: a,
          } = this._options.chartOptions;
          (e = this._isDWMResolution
            ? new u.DateFormatter(i)
            : new _.DateTimeFormatter({
                dateFormat: i,
                timeFormat: (0, v.getTimeFormatForInterval)(t, s),
              })),
            (this._dateTimeFormatter = e),
            this._widget.applyOptions({
              localization: {
                timeFormatter: (t) => e.format(new Date(1e3 * t)),
              },
              timeScale: {
                tickMarkFormatter: $.bind(null, s, a, this._timeframe.value()),
              },
            }),
            this._widget.applyOptions({
              timeScale: {
                timeVisible: !b.Interval.parse(
                  this._mainPlot.resolution()
                ).isDWM(),
              },
            });
        }
        _requestData() {
          this._createTooltipDateFormatter(),
            this._clearReconnectionTimeout(),
            this._mainPlot.requestData(),
            this._studyPlots.forEach((t) => t.requestData());
        }
        _onData(t) {
          if (this._mainPlot.isConnected())
            switch (t.method) {
              case "timescale_update": {
                const e = t.params;
                if (e.clear) {
                  this._tickmarks.clear(), this._mainPlot.clearSourceData();
                  for (const t of this._studyPlots) t.clearSourceData();
                }
                if (e.index_diff.length > 0) {
                  this._mainPlot.moveSourceData(e.index_diff);
                  for (const t of this._studyPlots)
                    t.moveSourceData(e.index_diff);
                }
                const i = e.marks;
                let s = 1 / 0,
                  a = -1 / 0;
                for (const t of i)
                  this._tickmarks.has(t.index) ||
                    ((s = Math.min(s, t.index)), (a = Math.max(a, t.index))),
                    this._tickmarks.set(t.index, t);
                Number.isFinite(s) && this._mainPlot.onTickmarksAdded(s, a),
                  this._saveCache();
                break;
              }
            }
        }
        _onSymbolResolved() {
          this.updateAvailableTimeframes(), this._initTimeframesRenderer();
        }
        _onTimeFrameInvalidated() {
          (this._activeRange = void 0),
            this._timeframeView?.update({ activeRange: void 0 });
        }
        _showLoading() {
          if (this._isLoading) return;
          this.hideMessage();
          const t = this._options.chartOptions.loading;
          t.spinner.visible &&
            (null === this._spinner &&
              (this._spinner = new P.Spinner("mini").setStyle({
                color: t.spinner.color,
                width: t.spinner.width.toString(),
                zIndex: "10",
              })),
            this._spinner.spin(this._innerContainer)),
            t.fade.visible && this._innerContainer.classList.add(O.fade),
            (this._isLoading = !0);
        }
        _hideLoading() {
          this._isLoading &&
            (this._spinner && this._spinner.stop(), (this._isLoading = !1));
        }
        _requestDataOnTimeframeChange() {
          this._options.chartOptions.loading.clearDataOnTimeframeChange &&
            (this._studyPlots.forEach((t) => t.clearData()),
            this._studyPlots.forEach((t) => t.deleteView()),
            this.mainPlot().clearData(),
            this.mainPlot().deleteView()),
            this.connected() ? this._requestData() : this.connect();
        }
        _updateStatus() {
          const t = [
              this._mainPlot.status().value(),
              ...this._studyPlots.map((t) => t.status().value()),
            ],
            e = t.every((t) => t !== n.PlotStatus.Initialized)
              ? t[0] === n.PlotStatus.DataReady
                ? "ready"
                : "error"
              : "loading";
          this._status.setValue(e);
        }
        _timeScaleSizeChangedHandler(t, e) {
          this._timeScaleSizeChanged.fire(t, e);
        }
        constructor(t, e, i, r) {
          (this._isDestroyed = !1),
            (this._studyPlotsOrderInvalidated = !0),
            (this._studyPlots = []),
            (this._elTimeframe = null),
            (this._timeframeView = null),
            (this._tickmarks = new Map()),
            (this._cachedTickmarks = new Map()),
            (this._chartSession = null),
            (this._chartSessionConnected = null),
            (this._connectCallback = null),
            (this._connected = !1),
            (this._loadErrorTimeout = null),
            (this._isLoading = !1),
            (this._spinner = null),
            (this._crosshairMoveHandlers = new Map()),
            (this._atomicUpdateIsGoing = !1),
            (this._seriesUpDownColors = {}),
            (this._isDWMResolution = !1),
            (this._updateTimerId = null),
            (this._width = new l.WatchedValue(0)),
            (this._height = new l.WatchedValue(0)),
            (this._status = new l.WatchedValue("loading")),
            (this._timeScaleSizeChanged = new d.Delegate()),
            (this._onPlotStatusChanged = () => {
              const t = this._mainPlot.status().value(),
                e = this._studyPlots.every(
                  (t) => t.status().value() !== n.PlotStatus.Initialized
                ),
                i =
                  e ||
                  this._studyPlots.some(
                    (t) =>
                      t.status().value() !== n.PlotStatus.Initialized &&
                      t.isVisible().value()
                  );
              switch (t) {
                case n.PlotStatus.DataReady:
                  e && this._onPlotsDataReady();
                  break;
                case n.PlotStatus.SeriesError:
                  this._onMainPlotDataError();
                  break;
                case n.PlotStatus.SymbolError:
                  this._onMainPlotSymbolResolvingError();
              }
              const s = this._options.chartOptions.loading.fade;
              if (s.visible)
                switch (this._cachedTickmarks.size > 0 || t) {
                  case n.PlotStatus.Initialized:
                    this._innerContainer.classList.add(O.fade);
                    break;
                  case n.PlotStatus.SeriesError:
                  case n.PlotStatus.SymbolError:
                  case !0:
                    this._innerContainer.classList.remove(O.fade);
                    break;
                  case n.PlotStatus.DataReady:
                    (s.waitForStudyPlots === o.None ||
                      (s.waitForStudyPlots === o.All && e) ||
                      (s.waitForStudyPlots === o.Any && i)) &&
                      this._innerContainer.classList.remove(O.fade);
                }
              this._updateStatus();
            }),
            (this._timeFrameOptions =
              i?.timeframe?.options ?? (0, C.getMiniTimeFrameOptions)()),
            (this._options = (0, a.default)({}, Y, i)),
            (this._chartSessionProvider = r ?? X),
            (this._container = e),
            (this._innerContainer = e.ownerDocument.createElement("div")),
            (this._innerContainer.style.width = "100%"),
            (this._innerContainer.style.height = "100%"),
            (this._innerContainer.style.minHeight = "inherit"),
            (this._innerContainer.style.minWidth = "inherit"),
            e.appendChild(this._innerContainer),
            (this._widget = (0, s.createChartEx)(
              this._innerContainer,
              new I(),
              { ...this._options.chartOptions?.chart, autoSize: !0 }
            ));
          const h = this._widget.panes()[0];
          (this._textWatermark = (0, s.createTextWatermark)(h, {
            visible: !1,
          })),
            (this._timeframe = new c.WatchedObject(
              this._options.timeframe.value
            )),
            (this._mainPlot = this._createMainPlot(t)),
            this.setTimeframe(this._timeframe.value(), !0);
          const m = (0, S.convertTimeFrameToStr)(this._timeframe.value()),
            u = this._options.cache?.loadData(m);
          u
            ? ((this._cachedTickmarks = u.tickmarks),
              (this._tickmarks = new Map(this._cachedTickmarks)),
              this._createTooltipDateFormatter())
            : this.connect(),
            (this._parentResizeObserver = new ResizeObserver((t) => {
              this._mainPlot.fitContent();
              for (const e of t)
                if (e.contentBoxSize) {
                  const t = e.contentBoxSize[0];
                  this._width.setValue(t.inlineSize),
                    this._height.setValue(t.blockSize);
                }
            })),
            this._parentResizeObserver.observe(e);
          const _ = e.getBoundingClientRect();
          this._width.setValue(_.width),
            this._height.setValue(_.height),
            this._createLegend(),
            this._updateSeriesUpDownColors(),
            (this._boundTimeScaleSizeChangedHandler =
              this._timeScaleSizeChangedHandler.bind(this)),
            this._widget
              .timeScale()
              .subscribeSizeChange(this._boundTimeScaleSizeChangedHandler),
            (Q += 1),
            (this._innerContainer.dataset.miniChartId = `${Q}`),
            (K[this._innerContainer.dataset.miniChartId] = this);
        }
      }
    },
    655044(t, e, i) {
      "use strict";
      function s(t) {
        return (
          t
            .getElementsByTagName("div")
            .item(0)
            ?.getElementsByTagName("table")
            .item(0)
            ?.getElementsByTagName("tr")
            .item(0)
            ?.getElementsByTagName("td")
            .item(1)
            ?.getElementsByTagName("div")
            .item(0) ?? null
        );
      }
      i.d(e, { getChartLayoutContainer: () => s });
    },
    344759(t, e, i) {
      "use strict";
      i.d(e, { MiniChartPlot: () => m });
      var s = i(740162),
        a = i(511538),
        r = i(246823),
        n = (function (t) {
          return (
            (t.Default = "default"),
            (t.FullSingleSession = "full_single_session"),
            t
          );
        })({}),
        o = i(208345),
        h = i(382044),
        l = i(652258),
        c = i(548903),
        d = i(106529);
      class m extends d.MiniChartPlotBase {
        destroy() {
          this._seriesDataSource?.destroy(), super.destroy();
        }
        updateHorzMargins(t) {
          (this._horzMargins = (0, s.default)(this._horzMargins, t)),
            this._miniChart.fitContent();
        }
        reloadCache(t) {
          (this._cache = t),
            t
              ? this._loadCache(t)
              : ((this._minBarIndex = null),
                (this._maxBarIndex = null),
                (this._cachedData = null),
                this._onData().then(() => {
                  this.fitContent();
                }));
        }
        requestData() {
          const t = this._getSeriesDataSource();
          this._status.setValue(r.PlotStatus.Initialized),
            this._noData.setValue(null),
            t.modifySeries(
              this.extendedSymbol(),
              (0, l.getServerInterval)(this.resolution()),
              this._miniChart.timeframe().value()
            ),
            t.isStarted() || t.start();
        }
        clearSourceData() {
          this._seriesDataSource?.clearData(),
            this._studyPlots().forEach((t) => t.clearSourceData());
        }
        moveSourceData(t) {
          this._seriesDataSource?.moveData(t);
          let e = !1,
            i = !1;
          for (const { old: s, new: a } of t)
            e || this._minBarIndex !== s || ((this._minBarIndex = a), (e = !0)),
              i ||
                this._maxBarIndex !== s ||
                ((this._maxBarIndex = a), (i = !0));
        }
        onTickmarksAdded(t, e) {
          const i = this.maxBarIndex();
          this._isLastSessionInterval.value() &&
            null !== i &&
            i >= t &&
            i <= e &&
            (this.updateData(!1, !0), this.fitContent());
        }
        disconnect() {
          this._seriesDataSource?.stop();
        }
        isConnected() {
          return Boolean(this._seriesDataSource?.isStarted());
        }
        clearData() {
          if (
            (super.clearData(),
            (this._minBarIndex = null),
            (this._maxBarIndex = null),
            null !== this._seriesDataSource &&
              (this._seriesDataSource.stop(), this.clearSourceData()),
            this._cache)
          ) {
            const {
              minBarIndex: t,
              maxBarIndex: e,
              symbolInfo: i,
            } = this._cache;
            (this._minBarIndex = t),
              (this._maxBarIndex = e),
              i &&
                ((this._symbolInfo = i),
                this._symbolInfoWV.setValue(i),
                this._initBarBuilder(i).then(() => {
                  this._isDestroyed.value() ||
                    this._onData().then(() => {
                      this.fitContent();
                    });
                }));
          }
        }
        seriesDataSource() {
          return this._getSeriesDataSource();
        }
        firstBar() {
          return (0, d.isTimePointIndex)(this._minBarIndex)
            ? this._bars().search(this._minBarIndex)
            : this._bars().first();
        }
        lastBar() {
          return (0, d.isTimePointIndex)(this._maxBarIndex)
            ? this._bars().search(
                this._maxBarIndex,
                o.PlotRowSearchMode.NearestLeft
              )
            : this._bars().last();
        }
        cacheData() {
          const t = this._seriesDataSource?.data()?.clone(),
            e = this._symbolInfo,
            i = this._minBarIndex,
            s = this._maxBarIndex;
          return t && null !== e && null !== i && null !== s
            ? { data: t, symbolInfo: e, minBarIndex: i, maxBarIndex: s }
            : null;
        }
        fitContent() {
          if (
            null === this._dataLengthInfo ||
            0 === this._dataLengthInfo.history
          )
            return;
          const {
              history: t,
              realtime: e,
              whitespaces: i,
              lastBarTime: s,
              fixLeftEdgeUntil: a = 0,
            } = this._dataLengthInfo,
            r = this._miniChart.widget(),
            n = r.paneSize().width;
          if (0 === n) return;
          const {
            leftLogical: o,
            rightLogical: h,
            leftPx: l,
            rightPx: c,
          } = this._horzMargins;
          let d =
              this._fitContentLeftIndex() - o - (null === s || a >= s ? 0 : e),
            m = Math.max(d, Math.max(0, t - 1) + h + i + e);
          if (0 !== l) {
            d -= l / ((n - l) / (m - d + 1));
          }
          if (0 !== c) {
            m += c / ((n - c) / (m - d + 1));
          }
          if (((m = Math.max(d, m)), m - d < 1)) {
            const t = (1 - (m - d)) / 2;
            (d -= t), (m += t);
          }
          r.timeScale().setVisibleLogicalRange({ from: d, to: m }),
            r.timeScale().applyOptions({ lockVisibleTimeRangeOnResize: !0 });
        }
        _fitContentLeftIndex() {
          return 0;
        }
        _updateSeriesOptions(t) {
          super._updateSeriesOptions(t),
            t.horzMargins && this.updateHorzMargins(t.horzMargins);
        }
        _isMainPlot() {
          return !0;
        }
        _dataUpdated(t, e, i) {
          if (
            (super._dataUpdated(t, e, i),
            !this._isLastSessionInterval.value() ||
              !this._miniChart.supportRealtimeUpdates() ||
              !i)
          )
            return;
          const s = i.lastBarSession;
          (s !== a.SessionPhase.Pre &&
            s !== a.SessionPhase.Post &&
            s !== a.SessionPhase.Night) ||
            e.lastBarSession !== a.SessionPhase.Regular ||
            Promise.resolve().then(() => {
              this._miniChart.setTimeframe(
                this._miniChart.timeframe().value(),
                !1,
                !0
              );
            });
        }
        _onChartStyleChanged() {
          super._onChartStyleChanged(),
            this._studyPlots().forEach((t) =>
              t.updateSeriesOptions({
                chartType: this._currentSeriesOptions.chartType,
              })
            );
        }
        _beforeDataReady() {
          super._beforeDataReady(),
            this._studyPlots().forEach((t) => t.deleteView());
        }
        _getSeriesDataSource() {
          if (null === this._seriesDataSource) {
            const t = this._currentSeriesOptions.initialRequestOptions,
              e = (this._seriesDataSource = new c.SeriesDataSource(
                this.chartSession(),
                "s",
                t
              )),
              i = e.dataEvents();
            i.symbolResolved().subscribe(this, this._onSymbolResolved),
              i
                .symbolNotPermitted()
                .subscribe(this, this._onSymbolNotPermitted),
              i
                .symbolGroupNotPermitted()
                .subscribe(this, this._onSymbolGroupNotPermitted),
              i
                .intradaySpreadNotPermitted()
                .subscribe(this, this._onIntradaySpreadNotPermitted),
              i.symbolInvalid().subscribe(this, this._onSymbolInvalid),
              i.symbolError().subscribe(this, this._onSymbolError),
              i
                .intradayExchangeNotPermitted()
                .subscribe(this, this._onResolutionOrExchangeNotPermittedError),
              i
                .customIntervalNotPermitted()
                .subscribe(this, this._onResolutionOrExchangeNotPermittedError),
              i.completed().subscribe(this, this._onDataCompleted),
              i.seriesError().subscribe(this, this._onDataError),
              i.seriesTimeFrame().subscribe(this, this._onTimeFrame),
              i.dataUpdated().subscribe(this, this._onDataInternal),
              i
                .created()
                .subscribe(
                  null,
                  () =>
                    performance.mark("RFD", { detail: "Request first data" }),
                  !0
                ),
              i
                .created()
                .subscribe(null, () =>
                  e.setFutureTickmarksMode(n.FullSingleSession)
                ),
              i.dataUpdated().subscribe(
                null,
                () => {
                  performance.mark("FDR", { detail: "First data response" }),
                    performance.measure("Response idle", "RFD", "FDR");
                },
                !0
              );
          }
          return this._seriesDataSource;
        }
        _bars() {
          return this._cachedData
            ? this._cachedData.seriesData.bars()
            : this._seriesDataSource?.data().bars() ?? new h.PlotList();
        }
        _onTimeFrame(t, e) {
          this._cachedData ||
            ((this._minBarIndex = t), (this._maxBarIndex = e)),
            this.updateData(!1),
            this._studyPlots().forEach((t) => t.updateData(!1, !0));
        }
        _onDataCompleted() {
          this._cachedData && (this._cachedData = null),
            this.updateData(!1, !0),
            super._onDataCompleted(),
            this.fitContent();
        }
        _onDataInternal(t, e, i) {
          this._onData(e ? void 0 : i?.index);
        }
        async _loadCache(t) {
          const { data: e, symbolInfo: i, minBarIndex: s, maxBarIndex: a } = t;
          (this._minBarIndex = s),
            (this._maxBarIndex = a),
            (this._cachedData = {
              symbol: this.extendedSymbol(),
              resolution: this.resolution(),
              timeFrame: this._miniChart.timeframe().value(),
              seriesData: e,
            }),
            (this._symbolInfo = i),
            this._symbolInfoWV.setValue(i);
          const n = await this._initBarBuilder(i);
          !this._isDestroyed.value() &&
            this._symbolInfo &&
            (this._symbolInfo !== i && n.update(this._symbolInfo),
            await this._onData(),
            this._status.setValue(r.PlotStatus.DataReady),
            this.fitContent());
        }
        constructor(t, e, i, a, r, n) {
          super(t, e, i, r),
            (this._seriesDataSource = null),
            (this._cachedData = null),
            (this._studyPlots = a),
            (this._options = r),
            (this._horzMargins = (0, s.default)(
              {},
              d.seriesHorzMarginsDefaults,
              e.horzMargins
            )),
            n && this._loadCache(n);
        }
      }
    },
    775303(t, e, i) {
      "use strict";
      i.d(e, { PrettyHistogramSeries: () => r });
      const s = {
        ...i(678312).customSeriesDefaultOptions,
        color: "#D63864",
        widthPercent: 50,
        radius: 4,
      };
      class a {
        draw(t, e) {
          t.useBitmapCoordinateSpace((t) => this._drawImpl(t, e));
        }
        update(t, e) {
          (this._data = t), (this._options = e);
        }
        _drawImpl(t, e) {
          if (
            null === this._data ||
            0 === this._data.bars.length ||
            null === this._data.visibleRange ||
            null === this._options
          )
            return;
          const i = this._options,
            s = this._data.bars.map((s) => ({
              x: s.x * t.horizontalPixelRatio,
              value: e(s.originalData.value) ?? NaN,
              color: s.barColor ?? i.color,
            })),
            a = e(0) ?? 0,
            r = t.context;
          let n = null;
          r.beginPath();
          const o = Math.max(
              1,
              Math.round(
                0.01 *
                  i.widthPercent *
                  this._data.barSpacing *
                  t.horizontalPixelRatio
              )
            ),
            h = Math.floor(i.radius * t.horizontalPixelRatio);
          s
            .slice(this._data.visibleRange.from, this._data.visibleRange.to + 1)
            .forEach((e) => {
              const i = e.color;
              null !== n && n !== i && (r.fill(), r.beginPath()),
                (r.fillStyle = i);
              const s = (function (t, e, i) {
                  const s = Math.round(i * t),
                    a = Math.round(i * e);
                  return {
                    position: Math.min(s, a),
                    length: Math.abs(a - s) + 1,
                  };
                })(a, e.value, t.verticalPixelRatio),
                l = Math.floor(Math.min(h, o / 2, Math.abs(s.length))),
                c = Math.round(e.x - o / 2);
              r.roundRect(
                c,
                s.position,
                o,
                s.length,
                e.value < a ? [l, l, 0, 0] : [0, 0, l, l]
              ),
                (n = i);
            }),
            r.fill();
        }
        constructor() {
          (this._data = null), (this._options = null);
        }
      }
      class r {
        priceValueBuilder(t) {
          return [t.value];
        }
        isWhitespace(t) {
          return void 0 === t.value;
        }
        renderer() {
          return this._renderer;
        }
        update(t, e) {
          this._renderer.update(t, e);
        }
        defaultOptions() {
          return s;
        }
        constructor() {
          this._renderer = new a();
        }
      }
    },
    246823(t, e, i) {
      "use strict";
      i.d(e, { PlotStatus: () => s });
      var s = (function (t) {
        return (
          (t[(t.Initialized = 0)] = "Initialized"),
          (t[(t.SymbolError = 1)] = "SymbolError"),
          (t[(t.SeriesError = 2)] = "SeriesError"),
          (t[(t.DataReady = 3)] = "DataReady"),
          t
        );
      })({});
    },
  },
]);
